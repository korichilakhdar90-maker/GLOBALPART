# GlobalPart

A global B2B partnership platform: company discovery, KYB verification & trust scoring, secure
deal rooms, AI-assisted matchmaking, market intelligence, a sourced trade-signal dashboard, and
free trade-education content (the Academy) — in 11 languages.

Monetization surfaces (each gated behind Stripe, safe to run with billing unconfigured — see
`server/.env.example`):
- **Verified Trust Badge** ($100/mo, `server/src/routes/trustBadge.routes.ts`) — required before a
  KYB submission can be approved; registration/search stay free.
- **Deal completion fee** (~1%, `server/src/routes/deals.routes.ts`) — a GlobalPart service fee on
  completed deals, *not* custody of trade funds (see the `DealFee` model comment in
  `server/prisma/schema.prisma` for the legal boundary this respects).
- **White-label licensing** (`server/src/routes/tenants.routes.ts`, `src/lib/tenantBranding.tsx`) —
  annual license for chambers of commerce to re-skin the platform via `?partner=<slug>`.

## Structure

```
/                 React 19 + TypeScript + Tailwind frontend (Vite)
/server           Node.js + Express + PostgreSQL production API (see server/README.md)
```

## Quick start

**Frontend only (demo mode, no backend, no setup):**
```bash
npm install
npm run dev
```
The app runs fully with mock/local data — this is how it's shipped by default. Pages that show
generated/sample data display a "Sample Data" banner so it's never mistaken for real traction.

**Frontend + real backend:**
```bash
# 1. Start the API (see server/README.md for full setup)
cd server && cp .env.example .env && npm install
docker compose up -d postgres
npx prisma migrate dev --name init && npm run seed && npm run dev

# 2. Point the frontend at it
cd ..
echo "VITE_API_URL=http://localhost:4000" > .env
npm run dev
```

## Deployment

- **Frontend**: any static host (Vercel, Netlify, Cloudflare Pages). `vercel.json` (SPA rewrites +
  long-lived cache headers for hashed assets + baseline security headers) and `public/_redirects`
  are already set up.
- **Backend**: see `server/README.md` — Docker image included, deploys to Railway/Render/Fly/etc.
  Includes a read-through in-process cache (`server/src/lib/cache.ts`, swap for Redis via
  `REDIS_URL` when running multiple instances) and graceful shutdown for zero-downtime deploys.

## What's real vs. mocked

By default (no `VITE_API_URL` set), the frontend uses `localStorage` for everything — this is
a fully functional demo/preview mode with **zero backend dependency**, unchanged from the
original build. Setting `VITE_API_URL` switches the app to the real backend in `/server`
(real database, real auth, real AI, real file storage). See `server/README.md` section 3 for
exactly which features are production-ready out of the box vs. which need your own
third-party accounts (Stripe, Resend, AWS S3, a KYB verification provider) or, for escrow and
compliance certifications, external legal/regulatory processes that no codebase can shortcut.
