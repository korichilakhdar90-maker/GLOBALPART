import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  build: {
    target: "es2020",
    sourcemap: false,
    rollupOptions: {
      output: {
        // Split heavy, rarely-changing vendor code from app code so browsers
        // can cache it independently across deploys.
        manualChunks: {
          "vendor-react": ["react", "react-dom", "react-router-dom"],
          // Icon set used across nearly every component. Pulling it out
          // means a change to app code doesn't invalidate the cached
          // icons, and vice versa.
          "vendor-icons": ["lucide-react"],
          // The English dictionary (~82KB of source) is statically
          // imported by i18n.ts as the guaranteed fallback for missing
          // keys, so unlike the other 14 languages it can't be lazy.
          // Splitting it out doesn't reduce total bytes, but it lets the
          // browser fetch it in parallel with app code on HTTP/2 and
          // cache it separately from code that changes more often.
          "i18n-en": ["./src/i18n-data/en.ts"],
        },
      },
    },
  },
});
