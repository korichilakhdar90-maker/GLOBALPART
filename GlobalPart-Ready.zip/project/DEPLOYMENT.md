# Deployment Guide

## 🔴 Do this first — nothing else in this guide works until you do

**The Prisma migration history is out of date.** `prisma/migrations/` currently
ends at `20260809160000` (the "Tender Trust Desk" era of this schema) and does
**not** include a migration for anything added since then:

- `AccountCategory` / role-based access (Individual, Enterprise, Government)
- The full Government pathway (`GovernmentPersonnel`, `SovereignFrameworkAcceptance`,
  FSC/PSC fields on `KybSubmission`)
- `Notification`, `AdminAuditEvent`
- GDPR models (`ConsentRecord`, `ErasureRequest`)
- Claimable Profiles (`Company.profileStatus`, `claimedByUserId`, etc.)
- `FeedbackEntry`
- Brute-force lockout fields (`failedLoginAttempts`, `lockedUntil`)

This isn't a bug to fix in code — it's because every development session on
this project so far has run in a sandboxed environment with **no network
access to Prisma's engine binaries** (documented repeatedly throughout this
project's history), so `prisma migrate dev` could never actually be run to
generate the missing migration file.

**You (or whoever has a real network connection) must run this once, against
a real Postgres database, before anything below will work:**

```bash
cd server
npx prisma migrate dev --name sync_full_schema
git add prisma/migrations
git commit -m "Add missing migration for RBAC, Government pathway, GDPR, notifications, claimable profiles"
```

Do this against a scratch/dev database, review the generated SQL, then commit
it. Once that migration file exists in `prisma/migrations/`, everything else
in this guide — CI, Docker, the seed script, production deploys — works as
described.

---

## Two deployment paths

### Path A — Vercel (frontend) + a managed Postgres

1. Push this repo to GitHub.
2. Import it into Vercel. `vercel.json` is already configured for the Vite
   SPA build.
3. Deploy the `server/` API separately (Vercel serverless functions aren't a
   great fit for a long-running Express app with WebSocket-adjacent needs
   like this one) — Railway, Render, Fly.io, or Scaleway's own App
   Platform/Serverless Containers all work with the `server/Dockerfile`
   as-is.
4. Provision Postgres (Neon, Supabase's Postgres, Scaleway Managed Database
   for PostgreSQL, or any standard Postgres 14+).
5. Set every variable in `server/.env.example` on your hosting provider —
   at minimum `DATABASE_URL`, `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`,
   `APP_URL`, and `EMAIL_PROVIDER=resend` + `RESEND_API_KEY` for real email
   delivery (it defaults to `console`, which only logs emails, never sends
   them — see the startup warning this prints).
6. Run `npx prisma migrate deploy` against production once, from CI or
   manually.

### Path B — Fully self-hosted (Scaleway, T-Systems, any Docker host)

```bash
cp server/.env.example server/.env   # fill in real values
docker compose up -d
docker compose exec api npx prisma migrate deploy
docker compose exec api npm run seed   # optional — see note on seed data below
```

`docker-compose.yml` provisions Postgres alongside the API in one stack. The
frontend is a static build (`npm run build` → `dist/`) meant to be served by
a CDN/nginx/Vercel, not bundled into this compose file as a long-running
container.

---

## CI/CD (`.github/workflows/deploy.yml`)

Runs on every push/PR to `main`:
- **Frontend job**: typecheck + production build.
- **Backend job**: typecheck, `prisma migrate deploy` against a real
  ephemeral Postgres service container, unit tests, and — for the first
  time anywhere in this project's history — the **actual execution** of
  `tests/e2e/kyb-flow*.test.ts` against a live database, since GitHub's
  runners have the network access this project's dev sandbox never did.
- **Migration-check job**: fails the build if `schema.prisma` and
  `prisma/migrations/` have drifted apart, so the gap described above can
  never silently reappear once fixed.

This workflow does not deploy anywhere by itself yet — wire the final
`deploy` step to whichever host you choose in Path A or B above once you've
picked one; the checks above are what should gate that deploy.

---

## About the seed script's data

`prisma/seed.ts` seeds **clearly synthetic, illustrative data** (the same
procedurally-generated company set used in the frontend's demo mode) — not
real companies. This is a deliberate choice, not a missing feature: inventing
"realistic-looking" company records and presenting them as genuine businesses
on a trust-verification platform would misrepresent them, exactly the
principle documented in `docs/compliance/README.md` and applied consistently
throughout this project. For real company data, use
`server/prisma/scripts/importCompanies.ts` with an actual licensed data
source — see `server/prisma/scripts/README.md`.
