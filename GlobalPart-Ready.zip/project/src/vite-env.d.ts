/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL of the real GlobalPart API server. Omit to run in local demo mode. */
  readonly VITE_API_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

