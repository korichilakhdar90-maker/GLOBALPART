import type { ApiCompany } from "./adaptApiCompany";

// Base URL of the real GlobalPart API server (see /server). When this is
// not set, the app runs in local demo mode: all data lives in
// localStorage and no network calls are made. This means the existing
// preview/demo behavior keeps working unchanged with zero configuration,
// while deployments that set VITE_API_URL get the real backend.
export const API_URL = import.meta.env.VITE_API_URL as string | undefined;

export const isBackendConfigured = Boolean(API_URL);

let accessToken: string | null = null;
export function setAccessToken(token: string | null) {
  accessToken = token;
}
export function getAccessToken() {
  return accessToken;
}

class ApiRequestError extends Error {
  constructor(public status: number, message: string, public code?: string) {
    super(message);
  }
}

/**
 * The three account-policy gates (accountPolicy.ts on the backend) return a
 * stable `code` alongside their error message. Registering a listener here
 * means ANY api call anywhere in the app -- not just the couple of routes
 * we explicitly wired -- automatically surfaces the right modal the moment
 * the backend says a sensitive action is blocked. context.tsx registers
 * itself as the listener once, on mount.
 */
type AccountPolicyErrorCode = "EMAIL_VERIFICATION_REQUIRED" | "TWO_FACTOR_SETUP_REQUIRED" | "ACCOUNT_PENDING_APPROVAL";
let accountPolicyListener: ((code: AccountPolicyErrorCode, message: string) => void) | null = null;
export function onAccountPolicyError(listener: typeof accountPolicyListener) {
  accountPolicyListener = listener;
}

async function request<T>(path: string, options: RequestInit = {}, retry = true): Promise<T> {
  if (!API_URL) throw new Error("API_URL is not configured");

  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    credentials: "include", // send the httpOnly refresh-token cookie
    headers: {
      ...(options.body && !(options.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...options.headers,
    },
  });

  // Access token expired — try exactly one silent refresh, then retry the request.
  if (res.status === 401 && retry && path !== "/api/auth/refresh") {
    const refreshed = await tryRefresh();
    if (refreshed) return request<T>(path, options, false);
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    const code = body.code as AccountPolicyErrorCode | undefined;
    if (res.status === 403 && code && accountPolicyListener) {
      accountPolicyListener(code, body.error ?? "Action blocked");
    }
    throw new ApiRequestError(res.status, body.error ?? "Request failed", code);
  }

  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

async function tryRefresh(): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/api/auth/refresh`, { method: "POST", credentials: "include" });
    if (!res.ok) return false;
    const data = await res.json();
    setAccessToken(data.accessToken);
    return true;
  } catch {
    return false;
  }
}

export type InviteeType = "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT";
export type InvitationStatus = "PENDING" | "ACCEPTED" | "EXPIRED" | "REVOKED";

export interface Invitation {
  id: string;
  inviteeEmail: string;
  inviteeType: InviteeType;
  status: InvitationStatus;
  createdAt: string;
  expiresAt: string;
  acceptedAt: string | null;
  link: string;
}

export interface MyKybSubmission {
  id: string;
  companyName: string;
  status: "DRAFT" | "PENDING" | "IN_REVIEW" | "APPROVED" | "REJECTED";
  trustScore: number | null;
  rejectionReason: string | null;
  createdAt: string;
  documents: { id: string; fileName: string; mimeType: string; sizeBytes: number; docCategory: string | null; url: string }[];
  personnel: GovernmentPersonnelItem[];
  frameworkAcceptances: { frameworkKey: string; acceptedAt: string }[];
}

export interface GovernmentPersonnelItem {
  id: string;
  fullName: string;
  officialTitle: string;
  userRole: "SOVEREIGN_ADMIN" | "PROCUREMENT_OFFICER" | "ANALYST" | "AUDITOR";
  pscLevel: "CONFIDENTIAL" | "SECRET" | "NATO_SECRET" | "TOP_SECRET";
  pscIssuingAuthority: string;
  pscIssueDate: string;
  pscExpiryDate: string;
}

export interface GovernmentDraft {
  id: string;
  status: string;
  companyName: string;
  countries: string;
  fscLevel: string | null;
  fscIssuingAuthority: string | null;
  securityOfficerName: string | null;
  dataClassificationPolicy: string | null;
  trustScore: number | null;
  personnel: GovernmentPersonnelItem[];
  frameworkAcceptances: { frameworkKey: string; acceptedAt: string }[];
}

export interface ApiUser {
  id: string;
  name: string;
  email: string;
  company: string | null;
  role: "USER" | "ADMIN";
  emailVerified: boolean;
  accountCategory: "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT";
  accountStatus: "ACTIVE" | "PENDING_KYB" | "PENDING_SOVEREIGN_APPROVAL" | "SUSPENDED";
  twoFactorEnabled: boolean;
}

export type LoginResult =
  | { twoFactorRequired: true; pendingToken: string }
  | { twoFactorRequired: false; accessToken: string; user: ApiUser };

export type RegisterResult =
  | { sessionIssued: true; accessToken: string; user: ApiUser }
  | { sessionIssued: false; message: string; user: ApiUser };

export const api = {
  auth: {
    register: (input: { name: string; email: string; password: string; company?: string; accountCategory?: "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT" }) =>
      request<RegisterResult>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    login: (input: { email: string; password: string }) =>
      request<LoginResult>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    verifyLogin2FA: (input: { pendingToken: string; code: string }) =>
      request<{ accessToken: string; user: ApiUser }>("/api/auth/2fa/verify-login", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    logout: () => request<void>("/api/auth/logout", { method: "POST" }),
    me: () => request<ApiUser>("/api/auth/me"),
    forgotPassword: (email: string) =>
      request<{ message: string }>("/api/auth/forgot-password", { method: "POST", body: JSON.stringify({ email }) }),
    resetPassword: (token: string, password: string) =>
      request<{ message: string }>("/api/auth/reset-password", { method: "POST", body: JSON.stringify({ token, password }) }),
    refresh: tryRefresh,
    // Sensitive-action OTP gate (mainly for INDIVIDUAL accounts, but usable by anyone unverified).
    requestOtp: () => request<{ sent: boolean }>("/api/auth/otp/request", { method: "POST", body: JSON.stringify({ purpose: "SENSITIVE_ACTION" }) }),
    verifyOtp: (code: string) =>
      request<{ verified: boolean }>("/api/auth/otp/verify", { method: "POST", body: JSON.stringify({ code, purpose: "SENSITIVE_ACTION" }) }),
    // Mandatory 2FA setup (ENTERPRISE).
    setup2FA: () => request<{ secret: string; otpAuthUrl: string; qrCodeDataUrl: string }>("/api/auth/2fa/setup", { method: "POST" }),
    enable2FA: (code: string) => request<{ twoFactorEnabled: boolean }>("/api/auth/2fa/enable", { method: "POST", body: JSON.stringify({ code }) }),
    disable2FA: () => request<{ twoFactorEnabled: boolean }>("/api/auth/2fa/disable", { method: "POST" }),
  },
  companies: {
    list: (params: {
      search?: string;
      industry?: string;
      countryCodes?: string;
      region?: string;
      minTrust?: number;
      verifiedOnly?: boolean;
      page?: number;
      perPage?: number;
    }) => {
      const qs = new URLSearchParams(
        Object.entries(params).filter(([, v]) => v !== undefined && v !== "" && v !== false) as [string, string][]
      );
      return request<{ items: ApiCompany[]; total: number; page: number; totalPages: number }>(`/api/companies?${qs}`);
    },
    get: (id: string) => request<ApiCompany>(`/api/companies/${id}`),
    claim: (id: string) =>
      request<{ companyId: string; claimed: boolean; nextStep: string }>(`/api/companies/${id}/claim`, { method: "POST" }),
  },
  favorites: {
    list: () => request<ApiCompany[]>("/api/favorites"),
    add: (companyId: string) => request<void>(`/api/favorites/${companyId}`, { method: "POST" }),
    remove: (companyId: string) => request<void>(`/api/favorites/${companyId}`, { method: "DELETE" }),
  },
  waitlist: {
    join: (input: { email: string; company?: string; country?: string; note?: string }) =>
      request<{ waitlisted: boolean; alreadyRegistered: boolean }>("/api/waitlist", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    count: () => request<{ count: number }>("/api/waitlist/count"),
  },
  feedback: {
    submit: (input: { email?: string; liked?: string; issues?: string; suggestions?: string }) =>
      request<{ received: boolean }>("/api/feedback", { method: "POST", body: JSON.stringify(input) }),
  },
  invitations: {
    create: (input: { inviteeEmail: string; inviteeType: InviteeType }) =>
      request<Invitation>("/api/invitations", { method: "POST", body: JSON.stringify(input) }),
    list: () => request<{ invitations: Invitation[]; creditBalanceCents: number }>("/api/invitations"),
    revoke: (id: string) => request<void>(`/api/invitations/${id}`, { method: "DELETE" }),
    accept: (token: string) => request<Invitation>(`/api/invitations/${token}/accept`, { method: "POST" }),
    preview: (token: string) =>
      request<{ inviterName: string; inviteeEmail: string; inviteeType: InviteeType; status: InvitationStatus; expiresAt: string }>(
        `/api/invitations/${token}/preview`
      ),
  },
  tradeSignals: {
    list: (params: { category?: string; countryCode?: string; page?: number; perPage?: number } = {}) => {
      const qs = new URLSearchParams();
      if (params.category) qs.set("category", params.category);
      if (params.countryCode) qs.set("countryCode", params.countryCode);
      if (params.page) qs.set("page", String(params.page));
      if (params.perPage) qs.set("perPage", String(params.perPage));
      const suffix = qs.toString() ? `?${qs.toString()}` : "";
      return request<{
        items: {
          id: string; title: string; category: string; countryCode: string | null;
          value: number; unit: string; trend: string | null;
          sourceName: string; sourceUrl: string; asOf: string;
        }[];
        total: number; page: number; perPage: number; totalPages: number;
      }>(`/api/trade-signals${suffix}`);
    },
  },
  trustBadge: {
    status: () => request<{ active: boolean; subscription: { status: string; currentPeriodEnd: string | null } | null }>("/api/trust-badge/status"),
    checkout: () => request<{ url: string }>("/api/trust-badge/checkout", { method: "POST" }),
  },
  tenants: {
    bySlug: (slug: string) =>
      request<{ name: string; slug: string; logoUrl: string | null; primaryColor: string | null; licenseStatus: string }>(
        `/api/tenants/by-slug/${encodeURIComponent(slug)}`
      ),
    adminList: () =>
      request<{ id: string; name: string; slug: string; logoUrl: string | null; primaryColor: string | null; contactEmail: string; licenseStatus: string }[]>(
        "/api/tenants"
      ),
    create: (input: { name: string; slug: string; contactEmail: string; logoUrl?: string; primaryColor?: string }) =>
      request<unknown>("/api/tenants", { method: "POST", body: JSON.stringify(input) }),
    checkout: (id: string) => request<{ url: string }>(`/api/tenants/${id}/checkout`, { method: "POST" }),
  },
  kyb: {
    submit: (formData: FormData) => request<unknown>("/api/kyb", { method: "POST", body: formData }),
    mine: () => request<MyKybSubmission[]>("/api/kyb/mine"),
    adminList: (status?: string) => request<unknown[]>(`/api/kyb${status ? `?status=${status}` : ""}`),
    assign: (id: string) => request<unknown>(`/api/kyb/${id}/assign`, { method: "POST" }),
    review: (
      id: string,
      body: {
        status: "APPROVED" | "REJECTED";
        reviewNotes?: string;
        rejectionReason?: string;
        bankAccountVerified?: boolean;
        physicalAddressConfirmed?: boolean;
        financialAuditCompleted?: boolean;
        certificationsVerified?: boolean;
        pepScreeningStatus?: "NOT_STARTED" | "PENDING" | "CLEAR" | "FLAGGED";
        pepScreeningNotes?: string;
        diplomaticVerificationCompleted?: boolean;
        diplomaticVerificationNotes?: string;
        fscValidated?: boolean;
        pscAllValidated?: boolean;
      }
    ) => request<unknown>(`/api/kyb/${id}/review`, { method: "PATCH", body: JSON.stringify(body) }),
  },
  deals: {
    list: () => request<unknown[]>("/api/deals"),
    get: (id: string) => request<unknown>(`/api/deals/${id}`),
    create: (input: { title: string; sellerId: string; buyerCompanyId?: string; sellerCompanyId?: string; valueUsd?: number }) =>
      request<unknown>("/api/deals", { method: "POST", body: JSON.stringify(input) }),
    sendMessage: (id: string, body: string) =>
      request<unknown>(`/api/deals/${id}/messages`, { method: "POST", body: JSON.stringify({ body }) }),
    uploadDocument: (id: string, file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return request<unknown>(`/api/deals/${id}/documents`, { method: "POST", body: fd });
    },
    updateStage: (id: string, stage: string) =>
      request<unknown>(`/api/deals/${id}/stage`, { method: "PATCH", body: JSON.stringify({ stage }) }),
    fees: (id: string) =>
      request<{ id: string; amountCents: number; currency: string; feeRateBps: number; status: string; payerId: string; createdAt: string }[]>(
        `/api/deals/${id}/fees`
      ),
    payFee: (id: string, feeId: string) =>
      request<{ url: string }>(`/api/deals/${id}/fees/${feeId}/checkout`, { method: "POST" }),
  },
  admin: {
    stats: () =>
      request<{ userCount: number; companyCount: number; pendingKyb: number; activeDeals: number; subscriptions: { tier: string; _count: number }[] }>(
        "/api/admin/stats"
      ),
    users: () => request<unknown[]>("/api/admin/users"),
    auditLog: (filters?: { entityType?: string; action?: string; adminId?: string; sort?: "asc" | "desc" }) => {
      const params = new URLSearchParams(filters as Record<string, string>).toString();
      return request<
        { id: string; adminId: string; admin: { id: string; name: string; email: string }; action: string; entityType: string; entityId: string; entityName: string | null; notes: string | null; createdAt: string }[]
      >(`/api/admin/audit-log${params ? `?${params}` : ""}`);
    },
  },
  notifications: {
    list: () => request<{ notifications: { id: string; type: string; title: string; body: string; read: boolean; createdAt: string }[]; unreadCount: number }>("/api/notifications"),
    markRead: (id: string) => request<unknown>(`/api/notifications/${id}/read`, { method: "POST" }),
    markAllRead: () => request<{ ok: boolean }>("/api/notifications/read-all", { method: "POST" }),
  },
  government: {
    createDraft: (formData: FormData) => request<{ id: string; status: string }>("/api/government/draft", { method: "POST", body: formData }),
    saveFsc: (id: string, formData: FormData) => request<{ id: string; step: number; saved: boolean }>(`/api/government/draft/${id}/fsc`, { method: "PATCH", body: formData }),
    addPersonnel: (id: string, body: {
      fullName: string; officialTitle: string; userRole: "SOVEREIGN_ADMIN" | "PROCUREMENT_OFFICER" | "ANALYST" | "AUDITOR";
      pscLevel: "CONFIDENTIAL" | "SECRET" | "NATO_SECRET" | "TOP_SECRET"; pscIssuingAuthority: string; pscIssueDate: string; pscExpiryDate: string;
    }) => request<{ id: string }>(`/api/government/draft/${id}/personnel`, { method: "POST", body: JSON.stringify(body) }),
    removePersonnel: (id: string, personnelId: string) => request<void>(`/api/government/draft/${id}/personnel/${personnelId}`, { method: "DELETE" }),
    saveAccess: (id: string, body: { dataClassificationPolicy: string; securityOfficerName: string; dataSharingConsent: true; accessLoggingConsent: true }) =>
      request<{ id: string; step: number; saved: boolean }>(`/api/government/draft/${id}/access`, { method: "PATCH", body: JSON.stringify(body) }),
    acceptFramework: (id: string, key: string) => request<unknown>(`/api/government/draft/${id}/frameworks/${key}/accept`, { method: "POST" }),
    getDraft: (id: string) => request<GovernmentDraft>(`/api/government/draft/${id}`),
    submit: (id: string) => request<unknown>(`/api/government/draft/${id}/submit`, { method: "POST" }),
  },
  ai: {
    status: () => request<{ configured: boolean }>("/api/ai/status"),
    chat: (messages: { role: "user" | "assistant"; content: string }[]) =>
      request<{ reply: string }>("/api/ai/chat", { method: "POST", body: JSON.stringify({ messages }) }),
    recommendations: () =>
      request<{ explanation: string; recommendations: { company: ApiCompany; score: number; reasons: string[] }[] }>(
        "/api/ai/recommendations"
      ),
  },
};
