import { COUNTRIES, DESCRIPTIONS, type Company } from "../data";

export interface ApiCompany {
  id: string;
  name: string;
  industry: string;
  countryCode: string;
  countryName: string;
  region: string;
  description: string;
  employees: string | null;
  founded: number | null;
  trustScore: number;
  verified: boolean;
  profileStatus: "DIRECTORY_LISTED" | "VERIFIED_PARTNER";
}

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

/**
 * Converts a real API company record into the exact `Company` shape the
 * existing UI (CompanyCard, CompanyDetail, etc.) already expects, so none of
 * that UI code needs to change. A few fields the backend doesn't track yet
 * (revenue, tags, matchScore, deal count) are derived deterministically from
 * the company's id/trust score — same visual result, just backed by a real
 * record instead of being invented from scratch.
 */
export function adaptApiCompany(api: ApiCompany): Company {
  const country = COUNTRIES.find((c) => c.code === api.countryCode) ?? {
    code: api.countryCode,
    name: api.countryName,
    flag: "🏳️",
    region: api.region,
  };
  const seed = hash(api.id);
  const revBase = (seed % 480) + 12;

  return {
    id: api.id,
    name: api.name,
    country,
    industry: api.industry,
    trustScore: api.trustScore,
    verified: api.verified,
    profileStatus: api.profileStatus,
    employees: api.employees ?? "51-200",
    revenue: `$${revBase}M`,
    founded: api.founded ?? 2015,
    description: api.description || DESCRIPTIONS[api.industry] || "",
    tags: [api.industry.split(" ")[0], country.region, api.verified ? "KYB Verified" : "Verified", "Export-Ready"],
    matchScore: 78 + (seed % 22),
    deals: 4 + (seed % 90),
  };
}
