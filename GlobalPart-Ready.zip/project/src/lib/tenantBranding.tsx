import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api } from "./api";

// Feature 3 — White-label licensing. A chamber of commerce / industry
// association that has an active license shows up here, keyed by a
// `?partner=<slug>` query param, and the header/footer re-skin themselves
// with that organization's name/logo/color.
//
// Why a query param and not a real subdomain: this codebase has no control
// over DNS/hosting for whatever domain it's deployed to, so wildcard
// subdomain routing (partner.globalpart.io) is a hosting-layer decision
// outside this repo. `?partner=slug` gives the exact same white-label
// behavior today with zero infrastructure changes, and a real deployment
// can later rewrite subdomains to this query param at the edge/CDN layer
// without touching this component.
export type TenantBranding = {
  name: string;
  slug: string;
  logoUrl: string | null;
  primaryColor: string | null;
};

interface TenantContextValue {
  tenant: TenantBranding | null;
  loading: boolean;
}

const TenantContext = createContext<TenantContextValue>({ tenant: null, loading: false });

export function TenantBrandingProvider({ children }: { children: ReactNode }) {
  const [tenant, setTenant] = useState<TenantBranding | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const slug = new URLSearchParams(window.location.search).get("partner");
    if (!slug) return;
    setLoading(true);
    api.tenants
      .bySlug(slug)
      .then((t) => setTenant(t))
      .catch(() => setTenant(null))
      .finally(() => setLoading(false));
  }, []);

  return <TenantContext.Provider value={{ tenant, loading }}>{children}</TenantContext.Provider>;
}

export function useTenantBranding() {
  return useContext(TenantContext);
}
