// Generic, jurisdiction-neutral contract templates offered as a starting
// point for early-stage exporters/importers who can't yet afford a lawyer
// for every first draft. These are deliberately plain and general — real,
// usable boilerplate, not filler text — with an explicit disclaimer that
// they are not a substitute for local legal review before signing.

export const LEGAL_DISCLAIMER =
  "This template is provided for general informational purposes only and does not constitute legal advice. " +
  "Laws governing contracts, confidentiality, and international trade vary by jurisdiction. Have any agreement " +
  "reviewed by a qualified lawyer in the relevant jurisdiction(s) before signing.";

export const NDA_TEMPLATE = `MUTUAL NON-DISCLOSURE AGREEMENT (TEMPLATE)

${LEGAL_DISCLAIMER}

This Mutual Non-Disclosure Agreement ("Agreement") is entered into as of [DATE] between:

Party A: [COMPANY NAME A], with its principal place of business at [ADDRESS A] ("Party A")
Party B: [COMPANY NAME B], with its principal place of business at [ADDRESS B] ("Party B")

(Party A and Party B are each referred to as a "Party" and together as the "Parties")

1. PURPOSE
The Parties wish to explore a potential business relationship related to [DESCRIBE PURPOSE, e.g.
"the supply and distribution of [PRODUCT/SERVICE]"] (the "Purpose"), during which each Party may
disclose certain confidential information to the other.

2. DEFINITION OF CONFIDENTIAL INFORMATION
"Confidential Information" means any non-public information disclosed by one Party (the "Disclosing
Party") to the other (the "Receiving Party"), whether oral, written, or electronic, including but not
limited to: business plans, pricing, supplier and customer information, product specifications,
financial information, and trade secrets, that is designated as confidential or that a reasonable
person would understand to be confidential given the nature of the information and circumstances of
disclosure.

Confidential Information does not include information that: (a) is or becomes publicly available
through no fault of the Receiving Party; (b) was already known to the Receiving Party before
disclosure; (c) is independently developed without use of the Confidential Information; or (d) is
rightfully received from a third party without breach of any confidentiality obligation.

3. OBLIGATIONS OF THE RECEIVING PARTY
The Receiving Party agrees to:
  (a) hold the Confidential Information in strict confidence;
  (b) use it solely for the Purpose;
  (c) not disclose it to any third party without the Disclosing Party's prior written consent, except
      to employees, contractors, or advisors who need to know it for the Purpose and are bound by
      confidentiality obligations at least as protective as this Agreement;
  (d) protect it using at least the same degree of care used to protect its own confidential
      information of similar importance, and no less than reasonable care.

4. TERM
This Agreement is effective as of the date first written above and remains in effect for [X] years,
unless terminated earlier by either Party with [X] days' written notice. Confidentiality obligations
with respect to Confidential Information disclosed during the term survive termination for a period
of [X] years.

5. RETURN OR DESTRUCTION OF INFORMATION
Upon the Disclosing Party's written request, the Receiving Party will promptly return or destroy all
Confidential Information and any copies thereof.

6. NO LICENSE OR OBLIGATION
Nothing in this Agreement obligates either Party to proceed with any transaction, and no license or
other right is granted to either Party except as expressly stated herein.

7. GOVERNING LAW
This Agreement shall be governed by the laws of [JURISDICTION], without regard to its conflict of
laws principles. [Consider specifying a dispute resolution mechanism, e.g. arbitration under a named
institution and seat, particularly for cross-border agreements.]

8. ENTIRE AGREEMENT
This Agreement constitutes the entire agreement between the Parties with respect to its subject
matter and supersedes all prior discussions or agreements on the same subject.

IN WITNESS WHEREOF, the Parties have executed this Agreement as of the date first written above.

Party A: _______________________        Party B: _______________________
Name:                                     Name:
Title:                                    Title:
Date:                                     Date:
`;

export const SHIPPING_CONTRACT_TEMPLATE = `INTERNATIONAL SALE OF GOODS AGREEMENT (TEMPLATE)

${LEGAL_DISCLAIMER}

This Agreement is entered into as of [DATE] between:

Seller: [SELLER COMPANY NAME], [SELLER ADDRESS] ("Seller")
Buyer: [BUYER COMPANY NAME], [BUYER ADDRESS] ("Buyer")

1. GOODS
Seller agrees to sell, and Buyer agrees to purchase, the following goods (the "Goods"):
  Description: [PRODUCT DESCRIPTION, INCLUDING SPECIFICATIONS/GRADE/STANDARD]
  Quantity: [QUANTITY AND UNIT]
  Unit Price: [PRICE PER UNIT AND CURRENCY]
  Total Price: [TOTAL CONTRACT VALUE]

2. INCOTERMS® / DELIVERY TERMS
Delivery shall be on [INCOTERMS RULE, e.g. FOB / CIF / DAP] [NAMED PORT OR PLACE], Incoterms® 2020,
as published by the International Chamber of Commerce. The chosen Incoterms rule determines which
Party is responsible for transport, insurance, and export/import clearance, and at what point risk
transfers from Seller to Buyer — confirm the rule matches the Parties' actual operational
arrangement before signing.

3. PAYMENT TERMS
Payment method: [e.g. Irrevocable Letter of Credit / Escrow / Advance Payment / Open Account]
Payment schedule: [e.g. 30% deposit on order confirmation, 70% on shipment / against documents]
Currency: [CURRENCY]
Late payment: Amounts not paid when due shall accrue interest at [RATE]% per [PERIOD], or the
maximum rate permitted by applicable law, whichever is lower.

4. DELIVERY SCHEDULE
Estimated shipment date: [DATE OR WINDOW]
Estimated delivery date: [DATE OR WINDOW]
Time is [/ is not] of the essence for delivery under this Agreement.

5. INSPECTION AND ACCEPTANCE
Buyer shall have [X] business days after delivery to inspect the Goods and notify Seller in writing
of any non-conformity. Absent timely notice, the Goods shall be deemed accepted. [Consider
specifying a named independent inspection body for higher-value shipments.]

6. WARRANTIES
Seller warrants that the Goods will conform to the agreed specifications and be free from material
defects at the time of delivery. [Add any regulatory/compliance warranties relevant to the goods and
destination market, e.g. safety certifications, country-of-origin documentation.]

7. FORCE MAJEURE
Neither Party is liable for delay or failure to perform caused by events beyond its reasonable
control, including natural disasters, war, port closures, or governmental action, provided the
affected Party gives prompt notice and uses reasonable efforts to mitigate the impact.

8. DISPUTE RESOLUTION
Any dispute arising out of or relating to this Agreement shall first be referred to good-faith
negotiation between the Parties. If unresolved within [X] days, the dispute shall be resolved by
[arbitration under the rules of NAMED INSTITUTION, seat of arbitration: LOCATION / the courts of
JURISDICTION], and this Agreement shall be governed by the laws of [JURISDICTION].

9. ENTIRE AGREEMENT
This Agreement, together with any attached specifications and Incoterms rule referenced above,
constitutes the entire agreement between the Parties regarding the Goods described herein.

IN WITNESS WHEREOF, the Parties have executed this Agreement as of the date first written above.

Seller: _______________________         Buyer: _______________________
Name:                                     Name:
Title:                                    Title:
Date:                                     Date:
`;
