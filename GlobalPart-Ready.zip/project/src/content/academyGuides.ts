// Real, general-knowledge trade guides — the "Global Trade University" free
// content hub (product notes, feature #3). Written as genuinely useful,
// standard trade-practice guidance, not AI-generated filler. English only
// for now; translating long-form articles into all 11 UI languages is a
// separate content project, not a quick i18n-key swap, so this is scoped
// honestly rather than shipped as thin machine-translated copies.

export type AcademyGuide = {
  slug: string;
  title: string;
  summary: string;
  readMinutes: number;
  body: string[]; // paragraphs / list blocks rendered in order
};

export const ACADEMY_GUIDES: AcademyGuide[] = [
  {
    slug: "verify-a-trade-partner",
    title: "How to Verify an International Trade Partner Before You Pay",
    summary:
      "A practical checklist for confirming a supplier or buyer is real and creditworthy before money or goods move.",
    readMinutes: 6,
    body: [
      "Most cross-border fraud isn't sophisticated — it exploits the fact that verifying a foreign company is genuinely harder than verifying a local one. Before you send a deposit or ship goods on credit, work through these checks in order.",
      "1. Confirm legal existence. Ask for the company's official registration number and look it up in the relevant national business registry (many countries publish these online for free). A company that resists sharing this is an immediate red flag.",
      "2. Match the details. Confirm the registered company name, address, and the name of the person you're dealing with all match what's on the registry record. Mismatches are the single most common scam pattern.",
      "3. Verify banking details independently. Never rely solely on bank details sent by email — confirm them by phone through a number you find independently (not one provided in the same email), especially before any wire transfer. Business Email Compromise scams routinely intercept and alter bank details mid-conversation.",
      "4. Check for a real operating history. A website, LinkedIn presence, and reviews from other trading partners are all weak signals individually but meaningful together. Ask for 2–3 references from companies they've traded with before, and actually contact them.",
      "5. Start small. On a first transaction with a new partner, use a smaller order size or a payment structure with milestones (deposit → shipment confirmation → delivery confirmation → balance) rather than paying the full amount upfront.",
      "6. Use a neutral third party for high-value or first-time transactions. An escrow arrangement, a letter of credit, or a documentary collection through banks all reduce the amount of trust you need to extend on faith alone.",
      "None of these steps guarantee safety on their own — but a partner who is unwilling to support any of them is telling you something important before you've risked anything.",
    ],
  },
  {
    slug: "incoterms-explained",
    title: "Incoterms 2020 Explained: Who Pays for What, and When Risk Transfers",
    summary:
      "The most common source of cross-border contract disputes is a misunderstood Incoterms rule. Here's what the main ones actually mean.",
    readMinutes: 7,
    body: [
      "Incoterms® (International Commercial Terms) are a standardized set of three-letter trade terms published by the International Chamber of Commerce (ICC). They answer two questions precisely: who arranges and pays for transport/insurance at each stage, and at what exact point risk of loss or damage passes from seller to buyer. They do not cover payment terms, ownership transfer, or contract remedies — those need separate clauses.",
      "EXW (Ex Works): Seller's only obligation is to make the goods available at their own premises. Buyer handles everything else — export clearance, transport, insurance, import clearance. Cheapest for the seller, most demanding for the buyer.",
      "FOB (Free On Board) — sea/inland waterway only: Seller delivers goods on board the vessel at the named port. Risk transfers once the goods are on board. Buyer arranges and pays for main carriage and insurance from that point.",
      "CIF (Cost, Insurance and Freight) — sea/inland waterway only: Seller pays for transport and minimum insurance to the named destination port, but risk still transfers to the buyer once goods are on board at the origin port — a common point of confusion, since the seller is paying for a leg of the journey the buyer already bears the risk on.",
      "DAP (Delivered At Place): Seller bears all risk and cost until the goods arrive ready for unloading at the named destination — the buyer only handles import clearance and unloading.",
      "DDP (Delivered Duty Paid): Maximum obligation for the seller — they handle transport, export and import clearance, and duties, delivering the goods ready for the buyer to unload. Convenient for the buyer, but sellers should only agree to this if they genuinely understand the destination country's import requirements.",
      "The practical rule: name the exact Incoterms rule, the exact named place, and the Incoterms version (2020) in the contract — e.g. 'CIF Port of Montreal, Incoterms® 2020' — not just 'CIF' on its own. Ambiguity here is the single most common cause of cross-border shipping disputes.",
    ],
  },
  {
    slug: "cross-border-contract-clauses",
    title: "5 Clauses Every Cross-Border Contract Should Have",
    summary:
      "Domestic contract habits don't transfer well across borders. These five clauses close the gaps that cause the most disputes.",
    readMinutes: 5,
    body: [
      "1. Governing law and dispute resolution. Silence on this point means a dispute could be litigated in a jurisdiction neither party expected, under law neither party understands. Name both the governing law and how disputes will be resolved (courts vs. arbitration, and which institution/seat).",
      "2. Language of the contract. If the agreement exists in two languages, state explicitly which version controls in case of conflict. Without this, a translation discrepancy can become the entire dispute.",
      "3. Currency and exchange-rate risk. Specify the currency for pricing and payment, and consider whether either party bears exchange-rate risk between contract signing and payment — especially relevant for longer production/shipping lead times.",
      "4. Force majeure with real specificity. Generic force majeure language is weak. Name the categories of events realistically relevant to the trade lane (port closures, export bans, extreme weather disruption of specific shipping routes) and specify the notice period and consequences (suspension vs. termination).",
      "5. Inspection and acceptance procedure. Define exactly how many days the buyer has to inspect goods after delivery, what happens if goods are rejected (return, replace, or credit), and — for higher-value shipments — whether an independent inspection body's report is binding on both parties.",
      "None of this replaces a lawyer's review, especially for higher-value or first-time trade lanes. But contracts that address these five points explicitly resolve far fewer disputes in expensive ways than contracts that leave them to be assumed.",
    ],
  },
];
