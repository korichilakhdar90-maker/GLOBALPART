import { useEffect, useRef, useState, type ReactNode, type FormEvent } from "react";
import { cn } from "./utils/cn";
import { useApp } from "./context";
import { api, isBackendConfigured } from "./lib/api";
import { useTenantBranding } from "./lib/tenantBranding";

/* Scroll reveal wrapper */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={cn("reveal", visible && "in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* Brand logo mark */
/**
 * `priority` marks the one above-the-fold instance (the header logo) so it
 * loads eagerly; every other instance (footer, auth cards, email-style
 * pages) is below the fold and lazy-loads instead. Explicit width/height
 * are always set to reserve layout space and keep CLS near zero.
 */
export function Logo({ size = 36, priority = false }: { size?: number; priority?: boolean }) {
  const { tenant } = useTenantBranding();
  const loadingProps = priority
    ? ({ loading: "eager", fetchPriority: "high" } as const)
    : ({ loading: "lazy", decoding: "async" } as const);

  if (tenant) {
    return (
      <div className="flex items-center gap-2.5">
        {tenant.logoUrl ? (
          <img
            src={tenant.logoUrl}
            alt={tenant.name}
            width={size}
            height={size}
            {...loadingProps}
            className="rounded-xl object-contain"
            style={{ width: size, height: size }}
          />
        ) : (
          <div
            className="grid shrink-0 place-items-center rounded-xl font-display text-sm font-bold text-white"
            style={{ width: size, height: size, background: tenant.primaryColor ?? "#3b82f6" }}
          >
            {tenant.name.slice(0, 1).toUpperCase()}
          </div>
        )}
        <div className="leading-none">
          <span className="font-display text-[1.05rem] font-bold tracking-tight">{tenant.name}</span>
          <div className="text-[0.6rem] text-[var(--text-muted)]">Powered by GlobalPart</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2.5">
      <img
        src="/images/logo-icon.png"
        alt="GlobalPart"
        width={size}
        height={size}
        {...loadingProps}
        className="shine rounded-xl object-contain"
        style={{ width: size, height: size, filter: "drop-shadow(0 8px 20px rgba(34,211,238,0.35))" }}
      />
      <div className="leading-none">
        <span className="font-display text-[1.18rem] font-bold tracking-tight">
          Global<span className="gradient-text">Part</span>
        </span>
      </div>
    </div>
  );
}

/* Section heading */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center = true,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <div className={cn("max-w-3xl", center && "mx-auto text-center")}>
      {eyebrow && (
        <span className="chip chip-brand mb-4 inline-flex">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan-glow animate-pulse" />
          {eyebrow}
        </span>
      )}
      <h2 className="font-display text-3xl font-bold leading-tight tracking-tight md:text-[2.7rem]">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-4 text-base text-[var(--text-muted)] md:text-lg">{subtitle}</p>
      )}
    </div>
  );
}

/* Honest "this is sample/illustrative data" banner.
   Used on pages that currently render generated demo data (companies,
   deal volume, market intelligence) so visitors and investors never
   mistake it for real, live platform traction. Remove per-page once
   that page is wired to real production data. */
export function SampleDataBanner({ textKey }: { textKey: string }) {
  const { t } = useApp();
  return (
    <div className="sample-data-banner mb-6">
      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
      {t(textKey)}
    </div>
  );
}

/* Real early-access capture form.
   - If a backend is configured (VITE_API_URL set), this actually persists
     the sign-up via POST /api/waitlist and can be reported as a genuine
     traction number later.
   - If no backend is configured yet (e.g. current static preview
     deployment), it falls back to a pre-filled mailto: link instead of
     pretending to "submit" — never shows a fake success state. */
export function WaitlistForm({ source = "website" }: { source?: string }) {
  const { t, toast } = useApp();
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;

    if (!isBackendConfigured) {
      const subject = encodeURIComponent("GlobalPart early access request");
      const body = encodeURIComponent(
        `Email: ${email}\nCompany: ${company || "—"}\nSource: ${source}`
      );
      window.location.href = `mailto:hello@globalpart.io?subject=${subject}&body=${body}`;
      return;
    }

    setStatus("loading");
    try {
      const res = await api.waitlist.join({ email: email.trim(), company: company.trim() || undefined });
      setStatus("done");
      toast(res.alreadyRegistered ? t("waitlist.alreadyIn") : t("waitlist.success"), "success");
    } catch {
      setStatus("idle");
      toast(t("waitlist.error"), "error");
    }
  }

  if (status === "done") {
    return (
      <div className="flex items-center gap-2 rounded-xl border border-emerald-trust/30 bg-emerald-trust/10 px-4 py-3 text-sm font-medium text-emerald-trust">
        {t("waitlist.success")}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2 sm:flex-row">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder={t("waitlist.emailPlaceholder")}
        className="flex-1 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none transition focus:border-cyan-glow/50"
      />
      <input
        type="text"
        value={company}
        onChange={(e) => setCompany(e.target.value)}
        placeholder={t("waitlist.companyPlaceholder")}
        className="flex-1 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none transition focus:border-cyan-glow/50 sm:max-w-[180px]"
      />
      <button type="submit" disabled={status === "loading"} className="btn btn-primary shrink-0 whitespace-nowrap">
        {status === "loading" ? t("waitlist.sending") : t("waitlist.cta")}
      </button>
    </form>
  );
}

/* Trust score ring */
export function TrustRing({ score, size = 56 }: { score: number; size?: number }) {
  const stroke = 5;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  const color = score >= 85 ? "#10b981" : score >= 70 ? "#22d3ee" : "#f6c453";
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--border)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(0.16,1,0.3,1)" }}
        />
      </svg>
      <div className="absolute text-center">
        <span className="font-display text-sm font-bold" style={{ color }}>
          {score}
        </span>
      </div>
    </div>
  );
}

const LOCALE_MAP: Record<string, string> = {
  en: "en-US", zh: "zh-CN", ar: "ar-SA", es: "es-ES", hi: "hi-IN",
  fr: "fr-FR", pt: "pt-PT", ru: "ru-RU", ja: "ja-JP", ko: "ko-KR", de: "de-DE",
};

/* Animated counter */
export function Counter({
  value,
  suffix = "",
  prefix = "",
  decimals = 0,
}: {
  value: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
}) {
  const { lang } = useApp();
  const ref = useRef<HTMLSpanElement>(null);
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        const duration = 1600;
        const start = performance.now();
        const tick = (now: number) => {
          const p = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          setDisplay(value * eased);
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        obs.disconnect();
      }
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, [value]);
  const formatted =
    decimals > 0
      ? display.toFixed(decimals)
      : Math.round(display).toLocaleString(LOCALE_MAP[lang] ?? "en-US");
  return (
    <span ref={ref}>
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
}

/* Decorative glow orbs */
export function Orbs() {
  return (
    <>
      <div className="pointer-events-none absolute left-[-6%] top-[8%] h-72 w-72 rounded-full bg-brand-500/20 blur-3xl animate-aurora" />
      <div className="pointer-events-none absolute right-[-4%] top-[30%] h-80 w-80 rounded-full bg-violet-glow/20 blur-3xl animate-aurora" style={{ animationDelay: "3s" }} />
    </>
  );
}
