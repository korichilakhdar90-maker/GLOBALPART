import { AlertCircle } from "lucide-react";

/**
 * Inline, screen-reader-announced form error (WCAG 2.1 SC 3.3.1, Error
 * Identification).
 *
 * This exists *alongside* the toast, not instead of it. A toast is
 * transient and unreachable once dismissed, so a screen-reader user who
 * tabs back through the form has no way to re-read what went wrong. This
 * message persists next to the field, is announced immediately via
 * `role="alert"`, and is linked to the failing input through
 * `aria-describedby={id}`.
 *
 * Usage:
 *   <FormError id="kyb-error" message={error} />
 *   <input aria-invalid={!!error} aria-describedby={error ? "kyb-error" : undefined} />
 *
 * Renders nothing when there's no message, so `aria-describedby` must be
 * left undefined in that case — pointing at a non-existent id is itself
 * an accessibility defect.
 */
export default function FormError({ id, message }: { id: string; message: string | null }) {
  if (!message) return null;
  return (
    <p
      id={id}
      role="alert"
      className="flex items-start gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300"
    >
      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <span>{message}</span>
    </p>
  );
}
