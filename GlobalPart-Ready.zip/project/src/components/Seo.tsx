import { useEffect } from "react";
import { useApp } from "../context";

const OG_LOCALE: Record<string, string> = {
  en: "en_US", zh: "zh_CN", ar: "ar_AR", es: "es_ES", hi: "hi_IN",
  fr: "fr_FR", pt: "pt_PT", ru: "ru_RU", ja: "ja_JP", ko: "ko_KR", de: "de_DE",
};

/**
 * Lightweight client-side document head manager.
 *
 * Note: this app is a client-rendered SPA (no server-side rendering), so
 * search engine crawlers that don't execute JavaScript will still only see
 * the fallback tags in index.html. For full SEO (unique previews per page,
 * guaranteed crawlability), pair this with server-side rendering or
 * pre-rendering (e.g. Vite SSR, Next.js, or a prerender service) at deploy
 * time. This component still helps: it improves the tab title/description
 * for real browsers, JS-executing crawlers (Googlebot does), and social
 * share tools that re-fetch the URL after render.
 *
 * hreflang alternate tags are intentionally omitted: this app has a single
 * URL per page regardless of language (language is client-side state, not
 * a route), so there are no distinct per-language URLs for hreflang to
 * point between. og:locale is set instead, which is meaningful for a
 * single-URL multilingual page.
 */
export default function Seo({ title, description }: { title: string; description: string }) {
  const { lang } = useApp();

  useEffect(() => {
    const fullTitle = `${title} — GlobalPart`;
    document.title = fullTitle;

    const setMeta = (name: string, content: string, attr: "name" | "property" = "name") => {
      let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    setMeta("description", description);
    setMeta("og:title", fullTitle, "property");
    setMeta("og:description", description, "property");
    setMeta("og:locale", OG_LOCALE[lang] ?? "en_US", "property");
    setMeta("twitter:title", fullTitle);
    setMeta("twitter:description", description);

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", window.location.origin + window.location.pathname);
  }, [title, description, lang]);

  return null;
}
