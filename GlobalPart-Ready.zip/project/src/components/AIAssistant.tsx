import { useEffect, useRef, useState } from "react";
import { Sparkles, X, Send, Bot, ArrowRight } from "lucide-react";
import { useApp } from "../context";
import { cn } from "../utils/cn";
import { api, isBackendConfigured } from "../lib/api";

interface Msg {
  id: number;
  role: "user" | "ai";
  text: string;
  chipTopics?: string[];
}

// Quick-reply chips and the demo-mode canned-reply engine are topic-based
// (not raw-English-text regex matching) so they work correctly in every
// supported language: clicking a chip sends its topic directly, and
// free-typed text is matched against keyword lists compiled across all
// languages, instead of only recognizing English phrasing.
const QUICK_TOPICS = ["findPartners", "pricing", "security", "kyb", "demo"];

const KEYWORD_TOPICS: Record<string, RegExp> = {
  pricing: /price|pricing|cost|plan|subscription|how much|fee|precio|prix|preis|preço|цена|价格|कीमत|価格|가격|السعر|التسعير/i,
  security: /secure|security|encrypt|soc|gdpr|compliance|safe|privacy|seguridad|sécurité|sicherheit|segurança|безопасность|安全|सुरक्षा|セキュリティ|보안|أمان|الأمن/i,
  kyb: /kyb|verify|verification|trust score|document|trust|verificar|vérifi|überprüf|verificaç|провер|验证|सत्यापन|検証|검증|تحقق|التحقق/i,
  findPartners: /partner|find|match|discover|company|companies|supplier|buyer|export|import|socio|partenaire|partner|parceiro|партнер|合作伙伴|साझेदार|パートナー|파트너|شريك|شركاء/i,
  escrow: /escrow|payment|pay|fund|money|deal|contract|sign|signature|custodia|séquestre|treuhand|escrow|эскроу|托管|एस्क्रो|エスクロー|에스크로|ضمان/i,
  demo: /demo|call|talk|sales|contact|salesperson|human|llamada|appel|anruf|chamada|звонок|演示|कॉल|デモ|데모|اتصال|عرض/i,
  greeting: /hello|hi|hey|hola|bonjour|مرحبا|你好|नमस्ते|こんにちは|안녕|здравствуйте|olá|hallo/i,
  thanks: /thank|thanks|شكرا|gracias|merci|danke|obrigado|спасибо|谢谢|धन्यवाद|ありがとう|감사/i,
};

function detectTopic(input: string): string {
  for (const [topic, pattern] of Object.entries(KEYWORD_TOPICS)) {
    if (pattern.test(input)) return topic;
  }
  return "default";
}

function replyForTopic(t: (key: string) => string, topic: string): { text: string; chipTopics?: string[] } {
  switch (topic) {
    case "pricing":
      return { text: t("chat.reply.pricing"), chipTopics: ["pricingRecommend", "demo", "pricingEnterprise"] };
    case "security":
      return { text: t("chat.reply.security"), chipTopics: ["securityView", "kyb", "securitySoc2"] };
    case "kyb":
      return { text: t("chat.reply.kyb"), chipTopics: ["kybStart", "kybWhatIsTrust", "pricing"] };
    case "findPartners":
      return { text: t("chat.reply.findPartners"), chipTopics: ["companiesOpen", "aiMatchmaking", "topMarkets"] };
    case "escrow":
      return { text: t("chat.reply.escrow"), chipTopics: ["dealRoomsOpen", "escrowFees", "security"] };
    case "demo":
      return { text: t("chat.reply.demo"), chipTopics: ["getStartedFree", "demo", "pricing"] };
    case "greeting":
      return { text: t("chat.reply.greeting"), chipTopics: QUICK_TOPICS };
    case "thanks":
      return { text: t("chat.reply.thanks"), chipTopics: ["findPartners", "demo", "getStartedFree"] };
    default:
      return { text: t("chat.reply.default"), chipTopics: QUICK_TOPICS };
  }
}

export default function AIAssistant() {
  const { t, aiMode } = useApp();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ id: idRef.current++, role: "ai", text: t("chat.greeting"), chipTopics: QUICK_TOPICS }]);
    }
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 9e9, behavior: "smooth" });
  }, [messages, typing]);

  /**
   * `topic`, when provided (i.e. the user clicked a translated quick-reply
   * chip), drives the canned reply directly. Free-typed text instead runs
   * through detectTopic()'s multi-language keyword matching. Either way,
   * matching never depends on the UI's current display language.
   */
  const send = (text: string, topic?: string) => {
    if (!text.trim()) return;
    const userMsg: Msg = { id: idRef.current++, role: "user", text };
    const history = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setTyping(true);

    if (isBackendConfigured) {
      api.ai
        .chat(history.map((m) => ({ role: m.role === "ai" ? "assistant" : "user", content: m.text })))
        .then(({ reply }) => {
          setMessages((m) => [...m, { id: idRef.current++, role: "ai", text: reply }]);
        })
        .catch(() => {
          setMessages((m) => [
            ...m,
            { id: idRef.current++, role: "ai", text: t("chat.unreachable") },
          ]);
        })
        .finally(() => setTyping(false));
      return;
    }

    // Demo mode: canned, topic-based replies — fully localized.
    setTimeout(() => {
      const reply = replyForTopic(t, topic ?? detectTopic(text));
      setMessages((m) => [...m, { id: idRef.current++, role: "ai", ...reply }]);
      setTyping(false);
    }, 850 + Math.random() * 500);
  };

  return (
    <>
      {/* Launcher */}
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "fixed bottom-5 end-5 z-50 flex items-center gap-2 rounded-full p-3 text-white shadow-2xl transition-all duration-300",
          "bg-gradient-to-br from-brand-600 to-cyan-glow",
          open ? "scale-90" : "hover:scale-105",
          aiMode && !open && "animate-pulse-ring"
        )}
        style={{ boxShadow: "0 12px 40px -8px rgba(34,211,238,0.6)" }}
        aria-label={open ? t("common.close") : t("chat.title")}
      >
        {open ? <X className="h-6 w-6" /> : <Sparkles className="h-6 w-6" />}
        {!open && (
          <span className="absolute end-0 top-0 h-3 w-3 rounded-full bg-emerald-trust ring-2 ring-[var(--bg)]" />
        )}
      </button>

      {/* Panel */}
      <div
        className={cn(
          "fixed bottom-24 end-5 z-50 w-[calc(100vw-2.5rem)] max-w-[400px] origin-bottom-right transition-all duration-300",
          open ? "scale-100 opacity-100" : "pointer-events-none scale-90 opacity-0"
        )}
      >
        <div className="ring-gradient flex h-[560px] max-h-[75vh] flex-col overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface-solid)] shadow-2xl backdrop-blur-xl">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-[var(--border)] bg-gradient-to-r from-brand-600/20 to-violet-glow/20 p-4">
            <div className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-600 to-cyan-glow">
              <Bot className="h-5 w-5 text-white" />
              <span className="absolute -bottom-0.5 -end-0.5 h-3 w-3 rounded-full bg-emerald-trust ring-2 ring-[var(--surface-solid)]" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-1.5 font-display font-bold">
                {t("chat.title")}
                <span className="chip chip-emerald !py-0 !text-[0.65rem]">{t("ai.chatbot")}</span>
              </div>
              <div className="text-xs text-[var(--text-muted)]">{t("chat.subtitle")}</div>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((m) => (
              <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div className="max-w-[85%]">
                  <div
                    className={cn(
                      "rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                      m.role === "user"
                        ? "rounded-ee-sm bg-brand-600 text-white"
                        : "rounded-es-sm border border-[var(--border)] bg-[var(--surface)]"
                    )}
                  >
                    {m.text}
                  </div>
                  {m.chipTopics && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {m.chipTopics.map((topic) => (
                        <button
                          key={topic}
                          onClick={() => send(t(`chat.chip.${topic}`), topic)}
                          className="chip chip-brand cursor-pointer transition hover:scale-105"
                        >
                          {t(`chat.chip.${topic}`)}
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex justify-start">
                <div className="flex gap-1 rounded-2xl rounded-es-sm border border-[var(--border)] bg-[var(--surface)] px-4 py-3">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="h-2 w-2 rounded-full bg-[var(--text-muted)]"
                      style={{ animation: `float 1s ease-in-out ${i * 0.15}s infinite` }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-center gap-2 border-t border-[var(--border)] p-3"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("chat.placeholder")}
              className="flex-1 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3.5 py-2.5 text-sm outline-none transition focus:border-cyan-glow/50"
            />
            <button
              type="submit"
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-600 to-cyan-glow text-white transition hover:scale-105"
              aria-label={t("chat.send")}
            >
              <Send className="h-4 w-4 flip-x" />
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
