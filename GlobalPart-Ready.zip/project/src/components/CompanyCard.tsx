import { Link } from "react-router-dom";
import { Heart, Star, Building2, TrendingUp, ArrowUpRight, ShieldCheck } from "lucide-react";
import type { Company } from "../data";
import { INDUSTRY_LABEL_KEY } from "../data";
import { useApp } from "../context";
import { cn } from "../utils/cn";
import { TrustRing } from "../ui";

export default function CompanyCard({ company, index = 0 }: { company: Company; index?: number }) {
  const { t, favorites, toggleFavorite, aiMode } = useApp();
  const fav = favorites.includes(company.id);

  return (
    <div
      className="card card-hover group relative flex flex-col p-5"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {aiMode && company.matchScore >= 90 && (
        <div className="absolute -top-2.5 end-4 z-10">
          <span className="chip chip-gold shadow-lg">
            <Star className="h-3 w-3 fill-current" />
            {t("common.aiRecommendation")}
          </span>
        </div>
      )}

      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-600/30 to-violet-glow/20 text-lg font-bold text-cyan-glow ring-1 ring-[var(--border)]">
            {company.name.charAt(0)}
          </div>
          <div className="min-w-0">
            <h3 className="truncate font-display font-semibold leading-tight">{company.name}</h3>
            <div className="mt-0.5 flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
              <span>{company.country.flag}</span>
              <span className="truncate">{company.country.name}</span>
            </div>
          </div>
        </div>
        <TrustRing score={company.trustScore} size={48} />
      </div>

      <p className="mt-3 line-clamp-2 text-sm text-[var(--text-muted)]">{company.description}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        <span className="chip">{t(INDUSTRY_LABEL_KEY[company.industry] ?? company.industry)}</span>
        {company.verified && (
          <span className="chip chip-emerald">
            <ShieldCheck className="h-3 w-3" />
            {t("common.verified")}
          </span>
        )}
      </div>

      <div className="mt-4 flex items-center gap-4 text-xs text-[var(--text-muted)]">
        <span className="flex items-center gap-1">
          <Building2 className="h-3.5 w-3.5" />
          {company.employees}
        </span>
        <span className="flex items-center gap-1">
          <TrendingUp className="h-3.5 w-3.5" />
          {company.revenue}
        </span>
        <span className="flex items-center gap-1">
          <Star className="h-3.5 w-3.5 text-gold" />
          {company.matchScore}% {t("common.matchScore")}
        </span>
      </div>

      <div className="mt-4 flex items-center gap-2 border-t border-[var(--border)] pt-3">
        <button
          onClick={() => toggleFavorite(company.id)}
          aria-label={fav ? `Remove ${company.name} from favorites` : `Save ${company.name} to favorites`}
          aria-pressed={fav}
          className={cn(
            "grid h-9 w-9 place-items-center rounded-lg border transition",
            fav
              ? "border-rose-400/40 bg-rose-500/10 text-rose-400"
              : "border-[var(--border)] text-[var(--text-muted)] hover:text-[var(--text)]"
          )}
        >
          <Heart className={cn("h-4 w-4", fav && "fill-current")} />
        </button>
        <Link to={`/companies/${company.id}`} className="btn btn-primary btn-sm flex-1">
          {t("common.viewProfile")}
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
