import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
  Sparkles, Sun, Moon, Menu, X, ChevronDown, Check, Search,
} from "lucide-react";
import { useApp } from "../context";
import { ACTIVE_LANGUAGES, LANGUAGES } from "../i18n";
import { cn } from "../utils/cn";
import { Logo } from "../ui";
import { useClickOutside } from "./useClickOutside";
import NotificationBell from "./NotificationBell";

function LanguageSwitcher() {
  const { lang, setLang, t } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(() => setOpen(false));
  // Fall back to the full LANGUAGES list only so a lang value that was
  // persisted before this switcher was scoped to active languages (or set
  // via a direct/reserve link) still renders a flag instead of crashing.
  const current = LANGUAGES.find((l) => l.code === lang) ?? ACTIVE_LANGUAGES[0];
  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-2 text-sm transition hover:border-[var(--border-strong)]"
        aria-label={t("common.language")}
      >
        <span className="text-base leading-none">{current.flag}</span>
        <span className="hidden font-medium sm:inline">{current.code.toUpperCase()}</span>
        <ChevronDown className={cn("h-3.5 w-3.5 opacity-60 transition", open && "rotate-180")} />
      </button>
      {open && (
        <div className="absolute end-0 z-50 mt-2 w-52 origin-top anim-slide-up overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--surface-solid)] p-1.5 shadow-2xl">
          <div className="px-2 py-1.5 text-[0.7rem] font-semibold uppercase tracking-wider text-[var(--text-faint)]">
            {t("common.language")} · {ACTIVE_LANGUAGES.length}
          </div>
          <div className="max-h-72 overflow-y-auto no-scrollbar">
            {ACTIVE_LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => {
                  setLang(l.code);
                  setOpen(false);
                }}
                className={cn(
                  "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition hover:bg-[var(--surface-2)]",
                  lang === l.code && "bg-[var(--surface-2)]"
                )}
              >
                <span className="text-base">{l.flag}</span>
                <span className="flex-1 text-start font-medium">{l.native}</span>
                {lang === l.code && <Check className="h-4 w-4 text-cyan-glow" />}
              </button>
            ))}
          </div>
          <div className="mt-1 border-t border-[var(--border)] px-2.5 pt-2 text-[0.68rem] leading-snug text-[var(--text-faint)]">
            {t("common.moreLanguagesComing")}
          </div>
        </div>
      )}
    </div>
  );
}

const NAV = [
  { to: "/companies", key: "nav.companies" },
  { to: "/intelligence", key: "nav.intelligence" },
  { to: "/signals", key: "nav.signals" },
  { to: "/deals", key: "nav.deals" },
  { to: "/kyb", key: "nav.kyb" },
  { to: "/academy", key: "nav.academy" },
  { to: "/pricing", key: "nav.pricing" },
  { to: "/security", key: "nav.security" },
];

export default function Header() {
  const { t, theme, toggleTheme, aiMode, toggleAi, user } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [mobile, setMobile] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 transition-all duration-500",
        scrolled ? "py-2.5" : "py-4"
      )}
    >
      <div className="mx-auto max-w-7xl px-4">
        <div
          className={cn(
            "flex items-center justify-between gap-3 rounded-2xl px-3 transition-all duration-500 sm:px-4",
            scrolled
              ? "border border-[var(--border)] bg-[var(--surface)] py-2 shadow-xl backdrop-blur-xl"
              : "border border-transparent py-2"
          )}
        >
          <Link to="/" className="shrink-0">
            <Logo size={34} priority />
          </Link>

          <nav className="hidden items-center gap-0.5 lg:flex">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  cn(
                    "rounded-lg px-3 py-2 text-sm font-medium transition",
                    isActive
                      ? "text-[var(--text)] bg-[var(--surface-2)]"
                      : "text-[var(--text-muted)] hover:text-[var(--text)] hover:bg-[var(--surface)]"
                  )
                }
              >
                {t(n.key)}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-1.5">
            <button
              onClick={toggleAi}
              className={cn(
                "hidden items-center gap-1.5 rounded-lg border px-2.5 py-2 text-sm font-medium transition sm:flex",
                aiMode
                  ? "border-cyan-glow/40 bg-cyan-glow/10 text-cyan-glow glow-blue"
                  : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
              title={t("common.aiModeTooltip")}
            >
              <Sparkles className={cn("h-4 w-4", aiMode && "animate-pulse")} />
              <span className="hidden md:inline">{t("common.aiMode")}</span>
            </button>

            <button
              onClick={toggleTheme}
              className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] transition hover:text-[var(--text)]"
              aria-label={theme === "dark" ? t("common.switchToLight") : t("common.switchToDark")}
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            <LanguageSwitcher />

            {user && <NotificationBell />}

            {user ? (
              <>
                {user.role === "ADMIN" && (
                  <button
                    onClick={() => navigate("/admin")}
                    className="btn btn-ghost btn-sm hidden md:inline-flex"
                  >
                    {t("common.admin")}
                  </button>
                )}
                <button
                  onClick={() => navigate("/dashboard")}
                  className="btn btn-primary btn-sm hidden md:inline-flex"
                >
                  {t("nav.dashboard")}
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => navigate("/dashboard")}
                  className="btn btn-ghost btn-sm hidden md:inline-flex"
                >
                  {t("cta.getStarted")}
                </button>
                <button
                  onClick={() => navigate("/companies")}
                  className="btn btn-primary btn-sm hidden md:inline-flex"
                >
                  <Search className="h-4 w-4" />
                  {t("nav.companies")}
                </button>
              </>
            )}

            <button
              onClick={() => setMobile((m) => !m)}
              className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] lg:hidden"
              aria-label={mobile ? t("common.closeMenu") : t("common.openMenu")}
              aria-expanded={mobile}
            >
              {mobile ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {mobile && (
          <div className="mt-2 anim-slide-up rounded-2xl border border-[var(--border)] bg-[var(--surface-solid)] p-2 shadow-2xl backdrop-blur-xl lg:hidden">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                onClick={() => setMobile(false)}
                className={({ isActive }) =>
                  cn(
                    "block rounded-lg px-3 py-2.5 text-sm font-medium transition",
                    isActive ? "bg-[var(--surface-2)] text-[var(--text)]" : "text-[var(--text-muted)]"
                  )
                }
              >
                {t(n.key)}
              </NavLink>
            ))}
            <div className="my-2 hairline" />
            <button
              onClick={() => {
                toggleAi();
              }}
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium"
            >
              <Sparkles className="h-4 w-4 text-cyan-glow" />
              {t("common.aiMode")}: {aiMode ? t("common.on") : t("common.off")}
            </button>
            <button
              onClick={() => {
                setMobile(false);
                navigate("/companies");
              }}
              className="btn btn-primary btn-sm mt-1 w-full"
            >
              {t("cta.getStarted")}
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
