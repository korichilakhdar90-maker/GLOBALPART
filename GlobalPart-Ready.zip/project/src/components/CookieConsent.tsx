import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Cookie, Check, X, SlidersHorizontal } from "lucide-react";
import { useApp } from "../context";

/**
 * GDPR / ePrivacy cookie consent.
 *
 * Deliberate design decisions, because the regulation cares about these
 * specifically and "dark patterns" here are exactly what EDPB guidance
 * (03/2022) calls out:
 *
 *  - "Reject all" is rendered with the SAME visual weight and size as
 *    "Accept all". Making reject smaller/greyer/hidden behind a second
 *    click is the single most common violation and invalidates consent.
 *  - Nothing non-essential is set before a choice is made. There is no
 *    implied consent from scrolling or continuing to browse.
 *  - Non-essential categories default to OFF in the customise panel
 *    (opt-in, not opt-out).
 *  - The choice is recorded with a timestamp and a policy version so it
 *    can be re-requested when the policy materially changes, and shown
 *    back to the user on the consent-management page.
 *
 * Strictly-necessary cookies (the httpOnly auth refresh token) are listed
 * but not toggleable, which is correct: they're exempt from consent
 * because the service cannot function without them.
 */

export const CONSENT_STORAGE_KEY = "gp_cookie_consent";
export const CONSENT_POLICY_VERSION = "2026-09-1";

export interface ConsentState {
  necessary: true; // always on, not user-toggleable
  functional: boolean; // language/theme preference persistence
  analytics: boolean; // reserved — no analytics provider is wired up yet
  decidedAt: string;
  policyVersion: string;
}

export function readConsent(): ConsentState | null {
  try {
    const raw = localStorage.getItem(CONSENT_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ConsentState;
    // Re-ask if the policy has changed since they decided.
    if (parsed.policyVersion !== CONSENT_POLICY_VERSION) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeConsent(state: Omit<ConsentState, "decidedAt" | "policyVersion" | "necessary">) {
  const full: ConsentState = {
    necessary: true,
    ...state,
    decidedAt: new Date().toISOString(),
    policyVersion: CONSENT_POLICY_VERSION,
  };
  localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(full));
  window.dispatchEvent(new CustomEvent("gp-consent-changed", { detail: full }));
  return full;
}

export function CookieConsent() {
  const { t } = useApp();
  const [visible, setVisible] = useState(false);
  const [customising, setCustomising] = useState(false);
  const [functional, setFunctional] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!readConsent()) setVisible(true);
  }, []);

  // Move focus into the banner when it appears, so keyboard and
  // screen-reader users reach it immediately rather than having to tab
  // past the whole page to find it.
  useEffect(() => {
    if (visible) dialogRef.current?.focus();
  }, [visible]);

  if (!visible) return null;

  const acceptAll = () => {
    writeConsent({ functional: true, analytics: true });
    setVisible(false);
  };
  const rejectAll = () => {
    writeConsent({ functional: false, analytics: false });
    setVisible(false);
  };
  const saveChoices = () => {
    writeConsent({ functional, analytics });
    setVisible(false);
  };

  return (
    <div
      ref={dialogRef}
      tabIndex={-1}
      role="dialog"
      aria-modal="false"
      aria-labelledby="cookie-consent-title"
      aria-describedby="cookie-consent-desc"
      className="fixed inset-x-0 bottom-0 z-[90] border-t border-[var(--border)] bg-[var(--surface-solid)] p-4 shadow-2xl sm:p-6"
    >
      <div className="mx-auto max-w-4xl">
        <div className="flex items-start gap-3">
          <div className="hidden h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--color-gold)]/15 text-[var(--color-gold)] sm:grid">
            <Cookie className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 id="cookie-consent-title" className="font-display text-sm font-bold">
              {t("cookies.title")}
            </h2>
            <p id="cookie-consent-desc" className="mt-1 text-sm leading-relaxed text-[var(--text-muted)]">
              {t("cookies.body")}{" "}
              <Link to="/privacy" className="text-cyan-glow underline hover:no-underline">
                {t("cookies.privacyLink")}
              </Link>
            </p>
          </div>
        </div>

        {customising && (
          <fieldset className="mt-4 space-y-2 rounded-xl border border-[var(--border)] p-4">
            <legend className="px-1 text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
              {t("cookies.customiseLegend")}
            </legend>

            <label className="flex items-start gap-3 opacity-70">
              <input type="checkbox" checked disabled className="mt-1 h-4 w-4 accent-[var(--color-gold)]" aria-describedby="cookie-necessary-desc" />
              <span>
                <span className="block text-sm font-medium">{t("cookies.necessary.name")}</span>
                <span id="cookie-necessary-desc" className="block text-xs text-[var(--text-muted)]">{t("cookies.necessary.desc")}</span>
              </span>
            </label>

            <label className="flex cursor-pointer items-start gap-3">
              <input
                type="checkbox"
                checked={functional}
                onChange={(e) => setFunctional(e.target.checked)}
                className="mt-1 h-4 w-4 accent-[var(--color-gold)]"
                aria-describedby="cookie-functional-desc"
              />
              <span>
                <span className="block text-sm font-medium">{t("cookies.functional.name")}</span>
                <span id="cookie-functional-desc" className="block text-xs text-[var(--text-muted)]">{t("cookies.functional.desc")}</span>
              </span>
            </label>

            <label className="flex cursor-pointer items-start gap-3">
              <input
                type="checkbox"
                checked={analytics}
                onChange={(e) => setAnalytics(e.target.checked)}
                className="mt-1 h-4 w-4 accent-[var(--color-gold)]"
                aria-describedby="cookie-analytics-desc"
              />
              <span>
                <span className="block text-sm font-medium">{t("cookies.analytics.name")}</span>
                <span id="cookie-analytics-desc" className="block text-xs text-[var(--text-muted)]">{t("cookies.analytics.desc")}</span>
              </span>
            </label>
          </fieldset>
        )}

        {/* Accept and Reject are intentionally identical in size, colour
            weight and prominence — see the component doc comment. */}
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <button onClick={acceptAll} className="btn btn-gold flex-1 justify-center">
            <Check className="h-4 w-4" /> {t("cookies.acceptAll")}
          </button>
          <button onClick={rejectAll} className="btn btn-gold flex-1 justify-center">
            <X className="h-4 w-4" /> {t("cookies.rejectAll")}
          </button>
          {customising ? (
            <button onClick={saveChoices} className="btn btn-ghost flex-1 justify-center">
              {t("cookies.saveChoices")}
            </button>
          ) : (
            <button onClick={() => setCustomising(true)} className="btn btn-ghost flex-1 justify-center" aria-expanded={customising}>
              <SlidersHorizontal className="h-4 w-4" /> {t("cookies.customise")}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
