import { useEffect, useRef, useState } from "react";
import { ShieldCheck, X, Loader2 } from "lucide-react";
import FocusLock from "react-focus-lock";
import { useApp } from "../context";
import { useEscapeKey } from "./useEscapeKey";
import { api } from "../lib/api";

/**
 * Opens automatically when any API call comes back 403
 * TWO_FACTOR_SETUP_REQUIRED (enterprise-only gate, see
 * requireEnterpriseAccess in accountPolicy.ts on the backend), and can also
 * be opened directly from a "Set up 2FA" button in account settings.
 */
export default function TwoFactorSetupModal() {
  const { t, twoFactorSetupOpen, closeTwoFactorSetup, toast } = useApp();
  const [loading, setLoading] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [enabling, setEnabling] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!twoFactorSetupOpen) return;
    setCode("");
    setLoading(true);
    api.auth
      .setup2FA()
      .then((res) => {
        setQrCodeDataUrl(res.qrCodeDataUrl);
        setSecret(res.secret);
      })
      .catch(() => toast(t("common.errorGeneric"), "error"))
      .finally(() => setLoading(false));
  }, [twoFactorSetupOpen, t, toast]);

  // Esc-to-close. Registered before the early return so the hook order
  // stays stable across renders.
  useEscapeKey(twoFactorSetupOpen, closeTwoFactorSetup);

  if (!twoFactorSetupOpen) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEnabling(true);
    try {
      await api.auth.enable2FA(code);
      toast(t("twoFactor.enabledToast"));
      closeTwoFactorSetup();
    } catch {
      toast(t("twoFactor.invalidCode"), "error");
      setCode("");
      inputRef.current?.focus();
    } finally {
      setEnabling(false);
    }
  };

  return (
    <FocusLock returnFocus autoFocus>
    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/60 backdrop-blur-sm p-4" role="dialog" aria-modal="true">
      <div className="card ring-gradient anim-slide-up w-full max-w-md overflow-hidden">
        <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-gradient-to-r from-emerald-trust/20 to-cyan-glow/20 p-5">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-trust to-cyan-glow">
              <ShieldCheck className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold">{t("twoFactor.title")}</h2>
              <p className="text-xs text-[var(--text-muted)]">{t("twoFactor.subtitle")}</p>
            </div>
          </div>
          <button onClick={closeTwoFactorSetup} className="rounded-lg p-1.5 text-[var(--text-faint)] transition hover:bg-[var(--surface-2)] hover:text-[var(--text)]" aria-label={t("common.close")}>
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4 p-5">
          {loading ? (
            <div className="grid h-48 place-items-center">
              <Loader2 className="h-6 w-6 animate-spin text-[var(--text-faint)]" />
            </div>
          ) : (
            <>
              <p className="text-sm text-[var(--text-muted)]">{t("twoFactor.scanInstructions")}</p>
              {qrCodeDataUrl && (
                <div className="grid place-items-center rounded-xl border border-[var(--border)] bg-white p-4">
                  <img src={qrCodeDataUrl} alt="2FA QR code" className="h-44 w-44" />
                </div>
              )}
              {secret && (
                <p className="break-all rounded-lg bg-[var(--surface)] px-3 py-2 text-center font-mono text-xs text-[var(--text-muted)]">{secret}</p>
              )}

              <form onSubmit={submit} className="space-y-3">
                <input
                  ref={inputRef}
                  required
                  inputMode="numeric"
                  pattern="[0-9]{6}"
                  maxLength={6}
                  autoComplete="one-time-code"
                  placeholder="000000"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3 text-center font-mono text-2xl tracking-[0.5em] outline-none transition focus:border-cyan-glow/60"
                />
                <button type="submit" disabled={enabling || code.length !== 6} className="btn btn-primary w-full shine disabled:opacity-60">
                  {enabling ? t("common.pleaseWait") : t("twoFactor.confirmButton")}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
    </FocusLock>
  );
}
