import { Component, type ErrorInfo, type ReactNode } from "react";
import { AlertTriangle } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  error: Error | null;
}

// A minimal, dependency-free translation lookup for the handful of strings
// this boundary needs. It reads the persisted language directly from
// localStorage instead of via React context, because an error boundary must
// keep working even if something above it (including the app's own
// context/provider tree) is what just crashed.
const STRINGS: Record<string, { title: string; body: string; button: string }> = {
  en: { title: "Something went wrong", body: "An unexpected error occurred while rendering this page. You can try returning to the homepage — your saved data hasn't been affected.", button: "Back to homepage" },
  ar: { title: "حدث خطأ ما", body: "حدث خطأ غير متوقع أثناء عرض هذه الصفحة. يمكنك محاولة العودة إلى الصفحة الرئيسية — بياناتك المحفوظة لم تتأثر.", button: "العودة إلى الصفحة الرئيسية" },
  zh: { title: "出现了一些问题", body: "渲染此页面时发生意外错误。您可以尝试返回首页——您保存的数据不受影响。", button: "返回首页" },
  es: { title: "Algo salió mal", body: "Se produjo un error inesperado al mostrar esta página. Puedes intentar volver al inicio — tus datos guardados no se han visto afectados.", button: "Volver al inicio" },
  fr: { title: "Une erreur s'est produite", body: "Une erreur inattendue s'est produite lors de l'affichage de cette page. Vous pouvez essayer de revenir à l'accueil — vos données enregistrées n'ont pas été affectées.", button: "Retour à l'accueil" },
  de: { title: "Etwas ist schiefgelaufen", body: "Beim Rendern dieser Seite ist ein unerwarteter Fehler aufgetreten. Sie können zur Startseite zurückkehren — Ihre gespeicherten Daten sind nicht betroffen.", button: "Zur Startseite" },
  pt: { title: "Algo deu errado", body: "Ocorreu um erro inesperado ao renderizar esta página. Você pode tentar voltar à página inicial — seus dados salvos não foram afetados.", button: "Voltar ao início" },
  ru: { title: "Что-то пошло не так", body: "При отображении этой страницы произошла непредвиденная ошибка. Вы можете вернуться на главную страницу — ваши сохранённые данные не пострадали.", button: "На главную страницу" },
  hi: { title: "कुछ गलत हो गया", body: "इस पेज को दिखाते समय एक अप्रत्याशित त्रुटि हुई। आप होमपेज पर वापस जाने का प्रयास कर सकते हैं — आपका सहेजा गया डेटा प्रभावित नहीं हुआ है।", button: "होमपेज पर वापस जाएं" },
  ja: { title: "問題が発生しました", body: "このページの表示中に予期しないエラーが発生しました。ホームページに戻ることができます — 保存されたデータには影響ありません。", button: "ホームページに戻る" },
  ko: { title: "문제가 발생했습니다", body: "이 페이지를 렌더링하는 동안 예기치 않은 오류가 발생했습니다. 홈페이지로 돌아가 보세요 — 저장된 데이터는 영향을 받지 않았습니다.", button: "홈페이지로 돌아가기" },
};

function getStrings() {
  try {
    const lang = JSON.parse(localStorage.getItem("gp_lang") ?? '"en"');
    return STRINGS[lang] ?? STRINGS.en;
  } catch {
    return STRINGS.en;
  }
}

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // In a real deployment, forward this to an error-tracking service
    // (Sentry, LogRocket, etc.) instead of just logging.
    console.error("GlobalPart crashed:", error, info.componentStack);
  }

  handleReset = () => {
    this.setState({ error: null });
    window.location.assign("/");
  };

  render() {
    if (this.state.error) {
      const s = getStrings();
      return (
        <div className="grid min-h-screen place-items-center px-4 text-center">
          <div className="card max-w-md p-8">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-500/10 text-rose-400">
              <AlertTriangle className="h-7 w-7" />
            </div>
            <h1 className="mt-4 font-display text-xl font-bold">{s.title}</h1>
            <p className="mt-2 text-sm text-[var(--text-muted)]">
              {s.body}
            </p>
            <button onClick={this.handleReset} className="btn btn-primary mt-6 w-full">
              {s.button}
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
