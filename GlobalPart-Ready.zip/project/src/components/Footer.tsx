import { Link } from "react-router-dom";
import { ShieldCheck, Lock, Globe, Award, Mail, Phone, Share2 } from "lucide-react";
import { useApp } from "../context";
import { Logo } from "../ui";
import { LANGUAGES } from "../i18n";

const COLS: { titleKey: string; links: { labelKey: string; to: string }[] }[] = [
  {
    titleKey: "footer.product",
    links: [
      { labelKey: "nav.companies", to: "/companies" },
      { labelKey: "nav.intelligence", to: "/intelligence" },
      { labelKey: "nav.deals", to: "/deals" },
      { labelKey: "nav.kyb", to: "/kyb" },
      { labelKey: "nav.dashboard", to: "/dashboard" },
    ],
  },
  {
    titleKey: "footer.solutions",
    links: [
      { labelKey: "footer.link.smes", to: "/pricing" },
      { labelKey: "footer.link.enterprise", to: "/pricing" },
      { labelKey: "footer.link.exporters", to: "/companies" },
      { labelKey: "footer.link.tradeAssoc", to: "/pricing" },
      { labelKey: "footer.link.govAgencies", to: "/pricing" },
    ],
  },
  {
    titleKey: "footer.resources",
    links: [
      { labelKey: "footer.link.marketIntel", to: "/intelligence" },
      { labelKey: "nav.signals", to: "/signals" },
      { labelKey: "nav.academy", to: "/academy" },
      { labelKey: "nav.security", to: "/security" },
      { labelKey: "nav.pricing", to: "/pricing" },
      { labelKey: "footer.link.about", to: "/about" },
      { labelKey: "footer.link.roadmap", to: "/roadmap" },
      { labelKey: "footer.link.commitments", to: "/commitments" },
      { labelKey: "footer.link.quickStart", to: "/quick-start" },
      { labelKey: "footer.link.status", to: "/status" },
      { labelKey: "footer.link.feedback", to: "/feedback" },
    ],
  },
  {
    titleKey: "footer.legal",
    links: [
      { labelKey: "footer.link.privacy", to: "/privacy" },
      { labelKey: "footer.link.compliance", to: "/compliance" },
      { labelKey: "footer.link.consentSettings", to: "/consent-settings" },
      { labelKey: "footer.link.terms", to: "/terms" },
      { labelKey: "footer.link.gdpr", to: "/security" },
      { labelKey: "footer.link.soc2", to: "/security" },
      { labelKey: "footer.link.transparency", to: "/security" },
    ],
  },
];

const BADGES = [
  { icon: ShieldCheck, key: "footer.badge.soc2" },
  { icon: Lock, key: "footer.badge.aes256" },
  { icon: Globe, key: "footer.badge.gdpr" },
  { icon: Award, key: "footer.badge.iso27001" },
];

export default function Footer() {
  const { t } = useApp();
  return (
    <footer className="relative mt-24 border-t border-[var(--border)]">
      <div className="mx-auto max-w-7xl px-4 py-16">
        {/* Trust strip */}
        <div className="mb-12 flex flex-wrap items-center justify-center gap-3">
          {BADGES.map((b) => (
            <div
              key={b.key}
              className="flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm"
            >
              <b.icon className="h-4 w-4 text-emerald-trust" />
              <span className="font-medium">{t(b.key)}</span>
            </div>
          ))}
        </div>

        <div className="grid gap-10 md:grid-cols-[1.4fr_repeat(4,1fr)]">
          <div>
            <Logo size={36} />
            <p className="mt-4 max-w-xs text-sm text-[var(--text-muted)]">{t("footer.tagline")}</p>
            <div className="mt-5 flex gap-2">
              <a
                href="mailto:hello@globalpart.io"
                className="flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs text-[var(--text-muted)] transition hover:text-[var(--text)]"
                aria-label={t("footer.emailLabel")}
              >
                <Mail className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">hello@globalpart.io</span>
              </a>
              <a
                href="tel:+14155550199"
                className="flex items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs text-[var(--text-muted)] transition hover:text-[var(--text)]"
                aria-label={t("footer.phoneLabel")}
              >
                <Phone className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">+1 (415) 555-0199</span>
              </a>
              <a
                href="#"
                aria-label={t("footer.share")}
                className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] transition hover:text-[var(--text)]"
              >
                <Share2 className="h-4 w-4" />
              </a>
            </div>
          </div>

          {COLS.map((col) => (
            <div key={col.titleKey}>
              <h3 className="mb-3 text-sm font-semibold">{t(col.titleKey)}</h3>
              <ul className="space-y-2">
                {col.links.map((l) => (
                  <li key={l.labelKey}>
                    <Link
                      to={l.to}
                      className="text-sm text-[var(--text-muted)] transition hover:text-cyan-glow"
                    >
                      {t(l.labelKey)}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Language strip */}
        <div className="my-10 hairline" />
        <div className="flex flex-wrap items-center justify-center gap-2">
          {LANGUAGES.map((l) => (
            <span
              key={l.code}
              className="flex items-center gap-1 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1 text-xs text-[var(--text-muted)]"
            >
              <span>{l.flag}</span>
              {l.native}
            </span>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 text-sm text-[var(--text-muted)] sm:flex-row">
          <span>© {new Date().getFullYear()} GlobalPart. {t("footer.rights")}</span>
          {/* Wording is deliberately "Built following ..." not "Certified":
              no external accessibility or privacy audit has been carried
              out, and claiming certification we don't hold would be false. */}
          <Link
            to="/compliance"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] px-2.5 py-1 text-xs text-[var(--text-muted)] transition hover:text-[var(--text)]"
          >
            <span aria-hidden="true">🇪🇺</span> {t("footer.euCompliant")}
          </Link>
          <span className="flex items-center gap-2">
            <span className="h-2 w-2 animate-pulse rounded-full bg-gold" />
            {t("footer.systemsStatus")}
          </span>
        </div>
      </div>
    </footer>
  );
}
