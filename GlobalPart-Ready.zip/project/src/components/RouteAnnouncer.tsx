import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useApp } from "../context";

/**
 * Announces route changes to screen readers (WCAG 2.1 SC 4.1.3, Status
 * Messages).
 *
 * In a single-page app, clicking a link swaps the DOM without a real page
 * load, so assistive technology gets no navigation event and stays
 * silent — the user has no idea the page changed. This visually-hidden
 * live region fills that gap.
 *
 * Reads document.title rather than deriving a name from the path: every
 * page already sets a proper, translated title through <Seo>, so this
 * stays correct in all 9 languages automatically instead of needing its
 * own route→label mapping that could drift out of sync.
 */
export default function RouteAnnouncer() {
  const location = useLocation();
  const { t } = useApp();
  const [message, setMessage] = useState("");

  useEffect(() => {
    // <Seo> sets document.title in its own effect. A microtask delay lets
    // that run first, so we announce the new title rather than the
    // previous page's.
    const id = window.setTimeout(() => {
      const title = document.title || "";
      setMessage(title ? t("a11y.navigatedTo", { page: title }) : "");
    }, 120);
    return () => window.clearTimeout(id);
  }, [location.pathname, t]);

  return (
    <div aria-live="polite" aria-atomic="true" className="sr-only">
      {message}
    </div>
  );
}
