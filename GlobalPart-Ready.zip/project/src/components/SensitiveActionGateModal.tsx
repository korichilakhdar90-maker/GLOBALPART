import { useEffect, useRef, useState } from "react";
import { ShieldAlert, X } from "lucide-react";
import FocusLock from "react-focus-lock";
import { useApp } from "../context";
import { useEscapeKey } from "./useEscapeKey";

/**
 * Opens automatically whenever any API call anywhere in the app comes back
 * 403 EMAIL_VERIFICATION_REQUIRED (see accountPolicy.ts on the backend and
 * the onAccountPolicyError listener registered in context.tsx). This is
 * the "clean modal prompting them to verify before proceeding" from the
 * product requirement -- it intercepts the sensitive action in place
 * rather than sending the user away to click an email link and lose
 * their spot mid-contract/mid-checkout.
 */
export default function SensitiveActionGateModal() {
  const { t, user, sensitiveActionGateOpen, sensitiveActionGateMessage, closeSensitiveActionGate, requestSensitiveActionOtp, verifySensitiveActionOtp, toast } = useApp();
  const [code, setCode] = useState("");
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [sent, setSent] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (sensitiveActionGateOpen) {
      setCode("");
      setSent(false);
      // Fire the OTP immediately so the user doesn't have to click a
      // separate "send code" button before they can even see the input.
      setSending(true);
      requestSensitiveActionOtp()
        .then(() => setSent(true))
        .catch(() => toast(t("common.errorGeneric"), "error"))
        .finally(() => setSending(false));
      setTimeout(() => inputRef.current?.focus(), 50);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sensitiveActionGateOpen]);

  // Esc-to-close. Registered before the early return so the hook order
  // stays stable across renders.
  useEscapeKey(sensitiveActionGateOpen, closeSensitiveActionGate);

  if (!sensitiveActionGateOpen) return null;

  const resend = async () => {
    setSending(true);
    try {
      await requestSensitiveActionOtp();
      setSent(true);
      toast(t("verifyGate.codeResent"));
    } catch {
      toast(t("common.errorGeneric"), "error");
    } finally {
      setSending(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifying(true);
    try {
      await verifySensitiveActionOtp(code);
    } catch {
      toast(t("verifyGate.invalidCode"), "error");
      setCode("");
      inputRef.current?.focus();
    } finally {
      setVerifying(false);
    }
  };

  return (
    <FocusLock returnFocus autoFocus>
    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/60 backdrop-blur-sm p-4" role="dialog" aria-modal="true">
      <div className="card ring-gradient anim-slide-up w-full max-w-md overflow-hidden">
        <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-gradient-to-r from-brand-600/20 to-cyan-glow/20 p-5">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-600 to-cyan-glow">
              <ShieldAlert className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold">{t("verifyGate.title")}</h2>
              <p className="text-xs text-[var(--text-muted)]">{sensitiveActionGateMessage || t("verifyGate.subtitle")}</p>
            </div>
          </div>
          <button onClick={closeSensitiveActionGate} className="rounded-lg p-1.5 text-[var(--text-faint)] transition hover:bg-[var(--surface-2)] hover:text-[var(--text)]" aria-label={t("common.close")}>
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={submit} className="space-y-4 p-5">
          <p className="text-sm text-[var(--text-muted)]">
            {sending && !sent ? t("verifyGate.sending") : t("verifyGate.sentTo", { email: user?.email ?? "" })}
          </p>

          <input
            ref={inputRef}
            required
            inputMode="numeric"
            pattern="[0-9]{6}"
            maxLength={6}
            autoComplete="one-time-code"
            placeholder="000000"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3 text-center font-mono text-2xl tracking-[0.5em] outline-none transition focus:border-cyan-glow/60"
          />

          <button type="submit" disabled={verifying || code.length !== 6} className="btn btn-primary w-full shine disabled:opacity-60">
            {verifying ? t("common.pleaseWait") : t("verifyGate.verifyButton")}
          </button>

          <button type="button" onClick={resend} disabled={sending} className="w-full text-center text-sm font-medium text-cyan-glow hover:underline disabled:opacity-60">
            {sending ? t("common.pleaseWait") : t("verifyGate.resend")}
          </button>
        </form>
      </div>
    </div>
    </FocusLock>
  );
}
