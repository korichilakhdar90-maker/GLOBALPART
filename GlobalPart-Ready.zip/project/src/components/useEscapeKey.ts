import { useEffect } from "react";

/**
 * Closes a dialog on Escape (WCAG 2.1 SC 2.1.2, No Keyboard Trap — a user
 * who opens a dialog must always be able to get back out with the
 * keyboard alone).
 *
 * Listens on `document` in the capture phase so the handler fires even
 * when focus is inside an input that stops propagation of its own
 * keydown events.
 *
 * Focus *restoration* is not handled here — that's react-focus-lock's
 * `returnFocus` prop, which is more reliable than tracking the previously
 * focused element by hand (it copes with the trigger being unmounted or
 * moved while the dialog was open).
 */
export function useEscapeKey(active: boolean, onEscape: () => void) {
  useEffect(() => {
    if (!active) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onEscape();
      }
    };
    document.addEventListener("keydown", handler, true);
    return () => document.removeEventListener("keydown", handler, true);
  }, [active, onEscape]);
}
