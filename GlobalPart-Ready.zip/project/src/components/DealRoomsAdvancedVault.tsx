import { useState } from "react";
import { ShieldCheck, FileText, History, Fingerprint, Download, ChevronDown, ChevronUp } from "lucide-react";
import { useApp } from "../context";
import { cn } from "../utils/cn";

interface VaultDocument {
  id: string;
  nameKey: string;
  versions: { version: number; dateKey: string; hash: string }[];
}

const VAULT_DOCUMENTS: VaultDocument[] = [
  {
    id: "master-agreement",
    nameKey: "deals.vault.doc.masterAgreement",
    versions: [
      { version: 3, dateKey: "deals.vault.updatedRecently", hash: "7f3a9c…e21b" },
      { version: 2, dateKey: "deals.vault.updated3dAgo", hash: "4d0e11…8ac2" },
      { version: 1, dateKey: "deals.vault.updated9dAgo", hash: "a12f77…003d" },
    ],
  },
  {
    id: "technical-spec",
    nameKey: "deals.vault.doc.technicalSpec",
    versions: [
      { version: 2, dateKey: "deals.vault.updated1dAgo", hash: "9b6c44…f710" },
      { version: 1, dateKey: "deals.vault.updated9dAgo", hash: "e5a833…12cd" },
    ],
  },
  {
    id: "invoice",
    nameKey: "deals.vault.doc.invoice",
    versions: [{ version: 1, dateKey: "deals.vault.updated2dAgo", hash: "b0912e…54aa" }],
  },
];

/**
 * A version-controlled document vault for a deal room. This is demo/sample
 * data by design — the real backend has a single Document model without
 * version history yet (see server/prisma/schema.prisma). It's built with
 * the platform's existing card/chip/CSS-variable design tokens so it slots
 * into DealRooms.tsx without introducing a second visual language.
 */
export default function DealRoomsAdvancedVault() {
  const { t, toast } = useApp();
  const [expanded, setExpanded] = useState<string | null>(VAULT_DOCUMENTS[0].id);

  return (
    <div className="card p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-trust/15 text-emerald-trust">
            <ShieldCheck className="h-4.5 w-4.5" />
          </div>
          <div>
            <h3 className="font-display text-sm font-bold">{t("deals.vault.title")}</h3>
            <p className="text-xs text-[var(--text-muted)]">{t("deals.vault.subtitle")}</p>
          </div>
        </div>
        <span className="chip chip-gold text-[0.65rem]">{t("common.example")}</span>
      </div>

      <div className="mt-5 space-y-2">
        {VAULT_DOCUMENTS.map((doc) => {
          const isOpen = expanded === doc.id;
          const latest = doc.versions[0];
          return (
            <div key={doc.id} className="overflow-hidden rounded-xl border border-[var(--border)]">
              <button
                onClick={() => setExpanded(isOpen ? null : doc.id)}
                className="flex w-full items-center gap-3 bg-[var(--surface)] p-3 text-start transition hover:bg-[var(--surface-2)]"
              >
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-rose-500/15 text-rose-400">
                  <FileText className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{t(doc.nameKey)}</div>
                  <div className="text-xs text-[var(--text-muted)]">
                    {t("deals.vault.versionLabel", { version: latest.version })} · {t(latest.dateKey)}
                  </div>
                </div>
                <span className="chip text-[0.65rem]">{t("deals.vault.versionCount", { count: doc.versions.length })}</span>
                {isOpen ? <ChevronUp className="h-4 w-4 text-[var(--text-faint)]" /> : <ChevronDown className="h-4 w-4 text-[var(--text-faint)]" />}
              </button>

              {isOpen && (
                <div className="space-y-1.5 border-t border-[var(--border)] bg-[var(--bg-soft)] p-3">
                  {doc.versions.map((v) => (
                    <div key={v.version} className="flex items-center gap-3 rounded-lg px-2 py-1.5 text-xs">
                      <History className={cn("h-3.5 w-3.5 shrink-0", v.version === latest.version ? "text-cyan-glow" : "text-[var(--text-faint)]")} />
                      <span className={cn("font-medium", v.version === latest.version ? "text-[var(--text)]" : "text-[var(--text-muted)]")}>
                        {t("deals.vault.versionLabel", { version: v.version })}
                      </span>
                      <span className="text-[var(--text-muted)]">{t(v.dateKey)}</span>
                      <span className="ms-auto flex items-center gap-1 font-mono text-[0.65rem] text-[var(--text-faint)]">
                        <Fingerprint className="h-3 w-3" /> {v.hash}
                      </span>
                      <button
                        onClick={() => toast(t("deals.downloadedToast"))}
                        className="text-[var(--text-muted)] transition hover:text-cyan-glow"
                        aria-label={t("deals.vault.downloadVersion", { version: v.version })}
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <p className="mt-4 text-xs leading-relaxed text-[var(--text-faint)]">{t("deals.vault.integrityNote")}</p>
    </div>
  );
}
