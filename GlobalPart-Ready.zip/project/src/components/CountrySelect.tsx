import { useMemo, useState } from "react";
import { Search, Check, X, MapPin, Plus } from "lucide-react";
import { COUNTRIES } from "../data";
import { useApp } from "../context";
import { cn } from "../utils/cn";
import { useClickOutside } from "./useClickOutside";

export default function CountrySelect({
  value,
  onChange,
  multi = true,
  placeholder = "Select countries…",
}: {
  value: string | string[];
  onChange: (v: string | string[]) => void;
  multi?: boolean;
  placeholder?: string;
}) {
  const { t } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const ref = useClickOutside(() => setOpen(false));

  const selected = useMemo(
    () => (Array.isArray(value) ? value : value ? [value] : []),
    [value]
  );

  const filtered = useMemo(() => {
    const s = q.toLowerCase();
    return COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(s) ||
        c.region.toLowerCase().includes(s) ||
        c.code.toLowerCase().includes(s)
    );
  }, [q]);

  const toggle = (code: string) => {
    if (multi) {
      onChange(selected.includes(code) ? selected.filter((c) => c !== code) : [...selected, code]);
    } else {
      onChange(code);
      setOpen(false);
    }
  };

  const selectedCountries = COUNTRIES.filter((c) => selected.includes(c.code));

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full min-h-[3rem] flex-wrap items-center gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-start transition hover:border-[var(--border-strong)]"
      >
        <MapPin className="me-1 h-4 w-4 shrink-0 text-[var(--text-muted)]" />
        {selectedCountries.length === 0 ? (
          <span className="text-sm text-[var(--text-muted)]">{placeholder}</span>
        ) : (
          selectedCountries.map((c) => (
            <span
              key={c.code}
              className="flex items-center gap-1 rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 text-xs"
            >
              <span>{c.flag}</span>
              <span className="font-medium">{c.name}</span>
              {multi && (
                <button
                  type="button"
                  aria-label={`Remove ${c.name}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggle(c.code);
                  }}
                  className="grid h-3.5 w-3.5 place-items-center rounded-full opacity-60 transition hover:opacity-100"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </span>
          ))
        )}
        <span className="ms-auto flex items-center gap-1 text-xs text-cyan-glow">
          {selected.length > 0 && `${selected.length} ${t("common.filter.country")}`}
        </span>
      </button>

      {open && (
        <div className="absolute z-50 mt-2 w-full anim-slide-up overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--surface-solid)] shadow-2xl">
          <div className="flex items-center gap-2 border-b border-[var(--border)] p-2.5">
            <Search className="h-4 w-4 text-[var(--text-muted)]" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("common.search")}
              className="w-full bg-transparent text-sm outline-none"
            />
          </div>
          <div className="max-h-60 overflow-y-auto no-scrollbar p-1.5">
            {filtered.map((c) => {
              const sel = selected.includes(c.code);
              return (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => toggle(c.code)}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition hover:bg-[var(--surface-2)]",
                    sel && "bg-[var(--surface-2)]"
                  )}
                >
                  <span className="text-base">{c.flag}</span>
                  <span className="flex-1 text-start">
                    <span className="font-medium">{c.name}</span>
                    <span className="ms-2 text-xs text-[var(--text-faint)]">{c.region}</span>
                  </span>
                  {sel ? (
                    <Check className="h-4 w-4 text-cyan-glow" />
                  ) : (
                    <Plus className="h-4 w-4 text-[var(--text-faint)]" />
                  )}
                </button>
              );
            })}
            {filtered.length === 0 && (
              <div className="px-3 py-6 text-center text-sm text-[var(--text-muted)]">{t("common.noMatches")}</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
