import { useEffect, useState } from "react";
import { Bell, CheckCheck } from "lucide-react";
import { useApp } from "../context";
import { api, isBackendConfigured } from "../lib/api";
import { useClickOutside } from "./useClickOutside";
import { cn } from "../utils/cn";

interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
}

/**
 * Requirement 3 ("Activate Notifications"): the in-app half of the pair --
 * shows every Notification row created by notification.service.ts on the
 * backend (KYB submitted/assigned/approved/rejected). Polls on an interval
 * rather than a websocket for simplicity; good enough for admin-console
 * -driven status changes, which aren't high-frequency.
 */
export default function NotificationBell() {
  const { t, user } = useApp();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const ref = useClickOutside(() => setOpen(false));

  const load = () => {
    if (!isBackendConfigured) return;
    api.notifications
      .list()
      .then((res) => {
        setItems(res.notifications);
        setUnreadCount(res.unreadCount);
      })
      .catch(() => {});
  };

  useEffect(() => {
    if (!user) return;
    load();
    const interval = setInterval(load, 30_000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  if (!user || !isBackendConfigured) return null;

  const markAllRead = async () => {
    await api.notifications.markAllRead();
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const markOneRead = async (id: string) => {
    await api.notifications.markRead(id);
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-lg border border-[var(--border)] bg-[var(--surface)] p-2 transition hover:border-[var(--border-strong)]"
        aria-label={t("notifications.title")}
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[0.6rem] font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute end-0 z-50 mt-2 w-80 origin-top anim-slide-up overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--surface-solid)] shadow-2xl">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-2.5">
            <span className="text-sm font-semibold">{t("notifications.title")}</span>
            {unreadCount > 0 && (
              <button onClick={markAllRead} className="flex items-center gap-1 text-xs text-cyan-glow hover:underline">
                <CheckCheck className="h-3.5 w-3.5" /> {t("notifications.markAllRead")}
              </button>
            )}
          </div>
          <div className="max-h-80 overflow-y-auto no-scrollbar">
            {items.length === 0 ? (
              <p className="p-4 text-center text-sm text-[var(--text-muted)]">{t("notifications.empty")}</p>
            ) : (
              items.map((n) => (
                <button
                  key={n.id}
                  onClick={() => !n.read && markOneRead(n.id)}
                  className={cn(
                    "block w-full border-b border-[var(--border)] px-4 py-3 text-start transition last:border-b-0 hover:bg-[var(--surface-2)]",
                    !n.read && "bg-cyan-glow/5"
                  )}
                >
                  <div className="flex items-start gap-2">
                    {!n.read && <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-glow" />}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{n.title}</p>
                      <p className="mt-0.5 line-clamp-2 text-xs text-[var(--text-muted)]">{n.body}</p>
                      <p className="mt-1 text-[0.65rem] text-[var(--text-faint)]">{new Date(n.createdAt).toLocaleString()}</p>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
