import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import { LANGUAGES, type LangCode, type Dict, loadDict, getCachedDict, englishDict, isReserveLang } from "./i18n";
import { api, isBackendConfigured, setAccessToken, onAccountPolicyError, type ApiUser } from "./lib/api";

type Theme = "dark" | "light";

interface User {
  id?: string;
  name: string;
  email: string;
  company: string;
  role?: "USER" | "ADMIN";
  emailVerified?: boolean;
  accountCategory?: ApiUser["accountCategory"];
  accountStatus?: ApiUser["accountStatus"];
  twoFactorEnabled?: boolean;
}

interface KybSubmission {
  id: string;
  company: string;
  registration: string;
  email: string;
  phone: string;
  country: string;
  documents: string[];
  status: "submitted" | "review" | "verified";
  submittedAt: number;
  trustScore: number;
}

interface Toast {
  id: number;
  message: string;
  type: "success" | "info" | "error";
}

interface Ctx {
  lang: LangCode;
  setLang: (l: LangCode) => void;
  dir: "ltr" | "rtl";
  t: (key: string, params?: Record<string, string | number>) => string;
  theme: Theme;
  toggleTheme: () => void;
  aiMode: boolean;
  toggleAi: () => void;
  user: User | null;
  authLoading: boolean;
  login: (input: { email: string; password: string }) => Promise<{ twoFactorRequired: boolean }>;
  register: (input: { name: string; email: string; password: string; company?: string; accountCategory?: ApiUser["accountCategory"] }) => Promise<{ sessionIssued: boolean; message?: string }>;
  logout: () => void;
  kyb: KybSubmission[];
  addKyb: (
    k: Omit<KybSubmission, "id" | "submittedAt" | "status" | "trustScore">
  ) => KybSubmission;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  toasts: Toast[];
  toast: (message: string, type?: Toast["type"]) => void;

  // ---- 2FA login step-up (any account with twoFactorEnabled) ----
  twoFactorPendingToken: string | null;
  verifyLoginTwoFactor: (code: string) => Promise<void>;
  cancelTwoFactorLogin: () => void;

  // ---- Sensitive-action email-verification gate (see accountPolicy.ts) ----
  // Opened automatically by onAccountPolicyError below whenever any API
  // call anywhere in the app comes back EMAIL_VERIFICATION_REQUIRED.
  sensitiveActionGateOpen: boolean;
  sensitiveActionGateMessage: string;
  openSensitiveActionGate: () => void;
  closeSensitiveActionGate: () => void;
  requestSensitiveActionOtp: () => Promise<void>;
  verifySensitiveActionOtp: (code: string) => Promise<void>;

  // ---- Enterprise mandatory 2FA setup ----
  twoFactorSetupOpen: boolean;
  openTwoFactorSetup: () => void;
  closeTwoFactorSetup: () => void;
}

const AppContext = createContext<Ctx | null>(null);

const LS = {
  lang: "gp_lang",
  theme: "gp_theme",
  ai: "gp_ai",
  user: "gp_user",
  kyb: "gp_kyb",
  fav: "gp_fav",
};

function read<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LangCode>(() => read(LS.lang, "en"));
  const [theme, setTheme] = useState<Theme>(() => read(LS.theme, "dark"));
  const [aiMode, setAiMode] = useState<boolean>(() => read(LS.ai, true));
  const [user, setUser] = useState<User | null>(() => read<User | null>(LS.user, null));
  const [authLoading, setAuthLoading] = useState(false);
  const [kyb, setKyb] = useState<KybSubmission[]>(() => read<KybSubmission[]>(LS.kyb, []));
  const [favorites, setFavorites] = useState<string[]>(() => read<string[]>(LS.fav, []));
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dir = LANGUAGES.find((l) => l.code === lang)?.dir ?? "ltr";

  // The active language's dictionary is loaded on demand (see loadDict in
  // ./i18n) so the initial bundle only ships English, not all 11 languages.
  // `dict` starts as whatever's already cached (instant for English, or a
  // language visited earlier this session) and updates once the async
  // import resolves for a newly-selected language.
  const [dict, setDict] = useState<Dict>(() => getCachedDict(lang) ?? englishDict);

  useEffect(() => {
    let cancelled = false;
    const cached = getCachedDict(lang);
    if (cached) {
      setDict(cached);
      return;
    }
    loadDict(lang).then((d) => {
      if (!cancelled) setDict(d);
    });
    return () => {
      cancelled = true;
    };
  }, [lang]);

  const t = useCallback(
    (key: string, params?: Record<string, string | number>) => {
      let str = dict[key] ?? englishDict[key] ?? key;
      if (params) {
        for (const [k, v] of Object.entries(params)) {
          str = str.replaceAll(`{${k}}`, String(v));
        }
      }
      return str;
    },
    [dict]
  );

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.classList.remove("light");
    } else {
      root.classList.add("light");
      root.classList.remove("dark");
    }
  }, [theme]);

  const setLang = useCallback((l: LangCode) => {
    setLangState(l);
    localStorage.setItem(LS.lang, JSON.stringify(l));
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((p) => {
      const next = p === "dark" ? "light" : "dark";
      localStorage.setItem(LS.theme, JSON.stringify(next));
      return next;
    });
  }, []);

  const toggleAi = useCallback(() => {
    setAiMode((p) => {
      const next = !p;
      localStorage.setItem(LS.ai, JSON.stringify(next));
      return next;
    });
  }, []);

  const [twoFactorPendingToken, setTwoFactorPendingToken] = useState<string | null>(null);
  const [sensitiveActionGateOpen, setSensitiveActionGateOpen] = useState(false);
  const [sensitiveActionGateMessage, setSensitiveActionGateMessage] = useState("");
  const [twoFactorSetupOpen, setTwoFactorSetupOpen] = useState(false);

  const login = useCallback(async (input: { email: string; password: string }) => {
    setAuthLoading(true);
    try {
      if (isBackendConfigured) {
        const result = await api.auth.login(input);
        if (result.twoFactorRequired) {
          setTwoFactorPendingToken(result.pendingToken);
          return { twoFactorRequired: true };
        }
        setAccessToken(result.accessToken);
        const nextUser: User = {
          id: result.user.id, name: result.user.name, email: result.user.email, company: result.user.company ?? "",
          role: result.user.role, emailVerified: result.user.emailVerified,
          accountCategory: result.user.accountCategory, accountStatus: result.user.accountStatus, twoFactorEnabled: result.user.twoFactorEnabled,
        };
        setUser(nextUser);
        localStorage.setItem(LS.user, JSON.stringify(nextUser));
        return { twoFactorRequired: false };
      } else {
        // Demo mode (no backend configured): accept any credentials, same
        // as the original mock behavior, so the preview keeps working with
        // zero setup.
        const nextUser: User = { name: "Alex Morgan", email: input.email || "alex@company.com", company: t("common.yourCompanyPlaceholder") };
        setUser(nextUser);
        localStorage.setItem(LS.user, JSON.stringify(nextUser));
        return { twoFactorRequired: false };
      }
    } finally {
      setAuthLoading(false);
    }
  }, [t]);

  const verifyLoginTwoFactor = useCallback(async (code: string) => {
    if (!twoFactorPendingToken) throw new Error("No pending login to verify");
    setAuthLoading(true);
    try {
      const result = await api.auth.verifyLogin2FA({ pendingToken: twoFactorPendingToken, code });
      setAccessToken(result.accessToken);
      const nextUser: User = {
        id: result.user.id, name: result.user.name, email: result.user.email, company: result.user.company ?? "",
        role: result.user.role, emailVerified: result.user.emailVerified,
        accountCategory: result.user.accountCategory, accountStatus: result.user.accountStatus, twoFactorEnabled: result.user.twoFactorEnabled,
      };
      setUser(nextUser);
      localStorage.setItem(LS.user, JSON.stringify(nextUser));
      setTwoFactorPendingToken(null);
    } finally {
      setAuthLoading(false);
    }
  }, [twoFactorPendingToken]);

  const cancelTwoFactorLogin = useCallback(() => setTwoFactorPendingToken(null), []);

  const register = useCallback(
    async (input: { name: string; email: string; password: string; company?: string; accountCategory?: ApiUser["accountCategory"] }) => {
      setAuthLoading(true);
      try {
        if (isBackendConfigured) {
          const result = await api.auth.register(input);
          if (!result.sessionIssued) {
            // GOVERNMENT: no session until email is verified -- nothing to
            // store locally yet, just surface the message to the caller.
            return { sessionIssued: false, message: result.message };
          }
          setAccessToken(result.accessToken);
          const nextUser: User = {
            id: result.user.id, name: result.user.name, email: result.user.email, company: result.user.company ?? "",
            role: result.user.role, emailVerified: result.user.emailVerified,
            accountCategory: result.user.accountCategory, accountStatus: result.user.accountStatus, twoFactorEnabled: result.user.twoFactorEnabled,
          };
          setUser(nextUser);
          localStorage.setItem(LS.user, JSON.stringify(nextUser));
          return { sessionIssued: true };
        } else {
          const nextUser: User = {
            name: input.name || "Alex Morgan", email: input.email || "alex@company.com", company: input.company || t("common.yourCompanyPlaceholder"),
            accountCategory: input.accountCategory ?? "INDIVIDUAL",
          };
          setUser(nextUser);
          localStorage.setItem(LS.user, JSON.stringify(nextUser));
          return { sessionIssued: true };
        }
      } finally {
        setAuthLoading(false);
      }
    },
    [t]
  );

  const logout = useCallback(() => {
    if (isBackendConfigured) {
      api.auth.logout().catch(() => {});
      setAccessToken(null);
    }
    setUser(null);
    localStorage.removeItem(LS.user);
  }, []);

  // On load, if a backend is configured and we have a persisted user, try
  // to silently restore a real session via the httpOnly refresh cookie.
  // If it fails (expired/cleared cookie), fall back to signed-out state
  // instead of showing a stale cached user with no valid session.
  useEffect(() => {
    if (!isBackendConfigured || !user) return;
    api.auth
      .refresh()
      .then((ok) => {
        if (!ok) {
          setUser(null);
          localStorage.removeItem(LS.user);
        }
      })
      .catch(() => {
        setUser(null);
        localStorage.removeItem(LS.user);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const addKyb = useCallback(
    (k: Omit<KybSubmission, "id" | "submittedAt" | "status" | "trustScore">) => {
      const submission: KybSubmission = {
        ...k,
        id: `kyb-${Date.now()}`,
        submittedAt: Date.now(),
        status: "review",
        trustScore: 78 + Math.floor(Math.random() * 14),
      };
      setKyb((p) => [submission, ...p]);
      return submission;
    },
    []
  );

  // Persist kyb submissions whenever they change, instead of manually
  // re-reading and re-writing localStorage inside addKyb.
  useEffect(() => {
    localStorage.setItem(LS.kyb, JSON.stringify(kyb));
  }, [kyb]);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((prev) => {
      const wasFavorited = prev.includes(id);
      const next = wasFavorited ? prev.filter((x) => x !== id) : [...prev, id];
      localStorage.setItem(LS.fav, JSON.stringify(next));
      if (isBackendConfigured) {
        const call = wasFavorited ? api.favorites.remove(id) : api.favorites.add(id);
        call.catch((err) => console.error("Failed to sync favorite to server:", err));
      }
      return next;
    });
  }, []);

  const toast = useCallback((message: string, type: Toast["type"] = "success") => {
    const id = Date.now() + Math.random();
    setToasts((p) => [...p, { id, message, type }]);
    setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 3600);
  }, []);

  // ---- Sensitive-action email-verification gate ----
  const openSensitiveActionGate = useCallback(() => setSensitiveActionGateOpen(true), []);
  const closeSensitiveActionGate = useCallback(() => setSensitiveActionGateOpen(false), []);

  const requestSensitiveActionOtp = useCallback(async () => {
    await api.auth.requestOtp();
  }, []);

  const verifySensitiveActionOtp = useCallback(async (code: string) => {
    await api.auth.verifyOtp(code);
    setUser((prev) => (prev ? { ...prev, emailVerified: true } : prev));
    setSensitiveActionGateOpen(false);
    toast(t("dashboard.welcomeToast"));
  }, [t, toast]);

  // ---- Enterprise mandatory 2FA setup ----
  const openTwoFactorSetup = useCallback(() => setTwoFactorSetupOpen(true), []);
  const closeTwoFactorSetup = useCallback(() => setTwoFactorSetupOpen(false), []);

  // Registers this provider as the single global listener for the three
  // account-policy error codes (see accountPolicy.ts / api.ts). Any api
  // call anywhere in the app that comes back 403 EMAIL_VERIFICATION_REQUIRED
  // or TWO_FACTOR_SETUP_REQUIRED automatically opens the matching modal --
  // callers don't need to catch these themselves.
  useEffect(() => {
    onAccountPolicyError((code, message) => {
      if (code === "EMAIL_VERIFICATION_REQUIRED") {
        setSensitiveActionGateMessage(message);
        setSensitiveActionGateOpen(true);
      } else if (code === "TWO_FACTOR_SETUP_REQUIRED") {
        setTwoFactorSetupOpen(true);
      } else if (code === "ACCOUNT_PENDING_APPROVAL") {
        toast(message, "info");
      }
    });
    return () => onAccountPolicyError(null);
  }, [toast]);

  // Someone can still land here with a reserve-language link (?lang=zh, an
  // old bookmark, a shared URL, etc.) even though the switcher only ever
  // offers the four active European languages. Rather than silently
  // ignoring it or crashing, we keep the visitor on their current/active
  // language and show a brief, positive explanation instead — the language
  // is real and already built, just not activated for this launch stage
  // (see /roadmap). Runs once on mount; doesn't fight the user if they
  // deliberately switch languages afterwards.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const requested = new URLSearchParams(window.location.search).get("lang");
    if (requested && isReserveLang(requested)) {
      toast(t("common.reserveLanguageNotice", { lang: requested.toUpperCase() }), "info");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        dir,
        t,
        theme,
        toggleTheme,
        aiMode,
        toggleAi,
        user,
        authLoading,
        login,
        register,
        logout,
        kyb,
        addKyb,
        favorites,
        toggleFavorite,
        toasts,
        toast,
        twoFactorPendingToken,
        verifyLoginTwoFactor,
        cancelTwoFactorLogin,
        sensitiveActionGateOpen,
        sensitiveActionGateMessage,
        openSensitiveActionGate,
        closeSensitiveActionGate,
        requestSensitiveActionOtp,
        verifySensitiveActionOtp,
        twoFactorSetupOpen,
        openTwoFactorSetup,
        closeTwoFactorSetup,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
