import { useEffect, Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AppProvider, useApp } from "./context";
import { TenantBrandingProvider } from "./lib/tenantBranding";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { CookieConsent } from "./components/CookieConsent";
import RouteAnnouncer from "./components/RouteAnnouncer";
import ErrorBoundary from "./components/ErrorBoundary";
import { CheckCircle2, Info, AlertCircle } from "lucide-react";

// Route-level code splitting: each page ships as its own chunk and is only
// downloaded when a visitor actually navigates to it, instead of everyone
// paying for every page's JS on first load.
const Home = lazy(() => import("./pages/Home"));
const Companies = lazy(() => import("./pages/Companies"));
const CompanyDetail = lazy(() => import("./pages/CompanyDetail"));
const KYB = lazy(() => import("./pages/KYB"));
const DealRooms = lazy(() => import("./pages/DealRooms"));
const Intelligence = lazy(() => import("./pages/Intelligence"));
const Pricing = lazy(() => import("./pages/Pricing"));
const Security = lazy(() => import("./pages/Security"));
const About = lazy(() => import("./pages/About"));
const Roadmap = lazy(() => import("./pages/Roadmap"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Commitments = lazy(() => import("./pages/Commitments"));
const GovernmentWizard = lazy(() => import("./pages/GovernmentWizard"));
const MyApplication = lazy(() => import("./pages/MyApplication"));
const CompliancePrivacy = lazy(() => import("./pages/CompliancePrivacy"));
const Methodology = lazy(() => import("./pages/Methodology"));
const ConsentSettings = lazy(() => import("./pages/ConsentSettings"));

// Overlays that are not part of first paint. AIAssistant is a floating
// widget, and both modals render null until something triggers them --
// keeping them in the entry bundle meant every visitor downloaded code
// most of them never execute. Suspense fallback is null because there is
// nothing meaningful to show while a not-yet-open modal loads.
const AIAssistant = lazy(() => import("./components/AIAssistant"));
const SensitiveActionGateModal = lazy(() => import("./components/SensitiveActionGateModal"));
const TwoFactorSetupModal = lazy(() => import("./components/TwoFactorSetupModal"));
const Feedback = lazy(() => import("./pages/Feedback"));
const Status = lazy(() => import("./pages/Status"));
const QuickStart = lazy(() => import("./pages/QuickStart"));
const InvitePartners = lazy(() => import("./pages/InvitePartners"));
const InvitationAccept = lazy(() => import("./pages/InvitationAccept"));
const Terms = lazy(() => import("./pages/Terms"));
const Signals = lazy(() => import("./pages/Signals"));
const Academy = lazy(() => import("./pages/Academy"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Apply = lazy(() => import("./pages/Apply"));
const Admin = lazy(() => import("./pages/Admin"));
const ForgotPassword = lazy(() => import("./pages/ForgotPassword"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const VerifyEmail = lazy(() => import("./pages/VerifyEmail"));
const NotFound = lazy(() => import("./pages/NotFound"));

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [pathname]);
  return null;
}

function ToastHost() {
  const { toasts } = useApp();
  return (
    <div
      className="fixed bottom-5 left-1/2 z-[60] flex -translate-x-1/2 flex-col items-center gap-2"
      // Toasts are the app's main dynamic feedback channel (saved,
      // approved, error). Without a live region a screen-reader user gets
      // no indication anything happened at all. "polite" rather than
      // "assertive" so it waits for a pause instead of interrupting
      // mid-sentence; role="status" carries the same meaning for older AT
      // that predates aria-live support.
      role="status"
      aria-live="polite"
      aria-atomic="false"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className="anim-slide-up flex items-center gap-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-solid)] px-4 py-3 text-sm shadow-2xl backdrop-blur-xl"
        >
          {t.type === "success" && <CheckCircle2 className="h-4 w-4 text-emerald-trust" />}
          {t.type === "info" && <Info className="h-4 w-4 text-cyan-glow" />}
          {t.type === "error" && <AlertCircle className="h-4 w-4 text-rose-400" />}
          {t.message}
        </div>
      ))}
    </div>
  );
}

function PageFallback() {
  return (
    <div className="grid min-h-[60vh] place-items-center">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-[var(--border-strong)] border-t-cyan-glow" />
    </div>
  );
}

function Shell() {
  const { t } = useApp();
  return (
    <>
      <div className="app-bg" />
      <div className="grid-overlay" />
      <ScrollToTop />
      <a href="#main-content" className="skip-link">
        {t("a11y.skipToContent")}
      </a>
      <Header />
      <RouteAnnouncer />
      <main id="main-content" className="min-h-screen">
        <ErrorBoundary>
          <Suspense fallback={<PageFallback />}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/companies" element={<Companies />} />
              <Route path="/companies/:id" element={<CompanyDetail />} />
              <Route path="/kyb" element={<KYB />} />
              <Route path="/deals" element={<DealRooms />} />
              <Route path="/intelligence" element={<Intelligence />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/security" element={<Security />} />
              <Route path="/about" element={<About />} />
              <Route path="/roadmap" element={<Roadmap />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/commitments" element={<Commitments />} />
              <Route path="/apply/government/wizard" element={<GovernmentWizard />} />
              <Route path="/my-application" element={<MyApplication />} />
              <Route path="/compliance" element={<CompliancePrivacy />} />
              <Route path="/methodology" element={<Methodology />} />
              <Route path="/consent-settings" element={<ConsentSettings />} />
              <Route path="/feedback" element={<Feedback />} />
              <Route path="/status" element={<Status />} />
              <Route path="/quick-start" element={<QuickStart />} />
              <Route path="/invite-partners" element={<InvitePartners />} />
              <Route path="/invite/:token" element={<InvitationAccept />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/signals" element={<Signals />} />
              <Route path="/academy" element={<Academy />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/apply/:tier" element={<Apply />} />
              <Route path="/apply" element={<Apply />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/verify-email" element={<VerifyEmail />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </ErrorBoundary>
      </main>
      <Footer />
      <Suspense fallback={null}>
        <AIAssistant />
        <SensitiveActionGateModal />
        <TwoFactorSetupModal />
      </Suspense>
      <CookieConsent />
      <ToastHost />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <TenantBrandingProvider>
        <BrowserRouter>
          <Shell />
        </BrowserRouter>
      </TenantBrandingProvider>
    </AppProvider>
  );
}
