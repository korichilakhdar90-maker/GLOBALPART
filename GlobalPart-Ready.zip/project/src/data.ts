export interface Country {
  code: string;
  name: string;
  flag: string;
  region: string;
}

export const COUNTRIES: Country[] = [
  { code: "US", name: "United States", flag: "🇺🇸", region: "North America" },
  { code: "CA", name: "Canada", flag: "🇨🇦", region: "North America" },
  { code: "MX", name: "Mexico", flag: "🇲🇽", region: "North America" },
  { code: "BR", name: "Brazil", flag: "🇧🇷", region: "South America" },
  { code: "AR", name: "Argentina", flag: "🇦🇷", region: "South America" },
  { code: "CL", name: "Chile", flag: "🇨🇱", region: "South America" },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧", region: "Europe" },
  { code: "DE", name: "Germany", flag: "🇩🇪", region: "Europe" },
  { code: "FR", name: "France", flag: "🇫🇷", region: "Europe" },
  { code: "IT", name: "Italy", flag: "🇮🇹", region: "Europe" },
  { code: "ES", name: "Spain", flag: "🇪🇸", region: "Europe" },
  { code: "NL", name: "Netherlands", flag: "🇳🇱", region: "Europe" },
  { code: "SE", name: "Sweden", flag: "🇸🇪", region: "Europe" },
  { code: "CH", name: "Switzerland", flag: "🇨🇭", region: "Europe" },
  { code: "PL", name: "Poland", flag: "🇵🇱", region: "Europe" },
  { code: "TR", name: "Türkiye", flag: "🇹🇷", region: "Europe" },
  { code: "IE", name: "Ireland", flag: "🇮🇪", region: "Europe" },
  { code: "AE", name: "United Arab Emirates", flag: "🇦🇪", region: "GCC" },
  { code: "SA", name: "Saudi Arabia", flag: "🇸🇦", region: "GCC" },
  { code: "QA", name: "Qatar", flag: "🇶🇦", region: "GCC" },
  { code: "KW", name: "Kuwait", flag: "🇰🇼", region: "GCC" },
  { code: "BH", name: "Bahrain", flag: "🇧🇭", region: "GCC" },
  { code: "OM", name: "Oman", flag: "🇴🇲", region: "GCC" },
  { code: "EG", name: "Egypt", flag: "🇪🇬", region: "North Africa" },
  { code: "MA", name: "Morocco", flag: "🇲🇦", region: "North Africa" },
  { code: "DZ", name: "Algeria", flag: "🇩🇿", region: "North Africa" },
  { code: "TN", name: "Tunisia", flag: "🇹🇳", region: "North Africa" },
  { code: "ZA", name: "South Africa", flag: "🇿🇦", region: "Africa" },
  { code: "NG", name: "Nigeria", flag: "🇳🇬", region: "Africa" },
  { code: "KE", name: "Kenya", flag: "🇰🇪", region: "Africa" },
  { code: "CN", name: "China", flag: "🇨🇳", region: "Asia" },
  { code: "JP", name: "Japan", flag: "🇯🇵", region: "Asia" },
  { code: "KR", name: "South Korea", flag: "🇰🇷", region: "Asia" },
  { code: "IN", name: "India", flag: "🇮🇳", region: "Asia" },
  { code: "SG", name: "Singapore", flag: "🇸🇬", region: "Southeast Asia" },
  { code: "MY", name: "Malaysia", flag: "🇲🇾", region: "Southeast Asia" },
  { code: "ID", name: "Indonesia", flag: "🇮🇩", region: "Southeast Asia" },
  { code: "TH", name: "Thailand", flag: "🇹🇭", region: "Southeast Asia" },
  { code: "VN", name: "Vietnam", flag: "🇻🇳", region: "Southeast Asia" },
  { code: "PH", name: "Philippines", flag: "🇵🇭", region: "Southeast Asia" },
  { code: "HK", name: "Hong Kong", flag: "🇭🇰", region: "Asia" },
  { code: "AU", name: "Australia", flag: "🇦🇺", region: "Oceania" },
  { code: "NZ", name: "New Zealand", flag: "🇳🇿", region: "Oceania" },
  { code: "RU", name: "Russia", flag: "🇷🇺", region: "Eurasia" },
  { code: "IL", name: "Israel", flag: "🇮🇱", region: "Middle East" },
];

export const INDUSTRIES = [
  "Technology",
  "Manufacturing",
  "Energy & Renewables",
  "Logistics & Supply Chain",
  "Finance & Fintech",
  "Pharmaceuticals",
  "Construction & Materials",
  "Automotive",
  "Aerospace & Defense",
  "Agriculture & AgriTech",
  "Food & Beverage",
  "Textiles & Apparel",
  "Mining & Metals",
  "Telecommunications",
  "Biotechnology",
  "Electronics",
];

// Maps each canonical (English, data-matching) industry name to a
// translation key, so the UI can display a localized label everywhere
// while filter/search logic keeps matching the stable English value.
export const INDUSTRY_LABEL_KEY: Record<string, string> = {
  "Technology": "industry.technology",
  "Manufacturing": "industry.manufacturing",
  "Energy & Renewables": "industry.energyRenewables",
  "Logistics & Supply Chain": "industry.logisticsSupplyChain",
  "Finance & Fintech": "industry.financeFintech",
  "Pharmaceuticals": "industry.pharmaceuticals",
  "Construction & Materials": "industry.constructionMaterials",
  "Automotive": "industry.automotive",
  "Aerospace & Defense": "industry.aerospaceDefense",
  "Agriculture & AgriTech": "industry.agricultureAgritech",
  "Food & Beverage": "industry.foodBeverage",
  "Textiles & Apparel": "industry.textilesApparel",
  "Mining & Metals": "industry.miningMetals",
  "Telecommunications": "industry.telecommunications",
  "Biotechnology": "industry.biotechnology",
  "Electronics": "industry.electronics",
};

// Same pattern for regions: canonical English value used for data
// matching/filtering, mapped to a translation key for display.
export const REGION_LABEL_KEY: Record<string, string> = {
  All: "common.filter.all",
  Europe: "region.europe",
  "North America": "region.northAmerica",
  Asia: "region.asia",
  "Southeast Asia": "region.southeastAsia",
  GCC: "region.gcc",
  Africa: "region.africa",
  "South America": "region.southAmerica",
};

export const TAG_LABEL_KEY: Record<string, string> = {
  "KYB Verified": "tag.kybVerified",
  "Verified": "tag.verifiedPending",
  "Export-Ready": "tag.exportReady",
};

export const COMPANY_PREFIXES = [
  "Nexora", "Vertex", "Quantum", "Aurora", "Helix", "Stellar", "Atlas", "Zenith",
  "Apex", "Orbit", "Nova", "Pinnacle", "Cobalt", "Meridian", "Solstice", "Vanguard",
  "Catalyst", "Summit", "Beacon", "Horizon", "Pioneer", "Crestline", "Ironclad",
  "Lumen", "Forge", "Cipher", "Polaris", "Equinox", "Granite", "Onyx", "Sapphire",
  "Verdant", "Azure", "Crimson", "Saffron", "Indigo", "Emerald", "Amber", "Titan",
  "Aramco", "Stenama", "Sinopec", "Cosco", "Maersk", "Bayer", "Siemens", "Honeywell",
];

const SUFFIXES = ["Global", "Industries", "Systems", "Group", "Technologies", "Partners", "Trade", "International", "Solutions", "Holdings", "Logistics", "Dynamics"];

export const DESCRIPTIONS: Record<string, string> = {
  Technology: "A leading software and cloud innovator delivering enterprise digital transformation across global markets.",
  Manufacturing: "Precision manufacturer of industrial components with a fully certified supply chain and global export capacity.",
  "Energy & Renewables": "Renewable energy developer advancing solar, wind, and green hydrogen projects at utility scale.",
  "Logistics & Supply Chain": "End-to-end logistics operator managing freight, warehousing, and customs across 40+ corridors.",
  "Finance & Fintech": "Regulated fintech providing cross-border payments, trade finance, and embedded banking infrastructure.",
  Pharmaceuticals: "GMP-certified pharmaceutical producer exporting generic and specialty medicines worldwide.",
  "Construction & Materials": "Integrated construction and building materials supplier for mega-projects and infrastructure.",
  Automotive: "Automotive parts and EV component manufacturer serving Tier-1 OEMs globally.",
  "Aerospace & Defense": "Aerospace engineering firm producing precision components to AS9100 standards.",
  "Agriculture & AgriTech": "AgriTech producer optimizing yields with smart farming and sustainable practices.",
  "Food & Beverage": "Food producer with HACCP and ISO 22000 certified export operations.",
  "Textiles & Apparel": "Vertically integrated textile manufacturer with ethical and sustainable sourcing.",
  "Mining & Metals": "Mining and metals processor supplying critical raw materials to global industry.",
  Telecommunications: "Telecommunications infrastructure provider enabling next-generation connectivity.",
  Biotechnology: "Biotech research and manufacturing organization advancing diagnostics and therapeutics.",
  Electronics: "Electronics manufacturer producing semiconductors, PCBs, and smart devices at scale.",
};

export interface Company {
  id: string;
  name: string;
  country: Country;
  industry: string;
  trustScore: number;
  verified: boolean;
  // Claimable Profiles: "DIRECTORY_LISTED" (unclaimed, imported from public
  // registers) vs "VERIFIED_PARTNER" (completed KYB + Trust Desk). Optional
  // because the procedurally-generated demo companies below don't model
  // this distinction -- they default to VERIFIED_PARTNER (all `verified`
  // demo rows) or DIRECTORY_LISTED, matching their `verified` boolean, so
  // existing demo UI keeps behaving the same. Real API companies always
  // set this from the actual database column.
  profileStatus?: "DIRECTORY_LISTED" | "VERIFIED_PARTNER";
  employees: string;
  revenue: string;
  founded: number;
  description: string;
  tags: string[];
  matchScore: number;
  deals: number;
}

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

export const COMPANIES: Company[] = (() => {
  const list: Company[] = [];
  const sizes = ["11-50", "51-200", "201-500", "501-1,000", "1,001-5,000", "5,000+"];
  // Directory geographic scope: Europe + the explicit Turkey exception
  // (Turkey is already tagged region "Europe" above per that product
  // decision). This demo generator is fake/procedural data -- see the
  // Company.profileStatus doc comment -- but the geographic restriction
  // itself is real and matches server/src/utils/geoScope.ts exactly, so
  // the browse experience reflects the actual directory policy even
  // before a real backend/database is connected.
  const scopedCountries = COUNTRIES.filter((c) => c.region === "Europe");
  for (let i = 0; i < 108; i++) {
    const seed = hash(`company-${i}-globalpart`);
    const prefix = pick(COMPANY_PREFIXES, seed >> 3);
    const suffix = pick(SUFFIXES, seed >> 7);
    const name = `${prefix} ${suffix}`;
    const country = pick(scopedCountries, seed >> 5);
    const industry = pick(INDUSTRIES, seed >> 2);
    const trust = 62 + (seed % 38);
    const verified = trust >= 74;
    const employees = pick(sizes, seed >> 4);
    const revBase = (seed % 480) + 12;
    const revenue = `$${revBase}M`;
    const founded = 1968 + (seed % 55);
    const deals = 4 + (seed % 90);
    const match = 78 + (seed % 22);
    list.push({
      id: `co-${i + 1}`,
      name,
      country,
      industry,
      trustScore: trust,
      verified,
      profileStatus: verified ? "VERIFIED_PARTNER" : "DIRECTORY_LISTED",
      employees,
      revenue,
      founded,
      description: DESCRIPTIONS[industry],
      tags: [industry.split(" ")[0], country.region, verified ? "KYB Verified" : "Verified", "Export-Ready"],
      matchScore: match,
      deals,
    });
  }
  return list;
})();

export interface Deal {
  id: string;
  partner: string;
  flag: string;
  title: string;
  value: string;
  stage: "Negotiation" | "Escrow" | "Signed" | "Milestone" | "Completed";
  progress: number;
  updated: string;
  industry: string;
}
