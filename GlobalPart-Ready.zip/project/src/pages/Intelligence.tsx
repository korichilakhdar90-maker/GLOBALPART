import { useState } from "react";
import {
  TrendingUp, Globe2, Sparkles, Activity, Target, Zap,
  RefreshCw, Download, ArrowUpRight, Brain, Layers,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal, Counter, SampleDataBanner } from "../ui";
import { COUNTRIES, INDUSTRY_LABEL_KEY } from "../data";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";

const TREND = [
  { mKey: "month.jan", v: 42 }, { mKey: "month.feb", v: 48 }, { mKey: "month.mar", v: 55 }, { mKey: "month.apr", v: 51 },
  { mKey: "month.may", v: 67 }, { mKey: "month.jun", v: 78 }, { mKey: "month.jul", v: 72 }, { mKey: "month.aug", v: 95 },
  { mKey: "month.sep", v: 110 }, { mKey: "month.oct", v: 124 }, { mKey: "month.nov", v: 138 }, { mKey: "month.dec", v: 162 },
];

const SECTORS = [
  { name: "Energy & Renewables", score: 94, trend: "+24%" },
  { name: "Finance & Fintech", score: 88, trend: "+18%" },
  { name: "Technology", score: 91, trend: "+21%" },
  { name: "Pharmaceuticals", score: 79, trend: "+12%" },
  { name: "Logistics & Supply Chain", score: 85, trend: "+15%" },
  { name: "Agriculture & AgriTech", score: 72, trend: "+9%" },
];

const OPPORTUNITIES = [
  { country: COUNTRIES.find((c) => c.code === "AE")!, score: 96, deals: 412 },
  { country: COUNTRIES.find((c) => c.code === "DE")!, score: 93, deals: 388 },
  { country: COUNTRIES.find((c) => c.code === "SG")!, score: 91, deals: 351 },
  { country: COUNTRIES.find((c) => c.code === "US")!, score: 89, deals: 524 },
  { country: COUNTRIES.find((c) => c.code === "IN")!, score: 87, deals: 467 },
  { country: COUNTRIES.find((c) => c.code === "BR")!, score: 83, deals: 298 },
];

const INSIGHT_KEYS = ["intel.insight1", "intel.insight2", "intel.insight3", "intel.insight4"];

export default function Intelligence() {
  const { t, toast, lang } = useApp();
  const [insight, setInsight] = useState(0);
  const [aiInsightText, setAiInsightText] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  const generate = () => {
    setGenerating(true);
    if (isBackendConfigured) {
      const context = `Top sectors: ${SECTORS.map((s) => `${t(INDUSTRY_LABEL_KEY[s.name] ?? s.name)} (${s.trend})`).join(", ")}. Top opportunity markets: ${OPPORTUNITIES.map((o) => `${o.country.name} (score ${o.score})`).join(", ")}.`;
      api.ai
        .chat([
          {
            role: "user",
            content: `Given this B2B market data: ${context}\nWrite exactly one punchy, single-sentence market insight for a B2B partnership platform dashboard, starting with a relevant emoji. Respond in this language: ${lang}. No preamble, just the sentence.`,
          },
        ])
        .then(({ reply }) => {
          setAiInsightText(reply.trim());
          toast(t("intel.insightGenerated"));
        })
        .catch(() => toast(t("intel.aiUnreachable"), "error"))
        .finally(() => setGenerating(false));
    } else {
      setTimeout(() => {
        setInsight((i) => (i + 1) % INSIGHT_KEYS.length);
        setGenerating(false);
        toast(t("intel.insightGenerated"));
      }, 1200);
    }
  };

  const displayedInsight = isBackendConfigured ? aiInsightText ?? t(INSIGHT_KEYS[0]) : t(INSIGHT_KEYS[insight]);
  const max = Math.max(...TREND.map((d) => d.v));

  return (
    <div className="pt-28">
      <Seo title={t("seo.intelligence.title")} description={t("seo.intelligence.desc")} />
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute right-1/3 top-0 h-64 w-96 rounded-full bg-cyan-glow/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("intel.eyebrow")}
              title={<>{t("section.intel.title")}</>}
              subtitle={t("section.intel.subtitle")}
            />
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-20">
        <SampleDataBanner textKey="common.sampleDataBanner" />

        {/* KPI cards */}
        <Reveal>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Activity, labelKey: "intel.kpi.dealVolume", val: 8.4, p: "$", s: "B", dec: 1 },
              { icon: Target, labelKey: "intel.kpi.avgOpportunity", val: 87, s: "/100" },
              { icon: Globe2, labelKey: "intel.kpi.activeMarkets", val: 45, s: "" },
              { icon: Zap, labelKey: "intel.kpi.aiConfidence", val: 94, s: "%" },
            ].map((k) => (
              <div key={k.labelKey} className="card card-hover p-5">
                <div className="flex items-center justify-between">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-brand-600/15 text-cyan-glow">
                    <k.icon className="h-5 w-5" />
                  </div>
                  <span className="chip chip-gold text-[0.7rem]">{t("common.sample")}</span>
                </div>
                <div className="mt-3 font-display text-2xl font-bold">
                  <Counter value={k.val} prefix={k.p || ""} suffix={k.s || ""} decimals={k.dec || 0} />
                </div>
                <div className="text-xs text-[var(--text-muted)]">{t(k.labelKey)}</div>
              </div>
            ))}
          </div>
        </Reveal>

        {/* Charts row */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          {/* Trend chart */}
          <Reveal>
            <div className="card p-6">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="font-display font-semibold">{t("intel.dealFlow.title")}</h3>
                  <p className="text-xs text-[var(--text-muted)]">{t("intel.dealFlow.subtitle")}</p>
                </div>
                <button onClick={() => toast(t("intel.reportExported"))} className="btn btn-ghost btn-sm">
                  <Download className="h-4 w-4" /> {t("common.export")}
                </button>
              </div>
              <div className="flex h-56 items-end gap-1.5">
                {TREND.map((d, i) => (
                  <div key={d.mKey} className="group flex flex-1 flex-col items-center gap-2">
                    <div className="relative flex w-full flex-1 items-end">
                      <div
                        className="w-full rounded-t-md bg-gradient-to-t from-brand-600/40 to-cyan-glow transition-all duration-300 group-hover:from-brand-600/70 group-hover:to-cyan-glow"
                        style={{ height: `${(d.v / max) * 100}%`, animationDelay: `${i * 40}ms` }}
                      >
                        <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[0.65rem] font-bold opacity-0 transition group-hover:opacity-100">
                          {d.v}B
                        </span>
                      </div>
                    </div>
                    <span className="text-[0.6rem] text-[var(--text-faint)]">{t(d.mKey)}</span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* AI insights */}
          <Reveal delay={100}>
            <div className="card ring-gradient flex h-full flex-col p-6">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="flex items-center gap-2 font-display font-semibold">
                  <Brain className="h-5 w-5 text-cyan-glow" /> {t("intel.aiInsights")}
                </h3>
                <button onClick={generate} disabled={generating} className="btn btn-ghost btn-sm">
                  <RefreshCw className={cn("h-4 w-4", generating && "animate-spin")} />
                  {generating ? t("common.generating") : t("common.refresh")}
                </button>
              </div>
              <div className="flex flex-1 items-center">
                {generating ? (
                  <div className="flex w-full flex-col items-center gap-3 py-8">
                    <Sparkles className="h-8 w-8 animate-pulse text-cyan-glow" />
                    <p className="text-sm text-[var(--text-muted)]">{t("intel.analyzingDataPoints")}</p>
                  </div>
                ) : (
                  <p className="anim-slide-up rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-sm leading-relaxed">
                    {displayedInsight}
                  </p>
                )}
              </div>
              <div className="mt-3 flex gap-1.5">
                {INSIGHT_KEYS.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setInsight(i)}
                    className={cn("h-1.5 flex-1 rounded-full transition", i === insight ? "bg-cyan-glow" : "bg-[var(--surface-2)]")}
                  />
                ))}
              </div>
            </div>
          </Reveal>
        </div>

        {/* Sectors + Opportunities */}
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          {/* Sector trends */}
          <Reveal>
            <div className="card p-6">
              <h3 className="mb-4 flex items-center gap-2 font-display font-semibold">
                <Layers className="h-5 w-5 text-violet-glow" /> {t("intel.sectorTrends")}
              </h3>
              <div className="space-y-3">
                {SECTORS.map((s, i) => (
                  <div key={s.name}>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="font-medium">{t(INDUSTRY_LABEL_KEY[s.name] ?? s.name)}</span>
                      <span className="flex items-center gap-2">
                        <span className="chip chip-emerald text-[0.65rem]">{s.trend}</span>
                        <span className="font-bold">{s.score}</span>
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-[var(--surface-2)]">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-violet-glow to-cyan-glow"
                        style={{ width: `${s.score}%`, transition: "width 1.2s ease", transitionDelay: `${i * 80}ms` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Opportunity map */}
          <Reveal delay={100}>
            <div className="card p-6">
              <h3 className="mb-4 flex items-center gap-2 font-display font-semibold">
                <Target className="h-5 w-5 text-emerald-trust" /> {t("intel.topOpportunityMarkets")}
              </h3>
              <div className="space-y-2">
                {OPPORTUNITIES.map((o, i) => (
                  <div key={o.country.code} className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                    <span className="text-2xl">{o.country.flag}</span>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold">{o.country.name}</span>
                        <span className="font-display font-bold text-emerald-trust">{o.score}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-2">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[var(--surface-2)]">
                          <div className="h-full rounded-full bg-gradient-to-r from-emerald-trust to-cyan-glow" style={{ width: `${o.score}%` }} />
                        </div>
                        <span className="text-[0.65rem] text-[var(--text-muted)]">{t("intel.dealsCount", { count: String(o.deals) })}</span>
                      </div>
                    </div>
                    {i === 0 && <span className="chip chip-gold text-[0.65rem]">#1</span>}
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>

        {/* Benchmark strip */}
        <Reveal delay={120}>
          <div className="mt-6 card flex flex-wrap items-center justify-between gap-4 p-6">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-brand-600/15 text-cyan-glow">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-display font-semibold">{t("intel.competitorBenchmarking")}</h3>
                <p className="text-sm text-[var(--text-muted)]">{t("intel.competitorBenchmarkingDesc")}</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              {[
                { lKey: "intel.benchmark.yourRank", v: t("intel.benchmark.top12") },
                { lKey: "intel.benchmark.marketAvg", v: "67" },
                { lKey: "intel.benchmark.yourScore", v: "92" },
              ].map((s) => (
                <div key={s.lKey} className="text-center">
                  <div className="font-display text-xl font-bold gradient-text">{s.v}</div>
                  <div className="text-xs text-[var(--text-muted)]">{t(s.lKey)}</div>
                </div>
              ))}
            </div>
            <button onClick={() => toast(t("intel.benchmarkGenerated"))} className="btn btn-primary btn-sm">
              {t("intel.fullReport")} <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
