import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Check, Sparkles, Crown, Rocket, Building2, Zap, Plug, FileText,
  Shield, ArrowRight, Star, Globe2, TrendingUp,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";

const CURRENCIES = { USD: "$", EUR: "€", GBP: "£" };
type Cur = keyof typeof CURRENCIES;
const RATE: Record<Cur, number> = { USD: 1, EUR: 0.92, GBP: 0.79 };

const PLANS = [
  {
    nameKey: "pricing.plan.starter.name", icon: Rocket, tagKey: "pricing.plan.starter.tag", price: 0,
    descKey: "pricing.plan.starter.desc",
    featureKeys: ["pricing.plan.starter.feature1", "pricing.plan.starter.feature2", "pricing.plan.starter.feature3", "pricing.plan.starter.feature4", "pricing.plan.starter.feature5"],
    ctaKey: "pricing.plan.starter.cta", accent: false, isEnterprise: false,
  },
  {
    nameKey: "pricing.plan.professional.name", icon: Zap, tagKey: "pricing.plan.professional.tag", price: 499,
    descKey: "pricing.plan.professional.desc",
    featureKeys: ["pricing.plan.professional.feature1", "pricing.plan.professional.feature2", "pricing.plan.professional.feature3", "pricing.plan.professional.feature4", "pricing.plan.professional.feature5", "pricing.plan.professional.feature6", "pricing.plan.professional.feature7"],
    ctaKey: "pricing.plan.professional.cta", accent: true, isEnterprise: false,
  },
  {
    nameKey: "pricing.plan.enterprise.name", icon: Crown, tagKey: "pricing.plan.enterprise.tag", price: null,
    descKey: "pricing.plan.enterprise.desc",
    featureKeys: ["pricing.plan.enterprise.feature1", "pricing.plan.enterprise.feature2", "pricing.plan.enterprise.feature3", "pricing.plan.enterprise.feature4", "pricing.plan.enterprise.feature5", "pricing.plan.enterprise.feature6", "pricing.plan.enterprise.feature7"],
    ctaKey: "pricing.plan.enterprise.cta", accent: false, isEnterprise: true,
  },
];

const REVENUE = [
  { icon: Zap, tKey: "pricing.revenue.saas.title", dKey: "pricing.revenue.saas.desc" },
  { icon: Shield, tKey: "pricing.revenue.kyb.title", dKey: "pricing.revenue.kyb.desc" },
  { icon: TrendingUp, tKey: "pricing.revenue.dealFees.title", dKey: "pricing.revenue.dealFees.desc" },
  { icon: FileText, tKey: "pricing.revenue.escrow.title", dKey: "pricing.revenue.escrow.desc" },
  { icon: Globe2, tKey: "pricing.revenue.whiteLabel.title", dKey: "pricing.revenue.whiteLabel.desc" },
  { icon: Plug, tKey: "pricing.revenue.api.title", dKey: "pricing.revenue.api.desc" },
];

const SEGMENTS = [
  { icon: Building2, tKey: "pricing.segment.smes.title", dKey: "pricing.segment.smes.desc" },
  { icon: Crown, tKey: "pricing.segment.corporations.title", dKey: "pricing.segment.corporations.desc" },
  { icon: Globe2, tKey: "pricing.segment.government.title", dKey: "pricing.segment.government.desc" },
];

export default function Pricing() {
  const { t, toast } = useApp();
  const [cur, setCur] = useState<Cur>("USD");
  const [annual, setAnnual] = useState(true);

  const fmt = (price: number) => {
    const v = Math.round(price * RATE[cur] * (annual ? 10 : 1));
    return `${CURRENCIES[cur]}${v.toLocaleString()}`;
  };

  return (
    <div className="pt-28">
      <Seo title={t("seo.pricing.title")} description={t("seo.pricing.desc")} />
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-[40rem] -translate-x-1/2 rounded-full bg-brand-500/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("pricing.eyebrow")}
              title={<>{t("section.pricing.title")}</>}
              subtitle={t("section.pricing.subtitle")}
            />
          </Reveal>

          {/* Toggles */}
          <Reveal delay={100}>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <div className="flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
                {(Object.keys(CURRENCIES) as Cur[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setCur(c)}
                    className={cn("rounded-lg px-4 py-2 text-sm font-medium transition", cur === c ? "bg-brand-600 text-white" : "text-[var(--text-muted)]")}
                  >
                    {CURRENCIES[c]} {c}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setAnnual((a) => !a)}
                className="flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm font-medium"
              >
                <span className={cn("relative h-5 w-9 rounded-full transition", annual ? "bg-emerald-trust" : "bg-[var(--surface-2)]")}>
                  <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white transition", annual ? "left-[1.2rem]" : "left-0.5")} />
                </span>
                {t("pricing.annual")} <span className="chip chip-emerald text-[0.65rem]">{t("pricing.save17")}</span>
              </button>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-12">
        <div className="grid gap-6 lg:grid-cols-3">
          {PLANS.map((p, i) => (
            <Reveal key={p.nameKey} delay={i * 90}>
              <div className={cn("card relative flex h-full flex-col p-6 md:p-7", p.accent && "ring-gradient glow-blue")}>
                {p.accent && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="chip chip-gold shadow-lg">
                      <Star className="h-3 w-3 fill-current" /> {t(p.tagKey)}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <div className={cn("grid h-11 w-11 place-items-center rounded-xl", p.accent ? "bg-gradient-to-br from-brand-600 to-cyan-glow text-white" : "bg-[var(--surface-2)] text-cyan-glow")}>
                    <p.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-bold">{t(p.nameKey)}</h3>
                    {!p.accent && <span className="text-xs text-[var(--text-muted)]">{t(p.tagKey)}</span>}
                  </div>
                </div>
                <p className="mt-4 text-sm text-[var(--text-muted)]">{t(p.descKey)}</p>
                <div className="mt-5">
                  {p.price === null ? (
                    <div className="font-display text-4xl font-bold">{t("pricing.custom")}</div>
                  ) : p.price === 0 ? (
                    <div className="font-display text-4xl font-bold">{t("pricing.free")}</div>
                  ) : (
                    <div className="flex items-end gap-1">
                      <span className="font-display text-4xl font-bold">{fmt(p.price)}</span>
                      <span className="mb-1 text-sm text-[var(--text-muted)]">/{annual ? t("pricing.perYear") : t("pricing.perMonth")}</span>
                    </div>
                  )}
                </div>
                <ul className="mt-5 flex-1 space-y-2.5">
                  {p.featureKeys.map((fKey) => (
                    <li key={fKey} className="flex items-start gap-2 text-sm">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-trust" />
                      <span className="text-[var(--text-muted)]">{t(fKey)}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to={p.isEnterprise ? "/security" : "/dashboard"}
                  onClick={() => toast(t("pricing.planSelected", { plan: t(p.nameKey) }))}
                  className={cn("btn mt-6 w-full", p.accent ? "btn-primary shine" : "btn-ghost")}
                >
                  {t(p.ctaKey)}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Revenue streams */}
        <Reveal delay={120}>
          <div className="mt-16">
            <h3 className="mb-6 text-center font-display text-2xl font-bold">{t("pricing.revenueStreamsHeading")}</h3>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {REVENUE.map((r) => (
                <div key={r.tKey} className="card flex items-center gap-3 p-4">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-brand-600/15 text-cyan-glow">
                    <r.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold">{t(r.tKey)}</div>
                    <div className="text-xs text-[var(--text-muted)]">{t(r.dKey)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Segments */}
        <Reveal delay={150}>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SEGMENTS.map((s) => (
              <div key={s.tKey} className="card card-hover p-5">
                <s.icon className="h-6 w-6 text-cyan-glow" />
                <h4 className="mt-3 font-display font-semibold">{t(s.tKey)}</h4>
                <p className="mt-1 text-sm text-[var(--text-muted)]">{t(s.dKey)}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <div className="ring-gradient flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[var(--border)] p-6">
              <div className="flex items-center gap-3">
                <Sparkles className="h-7 w-7 text-cyan-glow" />
                <div>
                  <h3 className="font-display text-lg font-bold">{t("pricing.tailoredPackage")}</h3>
                  <p className="text-sm text-[var(--text-muted)]">{t("pricing.tailoredPackageDesc")}</p>
                </div>
              </div>
              <Link to="/dashboard" onClick={() => toast(t("pricing.teamReachOut"))} className="btn btn-gold">
                {t("cta.connectSales")} <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
