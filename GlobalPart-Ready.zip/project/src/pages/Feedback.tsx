import { useState, type FormEvent } from "react";
import { MessageSquareText, CheckCircle2 } from "lucide-react";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";
import { api, isBackendConfigured } from "../lib/api";

export default function Feedback() {
  const { t, toast } = useApp();
  const [email, setEmail] = useState("");
  const [liked, setLiked] = useState("");
  const [issues, setIssues] = useState("");
  const [suggestions, setSuggestions] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();

    if (!isBackendConfigured) {
      const subject = encodeURIComponent("GlobalPart pilot feedback");
      const body = encodeURIComponent(`Email: ${email || "—"}\n\nWhat I liked:\n${liked || "—"}\n\nWhat I ran into:\n${issues || "—"}\n\nSuggestions:\n${suggestions || "—"}`);
      window.location.href = `mailto:hello@globalpart.io?subject=${subject}&body=${body}`;
      return;
    }

    setStatus("loading");
    try {
      await api.feedback.submit({ email: email || undefined, liked: liked || undefined, issues: issues || undefined, suggestions: suggestions || undefined });
      setStatus("done");
    } catch {
      setStatus("idle");
      toast(t("common.errorGeneric"), "error");
    }
  }

  if (status === "done") {
    return (
      <div className="grid min-h-screen place-items-center px-4 text-center">
        <Reveal>
          <div className="card ring-gradient max-w-md p-8">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-trust/15 text-emerald-trust">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h1 className="mt-4 font-display text-xl font-bold">{t("feedback.thanksTitle")}</h1>
            <p className="mt-2 text-sm text-[var(--text-muted)]">{t("feedback.thanksBody")}</p>
          </div>
        </Reveal>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("feedback.seoTitle")} description={t("feedback.seoDesc")} />
      <div className="mx-auto max-w-xl px-4">
        <Reveal>
          <SectionHeading eyebrow={t("feedback.eyebrow")} title={t("feedback.title")} subtitle={t("feedback.subtitle")} />
        </Reveal>
        <Reveal delay={0.05}>
          <form onSubmit={handleSubmit} className="card mt-8 space-y-4 p-6">
            <div className="mb-2 flex items-center gap-2 text-sm font-medium text-[var(--text-muted)]">
              <MessageSquareText className="h-4 w-4 text-cyan-glow" /> {t("feedback.formLabel")}
            </div>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("feedback.emailPlaceholder")} className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none focus:border-cyan-glow/60" />
            <textarea value={liked} onChange={(e) => setLiked(e.target.value)} placeholder={t("feedback.likedPlaceholder")} rows={2} className="w-full resize-none rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none focus:border-cyan-glow/60" />
            <textarea value={issues} onChange={(e) => setIssues(e.target.value)} placeholder={t("feedback.issuesPlaceholder")} rows={2} className="w-full resize-none rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none focus:border-cyan-glow/60" />
            <textarea value={suggestions} onChange={(e) => setSuggestions(e.target.value)} placeholder={t("feedback.suggestionsPlaceholder")} rows={2} className="w-full resize-none rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none focus:border-cyan-glow/60" />
            <button type="submit" disabled={status === "loading"} className="btn btn-primary w-full shine disabled:opacity-60">
              {status === "loading" ? t("common.pleaseWait") : t("feedback.submitButton")}
            </button>
          </form>
        </Reveal>
      </div>
    </div>
  );
}
