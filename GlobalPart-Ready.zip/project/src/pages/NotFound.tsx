import { Link } from "react-router-dom";
import { Compass, Search, ArrowRight } from "lucide-react";
import Seo from "../components/Seo";
import { useApp } from "../context";

export default function NotFound() {
  const { t } = useApp();
  return (
    <div className="grid min-h-[80vh] place-items-center px-4 pt-24 text-center">
      <Seo
        title={t("notFound.seoTitle")}
        description={t("notFound.seoDesc")}
      />
      <div>
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-brand-600/15 text-cyan-glow">
          <Compass className="h-8 w-8" />
        </div>
        <h1 className="mt-5 font-display text-3xl font-bold">{t("notFound.title")}</h1>
        <p className="mx-auto mt-2 max-w-sm text-[var(--text-muted)]">
          {t("notFound.subtitle")}
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Link to="/" className="btn btn-primary">
            {t("notFound.backHome")} <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/companies" className="btn btn-ghost">
            <Search className="h-4 w-4" /> {t("notFound.browseCompanies")}
          </Link>
        </div>
      </div>
    </div>
  );
}
