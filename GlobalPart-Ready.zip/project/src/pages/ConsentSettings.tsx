import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ShieldCheck, RotateCcw, Check, X } from "lucide-react";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";
import { readConsent, CONSENT_STORAGE_KEY, CONSENT_POLICY_VERSION, type ConsentState } from "../components/CookieConsent";

/**
 * GDPR Art. 7(3): withdrawing consent must be as easy as giving it. This
 * page is the "as easy" half — reachable from the footer on every page,
 * shows exactly what was agreed and when, and lets any non-essential
 * category be switched off in one click with no confirmation friction.
 */
export default function ConsentSettings() {
  const { t, toast } = useApp();
  const [consent, setConsent] = useState<ConsentState | null>(null);

  useEffect(() => {
    setConsent(readConsent());
  }, []);

  const update = (patch: Partial<Pick<ConsentState, "functional" | "analytics">>) => {
    const next: ConsentState = {
      necessary: true,
      functional: consent?.functional ?? false,
      analytics: consent?.analytics ?? false,
      ...patch,
      decidedAt: new Date().toISOString(),
      policyVersion: CONSENT_POLICY_VERSION,
    };
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(next));
    setConsent(next);
    toast(t("consentSettings.saved"));
  };

  const reset = () => {
    localStorage.removeItem(CONSENT_STORAGE_KEY);
    setConsent(null);
    toast(t("consentSettings.reset"));
  };

  const formatDate = (iso: string) => {
    // Intl rather than toLocaleString() with no locale, so the date
    // actually follows the user's selected platform language.
    try {
      return new Intl.DateTimeFormat(undefined, { dateStyle: "long", timeStyle: "short" }).format(new Date(iso));
    } catch {
      return iso;
    }
  };

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("consentSettings.seoTitle")} description={t("consentSettings.seoDesc")} />
      <div className="mx-auto max-w-2xl px-4">
        <Reveal>
          <SectionHeading eyebrow={t("consentSettings.eyebrow")} title={t("consentSettings.title")} subtitle={t("consentSettings.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="card mt-8 divide-y divide-[var(--border)]">
            <Row
              name={t("cookies.necessary.name")}
              desc={t("cookies.necessary.desc")}
              enabled
              locked
              lockedLabel={t("consentSettings.alwaysOn")}
            />
            <Row
              name={t("cookies.functional.name")}
              desc={t("cookies.functional.desc")}
              enabled={!!consent?.functional}
              onToggle={(v) => update({ functional: v })}
              onLabel={t("consentSettings.on")}
              offLabel={t("consentSettings.off")}
            />
            <Row
              name={t("cookies.analytics.name")}
              desc={t("cookies.analytics.desc")}
              enabled={!!consent?.analytics}
              onToggle={(v) => update({ analytics: v })}
              onLabel={t("consentSettings.on")}
              offLabel={t("consentSettings.off")}
            />
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="card mt-4 p-5">
            <h2 className="flex items-center gap-2 font-display text-sm font-bold">
              <ShieldCheck className="h-4 w-4 text-emerald-trust" /> {t("consentSettings.recordHeading")}
            </h2>
            {consent ? (
              <dl className="mt-3 space-y-1.5 text-sm">
                <div className="flex justify-between">
                  <dt className="text-[var(--text-faint)]">{t("consentSettings.decidedAt")}</dt>
                  <dd>{formatDate(consent.decidedAt)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[var(--text-faint)]">{t("consentSettings.policyVersion")}</dt>
                  <dd className="font-mono text-xs">{consent.policyVersion}</dd>
                </div>
              </dl>
            ) : (
              <p className="mt-2 text-sm text-[var(--text-muted)]">{t("consentSettings.noRecord")}</p>
            )}
            <button onClick={reset} className="btn btn-ghost btn-sm mt-4">
              <RotateCcw className="h-4 w-4" /> {t("consentSettings.resetButton")}
            </button>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="mt-6 text-center text-xs text-[var(--text-faint)]">
            {t("consentSettings.footerNote")}{" "}
            <Link to="/privacy" className="text-cyan-glow underline hover:no-underline">{t("footer.link.privacy")}</Link>
          </p>
        </Reveal>
      </div>
    </div>
  );
}

function Row({
  name, desc, enabled, locked, lockedLabel, onToggle, onLabel, offLabel,
}: {
  name: string; desc: string; enabled: boolean; locked?: boolean; lockedLabel?: string;
  onToggle?: (v: boolean) => void; onLabel?: string; offLabel?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-4 p-5">
      <div>
        <h3 className="text-sm font-semibold">{name}</h3>
        <p className="mt-0.5 text-xs text-[var(--text-muted)]">{desc}</p>
      </div>
      {locked ? (
        <span className="chip chip-emerald shrink-0 text-[0.65rem]">{lockedLabel}</span>
      ) : (
        <button
          onClick={() => onToggle?.(!enabled)}
          role="switch"
          aria-checked={enabled}
          aria-label={name}
          className={`flex shrink-0 items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
            enabled
              ? "border-emerald-trust/40 bg-emerald-trust/10 text-emerald-trust"
              : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)]"
          }`}
        >
          {enabled ? <Check className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5" />}
          {enabled ? onLabel : offLabel}
        </button>
      )}
    </div>
  );
}
