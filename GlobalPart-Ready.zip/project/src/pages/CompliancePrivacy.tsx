import { Link } from "react-router-dom";
import { ShieldCheck, FileText, Clock } from "lucide-react";
import { SectionHeading, Reveal, Logo } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";

/**
 * A general-audience overview of our data/compliance principles and the
 * real status of our legal documents. Deliberately does NOT link
 * docs/compliance/dpa-template.md -- that file is an internal, unsigned
 * draft (see its own header), and publishing it as if it were a live
 * legal document would misrepresent it. This page says plainly that the
 * DPA is in preparation instead.
 */
export default function CompliancePrivacy() {
  const { t } = useApp();

  return (
    <div className="pt-28">
      <Seo title={t("compliance.seoTitle")} description={t("compliance.seoDesc")} />
      <div className="mx-auto max-w-3xl px-4 pb-24">
        <Reveal>
          <div className="mb-8 flex justify-center"><Logo size={40} /></div>
          <SectionHeading eyebrow={t("compliance.eyebrow")} title={t("compliance.title")} subtitle={t("compliance.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-10 space-y-3">
            <div className="card flex items-start gap-3 p-5">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-trust" />
              <div>
                <h3 className="font-display text-sm font-bold">{t("compliance.principles.heading")}</h3>
                <p className="mt-1 text-sm text-[var(--text-muted)]">{t("compliance.principles.body")}</p>
              </div>
            </div>

            <div className="card flex items-start gap-3 p-5">
              <FileText className="mt-0.5 h-5 w-5 shrink-0 text-cyan-glow" />
              <div className="flex-1">
                <h3 className="font-display text-sm font-bold">{t("compliance.documents.heading")}</h3>
                <ul className="mt-2 space-y-2 text-sm">
                  <li className="flex items-center justify-between">
                    <span className="text-[var(--text-muted)]">{t("compliance.documents.privacy")}</span>
                    <Link to="/privacy" className="chip chip-emerald text-[0.65rem]">{t("compliance.status.live")}</Link>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-[var(--text-muted)]">{t("compliance.documents.commitments")}</span>
                    <Link to="/commitments" className="chip chip-emerald text-[0.65rem]">{t("compliance.status.live")}</Link>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-[var(--text-muted)]">{t("compliance.documents.dpa")}</span>
                    <span className="chip chip-gold text-[0.65rem]">{t("compliance.status.inPreparation")}</span>
                  </li>
                  <li className="flex items-center justify-between">
                    <span className="text-[var(--text-muted)]">{t("compliance.documents.terms")}</span>
                    <Link to="/terms" className="chip chip-emerald text-[0.65rem]">{t("compliance.status.live")}</Link>
                  </li>
                </ul>
              </div>
            </div>

            <div className="card flex items-start gap-3 p-5">
              <Clock className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-gold)]" />
              <div>
                <h3 className="font-display text-sm font-bold">{t("compliance.future.heading")}</h3>
                <p className="mt-1 text-sm text-[var(--text-muted)]">{t("compliance.future.body")}</p>
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <p className="mt-8 text-center text-xs text-[var(--text-faint)]">
            {t("compliance.footerNote")} <Link to="/commitments" className="text-cyan-glow hover:underline">{t("footer.link.commitments")}</Link>
          </p>
        </Reveal>
      </div>
    </div>
  );
}
