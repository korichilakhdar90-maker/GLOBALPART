import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import {
  ShieldCheck, Users, Building2, Clock, Handshake, CheckCircle2, XCircle, Loader2, History,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";

interface AdminStats {
  userCount: number;
  companyCount: number;
  pendingKyb: number;
  activeDeals: number;
}

interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: "USER" | "ADMIN";
  emailVerified: boolean;
  createdAt: string;
  subscription?: { tier: string; status: string } | null;
}

interface ChecklistState {
  bank: boolean;
  address: boolean;
  financialAudit: boolean;
  certifications: boolean;
  diplomatic: boolean;
  fscValidated: boolean;
  pscValidated: boolean;
}
const DEFAULT_CHECKLIST: ChecklistState = {
  bank: false, address: false, financialAudit: false, certifications: false, diplomatic: false, fscValidated: false, pscValidated: false,
};

interface KybQueueItem {
  id: string;
  companyName: string;
  registrationNo: string;
  countries: string;
  status: "PENDING" | "IN_REVIEW" | "APPROVED" | "REJECTED";
  assignedToId: string | null;
  createdAt: string;
  user: { name: string; email: string; accountCategory: "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT" };
}

interface AdminTenant {
  id: string;
  name: string;
  slug: string;
  logoUrl: string | null;
  primaryColor: string | null;
  contactEmail: string;
  licenseStatus: string;
}

export default function Admin() {
  const { t, user, toast } = useApp();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [queue, setQueue] = useState<KybQueueItem[] | null>(null);
  const [tenants, setTenants] = useState<AdminTenant[] | null>(null);
  const [tenantForm, setTenantForm] = useState({ name: "", slug: "", contactEmail: "", logoUrl: "", primaryColor: "" });
  const [creatingTenant, setCreatingTenant] = useState(false);
  const [loading, setLoading] = useState(true);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [checks, setChecks] = useState<Record<string, ChecklistState>>({});
  const [pepStatus, setPepStatus] = useState<Record<string, "NOT_STARTED" | "PENDING" | "CLEAR" | "FLAGGED">>({});
  const [rejectReasons, setRejectReasons] = useState<Record<string, string>>({});
  const [assigningId, setAssigningId] = useState<string | null>(null);
  const [auditLog, setAuditLog] = useState<
    { id: string; admin: { name: string; email: string }; action: string; entityType: string; entityId: string; entityName: string | null; notes: string | null; createdAt: string }[] | null
  >(null);
  const [auditFilter, setAuditFilter] = useState<{ action: string; sort: "asc" | "desc" }>({ action: "", sort: "desc" });
  const [queueSearch, setQueueSearch] = useState("");
  const [queueTierFilter, setQueueTierFilter] = useState<"" | "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT">("");
  const [queueStatusFilter, setQueueStatusFilter] = useState<"" | "PENDING" | "IN_REVIEW">("");

  const toggleCheck = (id: string, field: keyof ChecklistState) => {
    setChecks((c) => {
      const current: ChecklistState = c[id] ?? DEFAULT_CHECKLIST;
      return { ...c, [id]: { ...current, [field]: !current[field] } };
    });
  };

  const isAdmin = user?.role === "ADMIN";

  useEffect(() => {
    if (!isAdmin || !isBackendConfigured) {
      setLoading(false);
      return;
    }
    Promise.all([api.admin.stats(), api.admin.users(), api.kyb.adminList(), api.tenants.adminList()])
      .then(([s, u, q, tn]) => {
        setStats(s);
        setUsers(u as AdminUser[]);
        setQueue((q as KybQueueItem[]).filter((item) => item.status === "PENDING" || item.status === "IN_REVIEW"));
        setTenants(tn as AdminTenant[]);
      })
      .catch((err) => toast(err instanceof Error ? err.message : t("admin.loadFailed"), "error"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin || !isBackendConfigured) return;
    api.admin
      .auditLog({ action: auditFilter.action || undefined, sort: auditFilter.sort })
      .then((events) => setAuditLog(events))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin, auditFilter]);

  if (!user) return <Navigate to="/dashboard" replace />;
  if (!isAdmin) return <Navigate to="/dashboard" replace />;

  // Task 8: search by name, filter by tier/status. Client-side since the
  // queue is already fully loaded (PENDING + IN_REVIEW only, a bounded set).
  const filteredQueue = (queue ?? []).filter((item) => {
    const matchesSearch =
      !queueSearch.trim() ||
      item.companyName.toLowerCase().includes(queueSearch.toLowerCase()) ||
      item.user.name.toLowerCase().includes(queueSearch.toLowerCase()) ||
      item.user.email.toLowerCase().includes(queueSearch.toLowerCase());
    const matchesTier = !queueTierFilter || item.user.accountCategory === queueTierFilter;
    const matchesStatus = !queueStatusFilter || item.status === queueStatusFilter;
    return matchesSearch && matchesTier && matchesStatus;
  });

  const reviewKyb = async (id: string, status: "APPROVED" | "REJECTED") => {
    if (status === "REJECTED" && !rejectReasons[id]?.trim()) {
      toast(t("admin.rejectReasonRequired"), "error");
      return;
    }
    setReviewingId(id);
    try {
      const c = checks[id];
      const approved = status === "APPROVED";
      await api.kyb.review(id, {
        status,
        bankAccountVerified: approved ? !!c?.bank : undefined,
        physicalAddressConfirmed: approved ? !!c?.address : undefined,
        financialAuditCompleted: approved ? !!c?.financialAudit : undefined,
        certificationsVerified: approved ? !!c?.certifications : undefined,
        pepScreeningStatus: approved ? pepStatus[id] ?? "NOT_STARTED" : undefined,
        diplomaticVerificationCompleted: approved ? !!c?.diplomatic : undefined,
        fscValidated: approved ? !!c?.fscValidated : undefined,
        pscAllValidated: approved ? !!c?.pscValidated : undefined,
        rejectionReason: status === "REJECTED" ? rejectReasons[id] : undefined,
      });
      setQueue((q) => q?.filter((item) => item.id !== id) ?? null);
      toast(status === "APPROVED" ? t("admin.kybApproved") : t("admin.kybRejected"));
    } catch (err) {
      toast(err instanceof Error ? err.message : t("admin.reviewFailed"), "error");
    } finally {
      setReviewingId(null);
    }
  };

  const assignKyb = async (id: string) => {
    setAssigningId(id);
    try {
      const updated = (await api.kyb.assign(id)) as KybQueueItem;
      setQueue((q) => q?.map((item) => (item.id === id ? { ...item, status: updated.status, assignedToId: updated.assignedToId } : item)) ?? null);
      toast(t("admin.kybAssigned"));
    } catch (err) {
      toast(err instanceof Error ? err.message : t("admin.reviewFailed"), "error");
    } finally {
      setAssigningId(null);
    }
  };

  const createTenant = async () => {
    if (!tenantForm.name || !tenantForm.slug || !tenantForm.contactEmail) return;
    setCreatingTenant(true);
    try {
      await api.tenants.create({
        name: tenantForm.name,
        slug: tenantForm.slug,
        contactEmail: tenantForm.contactEmail,
        logoUrl: tenantForm.logoUrl || undefined,
        primaryColor: tenantForm.primaryColor || undefined,
      });
      const refreshed = await api.tenants.adminList();
      setTenants(refreshed as AdminTenant[]);
      setTenantForm({ name: "", slug: "", contactEmail: "", logoUrl: "", primaryColor: "" });
      toast(t("admin.tenant.created"));
    } catch (err) {
      toast(err instanceof Error ? err.message : t("admin.tenant.createFailed"), "error");
    } finally {
      setCreatingTenant(false);
    }
  };

  const startTenantCheckout = async (id: string) => {
    try {
      const res = await api.tenants.checkout(id);
      window.location.href = res.url;
    } catch (err) {
      toast(err instanceof Error ? err.message : t("admin.tenant.checkoutFailed"), "error");
    }
  };

  return (
    <div className="pt-28">
      <Seo title={t("admin.seoTitle")} description={t("admin.seoDesc")} />
      <div className="mx-auto max-w-7xl px-4 pb-20">
        <Reveal>
          <SectionHeading
            eyebrow={t("common.admin")}
            title={t("admin.pageTitle")}
            subtitle={t("admin.pageSubtitle")}
            center={false}
          />
        </Reveal>

        {!isBackendConfigured && (
          <div className="mt-8 card border-amber-500/30 bg-amber-500/10 p-5 text-sm">
            {t("admin.noBackendPrefix")} <code>VITE_API_URL</code> {t("admin.noBackendSuffix")}
          </div>
        )}

        {loading && isBackendConfigured && (
          <div className="mt-16 grid place-items-center">
            <Loader2 className="h-8 w-8 animate-spin text-cyan-glow" />
          </div>
        )}

        {!loading && stats && (
          <Reveal delay={100}>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Users, v: stats.userCount, lKey: "admin.stat.totalUsers" },
                { icon: Building2, v: stats.companyCount, lKey: "admin.stat.companies" },
                { icon: Clock, v: stats.pendingKyb, lKey: "admin.stat.pendingKyb" },
                { icon: Handshake, v: stats.activeDeals, lKey: "admin.stat.activeDeals" },
              ].map((s) => (
                <div key={s.lKey} className="card flex items-center gap-3 p-5">
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-brand-600/15 text-cyan-glow">
                    <s.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-xl font-bold">{s.v}</div>
                    <div className="text-xs text-[var(--text-muted)]">{t(s.lKey)}</div>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        )}

        {!loading && queue && (
          <Reveal delay={150}>
            <div className="card mt-8 overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] p-5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-emerald-trust" />
                  <h3 className="font-display text-lg font-bold">{t("admin.kybQueue", { count: String(filteredQueue.length) })}</h3>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    value={queueSearch}
                    onChange={(e) => setQueueSearch(e.target.value)}
                    placeholder={t("admin.search.placeholder")}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-xs outline-none focus:border-cyan-glow/60"
                  />
                  <select value={queueTierFilter} onChange={(e) => setQueueTierFilter(e.target.value as typeof queueTierFilter)} className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-xs outline-none">
                    <option value="">{t("admin.search.allTiers")}</option>
                    <option value="INDIVIDUAL">Standard</option>
                    <option value="ENTERPRISE">Corporate</option>
                    <option value="GOVERNMENT">Sovereign</option>
                  </select>
                  <select value={queueStatusFilter} onChange={(e) => setQueueStatusFilter(e.target.value as typeof queueStatusFilter)} className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-xs outline-none">
                    <option value="">{t("admin.search.allStatuses")}</option>
                    <option value="PENDING">{t("admin.status.pending")}</option>
                    <option value="IN_REVIEW">{t("admin.status.inReview")}</option>
                  </select>
                </div>
              </div>
              {filteredQueue.length === 0 ? (
                <p className="p-6 text-sm text-[var(--text-muted)]">{t("admin.noPendingSubmissions")}</p>
              ) : (
                <div className="divide-y divide-[var(--border)]">
                  {filteredQueue.map((item) => (
                    <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 p-5">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold">{item.companyName}</p>
                          {item.status === "IN_REVIEW" && (
                            <span className="chip chip-gold text-[0.65rem]">{t("admin.status.inReview")}</span>
                          )}
                        </div>
                        <p className="text-xs text-[var(--text-muted)]">
                          {item.user.name} · {item.user.email} · {t("admin.regNumber")}{item.registrationNo} · {item.countries}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-4 text-xs">
                          <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                            <input
                              type="checkbox"
                              checked={!!checks[item.id]?.bank}
                              onChange={() => toggleCheck(item.id, "bank")}
                              className="h-3.5 w-3.5 accent-cyan-glow"
                            />
                            {t("admin.check.bank")}
                          </label>
                          <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                            <input
                              type="checkbox"
                              checked={!!checks[item.id]?.address}
                              onChange={() => toggleCheck(item.id, "address")}
                              className="h-3.5 w-3.5 accent-cyan-glow"
                            />
                            {t("admin.check.address")}
                          </label>
                          {item.user.accountCategory === "ENTERPRISE" && (
                            <>
                              <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                                <input
                                  type="checkbox"
                                  checked={!!checks[item.id]?.financialAudit}
                                  onChange={() => toggleCheck(item.id, "financialAudit")}
                                  className="h-3.5 w-3.5 accent-emerald-trust"
                                />
                                {t("admin.check.financialAudit")}
                              </label>
                              <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                                <input
                                  type="checkbox"
                                  checked={!!checks[item.id]?.certifications}
                                  onChange={() => toggleCheck(item.id, "certifications")}
                                  className="h-3.5 w-3.5 accent-emerald-trust"
                                />
                                {t("admin.check.certifications")}
                              </label>
                              <label className="flex items-center gap-1.5 text-[var(--text-muted)]">
                                {t("admin.check.pepStatus")}
                                <select
                                  value={pepStatus[item.id] ?? "NOT_STARTED"}
                                  onChange={(e) => setPepStatus((p) => ({ ...p, [item.id]: e.target.value as typeof pepStatus[string] }))}
                                  className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-1.5 py-0.5 text-xs outline-none"
                                >
                                  <option value="NOT_STARTED">{t("admin.pep.notStarted")}</option>
                                  <option value="PENDING">{t("admin.pep.pending")}</option>
                                  <option value="CLEAR">{t("admin.pep.clear")}</option>
                                  <option value="FLAGGED">{t("admin.pep.flagged")}</option>
                                </select>
                              </label>
                            </>
                          )}
                          {item.user.accountCategory === "GOVERNMENT" && (
                            <>
                              <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                                <input
                                  type="checkbox"
                                  checked={!!checks[item.id]?.diplomatic}
                                  onChange={() => toggleCheck(item.id, "diplomatic")}
                                  className="h-3.5 w-3.5 accent-violet-glow"
                                />
                                {t("admin.check.diplomatic")}
                              </label>
                              <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                                <input
                                  type="checkbox"
                                  checked={!!checks[item.id]?.fscValidated}
                                  onChange={() => toggleCheck(item.id, "fscValidated")}
                                  className="h-3.5 w-3.5 accent-violet-glow"
                                />
                                {t("admin.check.fsc")}
                              </label>
                              <label className="flex cursor-pointer items-center gap-1.5 text-[var(--text-muted)]">
                                <input
                                  type="checkbox"
                                  checked={!!checks[item.id]?.pscValidated}
                                  onChange={() => toggleCheck(item.id, "pscValidated")}
                                  className="h-3.5 w-3.5 accent-violet-glow"
                                />
                                {t("admin.check.psc")}
                              </label>
                            </>
                          )}
                        </div>
                        <input
                          value={rejectReasons[item.id] ?? ""}
                          onChange={(e) => setRejectReasons((r) => ({ ...r, [item.id]: e.target.value }))}
                          placeholder={t("admin.rejectReasonPlaceholder")}
                          className="mt-2 w-full max-w-sm rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-xs outline-none focus:border-cyan-glow/60"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button
                          disabled={assigningId === item.id || !!item.assignedToId}
                          onClick={() => assignKyb(item.id)}
                          className="btn btn-sm bg-[var(--surface-2)] text-[var(--text-muted)] hover:text-[var(--text)] disabled:opacity-50"
                        >
                          <Clock className="h-4 w-4" /> {t("admin.review")}
                        </button>
                        <button
                          disabled={reviewingId === item.id}
                          onClick={() => reviewKyb(item.id, "APPROVED")}
                          className="btn btn-sm bg-emerald-trust/15 text-emerald-trust hover:bg-emerald-trust/25 disabled:opacity-50"
                        >
                          <CheckCircle2 className="h-4 w-4" /> {t("admin.approve")}
                        </button>
                        <button
                          disabled={reviewingId === item.id}
                          onClick={() => reviewKyb(item.id, "REJECTED")}
                          className="btn btn-sm bg-rose-500/15 text-rose-400 hover:bg-rose-500/25 disabled:opacity-50"
                        >
                          <XCircle className="h-4 w-4" /> {t("admin.reject")}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Reveal>
        )}

        {!loading && users && (
          <Reveal delay={200}>
            <div className="card mt-8 overflow-hidden">
              <div className="flex items-center gap-2 border-b border-[var(--border)] p-5">
                <Users className="h-5 w-5 text-cyan-glow" />
                <h3 className="font-display text-lg font-bold">{t("admin.usersHeading", { count: String(users.length) })}</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)] text-left text-xs uppercase tracking-wide text-[var(--text-faint)]">
                      <th className="p-4">{t("admin.table.name")}</th>
                      <th className="p-4">{t("admin.table.email")}</th>
                      <th className="p-4">{t("admin.table.role")}</th>
                      <th className="p-4">{t("common.verified")}</th>
                      <th className="p-4">{t("admin.table.plan")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border)]">
                    {users.map((u) => (
                      <tr key={u.id}>
                        <td className="p-4 font-medium">{u.name}</td>
                        <td className="p-4 text-[var(--text-muted)]">{u.email}</td>
                        <td className="p-4">
                          <span className={cn("chip", u.role === "ADMIN" ? "chip-brand" : "")}>{u.role}</span>
                        </td>
                        <td className="p-4">{u.emailVerified ? "✅" : "—"}</td>
                        <td className="p-4 text-[var(--text-muted)]">{u.subscription?.tier ?? "STARTER"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Reveal>
        )}

        {!loading && (
          <Reveal delay={250}>
            <div className="card mt-8 overflow-hidden">
              <div className="flex items-center gap-2 border-b border-[var(--border)] p-5">
                <Building2 className="h-5 w-5 text-gold" />
                <h3 className="font-display text-lg font-bold">{t("admin.tenant.heading")}</h3>
              </div>

              <div className="border-b border-[var(--border)] p-5">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                  <input
                    value={tenantForm.name}
                    onChange={(e) => setTenantForm((f) => ({ ...f, name: e.target.value }))}
                    placeholder={t("admin.tenant.namePlaceholder")}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm outline-none focus:border-cyan-glow/50"
                  />
                  <input
                    value={tenantForm.slug}
                    onChange={(e) => setTenantForm((f) => ({ ...f, slug: e.target.value.toLowerCase() }))}
                    placeholder={t("admin.tenant.slugPlaceholder")}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm outline-none focus:border-cyan-glow/50"
                  />
                  <input
                    value={tenantForm.contactEmail}
                    onChange={(e) => setTenantForm((f) => ({ ...f, contactEmail: e.target.value }))}
                    placeholder={t("admin.tenant.emailPlaceholder")}
                    type="email"
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm outline-none focus:border-cyan-glow/50"
                  />
                  <input
                    value={tenantForm.logoUrl}
                    onChange={(e) => setTenantForm((f) => ({ ...f, logoUrl: e.target.value }))}
                    placeholder={t("admin.tenant.logoPlaceholder")}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm outline-none focus:border-cyan-glow/50"
                  />
                  <button
                    onClick={createTenant}
                    disabled={creatingTenant}
                    className="btn btn-gold justify-center disabled:opacity-50"
                  >
                    {creatingTenant ? <Loader2 className="h-4 w-4 animate-spin" /> : <Building2 className="h-4 w-4" />}
                    {t("admin.tenant.create")}
                  </button>
                </div>
                <p className="mt-2 text-xs text-[var(--text-muted)]">{t("admin.tenant.formNote")}</p>
              </div>

              {!tenants || tenants.length === 0 ? (
                <p className="p-6 text-sm text-[var(--text-muted)]">{t("admin.tenant.empty")}</p>
              ) : (
                <div className="divide-y divide-[var(--border)]">
                  {tenants.map((tn) => (
                    <div key={tn.id} className="flex flex-wrap items-center justify-between gap-3 p-5">
                      <div>
                        <p className="font-semibold">{tn.name}</p>
                        <p className="text-xs text-[var(--text-muted)]">
                          /?partner={tn.slug} · {tn.contactEmail}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={cn("chip", tn.licenseStatus === "active" ? "chip-emerald" : "chip-gold")}>
                          {tn.licenseStatus === "active" ? t("admin.tenant.active") : t("admin.tenant.inactive")}
                        </span>
                        {tn.licenseStatus !== "active" && (
                          <button onClick={() => startTenantCheckout(tn.id)} className="btn btn-sm btn-ghost">
                            {t("admin.tenant.startLicense")}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Reveal>
        )}

        {!loading && auditLog && (
          <Reveal delay={250}>
            <div className="card mt-8 overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] p-5">
                <div className="flex items-center gap-2">
                  <History className="h-5 w-5 text-cyan-glow" />
                  <h3 className="font-display text-lg font-bold">{t("admin.auditLog.heading")}</h3>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={auditFilter.action}
                    onChange={(e) => setAuditFilter((f) => ({ ...f, action: e.target.value }))}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-xs outline-none"
                  >
                    <option value="">{t("admin.auditLog.allActions")}</option>
                    <option value="kyb.assigned">{t("admin.review")}</option>
                    <option value="kyb.approved">{t("admin.approve")}</option>
                    <option value="kyb.rejected">{t("admin.reject")}</option>
                  </select>
                  <button
                    onClick={() => setAuditFilter((f) => ({ ...f, sort: f.sort === "asc" ? "desc" : "asc" }))}
                    className="btn btn-sm btn-ghost"
                  >
                    {auditFilter.sort === "desc" ? t("admin.auditLog.newestFirst") : t("admin.auditLog.oldestFirst")}
                  </button>
                </div>
              </div>
              {auditLog.length === 0 ? (
                <p className="p-6 text-sm text-[var(--text-muted)]">{t("admin.auditLog.empty")}</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead>
                      <tr className="border-b border-[var(--border)] text-xs uppercase tracking-wide text-[var(--text-faint)]">
                        <th className="px-5 py-2.5 font-medium">{t("admin.auditLog.col.timestamp")}</th>
                        <th className="px-5 py-2.5 font-medium">{t("admin.auditLog.col.admin")}</th>
                        <th className="px-5 py-2.5 font-medium">{t("admin.auditLog.col.action")}</th>
                        <th className="px-5 py-2.5 font-medium">{t("admin.auditLog.col.entity")}</th>
                        <th className="px-5 py-2.5 font-medium">{t("admin.auditLog.col.notes")}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border)]">
                      {auditLog.map((ev) => (
                        <tr key={ev.id}>
                          <td className="px-5 py-3 text-xs text-[var(--text-muted)]">{new Date(ev.createdAt).toLocaleString()}</td>
                          <td className="px-5 py-3">{ev.admin?.name ?? "—"}</td>
                          <td className="px-5 py-3"><span className="chip text-[0.65rem]">{ev.action}</span></td>
                          <td className="px-5 py-3 text-xs">{ev.entityName ?? ev.entityId}</td>
                          <td className="max-w-xs truncate px-5 py-3 text-xs text-[var(--text-muted)]" title={ev.notes ?? ""}>{ev.notes ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </Reveal>
        )}
      </div>
    </div>
  );
}
