import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Sparkles, ArrowRight, Search, Brain, ShieldCheck, FileSignature,
  Lock, BarChart3, Plug, Globe2, Users, TrendingUp, Zap, Eye,
  Scale, Server, CheckCircle2, Star, Quote, ChevronRight,
  Building2, Landmark, User, ShieldQuestion,
} from "lucide-react";
import { useApp } from "../context";
import { COMPANIES, INDUSTRIES } from "../data";
import { Reveal, SectionHeading, Orbs, TrustRing, WaitlistForm } from "../ui";
import CountrySelect from "../components/CountrySelect";
import CompanyCard from "../components/CompanyCard";
import Seo from "../components/Seo";

// Served directly from /public so the browser can cache it independently
// across deploys, instead of being base64-inlined into the JS bundle.


const MODULES = [
  { icon: Brain, titleKey: "home.module.aiDiscovery.title", descKey: "home.module.aiDiscovery.desc", color: "from-brand-500 to-cyan-glow" },
  { icon: ShieldCheck, titleKey: "home.module.kyb.title", descKey: "home.module.kyb.desc", color: "from-emerald-trust to-cyan-glow" },
  { icon: FileSignature, titleKey: "home.module.dealRooms.title", descKey: "home.module.dealRooms.desc", color: "from-violet-glow to-brand-500" },
  { icon: Lock, titleKey: "home.module.escrow.title", descKey: "home.module.escrow.desc", color: "from-gold to-gold-deep" },
  { icon: BarChart3, titleKey: "home.module.intelligence.title", descKey: "home.module.intelligence.desc", color: "from-cyan-glow to-violet-glow" },
  { icon: Plug, titleKey: "home.module.whiteLabel.title", descKey: "home.module.whiteLabel.desc", color: "from-brand-500 to-violet-glow" },
];

const PILLARS = [
  { icon: ShieldCheck, titleKey: "home.pillar.trust.title", pointKeys: ["home.pillar.trust.point1", "home.pillar.trust.point2", "home.pillar.trust.point3"] },
  { icon: Lock, titleKey: "home.pillar.security.title", pointKeys: ["home.pillar.security.point1", "home.pillar.security.point2", "home.pillar.security.point3"] },
  { icon: Eye, titleKey: "home.pillar.transparency.title", pointKeys: ["home.pillar.transparency.point1", "home.pillar.transparency.point2", "home.pillar.transparency.point3"] },
  { icon: Zap, titleKey: "home.pillar.reliability.title", pointKeys: ["home.pillar.reliability.point1", "home.pillar.reliability.point2", "home.pillar.reliability.point3"] },
  { icon: Scale, titleKey: "home.pillar.compliance.title", pointKeys: ["home.pillar.compliance.point1", "home.pillar.compliance.point2", "home.pillar.compliance.point3"] },
  { icon: Server, titleKey: "home.pillar.scalability.title", pointKeys: ["home.pillar.scalability.point1", "home.pillar.scalability.point2", "home.pillar.scalability.point3"] },
];

const GROWTH = [42, 58, 75, 96, 128, 165, 210];

export default function Home() {
  const { t, aiMode } = useApp();
  const [countries, setCountries] = useState<string[]>([]);
  const [industry, setIndustry] = useState("");

  const recommended = useMemo(() => {
    let list = [...COMPANIES];
    if (countries.length) list = list.filter((c) => countries.includes(c.country.code));
    if (industry) list = list.filter((c) => c.industry === industry);
    if (aiMode) list.sort((a, b) => b.matchScore - a.matchScore);
    return list.slice(0, 3);
  }, [countries, industry, aiMode]);

  return (
    <div>
      <Seo
        title={t("seo.home.title")}
        description={t("seo.home.desc")}
      />
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
        <div
          className="hero-backdrop pointer-events-none absolute inset-0 opacity-40"
          style={{
            maskImage: "radial-gradient(ellipse 80% 70% at 50% 30%, #000 40%, transparent 85%)",
            WebkitMaskImage: "radial-gradient(ellipse 80% 70% at 50% 30%, #000 40%, transparent 85%)",
          }}
        />
        <Orbs />
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid items-center gap-12 lg:grid-cols-[1.15fr_1fr]">
            <div>
              <div className="inline-flex anim-slide-up">
                <span className="chip chip-brand mb-5">
                  <Sparkles className="h-3.5 w-3.5" />
                  {t("hero.badge")}
                </span>
              </div>
              <div className="anim-slide-up mb-4 flex flex-wrap items-center gap-2.5" style={{ animationDelay: "0.02s" }}>
                <span className="text-xl leading-none" role="img" aria-label="European Union flag">🇪🇺</span>
                <span className="font-serif-display text-sm font-semibold tracking-wide text-[var(--color-gold)]">
                  {t("hero.euBadge.label")}
                </span>
                <span className="group relative">
                  <ShieldQuestion className="h-3.5 w-3.5 cursor-help text-[var(--text-faint)]" />
                  <span className="pointer-events-none absolute start-0 top-6 z-20 w-72 rounded-lg border border-[var(--border)] bg-[var(--surface-solid)] p-3 text-xs leading-relaxed text-[var(--text-muted)] opacity-0 shadow-xl transition group-hover:opacity-100">
                    {t("hero.euBadge.tooltip")}
                  </span>
                </span>
              </div>
              <h1 className="anim-slide-up font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-[4.2rem]">
                {t("hero.title1")} <br />
                <span className="gradient-text">{t("hero.title2")}</span>
              </h1>
              <p
                className="anim-slide-up mt-6 max-w-xl text-base text-[var(--text-muted)] md:text-lg"
                style={{ animationDelay: "0.1s" }}
              >
                {t("hero.subtitle")}
              </p>
              <div
                className="anim-slide-up mt-8 flex flex-wrap gap-3"
                style={{ animationDelay: "0.2s" }}
              >
                <Link to="/companies" className="btn btn-primary shine">
                  <Search className="h-4 w-4" />
                  {t("cta.viewCompanies")}
                </Link>
                <Link to="/pricing" className="btn btn-gold">
                  {t("cta.bookDemo")}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>

              <div className="anim-slide-up mt-10" style={{ animationDelay: "0.3s" }}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div className="card p-4">
                    <div className="font-display text-lg font-bold">{t("hero.honest.tiers.value")}</div>
                    <div className="mt-1 text-xs text-[var(--text-muted)]">{t("hero.honest.tiers.label")}</div>
                  </div>
                  <div className="card p-4">
                    <div className="font-display text-lg font-bold">{t("hero.honest.scope.value")}</div>
                    <div className="mt-1 text-xs text-[var(--text-muted)]">{t("hero.honest.scope.label")}</div>
                  </div>
                  <div className="card p-4">
                    <div className="font-display text-lg font-bold">{t("hero.honest.languages.value")}</div>
                    <div className="mt-1 text-xs text-[var(--text-muted)]">{t("hero.honest.languages.label")}</div>
                  </div>
                </div>
                <Link to="/methodology" className="mt-3 inline-flex items-center gap-1 text-xs text-[var(--text-faint)] hover:text-[var(--color-gold)] hover:underline">
                  {t("hero.honest.methodologyLink")} <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            </div>

            {/* Hero visual */}
            <Reveal delay={200}>
              <HeroVisual />
            </Reveal>
          </div>
        </div>
      </section>

      {/* ============ APPLICATION PATHWAYS ============ */}
      <section className="border-y border-[var(--border)] bg-[var(--surface)]/40 py-14">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="mb-6 text-center text-xs font-semibold uppercase tracking-wider text-[var(--text-faint)]">{t("apply.eyebrow")}</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {(
              [
                { tier: "standard", Icon: User, color: "cyan-glow" },
                { tier: "corporate", Icon: Building2, color: "emerald-trust" },
                { tier: "sovereign", Icon: Landmark, color: "violet-glow" },
              ] as const
            ).map(({ tier, Icon, color }) => (
              <Link key={tier} to={`/apply/${tier}`} className="card card-hover group flex items-center gap-4 p-5">
                <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-${color}/15 text-${color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-display text-sm font-bold">{t(`apply.${tier}.title`)}</h3>
                  <p className="mt-0.5 truncate text-xs text-[var(--text-muted)]">{t(`apply.${tier}.desc`)}</p>
                </div>
                <ArrowRight className="h-4 w-4 shrink-0 text-[var(--text-faint)] transition group-hover:translate-x-1 group-hover:text-[var(--text)]" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ============ TRUST MARQUEE ============ */}
      <section className="border-y border-[var(--border)] py-8">
        <div className="mx-auto max-w-7xl px-4">
          <p className="mb-5 text-center text-xs font-semibold uppercase tracking-[0.2em] text-[var(--text-faint)]">
            {t("section.partners")}
          </p>
          <div className="relative overflow-hidden">
            <div className="flex w-max animate-marquee gap-3">
              {[...Array(2)].flatMap((_, dup) =>
                COMPANIES.slice(0, 16).map((c, i) => (
                  <div
                    key={`${dup}-${i}`}
                    className="flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5"
                  >
                    <span className="text-lg">{c.country.flag}</span>
                    <span className="whitespace-nowrap text-sm font-medium">{c.name}</span>
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-trust" />
                  </div>
                ))
              )}
            </div>
            <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-[var(--bg)] to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-[var(--bg)] to-transparent" />
          </div>
        </div>
      </section>

      {/* ============ MODULES ============ */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("home.eyebrow.corePlatform")}
              title={<>{t("section.modules.title")}</>}
              subtitle={t("section.modules.subtitle")}
            />
          </Reveal>
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {MODULES.map((m, i) => (
              <Reveal key={m.titleKey} delay={i * 70}>
                <div className="card card-hover group h-full p-6">
                  <div
                    className={`mb-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${m.color} shadow-lg`}
                  >
                    <m.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-display text-lg font-semibold">{t(m.titleKey)}</h3>
                  <p className="mt-2 text-sm text-[var(--text-muted)]">{t(m.descKey)}</p>
                  <div className="mt-4 flex items-center gap-1 text-sm font-medium text-cyan-glow opacity-0 transition group-hover:opacity-100">
                    {t("common.learnMore")} <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ AI DISCOVERY ============ */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
            <Reveal>
              <div>
                <span className="chip chip-gold mb-4 inline-flex">
                  <Brain className="h-3.5 w-3.5" />
                  {t("common.aiPowered")}
                </span>
                <h2 className="font-display text-3xl font-bold leading-tight md:text-4xl">
                  {t("section.discovery.title")}
                </h2>
                <p className="mt-4 text-[var(--text-muted)]">{t("section.discovery.subtitle")}</p>

                <div className="mt-6 space-y-3">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                      {t("common.filter.country")}
                    </label>
                    <CountrySelect value={countries} onChange={(v) => setCountries(v as string[])} />
                  </div>
                  <div>
                    <label htmlFor="home-industry-filter" className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                      {t("common.filter.industry")}
                    </label>
                    <select
                      id="home-industry-filter"
                      value={industry}
                      onChange={(e) => setIndustry(e.target.value)}
                      className="h-12 w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 text-sm outline-none transition focus:border-cyan-glow/50"
                    >
                      <option value="">{t("common.filter.all")}</option>
                      {INDUSTRIES.map((ind) => (
                        <option key={ind} value={ind}>{ind}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <Link to="/companies" className="btn btn-primary mt-5 w-full">
                  <Sparkles className="h-4 w-4" />
                  {t("home.findAiMatches")}
                </Link>
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div>
                <div className="mb-4 flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm font-semibold">
                    <Star className="h-4 w-4 fill-gold text-gold" />
                    {aiMode ? t("common.aiRecommendation") : t("home.topPartners")}
                  </span>
                  <span className="chip">{recommended.length} {t("common.results")}</span>
                </div>
                <div className="grid gap-4">
                  {recommended.map((c, i) => (
                    <CompanyCard key={c.id} company={c} index={i} />
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ============ TRUST PILLARS ============ */}
      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("home.eyebrow.trustEmpire")}
              title={<>{t("section.trust.title")}</>}
              subtitle={t("section.trust.subtitle")}
            />
          </Reveal>
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {PILLARS.map((p, i) => (
              <Reveal key={p.titleKey} delay={i * 60}>
                <div className="card card-hover h-full p-6">
                  <div className="flex items-center gap-3">
                    <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-trust/15 text-emerald-trust ring-1 ring-emerald-trust/30">
                      <p.icon className="h-5 w-5" />
                    </div>
                    <h3 className="font-display text-lg font-semibold">{t(p.titleKey)}</h3>
                  </div>
                  <ul className="mt-4 space-y-2">
                    {p.pointKeys.map((pk) => (
                      <li key={pk} className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-trust" />
                        {t(pk)}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={200}>
            <div className="mt-8 text-center">
              <Link to="/security" className="btn btn-ghost">
                {t("section.security.title")}
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============ INTELLIGENCE PREVIEW ============ */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <Reveal>
              <div>
                <span className="chip chip-brand mb-4 inline-flex">
                  <BarChart3 className="h-3.5 w-3.5" />
                  {t("common.aiPowered")}
                </span>
                <h2 className="font-display text-3xl font-bold leading-tight md:text-4xl">
                  {t("section.intel.title")}
                </h2>
                <p className="mt-4 text-[var(--text-muted)]">{t("section.intel.subtitle")}</p>
                <div className="mt-6 space-y-3">
                  {[
                    { icon: TrendingUp, tKey: "home.intel.feature1.title", dKey: "home.intel.feature1.desc" },
                    { icon: Globe2, tKey: "home.intel.feature2.title", dKey: "home.intel.feature2.desc" },
                    { icon: Users, tKey: "home.intel.feature3.title", dKey: "home.intel.feature3.desc" },
                  ].map((f) => (
                    <div key={f.tKey} className="flex gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-600/15 text-cyan-glow">
                        <f.icon className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-semibold">{t(f.tKey)}</div>
                        <div className="text-xs text-[var(--text-muted)]">{t(f.dKey)}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <Link to="/intelligence" className="btn btn-primary mt-6">
                  {t("home.openIntelligence")} <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </Reveal>
            <Reveal delay={150}>
              <div className="card ring-gradient p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold">{t("home.dealVolume.title")}</div>
                    <div className="text-xs text-[var(--text-muted)]">{t("home.dealVolume.subtitle")}</div>
                  </div>
                  <span className="chip chip-gold">{t("common.sampleData")}</span>
                </div>
                <MiniChart data={GROWTH} />
                <div className="mt-4 grid grid-cols-3 gap-3 border-t border-[var(--border)] pt-4 text-center">
                  {[
                    { lKey: "home.stat.avgTrust", v: "—" },
                    { lKey: "home.stat.activeMarkets", v: "45" },
                    { lKey: "home.stat.aiConfidence", v: "—" },
                  ].map((s) => (
                    <div key={s.lKey}>
                      <div className="font-display text-xl font-bold gradient-text">{s.v}</div>
                      <div className="text-xs text-[var(--text-muted)]">{t(s.lKey)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ============ FOR GOVERNMENTS / FOR ENTERPRISES ============ */}
      <section className="border-y border-[var(--border)] py-24">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeading eyebrow={t("audience.eyebrow")} title={t("audience.title")} subtitle={t("audience.subtitle")} />
          <div className="mt-12 grid gap-6 lg:grid-cols-2">
            <Reveal>
              <div className="card h-full p-7">
                <div className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-[var(--color-gold)]/15 text-[var(--color-gold)]">
                  <Landmark className="h-5 w-5" />
                </div>
                <h3 className="font-serif-display text-xl font-bold">{t("audience.gov.title")}</h3>
                <p className="mt-3 text-sm leading-relaxed text-[var(--text-muted)]">{t("audience.gov.body")}</p>
                <Link to="/commitments" className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-[var(--color-gold)] hover:underline">
                  {t("audience.gov.cta")} <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </Reveal>
            <Reveal delay={0.05}>
              <div className="card h-full p-7">
                <div className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-cyan-glow/15 text-cyan-glow">
                  <Building2 className="h-5 w-5" />
                </div>
                <h3 className="font-serif-display text-xl font-bold">{t("audience.enterprise.title")}</h3>
                <p className="mt-3 text-sm leading-relaxed text-[var(--text-muted)]">{t("audience.enterprise.body")}</p>
                <Link to="/apply/corporate" className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-cyan-glow hover:underline">
                  {t("audience.enterprise.cta")} <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.1}>
            <div className="ring-gradient mt-8 rounded-2xl border border-[var(--border)] p-6 text-center">
              <h3 className="font-serif-display text-lg font-bold">{t("audience.demo.title")}</h3>
              <p className="mx-auto mt-2 max-w-lg text-sm text-[var(--text-muted)]">{t("audience.demo.subtitle")}</p>
              <div className="mt-4 flex justify-center">
                <WaitlistForm source="home_demo_request" />
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============ FINAL CTA ============ */}
      <CTASection />
    </div>
  );
}

export function CTASection() {
  const { t } = useApp();
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4">
        <Reveal>
          <div className="ring-gradient relative overflow-hidden rounded-3xl border border-[var(--border)] p-10 text-center md:p-16">
            <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-600/15 via-transparent to-violet-glow/15" />
            <div className="pointer-events-none absolute -left-10 top-0 h-48 w-48 rounded-full bg-brand-500/30 blur-3xl" />
            <div className="pointer-events-none absolute -right-10 bottom-0 h-48 w-48 rounded-full bg-violet-glow/30 blur-3xl" />
            <Quote className="mx-auto mb-4 h-8 w-8 text-cyan-glow" />
            <h2 className="mx-auto max-w-2xl font-display text-3xl font-bold leading-tight md:text-5xl">
              {t("section.cta.title")}
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-[var(--text-muted)]">{t("section.cta.subtitle")}</p>
            <div className="mx-auto mt-8 max-w-md">
              <WaitlistForm source="home_cta" />
            </div>
            <div className="mt-4">
              <Link to="/pricing" className="text-sm text-[var(--text-muted)] underline-offset-4 hover:underline">
                {t("cta.bookDemo")}
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---- Mini SVG chart ---- */
function MiniChart({ data }: { data: number[] }) {
  const max = Math.max(...data);
  const w = 100;
  const h = 38;
  const step = w / (data.length - 1);
  const pts = data.map((d, i) => `${i * step},${h - (d / max) * h}`).join(" ");
  const area = `0,${h} ${pts} ${w},${h}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="h-36 w-full">
      <defs>
        <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={area} fill="url(#cg)" />
      <polyline points={pts} fill="none" stroke="#22d3ee" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
      {data.map((d, i) => (
        <circle key={i} cx={i * step} cy={h - (d / max) * h} r="1.1" fill="#22d3ee" vectorEffect="non-scaling-stroke" />
      ))}
    </svg>
  );
}

/* ---- Hero visual ---- */
function HeroVisual() {
  const { t } = useApp();
  return (
    <div className="relative mx-auto aspect-square w-full max-w-md">
      <div className="absolute inset-0 animate-spin-slow">
        <svg viewBox="0 0 200 200" className="h-full w-full">
          <circle cx="100" cy="100" r="92" fill="none" stroke="var(--border)" strokeWidth="0.5" strokeDasharray="2 4" />
          <circle cx="100" cy="100" r="68" fill="none" stroke="var(--border)" strokeWidth="0.5" />
          <circle cx="100" cy="100" r="44" fill="none" stroke="var(--border)" strokeWidth="0.5" />
        </svg>
      </div>
      {/* center hub */}
      <div className="absolute left-1/2 top-1/2 grid h-28 w-28 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-3xl bg-gradient-to-br from-brand-600 to-cyan-glow shadow-2xl">
        <Globe2 className="h-12 w-12 text-white" />
      </div>
      {/* orbiting nodes */}
      {[
        { top: "6%", left: "50%", flag: "🇺🇸", labelKey: "home.hero.country.usa", score: 92 },
        { top: "50%", left: "94%", flag: "🇨🇳", labelKey: "home.hero.country.china", score: 88 },
        { top: "94%", left: "50%", flag: "🇩🇪", labelKey: "home.hero.country.germany", score: 95 },
        { top: "50%", left: "6%", flag: "🇦🇪", labelKey: "home.hero.country.uae", score: 90 },
      ].map((n, i) => (
        <div
          key={n.labelKey}
          className="absolute -translate-x-1/2 -translate-y-1/2 animate-float"
          style={{ top: n.top, left: n.left, animationDelay: `${i * 0.8}s` }}
        >
          <div className="glass flex items-center gap-2 rounded-2xl px-3 py-2 shadow-xl">
            <span className="text-xl">{n.flag}</span>
            <div className="text-left">
              <div className="text-xs font-semibold">{t(n.labelKey)}</div>
              <div className="flex items-center gap-1 text-[0.65rem] text-emerald-trust">
                <ShieldCheck className="h-2.5 w-2.5" /> {n.score}
              </div>
            </div>
          </div>
        </div>
      ))}
      {/* trust badge floating */}
      <div className="absolute -bottom-2 right-4 animate-float" style={{ animationDelay: "1.5s" }}>
        <div className="glass glow-emerald flex items-center gap-2 rounded-xl px-3 py-2">
          <TrustRing score={99} size={32} />
          <div className="text-left">
            <div className="text-xs font-bold">{t("home.hero.trustVerified")}</div>
            <div className="text-[0.65rem] text-[var(--text-muted)]">SOC 2 · KYB</div>
          </div>
        </div>
      </div>
    </div>
  );
}
