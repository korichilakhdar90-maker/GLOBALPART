import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft, ShieldCheck, ShieldQuestion, Building2, TrendingUp, Calendar, Globe, Mail,
  Phone, Star, Heart, FileSignature, MapPin, Users, CheckCircle2, Send, Loader2,
} from "lucide-react";
import { COMPANIES, type Company, INDUSTRY_LABEL_KEY, REGION_LABEL_KEY } from "../data";
import { useApp } from "../context";
import { TrustRing, Reveal, SampleDataBanner } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";
import { adaptApiCompany } from "../lib/adaptApiCompany";

export default function CompanyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, favorites, toggleFavorite, toast, user } = useApp();
  const localCompany = COMPANIES.find((c) => c.id === id);
  const [apiCompany, setApiCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(isBackendConfigured);
  const [sent, setSent] = useState(false);
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    setSent(false);
    if (!isBackendConfigured || !id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    api.companies
      .get(id)
      .then((c) => setApiCompany(adaptApiCompany(c)))
      .catch(() => setApiCompany(null))
      .finally(() => setLoading(false));
  }, [id]);

  const company = isBackendConfigured ? apiCompany : localCompany;

  if (isBackendConfigured && loading) {
    return (
      <div className="grid min-h-[70vh] place-items-center px-4 pt-24">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-glow" />
      </div>
    );
  }

  if (!company) {
    return (
      <div className="grid min-h-[70vh] place-items-center px-4 pt-24">
        <Seo title={t("seo.companyNotFound.title")} description={t("seo.companyNotFound.desc")} />
        <div className="text-center">
          <p className="font-display text-2xl font-bold">{t("companyDetail.notFound")}</p>
          <Link to="/companies" className="btn btn-primary mt-4">{t("companyDetail.backToDirectory")}</Link>
        </div>
      </div>
    );
  }

  const fav = favorites.includes(company.id);
  const trustFactors = [
    { labelKey: "companyDetail.trust.legalRegistration", value: 96 },
    { labelKey: "companyDetail.trust.financialHealth", value: Math.min(99, company.trustScore + 4) },
    { labelKey: "companyDetail.trust.tradeHistory", value: company.trustScore - 6 },
    { labelKey: "companyDetail.trust.operationalStanding", value: company.trustScore + 2 },
  ];
  const reviews = [
    { name: "Marcus Lindqvist", roleKey: "companyDetail.review.role1", rating: 5, textKey: "companyDetail.review.text1" },
    { name: "Aiko Tanaka", roleKey: "companyDetail.review.role2", rating: 5, textKey: "companyDetail.review.text2" },
    { name: "Fatima Al-Rashid", roleKey: "companyDetail.review.role3", rating: 4, textKey: "companyDetail.review.text3" },
  ];

  return (
    <div className="pt-28">
      <Seo
        title={company.name}
        description={t("seo.companyDetail.desc", {
          name: company.name,
          industry: t(INDUSTRY_LABEL_KEY[company.industry] ?? company.industry),
          country: company.country.name,
          trust: String(company.trustScore),
        })}
      />
      <div className="mx-auto max-w-7xl px-4 pb-20">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] transition hover:text-[var(--text)]"
        >
          <ArrowLeft className="h-4 w-4 flip-x" /> {t("common.back")}
        </button>

        {/* Hero card */}
        <Reveal>
          <div className="card ring-gradient overflow-hidden">
            <div className="h-28 bg-gradient-to-r from-brand-600/30 via-violet-glow/20 to-cyan-glow/30" />
            <div className="px-6 pb-6">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div className="flex items-end gap-4">
                  <div className="grid h-20 w-20 -translate-y-8 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow text-3xl font-bold text-white shadow-xl">
                    {company.name.charAt(0)}
                  </div>
                  <div className="-mb-1">
                    <div className="flex items-center gap-2">
                      <h1 className="font-display text-2xl font-bold md:text-3xl">{company.name}</h1>
                      {company.verified && (
                        <span className="chip chip-emerald">
                          <ShieldCheck className="h-3.5 w-3.5" /> {t("common.verified")}
                        </span>
                      )}
                      {company.profileStatus === "DIRECTORY_LISTED" && (
                        <span className="chip chip-gold" title={t("companyDetail.unclaimedTooltip")}>
                          <ShieldQuestion className="h-3.5 w-3.5" /> {t("companyDetail.unclaimedBadge")}
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-[var(--text-muted)]">
                      <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {company.country.flag} {company.country.name}</span>
                      <span className="flex items-center gap-1"><Building2 className="h-4 w-4" /> {t(INDUSTRY_LABEL_KEY[company.industry] ?? company.industry)}</span>
                      <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {t("companyDetail.est")} {company.founded}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleFavorite(company.id)}
                    aria-label={fav ? t("companyDetail.removeFavorite", { name: company.name }) : t("companyDetail.saveFavorite", { name: company.name })}
                    aria-pressed={fav}
                    className={cn(
                      "grid h-11 w-11 place-items-center rounded-xl border transition",
                      fav ? "border-rose-400/40 bg-rose-500/10 text-rose-400" : "border-[var(--border)] hover:text-[var(--text)]"
                    )}
                  >
                    <Heart className={cn("h-5 w-5", fav && "fill-current")} />
                  </button>
                  <button onClick={() => navigate("/deals")} className="btn btn-primary">
                    <FileSignature className="h-4 w-4" /> {t("companyDetail.startDealRoom")}
                  </button>
                  {company.profileStatus === "DIRECTORY_LISTED" && (
                    <button
                      onClick={async () => {
                        if (!user) {
                          navigate("/dashboard");
                          return;
                        }
                        setClaiming(true);
                        try {
                          if (isBackendConfigured) await api.companies.claim(company.id);
                          navigate(`/kyb?claim=${company.id}&claimName=${encodeURIComponent(company.name)}`);
                        } catch (err) {
                          toast(err instanceof Error ? err.message : t("common.errorGeneric"), "error");
                        } finally {
                          setClaiming(false);
                        }
                      }}
                      disabled={claiming}
                      className="btn btn-gold disabled:opacity-60"
                    >
                      <ShieldQuestion className="h-4 w-4" /> {claiming ? t("common.pleaseWait") : t("companyDetail.claimProfile")}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        {company.profileStatus === "DIRECTORY_LISTED" && (
          <SampleDataBanner textKey="companyDetail.unclaimedBanner" />
        )}

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="space-y-6">
            {/* Overview */}
            <Reveal>
              <section className="card p-6">
                <h2 className="mb-3 font-display text-lg font-semibold">{t("companyDetail.overview")}</h2>
                <p className="text-[var(--text-muted)]">{company.description}</p>
                <p className="mt-3 text-[var(--text-muted)]">
                  {t("companyDetail.overviewDetail", {
                    employees: company.employees,
                    revenue: company.revenue,
                    name: company.name,
                    deals: String(company.deals),
                  })}
                </p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {[
                    INDUSTRY_LABEL_KEY[company.industry] ?? company.industry,
                    REGION_LABEL_KEY[company.country.region] ?? company.country.region,
                    company.verified ? "tag.kybVerified" : "tag.verifiedPending",
                    "tag.exportReady",
                  ].map((tagKey) => (
                    <span key={tagKey} className="chip">{t(tagKey)}</span>
                  ))}
                </div>
              </section>
            </Reveal>

            {/* Trust breakdown */}
            <Reveal>
              <section className="card p-6">
                <h2 className="mb-4 font-display text-lg font-semibold">{t("companyDetail.trustBreakdown")}</h2>
                <div className="space-y-3">
                  {trustFactors.map((f) => (
                    <div key={f.labelKey}>
                      <div className="mb-1 flex justify-between text-sm">
                        <span className="text-[var(--text-muted)]">{t(f.labelKey)}</span>
                        <span className="font-semibold">{f.value}/100</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-[var(--surface-2)]">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-emerald-trust to-cyan-glow"
                          style={{ width: `${Math.max(10, Math.min(100, f.value))}%`, transition: "width 1s ease" }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </Reveal>

            {/* Reviews */}
            <Reveal>
              <section className="card p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="font-display text-lg font-semibold">{t("companyDetail.verifiedReviews")}</h2>
                  <span className="flex items-center gap-1 text-sm">
                    <Star className="h-4 w-4 fill-gold text-gold" />
                    <span className="font-bold">4.8</span>
                    <span className="text-[var(--text-muted)]">({reviews.length * 47})</span>
                  </span>
                </div>
                <div className="space-y-4">
                  {reviews.map((r) => (
                    <div key={r.name} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold">{r.name}</div>
                          <div className="text-xs text-[var(--text-muted)]">{t(r.roleKey)}</div>
                        </div>
                        <div className="flex gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} className={cn("h-3.5 w-3.5", i < r.rating ? "fill-gold text-gold" : "text-[var(--text-faint)]")} />
                          ))}
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-[var(--text-muted)]">{t(r.textKey)}</p>
                    </div>
                  ))}
                </div>
              </section>
            </Reveal>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Reveal delay={100}>
              <div className="card flex flex-col items-center p-6 text-center">
                <TrustRing score={company.trustScore} size={96} />
                <p className="mt-3 text-sm font-semibold">{t("common.trustScore")}</p>
                <p className="text-xs text-[var(--text-muted)]">{t("companyDetail.updatedDaily")}</p>
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div className="card p-6">
                <h3 className="mb-4 font-display font-semibold">{t("companyDetail.keyFacts")}</h3>
                <div className="space-y-3 text-sm">
                  {[
                    { icon: Users, labelKey: "companyDetail.fact.employees", val: company.employees },
                    { icon: TrendingUp, labelKey: "companyDetail.fact.revenue", val: company.revenue },
                    { icon: FileSignature, labelKey: "companyDetail.fact.dealsClosed", val: `${company.deals}+` },
                    { icon: Calendar, labelKey: "companyDetail.fact.founded", val: String(company.founded) },
                    { icon: Globe, labelKey: "companyDetail.fact.website", val: `${company.name.split(" ")[0].toLowerCase()}.com` },
                  ].map((f) => (
                    <div key={f.labelKey} className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-[var(--text-muted)]">
                        <f.icon className="h-4 w-4" /> {t(f.labelKey)}
                      </span>
                      <span className="font-medium">{f.val}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="card p-6">
                <h3 className="mb-3 font-display font-semibold">{t("companyDetail.contact")} {company.name.split(" ")[0]}</h3>
                {sent ? (
                  <div className="flex flex-col items-center gap-2 py-6 text-center">
                    <CheckCircle2 className="h-10 w-10 text-emerald-trust" />
                    <p className="font-medium">{t("companyDetail.messageSent")}</p>
                    <p className="text-xs text-[var(--text-muted)]">{t("companyDetail.respondsWithin", { name: company.name })}</p>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setSent(true);
                      toast(t("companyDetail.inquirySent", { name: company.name }));
                    }}
                    className="space-y-3"
                  >
                    <input required placeholder={t("companyDetail.yourName")} className="h-10 w-full rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 text-sm outline-none focus:border-cyan-glow/50" />
                    <input required type="email" placeholder={t("common.workEmail")} className="h-10 w-full rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 text-sm outline-none focus:border-cyan-glow/50" />
                    <textarea required placeholder={t("companyDetail.howCanYouPartner")} rows={3} className="w-full rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm outline-none focus:border-cyan-glow/50" />
                    <button type="submit" className="btn btn-primary w-full">
                      <Send className="h-4 w-4 flip-x" /> {t("companyDetail.sendInquiry")}
                    </button>
                    <div className="flex justify-center gap-3 pt-1 text-[var(--text-faint)]">
                      <Mail className="h-4 w-4" />
                      <Phone className="h-4 w-4" />
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </div>
  );
}
