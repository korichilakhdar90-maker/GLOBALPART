import { useNavigate, useParams } from "react-router-dom";
import { Building2, Landmark, User, ShieldCheck, ArrowRight, FileCheck2 } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";

/**
 * Three public entry pathways -- /apply/standard, /apply/corporate,
 * /apply/sovereign -- mirroring the tiered application journey concept
 * from the reference platform. Deliberately thin: each maps directly onto
 * the AccountCategory (INDIVIDUAL / ENTERPRISE / GOVERNMENT) system
 * already built in context.tsx + auth.routes.ts + accountPolicy.ts,
 * rather than duplicating registration, domain-policy, 2FA, or KYB logic
 * in a second place. The pathway page's only job is to explain the tier
 * and hand off to Dashboard's existing signup form with the right
 * category pre-selected.
 */
const TIERS = {
  standard: {
    category: "INDIVIDUAL" as const,
    icon: User,
    color: "cyan-glow",
    titleKey: "apply.standard.title",
    descKey: "apply.standard.desc",
    stepsKeys: ["apply.standard.step1", "apply.standard.step2", "apply.standard.step3"],
  },
  corporate: {
    category: "ENTERPRISE" as const,
    icon: Building2,
    color: "emerald-trust",
    titleKey: "apply.corporate.title",
    descKey: "apply.corporate.desc",
    stepsKeys: ["apply.corporate.step1", "apply.corporate.step2", "apply.corporate.step3", "apply.corporate.step4"],
  },
  sovereign: {
    category: "GOVERNMENT" as const,
    icon: Landmark,
    color: "violet-glow",
    titleKey: "apply.sovereign.title",
    descKey: "apply.sovereign.desc",
    stepsKeys: ["apply.sovereign.step1", "apply.sovereign.step2", "apply.sovereign.step3"],
  },
} as const;

export default function Apply() {
  const { tier } = useParams<{ tier: string }>();
  const { t, user } = useApp();
  const navigate = useNavigate();

  const config = tier && tier in TIERS ? TIERS[tier as keyof typeof TIERS] : null;
  if (!config) {
    navigate("/apply/standard", { replace: true });
    return null;
  }
  const Icon = config.icon;

  return (
    <div className="min-h-screen">
      <Seo title={t(config.titleKey)} description={t(config.descKey)} />

      <section className="relative overflow-hidden py-16">
        <div className={`pointer-events-none absolute left-1/2 top-0 h-72 w-96 -translate-x-1/2 rounded-full bg-${config.color}/15 blur-3xl`} />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <Reveal>
            <div className={`mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-${config.color}/15 text-${config.color}`}>
              <Icon className="h-8 w-8" />
            </div>
            <SectionHeading eyebrow={t("apply.eyebrow")} title={t(config.titleKey)} subtitle={t(config.descKey)} center />
          </Reveal>

          {/* Tier switcher -- lets a visitor land on the wrong pathway and correct course in one click. */}
          <Reveal delay={0.05}>
            <div className="mt-6 inline-flex gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1.5">
              {(Object.keys(TIERS) as (keyof typeof TIERS)[]).map((key) => (
                <button
                  key={key}
                  onClick={() => navigate(`/apply/${key}`)}
                  className={`rounded-lg px-4 py-2 text-sm font-medium transition ${
                    key === tier ? "bg-cyan-glow/15 text-[var(--text)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"
                  }`}
                >
                  {t(`apply.${key}.title`)}
                </button>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 pb-20">
        <Reveal delay={0.1}>
          <div className="card space-y-4 p-6">
            <h3 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-[var(--text-muted)]">
              <FileCheck2 className="h-4 w-4" /> {t("apply.stepsHeading")}
            </h3>
            <ol className="space-y-3">
              {config.stepsKeys.map((key, i) => (
                <li key={key} className="flex items-start gap-3 text-sm text-[var(--text)]">
                  <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full bg-${config.color}/15 text-xs font-bold text-${config.color}`}>
                    {i + 1}
                  </span>
                  {t(key)}
                </li>
              ))}
            </ol>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <button
            onClick={() =>
              navigate(
                config.category === "GOVERNMENT" && user?.accountCategory === "GOVERNMENT"
                  ? "/apply/government/wizard"
                  : `/dashboard?mode=signup&category=${config.category}`
              )
            }
            className="btn btn-primary mt-6 w-full shine"
          >
            <ShieldCheck className="h-4 w-4" /> {t("apply.startButton")} <ArrowRight className="h-4 w-4" />
          </button>
        </Reveal>
      </section>
    </div>
  );
}
