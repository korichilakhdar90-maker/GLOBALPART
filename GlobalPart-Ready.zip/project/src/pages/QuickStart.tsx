import { Link } from "react-router-dom";
import { UserPlus, FileCheck2, Activity, LifeBuoy } from "lucide-react";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";

const STEPS = [
  { icon: UserPlus, titleKey: "quickStart.step1.title", bodyKey: "quickStart.step1.body", to: "/apply/standard" },
  { icon: FileCheck2, titleKey: "quickStart.step2.title", bodyKey: "quickStart.step2.body", to: "/kyb" },
  { icon: Activity, titleKey: "quickStart.step3.title", bodyKey: "quickStart.step3.body", to: "/my-application" },
  { icon: LifeBuoy, titleKey: "quickStart.step4.title", bodyKey: "quickStart.step4.body", to: "/feedback" },
] as const;

export default function QuickStart() {
  const { t } = useApp();

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("quickStart.seoTitle")} description={t("quickStart.seoDesc")} />
      <div className="mx-auto max-w-2xl px-4">
        <Reveal>
          <SectionHeading eyebrow={t("quickStart.eyebrow")} title={t("quickStart.title")} subtitle={t("quickStart.subtitle")} />
        </Reveal>

        <div className="mt-10 space-y-4">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            return (
              <Reveal key={step.titleKey} delay={i * 0.05}>
                <Link to={step.to} className="card card-hover flex items-start gap-4 p-5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-cyan-glow/15 text-sm font-bold text-cyan-glow">
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-[var(--text-faint)]" />
                      <h3 className="font-display text-sm font-bold">{t(step.titleKey)}</h3>
                    </div>
                    <p className="mt-1 text-sm text-[var(--text-muted)]">{t(step.bodyKey)}</p>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={0.25}>
          <p className="mt-8 text-center text-sm text-[var(--text-muted)]">
            {t("quickStart.footerNote")} <Link to="/feedback" className="text-cyan-glow hover:underline">{t("quickStart.footerLink")}</Link>
          </p>
        </Reveal>
      </div>
    </div>
  );
}
