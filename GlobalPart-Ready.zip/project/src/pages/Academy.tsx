import { useState } from "react";
import { Link } from "react-router-dom";
import { BookOpen, Clock, Download, FileText, ArrowRight, ArrowLeft } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { ACADEMY_GUIDES } from "../content/academyGuides";
import { NDA_TEMPLATE, SHIPPING_CONTRACT_TEMPLATE } from "../content/academyTemplates";

function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

const TEMPLATES = [
  { key: "nda", filename: "GlobalPart-NDA-Template.txt", content: NDA_TEMPLATE },
  { key: "shipping", filename: "GlobalPart-International-Sale-Agreement-Template.txt", content: SHIPPING_CONTRACT_TEMPLATE },
];

export default function Academy() {
  const { t } = useApp();
  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const openGuide = ACADEMY_GUIDES.find((g) => g.slug === openSlug);

  if (openGuide) {
    return (
      <div className="pt-28">
        <Seo title={openGuide.title} description={openGuide.summary} />
        <div className="mx-auto max-w-2xl px-4 pb-24">
          <button
            onClick={() => setOpenSlug(null)}
            className="mb-8 flex items-center gap-2 text-sm text-[var(--text-muted)] hover:text-[var(--text)]"
          >
            <ArrowLeft className="h-4 w-4 flip-x" /> {t("academy.backToGuides")}
          </button>
          <h1 className="font-display text-3xl font-bold leading-tight">{openGuide.title}</h1>
          <div className="mt-3 flex items-center gap-2 text-xs text-[var(--text-muted)]">
            <Clock className="h-3.5 w-3.5" /> {openGuide.readMinutes} {t("academy.minRead")}
          </div>
          <div className="mt-8 space-y-4 text-sm leading-relaxed text-[var(--text-muted)]">
            {openGuide.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
          <div className="mt-10 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 text-center">
            <p className="text-sm text-[var(--text-muted)]">{t("academy.ctaText")}</p>
            <Link to="/kyb" className="btn btn-primary mt-4 inline-flex">
              {t("academy.ctaButton")} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28">
      <Seo title={t("academy.seoTitle")} description={t("academy.seoDesc")} />

      <div className="mx-auto max-w-6xl px-4 pb-24">
        <Reveal>
          <SectionHeading eyebrow={t("academy.eyebrow")} title={t("academy.title")} subtitle={t("academy.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <h2 className="mt-14 mb-5 flex items-center gap-2 font-display text-xl font-bold">
            <BookOpen className="h-5 w-5 text-cyan-glow" /> {t("academy.guidesHeading")}
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            {ACADEMY_GUIDES.map((g) => (
              <button
                key={g.slug}
                onClick={() => setOpenSlug(g.slug)}
                className="card card-hover flex h-full flex-col p-6 text-left"
              >
                <h3 className="font-display text-base font-bold leading-snug">{g.title}</h3>
                <p className="mt-2 flex-1 text-sm text-[var(--text-muted)]">{g.summary}</p>
                <div className="mt-4 flex items-center justify-between text-xs text-[var(--text-muted)]">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" /> {g.readMinutes} {t("academy.minRead")}
                  </span>
                  <ArrowRight className="h-4 w-4" />
                </div>
              </button>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <h2 className="mt-16 mb-5 flex items-center gap-2 font-display text-xl font-bold">
            <FileText className="h-5 w-5 text-cyan-glow" /> {t("academy.templatesHeading")}
          </h2>
          <p className="mb-5 max-w-2xl text-sm text-[var(--text-muted)]">{t("academy.templatesNote")}</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {TEMPLATES.map((tpl) => (
              <div key={tpl.key} className="card flex items-center justify-between gap-4 p-6">
                <div>
                  <h3 className="font-display text-base font-bold">{t(`academy.template.${tpl.key}.title`)}</h3>
                  <p className="mt-1 text-sm text-[var(--text-muted)]">{t(`academy.template.${tpl.key}.desc`)}</p>
                </div>
                <button
                  onClick={() => downloadTextFile(tpl.filename, tpl.content)}
                  className="btn btn-ghost shrink-0"
                >
                  <Download className="h-4 w-4" /> {t("academy.download")}
                </button>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </div>
  );
}
