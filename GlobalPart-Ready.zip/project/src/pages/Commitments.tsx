import { CheckCircle2, XCircle, Compass } from "lucide-react";
import { SectionHeading, Reveal, Logo } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";

/**
 * Public, formal transparency page for government/sovereign entities
 * evaluating the platform. Every claim here is deliberately narrow and
 * checkable against what's actually built — no aspirational language in
 * the "today" column, no invented treaties or certifications anywhere.
 * See docs/compliance/README.md and the Sovereign Government Pathway
 * Integration Specification discussion this page implements §3.2–3.4 of.
 */
export default function Commitments() {
  const { t } = useApp();

  return (
    <div className="pt-28">
      <Seo title={t("commitments.seoTitle")} description={t("commitments.seoDesc")} />

      <div className="mx-auto max-w-4xl px-4 pb-24">
        <Reveal>
          <div className="mb-8 flex justify-center">
            <Logo size={44} />
          </div>
          <SectionHeading eyebrow={t("commitments.eyebrow")} title={t("commitments.title")} subtitle={t("commitments.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <p className="mx-auto mt-6 max-w-2xl text-center text-xs text-[var(--text-faint)]">{t("commitments.languageNote")}</p>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            <div className="card p-6">
              <div className="mb-4 flex items-center gap-2.5">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-trust/15 text-emerald-trust">
                  <CheckCircle2 className="h-4.5 w-4.5" />
                </div>
                <h3 className="font-display text-sm font-bold">{t("commitments.today.heading")}</h3>
              </div>
              <ul className="space-y-3 text-sm text-[var(--text-muted)]">
                <li>{t("commitments.today.item1")}</li>
                <li>{t("commitments.today.item2")}</li>
                <li>{t("commitments.today.item3")}</li>
                <li>{t("commitments.today.item4")}</li>
              </ul>
            </div>

            <div className="card p-6">
              <div className="mb-4 flex items-center gap-2.5">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-rose-500/15 text-rose-400">
                  <XCircle className="h-4.5 w-4.5" />
                </div>
                <h3 className="font-display text-sm font-bold">{t("commitments.notToday.heading")}</h3>
              </div>
              <ul className="space-y-3 text-sm text-[var(--text-muted)]">
                <li>{t("commitments.notToday.item1")}</li>
                <li>{t("commitments.notToday.item2")}</li>
                <li>{t("commitments.notToday.item3")}</li>
                <li>{t("commitments.notToday.item4")}</li>
              </ul>
            </div>

            <div className="card p-6">
              <div className="mb-4 flex items-center gap-2.5">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-violet-glow/15 text-violet-glow">
                  <Compass className="h-4.5 w-4.5" />
                </div>
                <h3 className="font-display text-sm font-bold">{t("commitments.future.heading")}</h3>
              </div>
              <ul className="space-y-3 text-sm text-[var(--text-muted)]">
                <li>{t("commitments.future.item1")}</li>
                <li>{t("commitments.future.item2")}</li>
                <li>{t("commitments.future.item3")}</li>
              </ul>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="prose-legal mt-12 space-y-6 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 text-sm leading-relaxed text-[var(--text-muted)]">
            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">{t("commitments.security.heading")}</h2>
              <p>{t("commitments.security.body")}</p>
            </section>
            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">{t("commitments.framework.heading")}</h2>
              <p>{t("commitments.framework.body")}</p>
            </section>
            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">{t("commitments.legalBasis.heading")}</h2>
              <p>
                {t("commitments.legalBasis.body")}{" "}
                <a href="/privacy" className="text-cyan-glow hover:underline">{t("commitments.legalBasis.privacyLink")}</a>
                {" · "}
                <a href="/security" className="text-cyan-glow hover:underline">{t("commitments.legalBasis.securityLink")}</a>
              </p>
            </section>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
