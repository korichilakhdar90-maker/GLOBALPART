import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";

const LAST_UPDATED = "July 2026";

export default function Privacy() {
  return (
    <div className="pt-28">
      <Seo
        title="Privacy Policy"
        description="How GlobalPart collects, uses, and protects your data."
      />
      <div className="mx-auto max-w-3xl px-4 pb-24">
        <Reveal>
          <SectionHeading
            eyebrow="Legal"
            title="Privacy Policy"
            subtitle={`Last updated: ${LAST_UPDATED}`}
          />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="prose-legal mt-10 space-y-8 text-sm leading-relaxed text-[var(--text-muted)]">
            <p>
              GlobalPart ("we", "us", "our") is a pre-launch, early-stage company. This policy
              explains what limited data we currently collect through this website (such as the
              early-access waitlist form) and how we handle it. We will publish an expanded policy
              covering account data, KYB verification documents, and deal-room content before any
              of those features are opened to real users.
            </p>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">1. What we collect today</h2>
              <p>
                If you submit the early-access / waitlist form, we collect the email address,
                company name, and any optional note you provide. We do not currently collect
                payment information, government ID, or other sensitive documents through the
                public website.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">2. How we use it</h2>
              <p>
                Waitlist information is used solely to contact you about early access to
                GlobalPart and to understand demand for the product. We do not sell this data to
                third parties.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">3. Storage & security</h2>
              <p>
                Data is stored using industry-standard encryption in transit (TLS). We are
                building toward formal SOC 2 and ISO 27001 certification — see our{" "}
                <a href="/security" className="text-cyan-glow hover:underline">Trust &amp; Security</a>{" "}
                page for the current status of that roadmap. Until those certifications are
                complete, please do not submit highly sensitive information through this site.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">4. Your rights</h2>
              <p>
                You may request access to, correction of, or deletion of any data we hold about
                you at any time by emailing{" "}
                <a href="mailto:hello@globalpart.io" className="text-cyan-glow hover:underline">
                  hello@globalpart.io
                </a>. We aim to respond within 30 days.
              </p>
            </section>

            {/* 🛑 PLACEHOLDER – REQUIRES LEGAL REVIEW: the statement below
                reflects the codebase as of this writing (no tracking/ad
                cookies, only functional localStorage + the httpOnly auth
                refresh-token cookie). Before public launch, have this
                reviewed by actual legal counsel against current ePrivacy
                Directive / GDPR cookie-consent requirements -- this
                comment is a flag for that review, not a substitute for it. */}
            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">5. Cookies</h2>
              <p>
                This site currently uses only essential, functional local storage (e.g. your
                selected language and theme) and does not use third-party advertising or tracking
                cookies.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">6. Contact</h2>
              <p>
                Questions about this policy can be sent to{" "}
                <a href="mailto:hello@globalpart.io" className="text-cyan-glow hover:underline">
                  hello@globalpart.io
                </a>.
              </p>
            </section>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
