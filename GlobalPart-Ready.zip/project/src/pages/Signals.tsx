import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, Minus, ExternalLink, RadioTower } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal, SampleDataBanner } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";

type Signal = {
  id: string;
  title: string;
  category: string;
  countryCode: string | null;
  value: number;
  unit: string;
  trend: string | null;
  sourceName: string;
  sourceUrl: string;
  asOf: string;
};

const CATEGORIES = ["demand", "shipping", "pricing", "tariffs"] as const;

function TrendIcon({ trend }: { trend: string | null }) {
  if (trend === "up") return <TrendingUp className="h-4 w-4 text-emerald-trust" />;
  if (trend === "down") return <TrendingDown className="h-4 w-4 text-rose-400" />;
  return <Minus className="h-4 w-4 text-[var(--text-muted)]" />;
}

export default function Signals() {
  const { t } = useApp();
  const [category, setCategory] = useState<string | undefined>(undefined);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [loading, setLoading] = useState(true);
  const [errored, setErrored] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setErrored(false);
      if (!isBackendConfigured) {
        // No backend wired yet — show the honest empty state below rather
        // than inventing numbers. This screen is real product surface
        // area, ready to display real data the moment a backend + a data
        // source (admin entry or an automated public-data import job) is
        // connected.
        if (!cancelled) {
          setSignals([]);
          setLoading(false);
        }
        return;
      }
      try {
        const res = await api.tradeSignals.list({ category, perPage: 24 });
        if (!cancelled) setSignals(res.items);
      } catch {
        if (!cancelled) setErrored(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [category]);

  return (
    <div className="pt-28">
      <Seo title={t("signals.seoTitle")} description={t("signals.seoDesc")} />

      <div className="mx-auto max-w-6xl px-4 pb-24">
        <Reveal>
          <SectionHeading eyebrow={t("signals.eyebrow")} title={t("signals.title")} subtitle={t("signals.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-8">
            <SampleDataBanner textKey="signals.sourcingNote" />
          </div>
        </Reveal>

        <Reveal delay={0.08}>
          <div className="mt-2 flex flex-wrap gap-2">
            <button
              onClick={() => setCategory(undefined)}
              className={cn("chip", !category ? "chip-brand" : "chip-gold opacity-60 hover:opacity-100")}
            >
              {t("signals.category.all")}
            </button>
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={cn("chip", category === c ? "chip-brand" : "chip-gold opacity-60 hover:opacity-100")}
              >
                {t(`signals.category.${c}`)}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-8">
          {loading && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="card h-32 animate-pulse p-5" />
              ))}
            </div>
          )}

          {!loading && errored && (
            <div className="card p-8 text-center text-sm text-[var(--text-muted)]">{t("signals.error")}</div>
          )}

          {!loading && !errored && signals.length === 0 && (
            <div className="card flex flex-col items-center gap-3 p-10 text-center">
              <RadioTower className="h-8 w-8 text-cyan-glow" />
              <h3 className="font-display text-lg font-bold">{t("signals.empty.title")}</h3>
              <p className="max-w-md text-sm text-[var(--text-muted)]">{t("signals.empty.desc")}</p>
            </div>
          )}

          {!loading && !errored && signals.length > 0 && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {signals.map((s) => (
                <div key={s.id} className="card card-hover p-5">
                  <div className="flex items-center justify-between">
                    <span className="chip chip-brand text-[0.65rem]">{t(`signals.category.${s.category}`)}</span>
                    <TrendIcon trend={s.trend} />
                  </div>
                  <h3 className="mt-3 font-display text-base font-semibold leading-snug">{s.title}</h3>
                  <div className="mt-2 font-display text-2xl font-bold">
                    {s.value}
                    <span className="ml-1 text-sm font-normal text-[var(--text-muted)]">{s.unit}</span>
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t border-[var(--border)] pt-3 text-xs text-[var(--text-muted)]">
                    <a
                      href={s.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 hover:text-cyan-glow"
                    >
                      {s.sourceName} <ExternalLink className="h-3 w-3" />
                    </a>
                    <span>{new Date(s.asOf).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
