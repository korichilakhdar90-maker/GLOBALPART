import { useState, useRef, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import {
  ShieldCheck, Upload, FileCheck2, CheckCircle2, Clock, Building2, Mail,
  Phone, MapPin, Hash, ArrowRight, ArrowLeft, Sparkles, Award, BadgeCheck, Layers, Crown, Loader2,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal, TrustRing } from "../ui";
import CountrySelect from "../components/CountrySelect";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import FormError from "../components/FormError";
import { api, isBackendConfigured } from "../lib/api";

const STEP_KEYS = ["kyb.step.company", "kyb.step.documents", "kyb.step.review", "kyb.step.status"];

export default function KYB() {
  const { t, addKyb, kyb, toast } = useApp();
  const [searchParams] = useSearchParams();
  // Arriving via "Claim this profile" on CompanyDetail.tsx passes both the
  // id (linked to the KYB submission so approval can flip that exact
  // Company's profileStatus -- see kyb.routes.ts) and a human-readable
  // name (purely to prefill the field below; the id is always what's
  // actually submitted and trusted server-side).
  const claimedCompanyId = searchParams.get("claim");
  const claimedCompanyName = searchParams.get("claimName");
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    company: claimedCompanyName ?? "",
    registration: "",
    email: "",
    phone: "",
    country: [] as string[],
    address: "",
  });
  const [docs, setDocs] = useState<string[]>([]);
  const [docFiles, setDocFiles] = useState<File[]>([]);
  const [recent, setRecent] = useState<(typeof kyb)[number] | null>(null);
  // Submission errors here are server-side and apply to the whole
  // application rather than one field, so this is surfaced as a
  // step-level announced message linked to the review step's group.
  const [submitError, setSubmitError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (k: keyof typeof form, v: string | string[]) => setForm((p) => ({ ...p, [k]: v }));

  const canNext =
    step === 0
      ? form.company && form.registration && form.email && form.phone && form.country.length && form.address
      : step === 1
      ? docs.length > 0
      : true;

  const submit = async () => {
    setSubmitError(null);
    if (isBackendConfigured) {
      const fd = new FormData();
      fd.append("companyName", form.company);
      fd.append("registrationNo", form.registration);
      fd.append("email", form.email);
      fd.append("phone", form.phone);
      fd.append("countries", form.country.join(", "));
      fd.append("address", form.address);
      if (claimedCompanyId) fd.append("claimedCompanyId", claimedCompanyId);
      docFiles.forEach((f) => fd.append("documents", f));
      try {
        const submission = await api.kyb.submit(fd);
        setRecent(submission as (typeof kyb)[number]);
        setStep(3);
        toast(t("kyb.submittedToast"));
      } catch (err) {
        console.error(err);
        const msg = err instanceof Error ? err.message : t("kyb.submitErrorToast");
        setSubmitError(msg);
        toast(msg, "error");
      }
    } else {
      const submission = addKyb({ ...form, country: form.country.join(", "), documents: docs });
      setRecent(submission);
      setStep(3);
      toast(t("kyb.submittedToast"));
    }
  };

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const list = Array.from(files);
    const names = list.map((f) => f.name);
    setDocs((d) => [...new Set([...d, ...names])]);
    setDocFiles((d) => [...d, ...list]);
  };

  return (
    <div className="pt-28">
      <Seo title={t("seo.kyb.title")} description={t("seo.kyb.desc")} />
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute right-1/4 top-0 h-64 w-96 rounded-full bg-emerald-trust/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("kyb.eyebrow")}
              title={<>{t("kyb.title")}</>}
              subtitle={t("kyb.subtitle")}
            />
          </Reveal>
          {claimedCompanyId && (
            <Reveal delay={0.05}>
              <div className="sample-data-banner mt-4">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
                {t("kyb.claimingBanner", { name: claimedCompanyName ?? "" })}
              </div>
            </Reveal>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 pb-20">
        {/* Trust pillars mini */}
        <Reveal>
          <div className="mb-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: BadgeCheck, labelKey: "kyb.pillar.legalRegistration" },
              { icon: FileCheck2, labelKey: "kyb.pillar.emailPhoneVerified" },
              { icon: Award, labelKey: "kyb.pillar.dynamicTrustScore" },
              { icon: ShieldCheck, labelKey: "kyb.pillar.adminReviewed" },
            ].map((p) => (
              <div key={p.labelKey} className="card flex items-center gap-3 p-4">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-emerald-trust/15 text-emerald-trust">
                  <p.icon className="h-5 w-5" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-medium">{t(p.labelKey)}</span>
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-trust" />
                </div>
              </div>
            ))}
          </div>
        </Reveal>

        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          {/* Form */}
          <Reveal>
            <div className="card p-6 md:p-8">
              {/* Stepper */}
              <div className="mb-8 flex items-center">
                {STEP_KEYS.map((s, i) => (
                  <div key={s} className="flex flex-1 items-center last:flex-none">
                    <div className="flex flex-col items-center">
                      <div
                        className={cn(
                          "grid h-9 w-9 place-items-center rounded-full border-2 text-sm font-bold transition",
                          i < step
                            ? "border-emerald-trust bg-emerald-trust text-white"
                            : i === step
                            ? "border-cyan-glow text-cyan-glow glow-blue"
                            : "border-[var(--border)] text-[var(--text-faint)]"
                        )}
                      >
                        {i < step ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
                      </div>
                      <span className={cn("mt-1.5 hidden text-xs sm:block", i === step ? "text-[var(--text)]" : "text-[var(--text-faint)]")}>{t(s)}</span>
                    </div>
                    {i < STEP_KEYS.length - 1 && (
                      <div className={cn("mx-2 h-0.5 flex-1 rounded transition", i < step ? "bg-emerald-trust" : "bg-[var(--border)]")} />
                    )}
                  </div>
                ))}
              </div>

              {/* Step 0: Company */}
              {step === 0 && (
                <div className="anim-slide-up space-y-4">
                  <Field icon={Building2} label={t("kyb.field.companyName")}>
                    <input value={form.company} onChange={(e) => set("company", e.target.value)} placeholder={t("kyb.field.companyNamePlaceholder")} className="kyb-input" />
                  </Field>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field icon={Hash} label={t("kyb.field.registrationNo")}>
                      <input value={form.registration} onChange={(e) => set("registration", e.target.value)} placeholder={t("kyb.field.registrationPlaceholder")} className="kyb-input" />
                    </Field>
                    <Field icon={MapPin} label={t("kyb.field.country")}>
                      <CountrySelect value={form.country} onChange={(v) => set("country", v as string[])} placeholder={t("kyb.field.countryPlaceholder")} multi={false} />
                    </Field>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field icon={Mail} label={t("kyb.field.officialEmail")}>
                      <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder={t("kyb.field.emailPlaceholder")} className="kyb-input" />
                    </Field>
                    <Field icon={Phone} label={t("kyb.field.phoneNumber")}>
                      <input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder={t("kyb.field.phonePlaceholder")} className="kyb-input" />
                    </Field>
                  </div>
                  <Field icon={MapPin} label={t("kyb.field.registeredAddress")}>
                    <input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder={t("kyb.field.addressPlaceholder")} className="kyb-input" />
                  </Field>
                </div>
              )}

              {/* Step 1: Documents */}
              {step === 1 && (
                <div className="anim-slide-up space-y-4">
                  <p className="text-sm text-[var(--text-muted)]">
                    {t("kyb.documents.instructions")}
                  </p>
                  <div
                    onClick={() => fileRef.current?.click()}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      handleFiles(e.dataTransfer.files);
                    }}
                    className="grid cursor-pointer place-items-center rounded-2xl border-2 border-dashed border-[var(--border-strong)] bg-[var(--surface)] p-10 text-center transition hover:border-cyan-glow/60"
                  >
                    <div className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-600/15 text-cyan-glow">
                      <Upload className="h-6 w-6" />
                    </div>
                    <p className="mt-3 font-medium">{t("kyb.documents.clickOrDrag")}</p>
                    <p className="text-xs text-[var(--text-muted)]">{t("kyb.documents.maxSize")}</p>
                    <input
                      ref={fileRef}
                      type="file"
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png"
                      className="hidden"
                      onChange={(e) => handleFiles(e.target.files)}
                    />
                  </div>
                  {docs.length > 0 && (
                    <div className="space-y-2">
                      {docs.map((d) => (
                        <div key={d} className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                          <FileCheck2 className="h-5 w-5 text-emerald-trust" />
                          <span className="flex-1 truncate text-sm">{d}</span>
                          <CheckCircle2 className="h-4 w-4 text-emerald-trust" />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Step 2: Review */}
              {step === 2 && (
                <div
                  className="anim-slide-up space-y-3"
                  role="group"
                  aria-label={t("kyb.step.review")}
                  aria-describedby={submitError ? "kyb-submit-error" : undefined}
                >
                  <FormError id="kyb-submit-error" message={submitError} />
                  <p className="text-sm text-[var(--text-muted)]">{t("kyb.review.pleaseReview")}</p>
                  <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4">
                    <dl className="grid gap-2 text-sm sm:grid-cols-2">
                      {[
                        [t("kyb.field.companyName"), form.company],
                        [t("kyb.field.registrationNo"), form.registration],
                        [t("kyb.field.officialEmail"), form.email],
                        [t("kyb.field.phoneNumber"), form.phone],
                        [t("kyb.field.country"), form.country.join(", ")],
                        [t("kyb.field.registeredAddress"), form.address],
                        [t("kyb.documents.label"), t("kyb.review.filesCount", { count: String(docs.length) })],
                      ].map(([k, v]) => (
                        <div key={k} className="flex flex-col">
                          <dt className="text-xs text-[var(--text-faint)]">{k}</dt>
                          <dd className="font-medium">{v || "—"}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                  <div className="flex items-start gap-2 rounded-xl bg-emerald-trust/10 p-3 text-sm text-emerald-trust">
                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
                    {t("kyb.review.encryptedNotice")}
                  </div>
                </div>
              )}

              {/* Step 3: Status */}
              {step === 3 && recent && (
                <div className="anim-slide-up flex flex-col items-center py-6 text-center">
                  <div className="relative mb-4">
                    <TrustRing score={recent.trustScore} size={120} />
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
                      <span className="chip chip-emerald shadow-lg"><Clock className="h-3 w-3" /> {t("kyb.status.inReview")}</span>
                    </div>
                  </div>
                  <h3 className="font-display text-xl font-bold">📬 {t("kyb.status.verificationInProgress")}</h3>
                  <p className="mt-2 max-w-sm text-sm text-[var(--text-muted)]">
                    {t("kyb.status.thankYouPrefix")} <span className="font-semibold text-[var(--text)]">{recent.company}</span>{t("kyb.status.thankYouSuffix")} <span className="font-bold text-emerald-trust">{recent.trustScore}</span>.
                  </p>
                  <div className="mt-5 w-full max-w-sm space-y-2">
                    {[
                      [t("kyb.checklist.emailSent"), true],
                      [t("kyb.checklist.phoneOtp"), true],
                      [t("kyb.checklist.documentReview"), false],
                      [t("kyb.checklist.adminApproval"), false],
                    ].map(([label, done]) => (
                      <div key={label as string} className="flex items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] p-2.5 text-sm">
                        {done ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-trust" />
                        ) : (
                          <Clock className="h-4 w-4 text-gold" />
                        )}
                        {label}
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      setStep(0);
                      setRecent(null);
                      setDocs([]);
                      setForm({ company: "", registration: "", email: "", phone: "", country: [] as string[], address: "" });
                    }}
                    className="btn btn-ghost btn-sm mt-6"
                  >
                    {t("kyb.submitAnother")}
                  </button>
                </div>
              )}

              {/* Nav buttons */}
              {step < 3 && (
                <div className="mt-8 flex items-center justify-between">
                  <button
                    onClick={() => setStep((s) => Math.max(0, s - 1))}
                    className={cn("btn btn-ghost btn-sm", step === 0 && "invisible")}
                  >
                    <ArrowLeft className="h-4 w-4 flip-x" /> {t("common.back")}
                  </button>
                  {step < 2 ? (
                    <button onClick={() => setStep((s) => s + 1)} disabled={!canNext} className="btn btn-primary">
                      {t("common.continue")} <ArrowRight className="h-4 w-4" />
                    </button>
                  ) : (
                    <button onClick={submit} className="btn btn-gold" aria-describedby={submitError ? "kyb-submit-error" : undefined}>
                      <ShieldCheck className="h-4 w-4" /> {t("kyb.submitForVerification")}
                    </button>
                  )}
                </div>
              )}
            </div>
          </Reveal>

          {/* Sidebar */}
          <div className="space-y-6">
            <Reveal delay={90}>
              <TrustBadgeCard />
            </Reveal>

            <Reveal delay={100}>
              <div className="card p-6">
                <h3 className="mb-4 flex items-center gap-2 font-display font-semibold">
                  <Sparkles className="h-4 w-4 text-cyan-glow" /> {t("kyb.whyVerify")}
                </h3>
                <ul className="space-y-3 text-sm">
                  {[
                    "kyb.benefit1",
                    "kyb.benefit2",
                    "kyb.benefit3",
                    "kyb.benefit4",
                    "kyb.benefit5",
                  ].map((bKey) => (
                    <li key={bKey} className="flex items-start gap-2 text-[var(--text-muted)]">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-trust" />
                      {t(bKey)}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={125}>
              <div className="card p-6">
                <h3 className="mb-4 flex items-center gap-2 font-display font-semibold">
                  <Layers className="h-4 w-4 text-cyan-glow" /> {t("kyb.methodology.title")}
                </h3>
                <ol className="space-y-3 text-sm">
                  {["kyb.methodology.step1", "kyb.methodology.step2", "kyb.methodology.step3", "kyb.methodology.step4"].map((sKey, i) => (
                    <li key={sKey} className="flex items-start gap-3 text-[var(--text-muted)]">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand-600/15 text-[0.65rem] font-bold text-cyan-glow">
                        {i + 1}
                      </span>
                      {t(sKey)}
                    </li>
                  ))}
                </ol>
                <p className="mt-4 border-t border-[var(--border)] pt-3 text-xs text-[var(--text-muted)]">
                  {t("kyb.methodology.disclaimer")}
                </p>
              </div>
            </Reveal>
            {kyb.length > 0 && (
              <Reveal delay={150}>
                <div className="card p-6">
                  <h3 className="mb-3 font-display font-semibold">{t("kyb.recentSubmissions")}</h3>
                  <div className="space-y-2">
                    {kyb.slice(0, 3).map((k) => (
                      <div key={k.id} className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                        <TrustRing score={k.trustScore} size={40} />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">{k.company}</div>
                          <div className="text-xs text-[var(--text-muted)]">{k.country}</div>
                        </div>
                        <span className="chip chip-gold">{t("kyb.reviewChip")}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>
            )}
          </div>
        </div>
      </div>

      <style>{`.kyb-input{width:100%;height:2.9rem;border-radius:0.6rem;border:1px solid var(--border);background:var(--surface);padding:0 0.85rem;font-size:0.9rem;outline:none;transition:border-color .2s}.kyb-input:focus{border-color:rgba(34,211,238,.5)}`}</style>
    </div>
  );
}

function Field({ icon: Icon, label, children }: { icon: any; label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
        <Icon className="h-3.5 w-3.5" /> {label}
      </label>
      {children}
    </div>
  );
}

// Feature 1 — Verified Trust Badge ($100/mo). Registration and search stay
// free; this is the paid product that unlocks the actual audit + badge +
// priority search placement. Shown at the top of the KYB sidebar since an
// active subscription here is now required before an admin can approve a
// submission (see server/src/routes/kyb.routes.ts).
function TrustBadgeCard() {
  const { t, user, toast } = useApp();
  const [active, setActive] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isBackendConfigured || !user) {
      setActive(false);
      return;
    }
    api.trustBadge
      .status()
      .then((res) => setActive(res.active))
      .catch(() => setActive(false));
  }, [user]);

  const subscribe = async () => {
    setLoading(true);
    try {
      const res = await api.trustBadge.checkout();
      window.location.href = res.url;
    } catch (err) {
      toast(err instanceof Error ? err.message : t("kyb.badge.checkoutError"), "error");
      setLoading(false);
    }
  };

  return (
    <div className="card border-gold/30 p-6">
      <div className="flex items-center gap-2">
        <Crown className="h-5 w-5 text-gold" />
        <h3 className="font-display font-semibold">{t("kyb.badge.title")}</h3>
      </div>
      <p className="mt-2 text-sm text-[var(--text-muted)]">{t("kyb.badge.desc")}</p>

      {active === true && (
        <div className="mt-4 flex items-center gap-2 rounded-lg border border-emerald-trust/30 bg-emerald-trust/10 px-3 py-2 text-sm font-medium text-emerald-trust">
          <BadgeCheck className="h-4 w-4" /> {t("kyb.badge.active")}
        </div>
      )}

      {active === false && (
        <button onClick={subscribe} disabled={loading} className="btn btn-gold mt-4 w-full">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Crown className="h-4 w-4" />}
          {t("kyb.badge.subscribe")}
        </button>
      )}

      <p className="mt-3 text-xs text-[var(--text-muted)]">{t("kyb.badge.note")}</p>
    </div>
  );
}

