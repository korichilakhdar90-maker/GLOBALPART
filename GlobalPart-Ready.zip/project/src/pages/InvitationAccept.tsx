import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Gift, CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";
import { useApp } from "../context";
import { Reveal, Logo } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured, type InvitationStatus, type InviteeType } from "../lib/api";

const TYPE_TO_PATHWAY: Record<InviteeType, string> = {
  INDIVIDUAL: "standard",
  ENTERPRISE: "corporate",
  GOVERNMENT: "government",
};

interface Preview {
  inviterName: string;
  inviteeEmail: string;
  inviteeType: InviteeType;
  status: InvitationStatus;
  expiresAt: string;
}

export default function InvitationAccept() {
  const { token } = useParams<{ token: string }>();
  const { t, user, toast } = useApp();
  const navigate = useNavigate();
  const [preview, setPreview] = useState<Preview | null>(null);
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token || !isBackendConfigured) {
      setLoading(false);
      return;
    }
    api.invitations
      .preview(token)
      .then(setPreview)
      .catch((err) => setError(err instanceof Error ? err.message : t("common.errorGeneric")))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const accept = async () => {
    if (!token) return;
    // Not signed in yet: send them to register with the matching pathway
    // pre-selected and the token carried along, so they land back here
    // after signup instead of losing the invitation.
    if (!user) {
      const pathway = preview ? TYPE_TO_PATHWAY[preview.inviteeType] : "standard";
      navigate(`/dashboard?mode=signup&category=${preview?.inviteeType ?? "INDIVIDUAL"}&invite=${token}&pathway=${pathway}`);
      return;
    }
    setAccepting(true);
    try {
      await api.invitations.accept(token);
      setAccepted(true);
      toast(t("invitationAccept.success"));
    } catch (err) {
      toast(err instanceof Error ? err.message : t("common.errorGeneric"), "error");
    } finally {
      setAccepting(false);
    }
  };

  const shell = (children: React.ReactNode) => (
    <div className="grid min-h-screen place-items-center px-4 py-28">
      <Seo title={t("invitationAccept.seoTitle")} description={t("invitationAccept.seoDesc")} />
      <Reveal>
        <div className="card ring-gradient w-full max-w-md p-8 text-center">
          <div className="mb-5 flex justify-center"><Logo size={38} /></div>
          {children}
        </div>
      </Reveal>
    </div>
  );

  if (!isBackendConfigured) return shell(<p className="text-sm text-[var(--text-muted)]">{t("invite.backendRequired")}</p>);
  if (loading) return shell(<Loader2 className="mx-auto h-6 w-6 animate-spin text-[var(--text-faint)]" />);

  if (error || !preview) {
    return shell(
      <>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-500/15 text-rose-400">
          <AlertTriangle className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-xl font-bold">{t("invitationAccept.invalidTitle")}</h1>
        <p className="mt-2 text-sm text-[var(--text-muted)]">{error ?? t("invitationAccept.invalidBody")}</p>
      </>
    );
  }

  if (accepted || preview.status === "ACCEPTED") {
    return shell(
      <>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-trust/15 text-emerald-trust">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-xl font-bold">{t("invitationAccept.acceptedTitle")}</h1>
        <p className="mt-2 text-sm text-[var(--text-muted)]">{t("invitationAccept.acceptedBody")}</p>
        <button onClick={() => navigate("/dashboard")} className="btn btn-gold mt-6 shine">{t("dashboard.partnershipHub")}</button>
      </>
    );
  }

  if (preview.status === "EXPIRED" || preview.status === "REVOKED") {
    return shell(
      <>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[var(--color-gold)]/15 text-[var(--color-gold)]">
          <AlertTriangle className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-xl font-bold">{t(`invitationAccept.${preview.status === "EXPIRED" ? "expiredTitle" : "revokedTitle"}`)}</h1>
        <p className="mt-2 text-sm text-[var(--text-muted)]">{t("invitationAccept.contactInviter", { inviter: preview.inviterName })}</p>
      </>
    );
  }

  return shell(
    <>
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[var(--color-gold)]/15 text-[var(--color-gold)]">
        <Gift className="h-7 w-7" />
      </div>
      <h1 className="mt-4 font-display text-xl font-bold">{t("invitationAccept.title")}</h1>
      <p className="mt-2 text-sm text-[var(--text-muted)]">
        {t("invitationAccept.invitedBy", { inviter: preview.inviterName })}
      </p>
      <p className="mt-3 rounded-lg bg-[var(--surface)] px-3 py-2 text-xs text-[var(--text-faint)]">
        {t("invitationAccept.forEmail", { email: preview.inviteeEmail })}
      </p>
      <button onClick={accept} disabled={accepting} className="btn btn-gold mt-6 w-full shine disabled:opacity-60">
        {accepting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
        {user ? t("invitationAccept.acceptButton") : t("invitationAccept.registerButton")}
      </button>
      {!user && <p className="mt-3 text-xs text-[var(--text-faint)]">{t("invitationAccept.registerHint")}</p>}
    </>
  );
}
