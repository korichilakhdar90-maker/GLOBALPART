import { useState } from "react";
import {
  ShieldCheck, Lock, KeyRound, Eye, Globe2,
  Scale, Activity, RefreshCw, Database, Cloud, Network,
  CheckCircle2, ChevronDown, ShieldAlert,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";

const PILLARS = [
  {
    icon: ShieldCheck, nameKey: "security.pillar.trust.name", color: "from-emerald-trust to-cyan-glow",
    itemKeys: ["security.pillar.trust.item1", "security.pillar.trust.item2", "security.pillar.trust.item3", "security.pillar.trust.item4", "security.pillar.trust.item5", "security.pillar.trust.item6"],
  },
  {
    icon: Lock, nameKey: "security.pillar.security.name", color: "from-brand-500 to-violet-glow",
    itemKeys: ["security.pillar.security.item1", "security.pillar.security.item2", "security.pillar.security.item3", "security.pillar.security.item4", "security.pillar.security.item5", "security.pillar.security.item6", "security.pillar.security.item7"],
  },
  {
    icon: Eye, nameKey: "security.pillar.transparency.name", color: "from-cyan-glow to-emerald-trust",
    itemKeys: ["security.pillar.transparency.item1", "security.pillar.transparency.item2", "security.pillar.transparency.item3", "security.pillar.transparency.item4", "security.pillar.transparency.item5", "security.pillar.transparency.item6"],
  },
  {
    icon: Activity, nameKey: "security.pillar.reliability.name", color: "from-gold to-gold-deep",
    itemKeys: ["security.pillar.reliability.item1", "security.pillar.reliability.item2", "security.pillar.reliability.item3", "security.pillar.reliability.item4", "security.pillar.reliability.item5", "security.pillar.reliability.item6"],
  },
  {
    icon: Scale, nameKey: "security.pillar.compliance.name", color: "from-violet-glow to-brand-500",
    itemKeys: ["security.pillar.compliance.item1", "security.pillar.compliance.item2", "security.pillar.compliance.item3", "security.pillar.compliance.item4", "security.pillar.compliance.item5", "security.pillar.compliance.item6"],
  },
  {
    icon: Cloud, nameKey: "security.pillar.scalability.name", color: "from-brand-500 to-cyan-glow",
    itemKeys: ["security.pillar.scalability.item1", "security.pillar.scalability.item2", "security.pillar.scalability.item3", "security.pillar.scalability.item4", "security.pillar.scalability.item5", "security.pillar.scalability.item6"],
  },
];

// `cert: true` = requires a formal third-party audit/certification we do not
// yet hold — shown as "Roadmap" rather than implying it's already achieved.
// `cert: false` = a design/operating principle we can honestly say we follow
// today without a third-party audit (data-handling practice, not a license).
const COMPLIANCE: { name: string; cert: boolean }[] = [
  { name: "SOC 2 Type II", cert: true },
  { name: "GDPR", cert: false },
  { name: "ISO 27001", cert: true },
  { name: "PCI DSS", cert: true },
  { name: "AML", cert: false },
  { name: "KYC", cert: false },
  { name: "CCPA", cert: false },
  { name: "ISO 9001", cert: true },
];

const FAQ_KEYS = [
  { qKey: "security.faq.q1", aKey: "security.faq.a1" },
  { qKey: "security.faq.q2", aKey: "security.faq.a2" },
  { qKey: "security.faq.q3", aKey: "security.faq.a3" },
  { qKey: "security.faq.q4", aKey: "security.faq.a4" },
  { qKey: "security.faq.q5", aKey: "security.faq.a5" },
];

export default function Security() {
  const { t } = useApp();
  const [open, setOpen] = useState(0);

  return (
    <div className="pt-28">
      <Seo title={t("seo.security.title")} description={t("seo.security.desc")} />
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-[40rem] -translate-x-1/2 rounded-full bg-emerald-trust/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("security.eyebrow")}
              title={<>{t("section.trust.title")}</>}
              subtitle={t("section.trust.subtitle")}
            />
          </Reveal>

          {/* Hero trust band */}
          <Reveal delay={100}>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Lock, v: "AES-256", lKey: "security.hero.encryption" },
                { icon: ShieldCheck, v: "SOC 2", lKey: "security.hero.typeII" },
                { icon: Activity, v: "99.9%", lKey: "security.hero.uptimeSla" },
                { icon: Globe2, v: "GDPR", lKey: "security.hero.compliant" },
              ].map((s) => (
                <div key={s.lKey} className="card flex items-center gap-3 p-5">
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-emerald-trust/15 text-emerald-trust">
                    <s.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-xl font-bold">{s.v}</div>
                    <div className="text-xs text-[var(--text-muted)]">{t(s.lKey)}</div>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* Pillars grid */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {PILLARS.map((p, i) => (
              <Reveal key={p.nameKey} delay={i * 70}>
                <div className="card card-hover h-full p-6">
                  <div className={`mb-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${p.color}`}>
                    <p.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-display text-lg font-semibold">{t(p.nameKey)}</h3>
                  <ul className="mt-3 space-y-2">
                    {p.itemKeys.map((itKey) => (
                      <li key={itKey} className="flex items-start gap-2 text-sm text-[var(--text-muted)]">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-trust" />
                        {t(itKey)}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Compliance badges */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <div className="card p-8">
              <div className="grid items-center gap-8 lg:grid-cols-[1fr_1.4fr]">
                <div className="flex flex-col items-center text-center">
                  <ShieldCheck className="h-16 w-16 text-emerald-trust" />
                  <h3 className="mt-4 font-display text-xl font-bold">{t("security.complianceCerts")}</h3>
                  <p className="mt-1 text-sm text-[var(--text-muted)]">{t("security.complianceCertsDesc")}</p>
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {COMPLIANCE.map((c) => (
                    <div key={c.name} className="flex flex-col items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-center transition hover:border-emerald-trust/40">
                      <ShieldCheck className={cn("h-6 w-6", c.cert ? "text-gold" : "text-emerald-trust")} />
                      <span className="text-xs font-semibold">{c.name}</span>
                      <span className={cn("chip", c.cert ? "chip-gold" : "chip-emerald", "text-[0.65rem]")}>
                        {t(c.cert ? "security.status.roadmap" : "security.status.aligned")}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Architecture highlights */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading eyebrow={t("security.infrastructure")} title={t("security.architectureTitle")} />
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Network, tKey: "security.arch.multiRegion.title", dKey: "security.arch.multiRegion.desc" },
              { icon: Database, tKey: "security.arch.shardedDb.title", dKey: "security.arch.shardedDb.desc" },
              { icon: KeyRound, tKey: "security.arch.zeroTrust.title", dKey: "security.arch.zeroTrust.desc" },
              { icon: RefreshCw, tKey: "security.arch.disasterRecovery.title", dKey: "security.arch.disasterRecovery.desc" },
            ].map((f, i) => (
              <Reveal key={f.tKey} delay={i * 70}>
                <div className="card h-full p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-brand-600/15 text-cyan-glow">
                    <f.icon className="h-5 w-5" />
                  </div>
                  <h4 className="mt-3 font-display font-semibold">{t(f.tKey)}</h4>
                  <p className="mt-1 text-sm text-[var(--text-muted)]">{t(f.dKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12">
        <div className="mx-auto max-w-3xl px-4">
          <Reveal>
            <SectionHeading eyebrow={t("security.faqEyebrow")} title={t("security.faqTitle")} />
          </Reveal>
          <div className="mt-8 space-y-3">
            {FAQ_KEYS.map((f, i) => (
              <Reveal key={i} delay={i * 50}>
                <div className="card overflow-hidden">
                  <button
                    onClick={() => setOpen(open === i ? -1 : i)}
                    className="flex w-full items-center justify-between gap-4 p-5 text-start"
                  >
                    <span className="flex items-center gap-3 font-medium">
                      <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-trust" />
                      {t(f.qKey)}
                    </span>
                    <ChevronDown className={cn("h-4 w-4 shrink-0 transition", open === i && "rotate-180")} />
                  </button>
                  <div className={cn("grid transition-all duration-300", open === i ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-sm text-[var(--text-muted)]">{t(f.aKey)}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal>
            <div className="mt-8 flex items-center justify-center gap-2 rounded-xl border border-emerald-trust/30 bg-emerald-trust/5 p-4 text-center text-sm">
              <ShieldAlert className="h-5 w-5 text-emerald-trust" />
              {t("security.vulnerabilityDisclosure")}
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
