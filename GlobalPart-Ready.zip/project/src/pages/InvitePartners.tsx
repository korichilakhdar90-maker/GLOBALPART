import { useEffect, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { UserPlus, Copy, Check, Trash2, Wallet, Loader2, ArrowLeft } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured, type Invitation, type InviteeType, type InvitationStatus } from "../lib/api";
import { cn } from "../utils/cn";
import FormError from "../components/FormError";

const STATUS_CHIP: Record<InvitationStatus, string> = {
  PENDING: "chip-gold",
  ACCEPTED: "chip-emerald",
  EXPIRED: "chip",
  REVOKED: "bg-rose-500/10 text-rose-400 border-rose-500/30",
};

export default function InvitePartners() {
  const { t, user, toast } = useApp();
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [balanceCents, setBalanceCents] = useState(0);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [email, setEmail] = useState("");
  const [inviteeType, setInviteeType] = useState<InviteeType>("INDIVIDUAL");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);

  const load = () => {
    api.invitations
      .list()
      .then((res) => {
        setInvitations(res.invitations);
        setBalanceCents(res.creditBalanceCents);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (!user || !isBackendConfigured) {
      setLoading(false);
      return;
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  if (!isBackendConfigured) {
    return (
      <div className="grid min-h-screen place-items-center px-4 text-center">
        <p className="text-sm text-[var(--text-muted)]">{t("invite.backendRequired")}</p>
      </div>
    );
  }

  const send = async (e: FormEvent) => {
    e.preventDefault();
    setSendError(null);
    setSending(true);
    try {
      await api.invitations.create({ inviteeEmail: email, inviteeType });
      setEmail("");
      toast(t("invite.sent"));
      load();
    } catch (err) {
      const msg = err instanceof Error ? err.message : t("common.errorGeneric");
      setSendError(msg);
      toast(msg, "error");
    } finally {
      setSending(false);
    }
  };

  const copyLink = async (inv: Invitation) => {
    try {
      await navigator.clipboard.writeText(inv.link);
      setCopiedId(inv.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      toast(t("common.errorGeneric"), "error");
    }
  };

  const revoke = async (inv: Invitation) => {
    try {
      await api.invitations.revoke(inv.id);
      toast(t("invite.revoked"));
      load();
    } catch (err) {
      toast(err instanceof Error ? err.message : t("common.errorGeneric"), "error");
    }
  };

  const inputCls = "w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none transition focus:border-[var(--color-gold)]/60";

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("invite.seoTitle")} description={t("invite.seoDesc")} />
      <div className="mx-auto max-w-4xl px-4">
        <Link to="/dashboard" className="mb-4 inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] hover:text-[var(--text)]">
          <ArrowLeft className="h-4 w-4" /> {t("dashboard.partnershipHub")}
        </Link>

        <Reveal>
          <SectionHeading eyebrow={t("invite.eyebrow")} title={t("invite.title")} subtitle={t("invite.subtitle")} center={false} />
        </Reveal>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_260px]">
          <Reveal delay={0.05}>
            <form onSubmit={send} className="card space-y-3 p-6">
              <h3 className="flex items-center gap-2 font-display text-sm font-bold">
                <UserPlus className="h-4 w-4 text-[var(--color-gold)]" /> {t("invite.formHeading")}
              </h3>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t("invite.emailPlaceholder")}
                className={inputCls}
                aria-invalid={!!sendError}
                aria-describedby={sendError ? "invite-error" : undefined}
              />
              <FormError id="invite-error" message={sendError} />
              <div>
                <label htmlFor="invitee-type" className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                  {t("invite.typeLabel")}
                </label>
                <select id="invitee-type" value={inviteeType} onChange={(e) => setInviteeType(e.target.value as InviteeType)} className={inputCls}>
                  <option value="INDIVIDUAL">{t("apply.standard.title")}</option>
                  <option value="ENTERPRISE">{t("apply.corporate.title")}</option>
                  <option value="GOVERNMENT">{t("apply.sovereign.title")}</option>
                </select>
                <p className="mt-1.5 text-xs text-[var(--text-faint)]">{t("invite.typeHint")}</p>
              </div>
              <button type="submit" disabled={sending} className="btn btn-gold w-full shine disabled:opacity-60">
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />} {t("invite.sendButton")}
              </button>
            </form>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="card p-6 text-center">
              <div className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-[var(--color-gold)]/15 text-[var(--color-gold)]">
                <Wallet className="h-5 w-5" />
              </div>
              <p className="mt-3 text-xs uppercase tracking-wide text-[var(--text-faint)]">{t("invite.balanceLabel")}</p>
              <p className="mt-1 font-display text-3xl font-bold">${(balanceCents / 100).toFixed(2)}</p>
              <p className="mt-2 text-xs text-[var(--text-muted)]">{t("invite.balanceHint")}</p>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.15}>
          <div className="card mt-6 overflow-hidden">
            <div className="border-b border-[var(--border)] p-5">
              <h3 className="font-display text-sm font-bold">{t("invite.tableHeading", { count: String(invitations.length) })}</h3>
            </div>
            {loading ? (
              <div className="grid h-32 place-items-center"><Loader2 className="h-5 w-5 animate-spin text-[var(--text-faint)]" /></div>
            ) : invitations.length === 0 ? (
              <p className="p-6 text-sm text-[var(--text-muted)]">{t("invite.empty")}</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)] text-xs uppercase tracking-wide text-[var(--text-faint)]">
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.email")}</th>
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.type")}</th>
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.status")}</th>
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.sent")}</th>
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.expires")}</th>
                      <th className="px-5 py-2.5 font-medium">{t("invite.col.actions")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border)]">
                    {invitations.map((inv) => (
                      <tr key={inv.id}>
                        <td className="px-5 py-3">{inv.inviteeEmail}</td>
                        <td className="px-5 py-3 text-xs text-[var(--text-muted)]">{inv.inviteeType}</td>
                        <td className="px-5 py-3">
                          <span className={cn("chip text-[0.65rem]", STATUS_CHIP[inv.status])}>{t(`invite.status.${inv.status}`)}</span>
                        </td>
                        <td className="px-5 py-3 text-xs text-[var(--text-muted)]">{new Date(inv.createdAt).toLocaleDateString()}</td>
                        <td className="px-5 py-3 text-xs text-[var(--text-muted)]">{new Date(inv.expiresAt).toLocaleDateString()}</td>
                        <td className="px-5 py-3">
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => copyLink(inv)}
                              className="rounded-lg p-1.5 text-[var(--text-faint)] transition hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                              aria-label={t("invite.copyLink")}
                              title={t("invite.copyLink")}
                            >
                              {copiedId === inv.id ? <Check className="h-3.5 w-3.5 text-emerald-trust" /> : <Copy className="h-3.5 w-3.5" />}
                            </button>
                            {inv.status === "PENDING" && (
                              <button
                                onClick={() => revoke(inv)}
                                className="rounded-lg p-1.5 text-[var(--text-faint)] transition hover:bg-rose-500/10 hover:text-rose-400"
                                aria-label={t("invite.revoke")}
                                title={t("invite.revoke")}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </div>
  );
}
