import { Mail, MapPin } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";

export default function About() {
  const { t } = useApp();
  return (
    <div className="pt-28">
      <Seo title={t("about.seoTitle")} description={t("about.seoDesc")} />

      <div className="mx-auto max-w-4xl px-4 pb-24">
        <Reveal>
          <SectionHeading eyebrow={t("about.eyebrow")} title={t("about.title")} subtitle={t("about.subtitle")} />
        </Reveal>

        <Reveal delay={0.02}>
          <div className="mt-8 rounded-2xl border border-[var(--border-strong)] bg-[var(--surface)] p-6">
            <h4 className="mb-2 font-display text-base font-bold text-[var(--text)]">{t("about.sovereign.title")}</h4>
            <p className="text-sm leading-relaxed text-[var(--text-muted)]">{t("about.sovereign.desc")}</p>
          </div>
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-12 card p-8">
            <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
              <div className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-violet-glow font-display text-2xl font-bold text-white">
                LK
              </div>
              <div>
                <h3 className="font-display text-xl font-bold">Lakhdar Korichi</h3>
                <p className="text-sm text-cyan-glow">{t("about.founderTitle")}</p>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
                  <MapPin className="h-3.5 w-3.5" /> {t("about.location")}
                </p>
              </div>
            </div>
            <p className="mt-6 text-sm leading-relaxed text-[var(--text-muted)]">{t("about.founderBio")}</p>
            <a
              href="mailto:hello@globalpart.io"
              className="btn btn-ghost mt-6 inline-flex w-fit items-center gap-2"
            >
              <Mail className="h-4 w-4" /> {t("about.contactCta")}
            </a>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-8 rounded-2xl border border-gold/30 bg-gold/10 p-6 text-sm leading-relaxed">
            <h4 className="mb-2 font-semibold text-[var(--text)]">{t("about.stageTitle")}</h4>
            <p className="text-[var(--text-muted)]">{t("about.stageDesc")}</p>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
