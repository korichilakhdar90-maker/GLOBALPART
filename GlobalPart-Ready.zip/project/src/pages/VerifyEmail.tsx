import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { MailCheck, XCircle, Loader2, ArrowLeft } from "lucide-react";
import { Reveal } from "../ui";
import Seo from "../components/Seo";
import { API_URL, isBackendConfigured } from "../lib/api";
import { useApp } from "../context";

type Status = "verifying" | "success" | "error";

export default function VerifyEmail() {
  const { t } = useApp();
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [status, setStatus] = useState<Status>("verifying");

  useEffect(() => {
    if (!isBackendConfigured || !token) {
      setStatus("error");
      return;
    }
    fetch(`${API_URL}/api/auth/verify-email?token=${encodeURIComponent(token)}`)
      .then((res) => setStatus(res.ok ? "success" : "error"))
      .catch(() => setStatus("error"));
  }, [token]);

  return (
    <div className="grid min-h-screen place-items-center px-4 py-28">
      <Seo title={t("verifyEmail.seoTitle")} description={t("verifyEmail.seoDesc")} />
      <Reveal>
        <div className="card ring-gradient w-full max-w-md overflow-hidden text-center">
          <div className="bg-gradient-to-r from-brand-600/20 to-violet-glow/20 p-6">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow">
              {status === "verifying" && <Loader2 className="h-7 w-7 animate-spin text-white" />}
              {status === "success" && <MailCheck className="h-7 w-7 text-white" />}
              {status === "error" && <XCircle className="h-7 w-7 text-white" />}
            </div>
            <h1 className="mt-3 font-display text-2xl font-bold">
              {status === "verifying" && t("verifyEmail.verifying")}
              {status === "success" && t("verifyEmail.success")}
              {status === "error" && t("verifyEmail.failed")}
            </h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              {status === "verifying" && t("verifyEmail.verifyingHint")}
              {status === "success" && t("verifyEmail.successHint")}
              {status === "error" && t("verifyEmail.failedHint")}
            </p>
          </div>
          <div className="border-t border-[var(--border)] p-4">
            <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm font-medium text-cyan-glow hover:underline">
              <ArrowLeft className="h-3.5 w-3.5" /> {t("verifyEmail.backToDashboard")}
            </Link>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
