import { Link } from "react-router-dom";
import { Database, ShieldCheck, AlertTriangle } from "lucide-react";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";

/**
 * Linked from the hero's honest stat cards on Home.tsx. Explains what the
 * three headline numbers actually mean and, critically, is upfront that
 * the company directory currently shown to visitors is illustrative demo
 * data (see common.sampleDataBanner elsewhere) rather than a live,
 * verified marketplace -- the same distinction Companies.tsx and
 * Intelligence.tsx already surface with their own banners.
 */
export default function Methodology() {
  const { t } = useApp();

  return (
    <div className="pt-28">
      <Seo title={t("methodology.seoTitle")} description={t("methodology.seoDesc")} />
      <div className="mx-auto max-w-3xl px-4 pb-24">
        <Reveal>
          <SectionHeading eyebrow={t("methodology.eyebrow")} title={t("methodology.title")} subtitle={t("methodology.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-10 rounded-xl border border-[var(--color-gold)]/30 bg-[var(--color-gold)]/5 p-4 text-sm text-[var(--text-muted)]">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--color-gold)]" />
              <p>{t("methodology.dataNotice")}</p>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-6 space-y-4">
            <div className="card p-5">
              <h3 className="font-display text-sm font-bold">{t("methodology.tiers.heading")}</h3>
              <p className="mt-1 text-sm text-[var(--text-muted)]">{t("methodology.tiers.body")}</p>
            </div>
            <div className="card p-5">
              <h3 className="font-display text-sm font-bold">{t("methodology.scope.heading")}</h3>
              <p className="mt-1 text-sm text-[var(--text-muted)]">{t("methodology.scope.body")}</p>
            </div>
            <div className="card p-5">
              <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold"><ShieldCheck className="h-4 w-4 text-emerald-trust" /> {t("kyb.methodology.title")}</h3>
              <ol className="space-y-2 text-sm text-[var(--text-muted)]">
                <li>1. {t("kyb.methodology.step1")}</li>
                <li>2. {t("kyb.methodology.step2")}</li>
                <li>3. {t("kyb.methodology.step3")}</li>
                <li>4. {t("kyb.methodology.step4")}</li>
              </ol>
              <p className="mt-3 text-xs italic text-[var(--text-faint)]">{t("kyb.methodology.disclaimer")}</p>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="mt-8 flex items-center gap-1.5 text-center text-xs text-[var(--text-faint)]">
            <Database className="h-3.5 w-3.5" />
            {t("methodology.footerNote")} <Link to="/commitments" className="text-cyan-glow hover:underline">{t("footer.link.commitments")}</Link>
          </p>
        </Reveal>
      </div>
    </div>
  );
}
