import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FileText, Download, Bell, ShieldAlert, Loader2, ArrowLeft } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal, TrustRing } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured, type MyKybSubmission } from "../lib/api";
import { cn } from "../utils/cn";

const STATUS_CHIP: Record<string, string> = {
  DRAFT: "chip",
  PENDING: "chip-gold",
  IN_REVIEW: "chip-gold",
  APPROVED: "chip-emerald",
  REJECTED: "bg-rose-500/10 text-rose-400 border-rose-500/30",
};

/**
 * Requirement 6 ("My Dashboard"): a single real view of a user's
 * application status, current Trust Score, notifications, and uploaded
 * documents — all fetched from the actual backend (GET /api/kyb/mine and
 * GET /api/notifications), not the local demo state the small sidebar
 * card on Dashboard.tsx uses.
 */
export default function MyApplication() {
  const { t, user } = useApp();
  const [submissions, setSubmissions] = useState<MyKybSubmission[] | null>(null);
  const [notifications, setNotifications] = useState<{ id: string; title: string; body: string; read: boolean; createdAt: string }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !isBackendConfigured) {
      setLoading(false);
      return;
    }
    Promise.all([api.kyb.mine(), api.notifications.list()])
      .then(([subs, notifs]) => {
        setSubmissions(subs);
        setNotifications(notifs.notifications);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user]);

  if (!isBackendConfigured) {
    return (
      <div className="grid min-h-screen place-items-center px-4 text-center">
        <p className="text-sm text-[var(--text-muted)]">{t("myApp.backendRequired")}</p>
      </div>
    );
  }

  const latest = submissions?.[0];

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("myApp.seoTitle")} description={t("myApp.seoDesc")} />
      <div className="mx-auto max-w-4xl px-4">
        <Link to="/dashboard" className="mb-4 inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] hover:text-[var(--text)]">
          <ArrowLeft className="h-4 w-4" /> {t("dashboard.partnershipHub")}
        </Link>

        <Reveal>
          <SectionHeading eyebrow={t("myApp.eyebrow")} title={t("myApp.title")} subtitle={t("myApp.subtitle")} center={false} />
        </Reveal>

        {loading ? (
          <div className="mt-12 grid place-items-center"><Loader2 className="h-6 w-6 animate-spin text-[var(--text-faint)]" /></div>
        ) : !latest ? (
          <Reveal delay={0.1}>
            <div className="card mt-8 p-8 text-center">
              <p className="text-sm text-[var(--text-muted)]">{t("myApp.noApplication")}</p>
              <Link to="/kyb" className="btn btn-primary mt-4 shine">{t("dashboard.getVerified")}</Link>
            </div>
          </Reveal>
        ) : (
          <div className="mt-8 grid gap-6 lg:grid-cols-[280px_1fr]">
            {/* Status + Trust Score */}
            <Reveal delay={0.05}>
              <div className="card flex flex-col items-center p-6 text-center">
                <TrustRing score={latest.trustScore ?? 0} size={110} />
                <span className={cn("chip mt-4", STATUS_CHIP[latest.status])}>{t(`myApp.status.${latest.status}`)}</span>
                <h3 className="mt-2 font-display font-semibold">{latest.companyName}</h3>
                {latest.status === "REJECTED" && latest.rejectionReason && (
                  <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-rose-500/10 p-2.5 text-start text-xs text-rose-300">
                    <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {latest.rejectionReason}
                  </p>
                )}
              </div>
            </Reveal>

            <div className="space-y-6">
              {/* Notifications */}
              <Reveal delay={0.1}>
                <div className="card p-6">
                  <h3 className="mb-3 flex items-center gap-2 font-display font-semibold"><Bell className="h-4 w-4 text-cyan-glow" /> {t("myApp.notifications")}</h3>
                  {notifications.length === 0 ? (
                    <p className="text-sm text-[var(--text-muted)]">{t("notifications.empty")}</p>
                  ) : (
                    <div className="space-y-2">
                      {notifications.slice(0, 5).map((n) => (
                        <div key={n.id} className={cn("rounded-lg border border-[var(--border)] p-3 text-sm", !n.read && "bg-cyan-glow/5")}>
                          <p className="font-medium">{n.title}</p>
                          <p className="mt-0.5 text-xs text-[var(--text-muted)]">{n.body}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </Reveal>

              {/* Documents */}
              <Reveal delay={0.15}>
                <div className="card p-6">
                  <h3 className="mb-3 flex items-center gap-2 font-display font-semibold"><FileText className="h-4 w-4 text-emerald-trust" /> {t("myApp.documents")}</h3>
                  {latest.documents.length === 0 ? (
                    <p className="text-sm text-[var(--text-muted)]">{t("myApp.noDocuments")}</p>
                  ) : (
                    <div className="space-y-2">
                      {latest.documents.map((d) => (
                        <a key={d.id} href={d.url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between rounded-lg border border-[var(--border)] p-3 text-sm transition hover:border-[var(--border-strong)]">
                          <span className="truncate">{d.fileName}</span>
                          <Download className="h-4 w-4 shrink-0 text-[var(--text-faint)]" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </Reveal>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
