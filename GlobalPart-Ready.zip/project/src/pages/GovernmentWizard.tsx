import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ShieldCheck, Upload, Landmark, Users, Lock, FileCheck2, CheckCircle2,
  Plus, Trash2, Loader2, ArrowRight, ArrowLeft,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured, type GovernmentPersonnelItem } from "../lib/api";
import { cn } from "../utils/cn";
import FormError from "../components/FormError";

const STEPS = [
  { key: "identity", labelKey: "govWizard.step1.short", icon: Landmark },
  { key: "fsc", labelKey: "govWizard.step2.short", icon: ShieldCheck },
  { key: "personnel", labelKey: "govWizard.step3.short", icon: Users },
  { key: "access", labelKey: "govWizard.step4.short", icon: Lock },
  { key: "legal", labelKey: "govWizard.step5.short", icon: FileCheck2 },
  { key: "review", labelKey: "govWizard.step6.short", icon: CheckCircle2 },
] as const;

const FRAMEWORK_KEYS = [
  "PRIVACY_POLICY",
  "DATA_PROCESSING_AGREEMENT",
  "SOVEREIGN_TRUST_FRAMEWORK",
  "SECURITY_PROTOCOL_COMMITMENT",
  "DATA_ISOLATION_POLICY",
] as const;

function ProgressBar({ currentIndex }: { currentIndex: number }) {
  return (
    <div className="mb-10 flex items-center justify-between">
      {STEPS.map((s, i) => {
        const Icon = s.icon;
        const done = i < currentIndex;
        const active = i === currentIndex;
        return (
          <div key={s.key} className="flex flex-1 items-center">
            <div className="flex flex-col items-center gap-1.5">
              <div
                className={cn(
                  "grid h-9 w-9 place-items-center rounded-full border-2 transition",
                  done && "border-[var(--color-gold)] bg-[var(--color-gold)] text-slate-900",
                  active && "border-[var(--color-gold)] text-[var(--color-gold)]",
                  !done && !active && "border-[var(--border)] text-[var(--text-faint)]"
                )}
              >
                {done ? <CheckCircle2 className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
              </div>
              <span className={cn("hidden text-[0.6rem] font-medium sm:block", active ? "text-[var(--text)]" : "text-[var(--text-faint)]")}>
                {i + 1}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={cn("mx-1.5 h-0.5 flex-1 rounded-full transition", done ? "bg-[var(--color-gold)]" : "bg-[var(--border)]")} />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function GovernmentWizard() {
  const { t, user, toast } = useApp();
  const navigate = useNavigate();
  const [stepIndex, setStepIndex] = useState(0);
  const [saving, setSaving] = useState(false);
  // Step-level rather than field-level: most failures here are
  // cross-field ("provide an FSC reference OR a justification file") or
  // server-side, so there is no single input to flag. The message is
  // announced via role="alert" and linked to the whole step group with
  // aria-describedby -- see the step container below.
  const [stepError, setStepError] = useState<string | null>(null);
  const [draftId, setDraftId] = useState<string | null>(null);

  // Step 1
  const [step1, setStep1] = useState({
    entityName: "", countryCode: "", registrationNo: "", officialContactName: "",
    officialTitle: "", officialEmail: user?.email ?? "", officialPhone: "",
  });
  const [sovereignStatusLetter, setSovereignStatusLetter] = useState<File | null>(null);
  const [entityRegistrationDoc, setEntityRegistrationDoc] = useState<File | null>(null);

  // Step 2
  const [step2, setStep2] = useState({
    fscLevel: "SECRET", fscIssuingAuthority: "", fscIssueDate: "", fscExpiryDate: "", fscReferenceNumber: "",
  });
  const [fscCertificate, setFscCertificate] = useState<File | null>(null);
  const [fscJustification, setFscJustification] = useState<File | null>(null);

  // Step 3
  const [personnel, setPersonnel] = useState<GovernmentPersonnelItem[]>([]);
  const [newPerson, setNewPerson] = useState({
    fullName: "", officialTitle: "", userRole: "SOVEREIGN_ADMIN" as GovernmentPersonnelItem["userRole"],
    pscLevel: "SECRET" as GovernmentPersonnelItem["pscLevel"], pscIssuingAuthority: "", pscIssueDate: "", pscExpiryDate: "",
  });

  // Step 4
  const [step4, setStep4] = useState({
    dataClassificationPolicy: "CONFIDENTIAL", securityOfficerName: "", dataSharingConsent: false, accessLoggingConsent: false,
  });

  // Step 5
  const [acceptedFrameworks, setAcceptedFrameworks] = useState<Set<string>>(new Set());

  // Step 6
  const [finalConfirm, setFinalConfirm] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isBackendConfigured) {
    return (
      <div className="grid min-h-screen place-items-center px-4 text-center">
        <p className="text-sm text-[var(--text-muted)]">{t("govWizard.backendRequired")}</p>
      </div>
    );
  }
  if (!user) {
    navigate("/apply/government");
    return null;
  }

  /** Sets the inline (announced) error AND fires the toast — not either/or. */
  const fail = (msg: string) => {
    setStepError(msg);
    toast(msg, "error");
  };

  const goNext = () => { setStepError(null); setStepIndex((i) => Math.min(i + 1, STEPS.length - 1)); };
  const goBack = () => { setStepError(null); setStepIndex((i) => Math.max(i - 1, 0)); };

  const submitStep1 = async () => {
    setStepError(null);
    if (!sovereignStatusLetter || !entityRegistrationDoc) {
      fail(t("govWizard.filesRequired"));
      return;
    }
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(step1).forEach(([k, v]) => fd.append(k, v));
      fd.append("sovereignStatusLetter", sovereignStatusLetter);
      fd.append("entityRegistrationDoc", entityRegistrationDoc);
      const res = await api.government.createDraft(fd);
      setDraftId(res.id);
      toast(t("govWizard.stepSaved"));
      goNext();
    } catch (err) {
      fail(err instanceof Error ? err.message : t("common.errorGeneric"));
    } finally {
      setSaving(false);
    }
  };

  const submitStep2 = async () => {
    setStepError(null);
    if (!draftId) return;
    if (!step2.fscReferenceNumber && !fscJustification) {
      fail(t("govWizard.fscRequired"));
      return;
    }
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(step2).forEach(([k, v]) => fd.append(k, v));
      fd.append("fscJustificationProvided", String(!step2.fscReferenceNumber && !!fscJustification));
      if (fscCertificate) fd.append("fscCertificate", fscCertificate);
      if (fscJustification) fd.append("fscJustification", fscJustification);
      await api.government.saveFsc(draftId, fd);
      toast(t("govWizard.stepSaved"));
      goNext();
    } catch (err) {
      fail(err instanceof Error ? err.message : t("common.errorGeneric"));
    } finally {
      setSaving(false);
    }
  };

  const addPerson = async () => {
    setStepError(null);
    if (!draftId) return;
    setSaving(true);
    try {
      const res = await api.government.addPersonnel(draftId, newPerson);
      setPersonnel((p) => [...p, { ...newPerson, id: res.id }]);
      setNewPerson({ fullName: "", officialTitle: "", userRole: "PROCUREMENT_OFFICER", pscLevel: "SECRET", pscIssuingAuthority: "", pscIssueDate: "", pscExpiryDate: "" });
      toast(t("govWizard.personAdded"));
    } catch (err) {
      fail(err instanceof Error ? err.message : t("common.errorGeneric"));
    } finally {
      setSaving(false);
    }
  };

  const removePerson = async (id: string) => {
    if (!draftId) return;
    await api.government.removePersonnel(draftId, id).catch(() => {});
    setPersonnel((p) => p.filter((x) => x.id !== id));
  };

  const submitStep4 = async () => {
    setStepError(null);
    if (!draftId) return;
    if (!step4.dataSharingConsent || !step4.accessLoggingConsent) {
      fail(t("govWizard.consentsRequired"));
      return;
    }
    setSaving(true);
    try {
      await api.government.saveAccess(draftId, { ...step4, dataSharingConsent: true, accessLoggingConsent: true });
      toast(t("govWizard.stepSaved"));
      goNext();
    } catch (err) {
      fail(err instanceof Error ? err.message : t("common.errorGeneric"));
    } finally {
      setSaving(false);
    }
  };

  const toggleFramework = async (key: string) => {
    if (!draftId) return;
    const next = new Set(acceptedFrameworks);
    if (next.has(key)) return; // acceptance is permanent within this draft, matches the backend's append-only timestamp
    next.add(key);
    setAcceptedFrameworks(next);
    try {
      await api.government.acceptFramework(draftId, key);
    } catch {
      // revert on failure
      next.delete(key);
      setAcceptedFrameworks(new Set(next));
    }
  };

  const finalSubmit = async () => {
    setStepError(null);
    if (!draftId || !finalConfirm) return;
    setSaving(true);
    try {
      await api.government.submit(draftId);
      setSubmitted(true);
      toast(t("govWizard.submitted"));
    } catch (err) {
      fail(err instanceof Error ? err.message : t("common.errorGeneric"));
    } finally {
      setSaving(false);
    }
  };

  if (submitted) {
    return (
      <div className="grid min-h-screen place-items-center px-4 py-28">
        <Reveal>
          <div className="card ring-gradient w-full max-w-lg overflow-hidden p-8 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[var(--color-gold)]/15 text-[var(--color-gold)]">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <h1 className="mt-4 font-display text-2xl font-bold">{t("govWizard.successTitle")}</h1>
            <p className="mt-2 text-sm text-[var(--text-muted)]">{t("govWizard.successBody")}</p>
            <button onClick={() => navigate("/dashboard")} className="btn btn-gold mt-6 shine">{t("dashboard.partnershipHub")}</button>
          </div>
        </Reveal>
      </div>
    );
  }

  const inputCls = "w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm outline-none transition focus:border-[var(--color-gold)]/60";

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("govWizard.seoTitle")} description={t("govWizard.seoDesc")} />
      <div className="mx-auto max-w-3xl px-4">
        <Reveal>
          <SectionHeading eyebrow={t("govWizard.eyebrow")} title={t(STEPS[stepIndex].labelKey)} subtitle={t("govWizard.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-8">
            <ProgressBar currentIndex={stepIndex} />
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div
            className="card p-6 sm:p-8"
            role="group"
            aria-label={t(STEPS[stepIndex].labelKey)}
            aria-describedby={stepError ? "gov-step-error" : undefined}
          >
            <div className="mb-3 empty:mb-0">
              <FormError id="gov-step-error" message={stepError} />
            </div>
            {/* STEP 1 */}
            {stepIndex === 0 && (
              <div className="space-y-3">
                <input placeholder={t("govWizard.step1.entityName")} value={step1.entityName} onChange={(e) => setStep1({ ...step1, entityName: e.target.value })} className={inputCls} />
                <input placeholder={t("govWizard.step1.countryCode")} maxLength={2} value={step1.countryCode} onChange={(e) => setStep1({ ...step1, countryCode: e.target.value.toUpperCase() })} className={inputCls} />
                <input placeholder={t("govWizard.step1.registrationNo")} value={step1.registrationNo} onChange={(e) => setStep1({ ...step1, registrationNo: e.target.value })} className={inputCls} />
                <input placeholder={t("govWizard.step1.contactName")} value={step1.officialContactName} onChange={(e) => setStep1({ ...step1, officialContactName: e.target.value })} className={inputCls} />
                <input placeholder={t("govWizard.step1.contactTitle")} value={step1.officialTitle} onChange={(e) => setStep1({ ...step1, officialTitle: e.target.value })} className={inputCls} />
                <input type="email" placeholder={t("govWizard.step1.contactEmail")} value={step1.officialEmail} onChange={(e) => setStep1({ ...step1, officialEmail: e.target.value })} className={inputCls} />
                <input placeholder={t("govWizard.step1.contactPhone")} value={step1.officialPhone} onChange={(e) => setStep1({ ...step1, officialPhone: e.target.value })} className={inputCls} />

                <FileField label={t("govWizard.step1.statusLetter")} file={sovereignStatusLetter} onChange={setSovereignStatusLetter} />
                <FileField label={t("govWizard.step1.registrationDoc")} file={entityRegistrationDoc} onChange={setEntityRegistrationDoc} />

                <button onClick={submitStep1} disabled={saving} className="btn btn-gold mt-2 w-full shine disabled:opacity-60">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />} {t("govWizard.saveAndContinue")}
                </button>
              </div>
            )}

            {/* STEP 2 */}
            {stepIndex === 1 && (
              <div className="space-y-3">
                <select value={step2.fscLevel} onChange={(e) => setStep2({ ...step2, fscLevel: e.target.value })} className={inputCls} aria-label={t("govWizard.step2.fscLevelLabel")}>
                  <option value="CONFIDENTIAL">CONFIDENTIAL</option>
                  <option value="SECRET">SECRET</option>
                  <option value="NATO_SECRET">NATO SECRET</option>
                  <option value="TOP_SECRET">TOP SECRET</option>
                </select>
                <input placeholder={t("govWizard.step2.authority")} value={step2.fscIssuingAuthority} onChange={(e) => setStep2({ ...step2, fscIssuingAuthority: e.target.value })} className={inputCls} />
                <div className="grid grid-cols-2 gap-3">
                  <input type="date" value={step2.fscIssueDate} onChange={(e) => setStep2({ ...step2, fscIssueDate: e.target.value })} className={inputCls} />
                  <input type="date" value={step2.fscExpiryDate} onChange={(e) => setStep2({ ...step2, fscExpiryDate: e.target.value })} className={inputCls} />
                </div>
                <input placeholder={t("govWizard.step2.referenceNumber")} value={step2.fscReferenceNumber} onChange={(e) => setStep2({ ...step2, fscReferenceNumber: e.target.value })} className={inputCls} />
                <FileField label={t("govWizard.step2.certificate")} file={fscCertificate} onChange={setFscCertificate} />
                <p className="text-xs text-[var(--text-faint)]">{t("govWizard.step2.orJustification")}</p>
                <FileField label={t("govWizard.step2.justification")} file={fscJustification} onChange={setFscJustification} />

                <div className="flex gap-2">
                  <button onClick={goBack} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" /> {t("common.back")}</button>
                  <button onClick={submitStep2} disabled={saving} className="btn btn-gold flex-1 shine disabled:opacity-60">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />} {t("govWizard.saveAndContinue")}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3 */}
            {stepIndex === 2 && (
              <div className="space-y-4">
                <p className="text-xs text-[var(--text-faint)]">{t("govWizard.step3.hint")}</p>
                <div className="space-y-2">
                  {personnel.map((p) => (
                    <div key={p.id} className="flex items-center justify-between rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm">
                      <div>
                        <span className="font-medium">{p.fullName}</span>{" "}
                        <span className="text-xs text-[var(--text-muted)]">— {p.userRole} · {p.pscLevel}</span>
                      </div>
                      <button onClick={() => removePerson(p.id)} className="text-rose-400 hover:text-rose-300"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 rounded-xl border border-dashed border-[var(--border)] p-4">
                  <input placeholder={t("govWizard.step3.fullName")} value={newPerson.fullName} onChange={(e) => setNewPerson({ ...newPerson, fullName: e.target.value })} className={inputCls} />
                  <input placeholder={t("govWizard.step3.title")} value={newPerson.officialTitle} onChange={(e) => setNewPerson({ ...newPerson, officialTitle: e.target.value })} className={inputCls} />
                  <select value={newPerson.userRole} onChange={(e) => setNewPerson({ ...newPerson, userRole: e.target.value as typeof newPerson.userRole })} className={inputCls} aria-label={t("govWizard.step3.roleLabel")}>
                    <option value="SOVEREIGN_ADMIN">SOVEREIGN_ADMIN</option>
                    <option value="PROCUREMENT_OFFICER">PROCUREMENT_OFFICER</option>
                    <option value="ANALYST">ANALYST</option>
                    <option value="AUDITOR">AUDITOR</option>
                  </select>
                  <select value={newPerson.pscLevel} onChange={(e) => setNewPerson({ ...newPerson, pscLevel: e.target.value as typeof newPerson.pscLevel })} className={inputCls} aria-label={t("govWizard.step3.pscLevelLabel")}>
                    <option value="SECRET">SECRET</option>
                    <option value="NATO_SECRET">NATO SECRET</option>
                    <option value="TOP_SECRET">TOP SECRET</option>
                  </select>
                  <input placeholder={t("govWizard.step3.authority")} value={newPerson.pscIssuingAuthority} onChange={(e) => setNewPerson({ ...newPerson, pscIssuingAuthority: e.target.value })} className={inputCls} />
                  <div className="grid grid-cols-2 gap-3">
                    <input type="date" value={newPerson.pscIssueDate} onChange={(e) => setNewPerson({ ...newPerson, pscIssueDate: e.target.value })} className={inputCls} />
                    <input type="date" value={newPerson.pscExpiryDate} onChange={(e) => setNewPerson({ ...newPerson, pscExpiryDate: e.target.value })} className={inputCls} />
                  </div>
                  <button onClick={addPerson} disabled={saving} className="btn btn-sm bg-[var(--color-gold)]/15 text-[var(--color-gold)] hover:bg-[var(--color-gold)]/25">
                    <Plus className="h-4 w-4" /> {t("govWizard.step3.addPerson")}
                  </button>
                </div>

                <div className="flex gap-2">
                  <button onClick={goBack} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" /> {t("common.back")}</button>
                  <button
                    onClick={goNext}
                    disabled={personnel.length < 2 || !personnel.some((p) => p.userRole === "SOVEREIGN_ADMIN")}
                    className="btn btn-gold flex-1 shine disabled:opacity-60"
                  >
                    <ArrowRight className="h-4 w-4" /> {t("common.continue")}
                  </button>
                </div>
                {(personnel.length < 2 || !personnel.some((p) => p.userRole === "SOVEREIGN_ADMIN")) && (
                  <p className="text-center text-xs text-[var(--text-faint)]">{t("govWizard.step3.minimumHint")}</p>
                )}
              </div>
            )}

            {/* STEP 4 */}
            {stepIndex === 3 && (
              <div className="space-y-3">
                <select value={step4.dataClassificationPolicy} onChange={(e) => setStep4({ ...step4, dataClassificationPolicy: e.target.value })} className={inputCls} aria-label={t("govWizard.step4.classificationLabel")}>
                  <option value="PUBLIC">PUBLIC</option>
                  <option value="INTERNAL">INTERNAL</option>
                  <option value="CONFIDENTIAL">CONFIDENTIAL</option>
                  <option value="SECRET">SECRET</option>
                </select>
                <input placeholder={t("govWizard.step4.officerName")} value={step4.securityOfficerName} onChange={(e) => setStep4({ ...step4, securityOfficerName: e.target.value })} className={inputCls} />
                <label className="flex cursor-pointer items-start gap-2 text-sm text-[var(--text-muted)]">
                  <input type="checkbox" checked={step4.dataSharingConsent} onChange={(e) => setStep4({ ...step4, dataSharingConsent: e.target.checked })} className="mt-1 h-4 w-4 accent-[var(--color-gold)]" />
                  {t("govWizard.step4.dataSharingConsent")}
                </label>
                <label className="flex cursor-pointer items-start gap-2 text-sm text-[var(--text-muted)]">
                  <input type="checkbox" checked={step4.accessLoggingConsent} onChange={(e) => setStep4({ ...step4, accessLoggingConsent: e.target.checked })} className="mt-1 h-4 w-4 accent-[var(--color-gold)]" />
                  {t("govWizard.step4.accessLoggingConsent")}
                </label>
                <p className="text-xs italic text-[var(--text-faint)]">{t("govWizard.step4.disclaimer")}</p>

                <div className="flex gap-2">
                  <button onClick={goBack} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" /> {t("common.back")}</button>
                  <button onClick={submitStep4} disabled={saving} className="btn btn-gold flex-1 shine disabled:opacity-60">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />} {t("govWizard.saveAndContinue")}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 5 */}
            {stepIndex === 4 && (
              <div className="space-y-3">
                {FRAMEWORK_KEYS.map((key) => (
                  <label key={key} className="flex cursor-pointer items-start gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] p-3 text-sm text-[var(--text-muted)]">
                    <input type="checkbox" checked={acceptedFrameworks.has(key)} onChange={() => toggleFramework(key)} className="mt-1 h-4 w-4 accent-[var(--color-gold)]" />
                    <span>{t(`govWizard.framework.${key}`)}</span>
                  </label>
                ))}
                {acceptedFrameworks.has("SOVEREIGN_TRUST_FRAMEWORK") && (
                  <p className="rounded-lg bg-[var(--color-gold)]/10 p-3 text-xs text-[var(--text-faint)]">{t("govWizard.framework.aspirationalNote")}</p>
                )}

                <div className="flex gap-2">
                  <button onClick={goBack} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" /> {t("common.back")}</button>
                  <button onClick={goNext} disabled={acceptedFrameworks.size < FRAMEWORK_KEYS.length} className="btn btn-gold flex-1 shine disabled:opacity-60">
                    <ArrowRight className="h-4 w-4" /> {t("common.continue")}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 6 */}
            {stepIndex === 5 && (
              <div className="space-y-4">
                <div className="space-y-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-sm">
                  <SummaryRow label={t("govWizard.step6.entityName")} value={step1.entityName} />
                  <SummaryRow label={t("govWizard.step6.country")} value={step1.countryCode} />
                  <SummaryRow label={t("govWizard.step6.fscLevel")} value={step2.fscLevel} />
                  <SummaryRow label={t("govWizard.step6.usersAdded")} value={String(personnel.length)} />
                  <SummaryRow label={t("govWizard.step6.frameworksAccepted")} value={`${acceptedFrameworks.size}/${FRAMEWORK_KEYS.length}`} />
                </div>

                <label className="flex cursor-pointer items-start gap-2 text-sm text-[var(--text-muted)]">
                  <input type="checkbox" checked={finalConfirm} onChange={(e) => setFinalConfirm(e.target.checked)} className="mt-1 h-4 w-4 accent-[var(--color-gold)]" />
                  {t("govWizard.step6.finalConfirm")}
                </label>
                <p className="text-xs text-[var(--text-faint)]">{t("govWizard.step6.trustScoreNote")}</p>

                <div className="flex gap-2">
                  <button onClick={goBack} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" /> {t("common.back")}</button>
                  <button onClick={finalSubmit} disabled={!finalConfirm || saving} className="btn btn-gold flex-1 shine disabled:opacity-60">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} {t("govWizard.step6.submitButton")}
                  </button>
                </div>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </div>
  );
}

function FileField({ label, file, onChange }: { label: string; file: File | null; onChange: (f: File | null) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-[var(--border)] px-4 py-3 text-sm text-[var(--text-muted)] transition hover:border-[var(--color-gold)]/50">
      <Upload className="h-4 w-4 shrink-0" />
      <span className="flex-1 truncate">{file ? file.name : label}</span>
      <input type="file" accept=".pdf" className="hidden" onChange={(e) => onChange(e.target.files?.[0] ?? null)} />
    </label>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-[var(--border)] pb-1.5 last:border-0">
      <span className="text-[var(--text-faint)]">{label}</span>
      <span className="font-medium">{value || "—"}</span>
    </div>
  );
}
