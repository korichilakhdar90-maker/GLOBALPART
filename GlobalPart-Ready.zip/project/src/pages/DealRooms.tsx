import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Lock, CheckCircle2, Clock, FileText, PenLine, Shield,
  TrendingUp, ArrowRight, Plus, DollarSign, GitBranch, Eye, Download, Loader2, Percent,
} from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal, SampleDataBanner } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";

const DEALS = [
  { id: "1", partner: "Vertex Systems", flag: "🇩🇪", titleKey: "deals.demo.title1", value: "$2.4M", stageKey: "deals.stage.escrowFunded", progress: 75, updated: "2h" },
  { id: "2", partner: "Aurora Manufacturing", flag: "🇨🇳", titleKey: "deals.demo.title2", value: "$890K", stageKey: "deals.demo.stage2", progress: 60, updated: "1d" },
  { id: "3", partner: "Helix Pharma", flag: "🇨🇭", titleKey: "deals.demo.title3", value: "$1.7M", stageKey: "deals.stage.signed", progress: 100, updated: "3d" },
  { id: "4", partner: "Meridian Logistics", flag: "🇦🇪", titleKey: "deals.demo.title4", value: "$540K", stageKey: "deals.stage.negotiation", progress: 25, updated: "5h" },
];

const MILESTONES = [
  { nameKey: "deals.milestone.contractDrafting", done: true, escrow: 0 },
  { nameKey: "deals.milestone.initialDeposit", done: true, escrow: 720000 },
  { nameKey: "deals.milestone.deliveryConfirmation", done: true, escrow: 600000 },
  { nameKey: "deals.milestone.qualityAcceptance", done: false, escrow: 1080000 },
  { nameKey: "deals.milestone.finalSettlement", done: false, escrow: 0 },
];

const STAGE_LABEL_KEY: Record<string, string> = {
  DISCOVERY: "deals.stage.discovery",
  NEGOTIATION: "deals.stage.negotiation",
  CONTRACT: "deals.stage.signed",
  ESCROW: "deals.stage.escrowFunded",
  COMPLETED: "deals.stage.completed",
  CANCELLED: "deals.stage.cancelled",
};
const STAGE_PROGRESS: Record<string, number> = {
  DISCOVERY: 10, NEGOTIATION: 35, CONTRACT: 60, ESCROW: 85, COMPLETED: 100, CANCELLED: 0,
};

interface UiDeal {
  id: string;
  partner: string;
  flag: string;
  title: string;
  value: string;
  stage: string;
  progress: number;
  updated: string;
}

interface ApiDealDetail {
  documents: { id: string; fileName: string; url: string }[];
  stage?: string;
  buyerId?: string;
  sellerId?: string;
  valueUsd?: number | null;
}

interface DealFee {
  id: string;
  amountCents: number;
  currency: string;
  feeRateBps: number;
  status: string;
  payerId: string;
  createdAt: string;
}

function formatValue(v?: number | null) {
  if (!v) return "—";
  return v >= 1_000_000 ? `$${(v / 1_000_000).toFixed(1)}M` : `$${Math.round(v / 1000)}K`;
}
function timeAgo(iso: string) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 60) return `${mins}m`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h`;
  return `${Math.round(hours / 24)}d`;
}

export default function DealRooms() {
  const { t, toast, user } = useApp();
  const [active, setActive] = useState(0);
  const [signed, setSigned] = useState(false);
  const [apiDeals, setApiDeals] = useState<UiDeal[] | null>(null);
  const [dealsLoading, setDealsLoading] = useState(isBackendConfigured);
  const [activeDetail, setActiveDetail] = useState<ApiDealDetail | null>(null);
  const [fees, setFees] = useState<DealFee[]>([]);

  useEffect(() => {
    if (!isBackendConfigured) return;
    setDealsLoading(true);
    api.deals
      .list()
      .then((raw) => {
        const list = (raw as {
          id: string; title: string; stage: string; valueUsd: number | null; updatedAt: string;
          buyerCompany?: { name: string } | null; sellerCompany?: { name: string } | null;
        }[]).map((d) => ({
          id: d.id,
          partner: d.sellerCompany?.name ?? d.buyerCompany?.name ?? t("deals.counterpartyPending"),
          flag: "🌐",
          title: d.title,
          value: formatValue(d.valueUsd),
          stage: t(STAGE_LABEL_KEY[d.stage] ?? d.stage),
          progress: STAGE_PROGRESS[d.stage] ?? 0,
          updated: timeAgo(d.updatedAt),
        }));
        setApiDeals(list);
      })
      .catch(() => setApiDeals([]))
      .finally(() => setDealsLoading(false));
  }, []);

  const deals: UiDeal[] = isBackendConfigured
    ? apiDeals ?? []
    : DEALS.map((d) => ({ id: d.id, partner: d.partner, flag: d.flag, title: t(d.titleKey), value: d.value, stage: t(d.stageKey), progress: d.progress, updated: d.updated }));
  const deal = deals[active] ?? deals[0];

  useEffect(() => {
    if (!isBackendConfigured || !deal) return;
    api.deals
      .get(deal.id)
      .then((d) => setActiveDetail(d as ApiDealDetail))
      .catch(() => setActiveDetail(null));
    api.deals
      .fees(deal.id)
      .then((f) => setFees(f))
      .catch(() => setFees([]));
  }, [deal?.id]);

  const handleSign = async () => {
    if (isBackendConfigured && deal) {
      try {
        await api.deals.updateStage(deal.id, "CONTRACT");
      } catch {
        // Non-fatal — still reflect the signature locally so the UI stays responsive.
      }
    }
    setSigned(true);
    toast(t("deals.signedToast"));
  };

  const payFee = async (feeId: string) => {
    if (!deal) return;
    try {
      const res = await api.deals.payFee(deal.id, feeId);
      window.location.href = res.url;
    } catch (err) {
      toast(err instanceof Error ? err.message : t("deals.fee.payError"), "error");
    }
  };

  if (isBackendConfigured && dealsLoading) {
    return (
      <div className="grid min-h-[70vh] place-items-center pt-24">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-glow" />
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="grid min-h-[70vh] place-items-center px-4 pt-24 text-center">
        <div>
          <p className="font-display text-xl font-bold">{t("deals.noRoomsYet")}</p>
          <p className="mt-2 text-sm text-[var(--text-muted)]">{t("deals.noRoomsHint")}</p>
          <Link to="/companies" className="btn btn-primary mt-5">
            <Eye className="h-4 w-4" /> {t("deals.findAPartner")}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28">
      <Seo title={t("seo.dealRooms.title")} description={t("seo.dealRooms.desc")} />
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute left-1/4 top-0 h-64 w-96 rounded-full bg-violet-glow/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("deals.eyebrow")}
              title={<>{t("section.deals.title")}</>}
              subtitle={t("section.deals.subtitle")}
            />
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-20">
        {!isBackendConfigured && <SampleDataBanner textKey="deals.exampleRoomBanner" />}

        {/* Feature strip */}
        <Reveal>
          <div className="mb-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Lock, tKey: "deals.feature.encrypted.title", dKey: "deals.feature.encrypted.desc" },
              { icon: PenLine, tKey: "deals.feature.esignature.title", dKey: "deals.feature.esignature.desc" },
              { icon: GitBranch, tKey: "deals.feature.versionControl.title", dKey: "deals.feature.versionControl.desc" },
              { icon: Shield, tKey: "deals.feature.escrow.title", dKey: "deals.feature.escrow.desc" },
            ].map((f) => (
              <div key={f.tKey} className="card flex items-center gap-3 p-4">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-violet-glow/15 text-violet-glow">
                  <f.icon className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold">{t(f.tKey)}</div>
                  <div className="text-xs text-[var(--text-muted)]">{t(f.dKey)}</div>
                </div>
              </div>
            ))}
          </div>
        </Reveal>

        <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
          {/* Deal list */}
          <Reveal>
            <div className="card p-4">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-display font-semibold">{t("deals.activeDeals")}</h3>
                <button
                  onClick={() =>
                    toast(
                      isBackendConfigured
                        ? t("deals.newRealDealHint")
                        : t("deals.newDealToast")
                    )
                  }
                  className="btn btn-primary btn-sm"
                >
                  <Plus className="h-4 w-4" /> {t("deals.new")}
                </button>
              </div>
              <div className="space-y-2">
                {deals.map((d, i) => (
                  <button
                    key={d.id}
                    onClick={() => { setActive(i); setSigned(false); }}
                    className={cn(
                      "w-full rounded-xl border p-3 text-start transition",
                      i === active ? "border-cyan-glow/50 bg-cyan-glow/5 glow-blue" : "border-[var(--border)] hover:bg-[var(--surface-2)]"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm font-semibold">
                        <span className="text-base">{d.flag}</span> {d.partner}
                      </span>
                      <span className="text-xs font-bold text-cyan-glow">{d.value}</span>
                    </div>
                    <div className="mt-1 truncate text-xs text-[var(--text-muted)]">{d.title}</div>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[var(--surface-2)]">
                        <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-cyan-glow" style={{ width: `${d.progress}%` }} />
                      </div>
                      <span className="text-[0.65rem] text-[var(--text-muted)]">{d.stage}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Deal detail */}
          <Reveal delay={100}>
            <div className="card p-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{deal.flag}</span>
                    <h2 className="font-display text-xl font-bold">{deal.partner}</h2>
                  </div>
                  <p className="mt-1 text-sm text-[var(--text-muted)]">{deal.title}</p>
                </div>
                <span className={cn("chip", deal.progress === 100 ? "chip-emerald" : "chip-gold")}>
                  {deal.stage}
                </span>
              </div>

              {/* Stats */}
              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { icon: DollarSign, label: t("deals.stat.value"), val: deal.value },
                  { icon: TrendingUp, label: t("deals.stat.progress"), val: `${deal.progress}%` },
                  { icon: Clock, label: t("deals.stat.updated"), val: t("deals.timeAgo", { time: deal.updated }) },
                  { icon: Shield, label: t("deals.stat.escrowFee"), val: `0.8%` },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                    <s.icon className="h-4 w-4 text-[var(--text-muted)]" />
                    <div className="mt-1.5 font-display font-bold">{s.val}</div>
                    <div className="text-xs text-[var(--text-muted)]">{s.label}</div>
                  </div>
                ))}
              </div>

              {/* Documents */}
              <div className="mt-6">
                <h3 className="mb-2 text-sm font-semibold">{t("deals.sharedDocuments")}</h3>
                <div className="grid gap-2 sm:grid-cols-2">
                  {(isBackendConfigured
                    ? activeDetail?.documents ?? []
                    : ["Master Agreement v3.pdf", "Technical Spec Sheet.pdf", "Invoice INV-2024-081.pdf", "Quality Certificate.pdf"].map(
                        (fileName) => ({ id: fileName, fileName, url: "" })
                      )
                  ).map((doc) => (
                    <div key={doc.id} className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3">
                      <div className="grid h-9 w-9 place-items-center rounded-lg bg-rose-500/15 text-rose-400">
                        <FileText className="h-4 w-4" />
                      </div>
                      <span className="flex-1 truncate text-sm">{doc.fileName}</span>
                      <button
                        onClick={() => {
                          if (isBackendConfigured && doc.url) window.open(doc.url, "_blank");
                          else toast(t("deals.downloadedToast"));
                        }}
                        className="text-[var(--text-muted)] transition hover:text-cyan-glow"
                      >
                        <Download className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                  {isBackendConfigured && (activeDetail?.documents.length ?? 0) === 0 && (
                    <p className="text-sm text-[var(--text-muted)]">{t("deals.noDocuments")}</p>
                  )}
                </div>
              </div>

              {/* Escrow milestones */}
              <div className="mt-6">
                <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold">
                  <Lock className="h-4 w-4 text-emerald-trust" /> {t("deals.escrowMilestones")}
                  <span className="chip chip-gold text-[0.65rem]">{t("common.example")}</span>
                </h3>
                <div className="space-y-2">
                  {MILESTONES.map((m) => (
                    <div key={m.nameKey} className={cn("flex items-center gap-3 rounded-xl border p-3 transition", m.done ? "border-emerald-trust/30 bg-emerald-trust/5" : "border-[var(--border)]")}>
                      {m.done ? (
                        <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-trust" />
                      ) : (
                        <Clock className="h-5 w-5 shrink-0 text-gold" />
                      )}
                      <span className={cn("flex-1 text-sm", m.done && "line-through opacity-60")}>{t(m.nameKey)}</span>
                      {m.escrow > 0 && (
                        <span className="chip chip-emerald">{t("deals.milestone.released", { amount: (m.escrow / 1000).toFixed(0) })}</span>
                      )}
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between rounded-xl bg-gradient-to-r from-emerald-trust/10 to-transparent p-3 text-sm">
                  <span className="flex items-center gap-2 font-medium">
                    <Shield className="h-4 w-4 text-emerald-trust" /> {t("deals.inEscrow")}
                  </span>
                  <span className="font-display font-bold text-emerald-trust">{t("deals.securedAmount", { amount: "1.32M" })}</span>
                </div>
              </div>

              {/* Platform fee (Feature 2) — only rendered against real backend data */}
              {isBackendConfigured && fees.length > 0 && (
                <div className="mt-6 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
                  <div className="flex items-center gap-2 text-sm font-semibold">
                    <Percent className="h-4 w-4 text-gold" /> {t("deals.fee.title")}
                  </div>
                  {fees.map((f) => (
                    <div key={f.id} className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--bg-soft)] p-3">
                      <div>
                        <div className="font-display font-bold">
                          ${(f.amountCents / 100).toLocaleString()} {f.currency.toUpperCase()}
                        </div>
                        <div className="text-xs text-[var(--text-muted)]">
                          {t("deals.fee.rate", { rate: (f.feeRateBps / 100).toFixed(2) })}
                        </div>
                      </div>
                      {f.status === "paid" ? (
                        <span className="chip chip-emerald">{t("deals.fee.paid")}</span>
                      ) : user?.id === f.payerId ? (
                        <button onClick={() => payFee(f.id)} className="btn btn-gold btn-sm">
                          {t("deals.fee.pay")}
                        </button>
                      ) : (
                        <span className="chip chip-gold">{t("deals.fee.pending")}</span>
                      )}
                    </div>
                  ))}
                  <p className="mt-3 text-xs text-[var(--text-muted)]">{t("deals.fee.disclaimer")}</p>
                </div>
              )}

              {/* E-signature */}
              <div className="mt-6 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <PenLine className="h-4 w-4 text-violet-glow" /> {t("deals.eSignature")}
                </div>
                {signed ? (
                  <div className="mt-3 flex items-center gap-3">
                    <CheckCircle2 className="h-6 w-6 text-emerald-trust" />
                    <div>
                      <div className="text-sm font-medium">{t("deals.contractSigned")}</div>
                      <div className="text-xs text-[var(--text-muted)]">{t("deals.auditHash", { hash: "0x9f3a…c2e1", date: new Date().toLocaleString() })}</div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="mt-3 h-16 rounded-xl border-2 border-dashed border-[var(--border-strong)] bg-[var(--bg-soft)]" />
                    <button onClick={handleSign} className="btn btn-primary mt-3 w-full">
                      <PenLine className="h-4 w-4" /> {t("deals.signAgreement")}
                    </button>
                  </>
                )}
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={150}>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link to="/companies" className="btn btn-ghost">
              <Eye className="h-4 w-4" /> {t("deals.findPartnerToDealWith")}
            </Link>
            <Link to="/kyb" className="btn btn-primary">
              {t("deals.getVerifiedUnlockEscrow")} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
