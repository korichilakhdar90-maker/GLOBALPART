import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ShieldCheck, ArrowLeft, CheckCircle2 } from "lucide-react";
import { Reveal } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";
import { useApp } from "../context";

export default function ResetPassword() {
  const { t, toast } = useApp();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  return (
    <div className="grid min-h-screen place-items-center px-4 py-28">
      <Seo title={t("resetPassword.seoTitle")} description={t("resetPassword.seoDesc")} />
      <Reveal>
        <div className="card ring-gradient w-full max-w-md overflow-hidden">
          <div className="bg-gradient-to-r from-brand-600/20 to-violet-glow/20 p-6 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow">
              {done ? <CheckCircle2 className="h-7 w-7 text-white" /> : <ShieldCheck className="h-7 w-7 text-white" />}
            </div>
            <h1 className="mt-3 font-display text-2xl font-bold">{done ? t("resetPassword.updated") : t("resetPassword.title")}</h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              {done ? t("resetPassword.updatedHint") : t("resetPassword.subtitle")}
            </p>
          </div>

          {!done ? (
            <form
              className="space-y-3 p-6"
              onSubmit={async (e) => {
                e.preventDefault();
                if (password !== confirm) {
                  toast(t("resetPassword.mismatch"), "error");
                  return;
                }
                if (!token) {
                  toast(t("resetPassword.missingToken"), "error");
                  return;
                }
                if (!isBackendConfigured) {
                  toast(t("forgotPassword.backendRequired"), "info");
                  setDone(true);
                  return;
                }
                setLoading(true);
                try {
                  await api.auth.resetPassword(token, password);
                  setDone(true);
                } catch (err) {
                  toast(err instanceof Error ? err.message : t("resetPassword.invalidLink"), "error");
                } finally {
                  setLoading(false);
                }
              }}
            >
              <input
                required
                type="password"
                autoComplete="new-password"
                placeholder={t("resetPassword.newPassword")}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="auth-input"
              />
              <input
                required
                type="password"
                autoComplete="new-password"
                placeholder={t("resetPassword.confirmPassword")}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="auth-input"
              />
              <button type="submit" disabled={loading} className="btn btn-primary w-full shine disabled:opacity-60">
                {loading ? t("resetPassword.updating") : t("resetPassword.updateButton")}
              </button>
            </form>
          ) : (
            <div className="p-6">
              <button onClick={() => navigate("/dashboard")} className="btn btn-primary w-full shine">
                {t("resetPassword.goToSignIn")}
              </button>
            </div>
          )}

          <div className="border-t border-[var(--border)] p-4 text-center">
            <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm font-medium text-cyan-glow hover:underline">
              <ArrowLeft className="h-3.5 w-3.5" /> {t("common.backToSignIn")}
            </Link>
          </div>
        </div>
      </Reveal>
      <style>{`.auth-input{width:100%;height:2.9rem;border-radius:0.7rem;border:1px solid var(--border);background:var(--surface);padding:0 0.9rem;font-size:0.9rem;outline:none;transition:border-color .2s}.auth-input:focus{border-color:rgba(34,211,238,.5)}`}</style>
    </div>
  );
}
