import { CheckCircle2, Circle, Loader2 } from "lucide-react";
import { useApp } from "../context";
import { SectionHeading, Reveal } from "../ui";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";

const STAGES = [
  { key: "now", icon: Loader2, status: "active" as const, titleKey: "roadmap.now.title", itemKeys: ["roadmap.now.item1", "roadmap.now.item2", "roadmap.now.item3"] },
  { key: "next", icon: Circle, status: "planned" as const, titleKey: "roadmap.next.title", itemKeys: ["roadmap.next.item1", "roadmap.next.item2", "roadmap.next.item3"] },
  { key: "later", icon: Circle, status: "planned" as const, titleKey: "roadmap.later.title", itemKeys: ["roadmap.later.item1", "roadmap.later.item2", "roadmap.later.item3"] },
];

export default function Roadmap() {
  const { t } = useApp();
  return (
    <div className="pt-28">
      <Seo title={t("roadmap.seoTitle")} description={t("roadmap.seoDesc")} />

      <div className="mx-auto max-w-3xl px-4 pb-24">
        <Reveal>
          <SectionHeading eyebrow={t("roadmap.eyebrow")} title={t("roadmap.title")} subtitle={t("roadmap.subtitle")} />
        </Reveal>

        <div className="mt-14 space-y-8">
          {STAGES.map((stage, i) => (
            <Reveal key={stage.key} delay={i * 0.06}>
              <div className="relative flex gap-5">
                <div className="flex flex-col items-center">
                  <div
                    className={cn(
                      "grid h-10 w-10 shrink-0 place-items-center rounded-full border-2",
                      stage.status === "active"
                        ? "border-gold bg-gold/15 text-gold-deep"
                        : "border-[var(--border-strong)] bg-[var(--surface)] text-[var(--text-muted)]"
                    )}
                  >
                    <stage.icon className={cn("h-5 w-5", stage.status === "active" && "animate-spin-slow")} />
                  </div>
                  {i < STAGES.length - 1 && <div className="mt-2 h-full w-px flex-1 bg-[var(--border)]" />}
                </div>
                <div className="flex-1 pb-8">
                  <div className="mb-2 flex items-center gap-2">
                    <h3 className="font-display text-lg font-bold">{t(stage.titleKey)}</h3>
                    <span className={cn("chip text-[0.65rem]", stage.status === "active" ? "chip-gold" : "chip-brand")}>
                      {t(stage.status === "active" ? "roadmap.status.inProgress" : "roadmap.status.planned")}
                    </span>
                  </div>
                  <ul className="space-y-2">
                    {stage.itemKeys.map((k) => (
                      <li key={k} className="flex items-start gap-2 text-sm text-[var(--text-muted)]">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--border-strong)]" />
                        {t(k)}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
