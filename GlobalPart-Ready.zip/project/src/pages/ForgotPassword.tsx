import { useState } from "react";
import { Link } from "react-router-dom";
import { KeyRound, ArrowLeft, MailCheck } from "lucide-react";
import { Reveal } from "../ui";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";
import { useApp } from "../context";

export default function ForgotPassword() {
  const { t, toast } = useApp();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  return (
    <div className="grid min-h-screen place-items-center px-4 py-28">
      <Seo
        title={t("forgotPassword.seoTitle")}
        description={t("forgotPassword.seoDesc")}
      />
      <Reveal>
        <div className="card ring-gradient w-full max-w-md overflow-hidden">
          <div className="bg-gradient-to-r from-brand-600/20 to-violet-glow/20 p-6 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow">
              {sent ? <MailCheck className="h-7 w-7 text-white" /> : <KeyRound className="h-7 w-7 text-white" />}
            </div>
            <h1 className="mt-3 font-display text-2xl font-bold">
              {sent ? t("forgotPassword.checkEmail") : t("forgotPassword.title")}
            </h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              {sent
                ? t("forgotPassword.sentHint")
                : t("forgotPassword.subtitle")}
            </p>
          </div>

          {!sent ? (
            <form
              className="space-y-3 p-6"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!isBackendConfigured) {
                  toast(t("forgotPassword.backendRequired"), "info");
                  setSent(true);
                  return;
                }
                setLoading(true);
                try {
                  await api.auth.forgotPassword(email);
                  setSent(true);
                } catch (err) {
                  toast(err instanceof Error ? err.message : t("common.errorGeneric"), "error");
                } finally {
                  setLoading(false);
                }
              }}
            >
              <input
                required
                type="email"
                name="email"
                autoComplete="email"
                placeholder={t("common.workEmail")}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="auth-input"
              />
              <button type="submit" disabled={loading} className="btn btn-primary w-full shine disabled:opacity-60">
                {loading ? t("forgotPassword.sending") : t("forgotPassword.sendLink")}
              </button>
            </form>
          ) : (
            <div className="p-6" />
          )}

          <div className="border-t border-[var(--border)] p-4 text-center">
            <Link to="/dashboard" className="inline-flex items-center gap-1.5 text-sm font-medium text-cyan-glow hover:underline">
              <ArrowLeft className="h-3.5 w-3.5" /> {t("common.backToSignIn")}
            </Link>
          </div>
        </div>
      </Reveal>
      <style>{`.auth-input{width:100%;height:2.9rem;border-radius:0.7rem;border:1px solid var(--border);background:var(--surface);padding:0 0.9rem;font-size:0.9rem;outline:none;transition:border-color .2s}.auth-input:focus{border-color:rgba(34,211,238,.5)}`}</style>
    </div>
  );
}
