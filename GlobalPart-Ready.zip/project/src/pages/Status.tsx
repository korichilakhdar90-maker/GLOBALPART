import { CheckCircle2, AlertTriangle, XCircle, Wrench } from "lucide-react";
import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";
import { useApp } from "../context";
import { cn } from "../utils/cn";

type ComponentStatus = "operational" | "degraded" | "maintenance" | "down";

/**
 * Manually maintained -- there is no live monitoring/uptime service wired
 * up yet (see the honest note at the bottom of this page). Update this
 * array by hand when something changes, the same way a small team runs a
 * status page before they can justify a dedicated status-page product.
 * Overall status is derived from the worst individual component below,
 * so it can't silently drift out of sync with reality.
 */
const COMPONENTS: { key: string; status: ComponentStatus }[] = [
  { key: "webApp", status: "operational" },
  { key: "api", status: "operational" },
  { key: "auth", status: "operational" },
  { key: "email", status: "degraded" }, // honest: EMAIL_PROVIDER defaults to console, not real delivery, until configured
  { key: "fileUploads", status: "operational" },
];

const STATUS_CONFIG: Record<ComponentStatus, { icon: typeof CheckCircle2; color: string }> = {
  operational: { icon: CheckCircle2, color: "text-emerald-trust" },
  degraded: { icon: AlertTriangle, color: "text-[var(--color-gold)]" },
  maintenance: { icon: Wrench, color: "text-cyan-glow" },
  down: { icon: XCircle, color: "text-rose-400" },
};

const SEVERITY_RANK: Record<ComponentStatus, number> = { operational: 0, degraded: 1, maintenance: 2, down: 3 };

export default function Status() {
  const { t } = useApp();
  const overall = COMPONENTS.reduce<ComponentStatus>((worst, c) => (SEVERITY_RANK[c.status] > SEVERITY_RANK[worst] ? c.status : worst), "operational");
  const OverallIcon = STATUS_CONFIG[overall].icon;

  return (
    <div className="min-h-screen pb-24 pt-28">
      <Seo title={t("status.seoTitle")} description={t("status.seoDesc")} />
      <div className="mx-auto max-w-2xl px-4">
        <Reveal>
          <SectionHeading eyebrow={t("status.eyebrow")} title={t("status.title")} subtitle={t("status.subtitle")} />
        </Reveal>

        <Reveal delay={0.05}>
          <div className={cn("card mt-8 flex items-center gap-3 p-5", overall === "operational" ? "border-emerald-trust/30" : "border-[var(--color-gold)]/30")}>
            <OverallIcon className={cn("h-6 w-6 shrink-0", STATUS_CONFIG[overall].color)} />
            <span className="font-display font-semibold">{t(`status.overall.${overall}`)}</span>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="card mt-4 divide-y divide-[var(--border)] overflow-hidden">
            {COMPONENTS.map((c) => {
              const Icon = STATUS_CONFIG[c.status].icon;
              return (
                <div key={c.key} className="flex items-center justify-between p-4">
                  <span className="text-sm">{t(`status.component.${c.key}`)}</span>
                  <span className={cn("flex items-center gap-1.5 text-xs font-medium", STATUS_CONFIG[c.status].color)}>
                    <Icon className="h-3.5 w-3.5" /> {t(`status.state.${c.status}`)}
                  </span>
                </div>
              );
            })}
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="mt-6 text-center text-xs text-[var(--text-faint)]">{t("status.honestNote")}</p>
        </Reveal>
      </div>
    </div>
  );
}
