import { SectionHeading, Reveal } from "../ui";
import Seo from "../components/Seo";

const LAST_UPDATED = "July 2026";

export default function Terms() {
  return (
    <div className="pt-28">
      <Seo
        title="Terms of Service"
        description="The terms that apply to using the GlobalPart website while it is in early access."
      />
      <div className="mx-auto max-w-3xl px-4 pb-24">
        <Reveal>
          <SectionHeading
            eyebrow="Legal"
            title="Terms of Service"
            subtitle={`Last updated: ${LAST_UPDATED}`}
          />
        </Reveal>

        <Reveal delay={0.05}>
          <div className="mt-10 space-y-8 text-sm leading-relaxed text-[var(--text-muted)]">
            <p>
              These terms cover use of the public GlobalPart website while the product is in
              pre-launch / early-access status. A separate, more detailed Terms of Service will
              apply once companies can transact, verify, and message on the live platform.
            </p>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">1. Current status of the platform</h2>
              <p>
                GlobalPart is under active development. Company profiles, market-intelligence
                figures, and deal-room examples shown on this site that are labelled "Sample" or
                "Example" are illustrative only and do not represent real, verified companies,
                live deals, or actual platform traffic.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">2. Early-access waitlist</h2>
              <p>
                Joining the waitlist does not create a contract, subscription, or any obligation
                on either side. It only registers your interest so we can contact you as the
                product becomes available.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">3. No professional advice</h2>
              <p>
                Nothing on this site — including market-intelligence figures or trust-score
                examples — constitutes legal, financial, or investment advice, or a guarantee
                about any company, partner, or transaction.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">4. Acceptable use</h2>
              <p>
                You agree not to misuse this website — including attempting to access non-public
                areas without authorization, scraping the site at high volume, or submitting
                false information through the waitlist form.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">5. Changes</h2>
              <p>
                We may update these terms as the product develops. Material changes will be
                reflected by updating the "Last updated" date above.
              </p>
            </section>

            <section>
              <h2 className="mb-2 text-base font-semibold text-[var(--text)]">6. Contact</h2>
              <p>
                Questions about these terms can be sent to{" "}
                <a href="mailto:hello@globalpart.io" className="text-cyan-glow hover:underline">
                  hello@globalpart.io
                </a>.
              </p>
            </section>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
