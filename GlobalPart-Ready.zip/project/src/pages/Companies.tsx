import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal, Sparkles, X, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { useApp } from "../context";
import { COMPANIES, INDUSTRIES, COUNTRIES, INDUSTRY_LABEL_KEY, REGION_LABEL_KEY } from "../data";
import { SectionHeading, Reveal, SampleDataBanner } from "../ui";
import CompanyCard from "../components/CompanyCard";
import CountrySelect from "../components/CountrySelect";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";
import { adaptApiCompany } from "../lib/adaptApiCompany";

const PER_PAGE = 9;
const REGIONS = ["All", "Europe", "North America", "Asia", "Southeast Asia", "GCC", "Africa", "South America"];

/**
 * Builds a windowed page list like [1, "…", 4, 5, 6, "…", 12] so the current
 * page is always reachable and visible, no matter how many pages exist.
 */
function paginationRange(current: number, total: number): (number | "…")[] {
  const delta = 1;
  const range: (number | "…")[] = [];
  const start = Math.max(2, current - delta);
  const end = Math.min(total - 1, current + delta);

  range.push(1);
  if (start > 2) range.push("…");
  for (let i = start; i <= end; i++) range.push(i);
  if (end < total - 1) range.push("…");
  if (total > 1) range.push(total);
  return range;
}

export default function Companies() {
  const { t, aiMode } = useApp();
  const [q, setQ] = useState("");
  const [countries, setCountries] = useState<string[]>([]);
  const [industry, setIndustry] = useState("");
  const [region, setRegion] = useState("All");
  const [minTrust, setMinTrust] = useState(0);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  // Real-backend mode: server-side search/filter/pagination.
  const [apiItems, setApiItems] = useState<typeof COMPANIES | null>(null);
  const [apiTotal, setApiTotal] = useState(0);
  const [apiTotalPages, setApiTotalPages] = useState(1);
  const [apiLoading, setApiLoading] = useState(false);

  useEffect(() => {
    if (!isBackendConfigured) return;
    let cancelled = false;
    setApiLoading(true);
    const timeout = setTimeout(() => {
      api.companies
        .list({
          search: q || undefined,
          industry: industry || undefined,
          countryCodes: countries.length ? countries.join(",") : undefined,
          region: region !== "All" ? region : undefined,
          minTrust: minTrust > 0 ? minTrust : undefined,
          verifiedOnly: verifiedOnly || undefined,
          page,
          perPage: PER_PAGE,
        })
        .then((res) => {
          if (cancelled) return;
          let items = res.items.map(adaptApiCompany);
          if (aiMode) items = [...items].sort((a, b) => b.matchScore - a.matchScore);
          setApiItems(items);
          setApiTotal(res.total);
          setApiTotalPages(res.totalPages);
        })
        .catch(() => {
          if (!cancelled) {
            setApiItems([]);
            setApiTotal(0);
            setApiTotalPages(1);
          }
        })
        .finally(() => {
          if (!cancelled) setApiLoading(false);
        });
    }, 300); // debounce so fast typing doesn't fire a request per keystroke

    return () => {
      cancelled = true;
      clearTimeout(timeout);
    };
  }, [q, countries, industry, region, minTrust, verifiedOnly, page, aiMode]);

  const filtered = useMemo(() => {
    let list = COMPANIES.filter((c) => {
      if (q) {
        const s = q.toLowerCase();
        if (
          !c.name.toLowerCase().includes(s) &&
          !c.industry.toLowerCase().includes(s) &&
          !c.country.name.toLowerCase().includes(s) &&
          !c.description.toLowerCase().includes(s)
        )
          return false;
      }
      if (countries.length && !countries.includes(c.country.code)) return false;
      if (industry && c.industry !== industry) return false;
      if (region !== "All" && c.country.region !== region) return false;
      if (c.trustScore < minTrust) return false;
      if (verifiedOnly && !c.verified) return false;
      return true;
    });
    if (aiMode) list.sort((a, b) => b.matchScore - a.matchScore);
    else list.sort((a, b) => b.trustScore - a.trustScore);
    return list;
  }, [q, countries, industry, region, minTrust, verifiedOnly, aiMode]);

  const totalPages = isBackendConfigured ? apiTotalPages : Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const current = Math.min(page, totalPages);
  const shown = isBackendConfigured ? apiItems ?? [] : filtered.slice((current - 1) * PER_PAGE, current * PER_PAGE);
  const resultCount = isBackendConfigured ? apiTotal : filtered.length;

  const resetPage = () => setPage(1);
  const clearAll = () => {
    setQ("");
    setCountries([]);
    setIndustry("");
    setRegion("All");
    setMinTrust(0);
    setVerifiedOnly(false);
    resetPage();
  };

  const activeFilters =
    (countries.length ? 1 : 0) + (industry ? 1 : 0) + (region !== "All" ? 1 : 0) + (minTrust > 0 ? 1 : 0) + (verifiedOnly ? 1 : 0);

  return (
    <div className="pt-28">
      <Seo
        title={t("seo.companies.title")}
        description={t("seo.companies.desc", { companies: String(COMPANIES.length), countries: String(COUNTRIES.length) })}
      />
      {/* Header */}
      <section className="relative overflow-hidden py-12">
        <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-[40rem] -translate-x-1/2 rounded-full bg-brand-500/15 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              eyebrow={t("companies.eyebrow")}
              title={<>{t("companies.title")}</>}
              subtitle={t("companies.subtitle", { companies: String(COMPANIES.length), countries: String(COUNTRIES.length) })}
            />
          </Reveal>

          {/* Search bar */}
          <Reveal delay={100}>
            <div className="mx-auto mt-8 max-w-3xl">
              <div className="flex items-center gap-2 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-2 backdrop-blur-xl">
                <Search className="ms-2 h-5 w-5 text-[var(--text-muted)]" />
                <input
                  value={q}
                  onChange={(e) => {
                    setQ(e.target.value);
                    resetPage();
                  }}
                  placeholder={t("common.search")}
                  className="flex-1 bg-transparent py-2 text-sm outline-none md:text-base"
                />
                {aiMode && (
                  <span className="chip chip-gold hidden sm:inline-flex">
                    <Sparkles className="h-3 w-3" />
                    {t("common.aiPowered")}
                  </span>
                )}
                <button
                  onClick={() => setShowFilters((s) => !s)}
                  className="btn btn-ghost btn-sm lg:hidden"
                >
                  <SlidersHorizontal className="h-4 w-4" />
                  {activeFilters > 0 && activeFilters}
                </button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-20">
        {!isBackendConfigured && <SampleDataBanner textKey="common.sampleDataBanner" />}
        <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
          {/* Filters sidebar */}
          <aside className={cn("lg:block", showFilters ? "block" : "hidden")}>
            <div className="card sticky top-24 p-5">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-display font-semibold">{t("companies.filters")}</h3>
                {activeFilters > 0 && (
                  <button onClick={clearAll} className="text-xs text-cyan-glow hover:underline">
                    {t("companies.clearAll")}
                  </button>
                )}
              </div>

              <div className="space-y-5">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                    {t("common.filter.country")}
                  </label>
                  <CountrySelect
                    value={countries}
                    onChange={(v) => {
                      setCountries(v as string[]);
                      resetPage();
                    }}
                  />
                </div>

                <div>
                  <label htmlFor="companies-industry-filter" className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                    {t("common.filter.industry")}
                  </label>
                  <select
                    id="companies-industry-filter"
                    value={industry}
                    onChange={(e) => {
                      setIndustry(e.target.value);
                      resetPage();
                    }}
                    className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 text-sm outline-none focus:border-cyan-glow/50"
                  >
                    <option value="">{t("common.filter.all")}</option>
                    {INDUSTRIES.map((ind) => (
                      <option key={ind} value={ind}>{t(INDUSTRY_LABEL_KEY[ind])}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                    {t("companies.region")}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {REGIONS.map((r) => (
                      <button
                        key={r}
                        onClick={() => {
                          setRegion(r);
                          resetPage();
                        }}
                        className={cn(
                          "rounded-lg px-2.5 py-1.5 text-xs font-medium transition",
                          region === r
                            ? "bg-brand-600 text-white"
                            : "border border-[var(--border)] text-[var(--text-muted)] hover:text-[var(--text)]"
                        )}
                      >
                        {t(REGION_LABEL_KEY[r])}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-[var(--text-faint)]">
                    {t("companies.minTrustScore")}
                    <span className="text-cyan-glow">{minTrust}</span>
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={minTrust}
                    onChange={(e) => {
                      setMinTrust(Number(e.target.value));
                      resetPage();
                    }}
                    className="w-full accent-cyan-glow"
                  />
                </div>

                <label className="flex cursor-pointer items-center justify-between rounded-xl border border-[var(--border)] p-3">
                  <span className="flex items-center gap-2 text-sm font-medium">
                    <Sparkles className="h-4 w-4 text-emerald-trust" />
                    {t("companies.verifiedOnly")}
                  </span>
                  <button
                    onClick={() => {
                      setVerifiedOnly((v) => !v);
                      resetPage();
                    }}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition",
                      verifiedOnly ? "bg-emerald-trust" : "bg-[var(--surface-2)]"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-white transition",
                        verifiedOnly ? "left-[1.4rem]" : "left-0.5"
                      )}
                    />
                  </button>
                </label>
              </div>
            </div>
          </aside>

          {/* Results */}
          <div>
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-[var(--text-muted)]">
                <span className="font-semibold text-[var(--text)]">{resultCount}</span> {t("common.results")}
                {aiMode && (
                  <span className="ms-2 chip chip-gold">
                    <Sparkles className="h-3 w-3" /> AI ranked
                  </span>
                )}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {countries.map((code) => {
                  const c = COUNTRIES.find((x) => x.code === code)!;
                  return (
                    <span key={code} className="chip">
                      {c.flag} {c.name}
                      <button
                        type="button"
                        aria-label={`Remove ${c.name} filter`}
                        onClick={() => setCountries((p) => p.filter((x) => x !== code))}
                        className="grid h-3 w-3 place-items-center"
                      >
                        <X className="h-3 w-3 cursor-pointer" />
                      </button>
                    </span>
                  );
                })}
              </div>
            </div>

            {isBackendConfigured && apiLoading ? (
              <div className="grid place-items-center p-16">
                <Loader2 className="h-8 w-8 animate-spin text-cyan-glow" />
              </div>
            ) : shown.length > 0 ? (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {shown.map((c, i) => (
                  <CompanyCard key={c.id} company={c} index={i} />
                ))}
              </div>
            ) : (
              <div className="card grid place-items-center p-16 text-center">
                <Search className="mb-3 h-10 w-10 text-[var(--text-faint)]" />
                <p className="font-medium">{t("companies.noMatch")}</p>
                <p className="mt-1 text-sm text-[var(--text-muted)]">{t("companies.noMatchHint")}</p>
                <button onClick={clearAll} className="btn btn-ghost btn-sm mt-4">{t("companies.clearFilters")}</button>
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex items-center justify-center gap-2">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={current === 1}
                  className="grid h-10 w-10 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] transition hover:border-[var(--border-strong)] disabled:opacity-40"
                >
                  <ChevronLeft className="h-4 w-4 flip-x" />
                </button>
                {paginationRange(current, totalPages).map((num, i) =>
                  num === "…" ? (
                    <span
                      key={`ellipsis-${i}`}
                      className="grid h-10 w-6 place-items-center text-sm text-[var(--text-faint)]"
                    >
                      …
                    </span>
                  ) : (
                    <button
                      key={num}
                      onClick={() => setPage(num)}
                      aria-current={num === current ? "page" : undefined}
                      className={cn(
                        "h-10 w-10 rounded-lg text-sm font-medium transition",
                        num === current
                          ? "bg-brand-600 text-white"
                          : "border border-[var(--border)] bg-[var(--surface)] hover:border-[var(--border-strong)]"
                      )}
                    >
                      {num}
                    </button>
                  )
                )}
                <button
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={current === totalPages}
                  className="grid h-10 w-10 place-items-center rounded-lg border border-[var(--border)] bg-[var(--surface)] transition hover:border-[var(--border-strong)] disabled:opacity-40"
                >
                  <ChevronRight className="h-4 w-4 flip-x" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
