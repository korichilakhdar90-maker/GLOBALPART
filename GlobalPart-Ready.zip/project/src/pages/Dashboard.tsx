import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import {
  Sparkles, TrendingUp, Heart, FileSignature, ShieldCheck, Bell, Plus,
  ArrowUpRight, BarChart3, Globe2, Users, Zap, LogOut, Search, Star, Loader2,
} from "lucide-react";
import { useApp } from "../context";
import { COMPANIES, type Company } from "../data";
import { Reveal, TrustRing } from "../ui";
import CompanyCard from "../components/CompanyCard";
import { cn } from "../utils/cn";
import Seo from "../components/Seo";
import { api, isBackendConfigured } from "../lib/api";
import { adaptApiCompany } from "../lib/adaptApiCompany";

export default function Dashboard() {
  const { t, user, login, register, verifyLoginTwoFactor, twoFactorPendingToken, cancelTwoFactorLogin, authLoading, logout, favorites, kyb, toast } = useApp();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialCategory = (["INDIVIDUAL", "ENTERPRISE", "GOVERNMENT"] as const).includes(
    searchParams.get("category") as never
  )
    ? (searchParams.get("category") as "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT")
    : "INDIVIDUAL";
  const [mode, setMode] = useState<"login" | "signup">(searchParams.get("mode") === "login" ? "login" : "signup");
  const [form, setForm] = useState({ name: "", email: "", company: "", password: "" });
  const [accountCategory, setAccountCategory] = useState<"INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT">(initialCategory);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [governmentPending, setGovernmentPending] = useState(false);
  // Auth errors are surfaced inline (role="alert" + aria-describedby on the
  // fields) in addition to the toast. A toast alone disappears and is not
  // reachable again by tabbing back through the form, which leaves
  // screen-reader users with no way to re-read why submission failed
  // (WCAG 2.1 SC 3.3.1, Error Identification).
  const [authError, setAuthError] = useState<string | null>(null);

  // Real-backend mode: fetch actual favorited companies + AI recommendations
  // instead of filtering the local demo dataset. Hooks must run
  // unconditionally (before the early return below), guarded internally by
  // `user`/`isBackendConfigured` instead.
  const [apiSaved, setApiSaved] = useState<Company[] | null>(null);
  const [apiPicks, setApiPicks] = useState<Company[] | null>(null);
  const [picksLoading, setPicksLoading] = useState(isBackendConfigured);

  useEffect(() => {
    if (!user || !isBackendConfigured) return;
    api.favorites
      .list()
      .then((items) => setApiSaved(items.map(adaptApiCompany)))
      .catch(() => setApiSaved([]));

    setPicksLoading(true);
    api.ai
      .recommendations()
      .then((res) => setApiPicks(res.recommendations.map((r) => adaptApiCompany(r.company))))
      .catch(() => setApiPicks([]))
      .finally(() => setPicksLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, favorites]);

  if (twoFactorPendingToken) {
    return (
      <div className="grid min-h-screen place-items-center px-4 py-28">
        <Reveal>
          <div className="card ring-gradient w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-trust/20 to-cyan-glow/20 p-6 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-emerald-trust to-cyan-glow">
                <ShieldCheck className="h-7 w-7 text-white" />
              </div>
              <h1 className="mt-3 font-display text-2xl font-bold">{t("twoFactorLogin.title")}</h1>
              <p className="mt-1 text-sm text-[var(--text-muted)]">{t("twoFactorLogin.subtitle")}</p>
            </div>
            <form
              className="space-y-3 p-6"
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await verifyLoginTwoFactor(twoFactorCode);
                  toast(t("dashboard.welcomeToast"));
                  navigate("/dashboard");
                } catch (err) {
                  toast(err instanceof Error ? err.message : t("common.errorGeneric"), "error");
                  setTwoFactorCode("");
                }
              }}
            >
              <input
                required
                inputMode="numeric"
                pattern="[0-9]{6}"
                maxLength={6}
                autoComplete="one-time-code"
                placeholder="000000"
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                className="auth-input text-center font-mono text-2xl tracking-[0.5em]"
              />
              <button type="submit" disabled={authLoading || twoFactorCode.length !== 6} className="btn btn-primary w-full shine disabled:opacity-60">
                {authLoading ? t("common.pleaseWait") : t("twoFactorLogin.verifyButton")}
              </button>
              <button type="button" onClick={cancelTwoFactorLogin} className="w-full text-center text-sm font-medium text-[var(--text-muted)] hover:underline">
                {t("twoFactorLogin.cancel")}
              </button>
            </form>
          </div>
        </Reveal>
        <style>{`.auth-input{width:100%;height:2.9rem;border-radius:0.7rem;border:1px solid var(--border);background:var(--surface);padding:0 0.9rem;font-size:0.9rem;outline:none;transition:border-color .2s}.auth-input:focus{border-color:rgba(34,211,238,.5)}`}</style>
      </div>
    );
  }

  if (governmentPending) {
    return (
      <div className="grid min-h-screen place-items-center px-4 py-28">
        <Reveal>
          <div className="card ring-gradient w-full max-w-md overflow-hidden p-8 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-violet-glow to-cyan-glow">
              <ShieldCheck className="h-7 w-7 text-white" />
            </div>
            <h1 className="mt-3 font-display text-2xl font-bold">{t("register.governmentPendingTitle")}</h1>
            <p className="mt-2 text-sm text-[var(--text-muted)]">{t("register.governmentPendingDesc")}</p>
            <button onClick={() => { setGovernmentPending(false); setMode("login"); }} className="btn btn-primary mt-6 shine">
              {t("dashboard.signIn")}
            </button>
          </div>
        </Reveal>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-4 py-28">
        <Seo title={t("seo.dashboard.auth.title")} description={t("seo.dashboard.auth.desc")} />
        <Reveal>
          <div className="card ring-gradient w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-brand-600/20 to-violet-glow/20 p-6 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow">
                <Sparkles className="h-7 w-7 text-white" />
              </div>
              <h1 className="mt-3 font-display text-2xl font-bold">
                {mode === "signup" ? t("dashboard.joinTitle") : t("dashboard.welcomeBackTitle")}
              </h1>
              <p className="mt-1 text-sm text-[var(--text-muted)]">
                {mode === "signup" ? t("dashboard.joinSubtitle") : t("dashboard.welcomeBackSubtitle")}
              </p>
            </div>
            <form
              className="space-y-3 p-6"
              onSubmit={async (e) => {
                e.preventDefault();
                setAuthError(null);
                try {
                  if (mode === "signup") {
                    const result = await register({ name: form.name, email: form.email, password: form.password, company: form.company, accountCategory });
                    if (!result.sessionIssued) {
                      setGovernmentPending(true);
                      return;
                    }
                  } else {
                    const result = await login({ email: form.email, password: form.password });
                    if (result.twoFactorRequired) return; // twoFactorPendingToken screen takes over
                  }
                  toast(t("dashboard.welcomeToast"));
                  navigate("/dashboard");
                } catch (err) {
                  const msg = err instanceof Error ? err.message : t("common.errorGeneric");
                  setAuthError(msg);
                  toast(msg, "error");
                }
              }}
            >
              {authError && (
                <p id="auth-error" role="alert" className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
                  {authError}
                </p>
              )}
              {mode === "signup" && (
                <div className="grid grid-cols-3 gap-1.5" role="radiogroup" aria-label={t("register.accountType")}>
                  {(["INDIVIDUAL", "ENTERPRISE", "GOVERNMENT"] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      role="radio"
                      aria-checked={accountCategory === cat}
                      onClick={() => setAccountCategory(cat)}
                      className={cn(
                        "rounded-lg border px-2 py-2 text-center text-[0.7rem] font-medium leading-tight transition",
                        accountCategory === cat
                          ? "border-cyan-glow/60 bg-cyan-glow/10 text-[var(--text)]"
                          : "border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] hover:border-[var(--border-strong)]"
                      )}
                    >
                      {t(`register.accountType.${cat.toLowerCase()}`)}
                    </button>
                  ))}
                </div>
              )}
              {mode === "signup" && (
                <p className="text-center text-xs text-[var(--text-faint)]">{t(`register.accountType.${accountCategory.toLowerCase()}Desc`) || ""}</p>
              )}
              {mode === "signup" && (
                <input
                  required
                  name="name"
                  autoComplete="name"
                  placeholder={t("dashboard.fullName")}
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="auth-input"
                />
              )}
              <input
                required
                type="email"
                name="email"
                autoComplete="email"
                placeholder={t("common.workEmail")}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="auth-input"
                aria-invalid={!!authError}
                aria-describedby={authError ? "auth-error" : undefined}
              />
              {mode === "signup" && accountCategory === "ENTERPRISE" && (
                <p className="text-xs text-[var(--text-faint)]">{t("register.enterpriseEmailHint")}</p>
              )}
              {mode === "signup" && accountCategory === "GOVERNMENT" && (
                <p className="text-xs text-[var(--text-faint)]">{t("register.governmentEmailHint")}</p>
              )}
              {mode === "signup" && (
                <input
                  name="company"
                  autoComplete="organization"
                  placeholder={t("dashboard.companyName")}
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  className="auth-input"
                />
              )}
              <input
                required
                type="password"
                name="password"
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                placeholder={t("common.password")}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="auth-input"
                aria-invalid={!!authError}
                aria-describedby={authError ? "auth-error" : undefined}
              />
              <button type="submit" disabled={authLoading} className="btn btn-primary w-full shine disabled:opacity-60">
                {authLoading ? t("common.pleaseWait") : mode === "signup" ? t("dashboard.createAccount") : t("dashboard.signIn")}
              </button>
              {mode === "login" && (
                <p className="text-center text-sm">
                  <Link to="/forgot-password" className="font-medium text-cyan-glow hover:underline">
                    {t("dashboard.forgotPassword")}
                  </Link>
                </p>
              )}
              <p className="text-center text-sm text-[var(--text-muted)]">
                {mode === "signup" ? t("dashboard.alreadyHaveAccount") : t("dashboard.newToGlobalPart")}{" "}
                <button type="button" onClick={() => setMode(mode === "signup" ? "login" : "signup")} className="font-medium text-cyan-glow hover:underline">
                  {mode === "signup" ? t("dashboard.signIn") : t("dashboard.signUpFree")}
                </button>
              </p>
            </form>
          </div>
        </Reveal>
        <style>{`.auth-input{width:100%;height:2.9rem;border-radius:0.7rem;border:1px solid var(--border);background:var(--surface);padding:0 0.9rem;font-size:0.9rem;outline:none;transition:border-color .2s}.auth-input:focus{border-color:rgba(34,211,238,.5)}`}</style>
      </div>
    );
  }

  const saved = isBackendConfigured ? apiSaved ?? [] : COMPANIES.filter((c) => favorites.includes(c.id));
  const aiPicks = isBackendConfigured ? apiPicks ?? [] : [...COMPANIES].sort((a, b) => b.matchScore - a.matchScore).slice(0, 3);
  const trustScore = kyb[0]?.trustScore ?? 82;

  const stats = [
    { icon: TrendingUp, labelKey: "dashboard.stat.activeDeals", val: "4", trend: "+2", color: "text-emerald-trust" },
    { icon: Heart, labelKey: "dashboard.stat.savedPartners", val: String(saved.length), trend: "", color: "text-rose-400" },
    { icon: Globe2, labelKey: "dashboard.stat.marketsTouched", val: "12", trend: "+3", color: "text-cyan-glow" },
    { icon: FileSignature, labelKey: "dashboard.stat.capitalInEscrow", val: "$1.3M", trend: "", color: "text-gold" },
  ];

  return (
    <div className="pt-28">
      <Seo
        title={t("seo.dashboard.hub.title")}
        description={t("seo.dashboard.hub.desc")}
      />
      <div className="mx-auto max-w-7xl px-4 pb-20">
        {/* Header */}
        <Reveal>
          <div className="card flex flex-wrap items-center justify-between gap-4 p-6">
            <div className="flex items-center gap-4">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-cyan-glow text-xl font-bold text-white">
                {user.name.charAt(0)}
              </div>
              <div>
                <h1 className="font-display text-2xl font-bold">{t("dashboard.welcomeUser", { name: user.name.split(" ")[0] })} 👋</h1>
                <p className="text-sm text-[var(--text-muted)]">{user.company} · {t("dashboard.partnershipHub")}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => toast(t("dashboard.allCaughtUp"))} className="relative grid h-10 w-10 place-items-center rounded-xl border border-[var(--border)] bg-[var(--surface)]">
                <Bell className="h-4 w-4" />
                <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-rose-400" />
              </button>
              <button onClick={() => { logout(); toast(t("dashboard.signedOut")); navigate("/"); }} className="btn btn-ghost btn-sm">
                <LogOut className="h-4 w-4 flip-x" /> {t("dashboard.signOut")}
              </button>
            </div>
          </div>
        </Reveal>

        {/* Stats */}
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.labelKey} delay={i * 60}>
              <div className="card card-hover p-5">
                <div className="flex items-center justify-between">
                  <div className={cn("grid h-10 w-10 place-items-center rounded-lg bg-[var(--surface-2)]", s.color)}>
                    <s.icon className="h-5 w-5" />
                  </div>
                  {s.trend && <span className="chip chip-emerald text-[0.7rem]">{s.trend}</span>}
                </div>
                <div className="mt-3 font-display text-2xl font-bold">{s.val}</div>
                <div className="text-xs text-[var(--text-muted)]">{t(s.labelKey)}</div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="space-y-6">
            {/* AI recommendations */}
            <Reveal>
              <div className="card p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="flex items-center gap-2 font-display font-semibold">
                    <Sparkles className="h-5 w-5 text-cyan-glow" /> {t("dashboard.aiRecsForYou")}
                  </h3>
                  <Link to="/companies" className="text-sm text-cyan-glow hover:underline">{t("common.viewAll")}</Link>
                </div>
                {isBackendConfigured && picksLoading ? (
                  <div className="grid place-items-center py-10">
                    <Loader2 className="h-6 w-6 animate-spin text-cyan-glow" />
                  </div>
                ) : (
                  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                    {aiPicks.map((c, i) => (
                      <CompanyCard key={c.id} company={c} index={i} />
                    ))}
                  </div>
                )}
              </div>
            </Reveal>

            {/* Saved */}
            <Reveal delay={80}>
              <div className="card p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="flex items-center gap-2 font-display font-semibold">
                    <Heart className="h-5 w-5 text-rose-400" /> {t("dashboard.savedPartners")}
                  </h3>
                  <span className="chip">{saved.length}</span>
                </div>
                {saved.length > 0 ? (
                  <div className="space-y-2">
                    {saved.map((c) => (
                      <Link key={c.id} to={`/companies/${c.id}`} className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3 transition hover:border-cyan-glow/40">
                        <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-brand-600/30 to-violet-glow/20 font-bold text-cyan-glow">{c.name.charAt(0)}</div>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-semibold">{c.name}</div>
                          <div className="text-xs text-[var(--text-muted)]">{c.country.flag} {c.country.name} · {c.industry}</div>
                        </div>
                        <TrustRing score={c.trustScore} size={36} />
                        <ArrowUpRight className="h-4 w-4 text-[var(--text-muted)]" />
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="grid place-items-center py-10 text-center">
                    <Heart className="mb-2 h-8 w-8 text-[var(--text-faint)]" />
                    <p className="text-sm text-[var(--text-muted)]">{t("dashboard.noSavedPartners")}</p>
                    <Link to="/companies" className="btn btn-primary btn-sm mt-3">
                      <Search className="h-4 w-4" /> {t("dashboard.discoverPartners")}
                    </Link>
                  </div>
                )}
              </div>
            </Reveal>

            {/* Quick actions */}
            <Reveal delay={120}>
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  { icon: Plus, tKey: "dashboard.action.newDealRoom", to: "/deals" },
                  { icon: ShieldCheck, tKey: "dashboard.action.verifyCompany", to: "/kyb" },
                  { icon: BarChart3, tKey: "nav.intelligence", to: "/intelligence" },
                ].map((a) => (
                  <Link key={a.tKey} to={a.to} onClick={() => toast(t("dashboard.opening", { action: t(a.tKey) }))} className="card card-hover flex items-center gap-3 p-4">
                    <div className="grid h-10 w-10 place-items-center rounded-lg bg-brand-600/15 text-cyan-glow">
                      <a.icon className="h-5 w-5" />
                    </div>
                    <span className="text-sm font-semibold">{t(a.tKey)}</span>
                  </Link>
                ))}
              </div>
            </Reveal>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Reveal delay={100}>
              <div className="card flex flex-col items-center p-6 text-center">
                <TrustRing score={trustScore} size={110} />
                <h3 className="mt-3 font-display font-semibold">{t("dashboard.yourTrustScore")}</h3>
                <p className="text-xs text-[var(--text-muted)]">
                  {kyb.length > 0 ? t("dashboard.kybInReview") : t("dashboard.completeKyb")}
                </p>
                <Link to="/kyb" className="btn btn-gold btn-sm mt-4">
                  <ShieldCheck className="h-4 w-4" /> {kyb.length > 0 ? t("dashboard.viewStatus") : t("dashboard.getVerified")}
                </Link>
                {isBackendConfigured && (
                  <Link to="/my-application" className="mt-2 text-xs text-cyan-glow hover:underline">{t("myApp.viewFullDashboard")}</Link>
                )}
                {isBackendConfigured && (
                  <Link to="/invite-partners" className="mt-1 text-xs text-[var(--color-gold)] hover:underline">{t("invite.title")}</Link>
                )}
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div className="card p-6">
                <h3 className="mb-3 flex items-center gap-2 font-display font-semibold">
                  <Star className="h-4 w-4 fill-gold text-gold" /> {t("dashboard.networkSnapshot")}
                </h3>
                <div className="space-y-3">
                  {[
                    { icon: Users, labelKey: "dashboard.partnerMatches", val: "248" },
                    { icon: Globe2, labelKey: "dashboard.targetMarkets", val: "18" },
                    { icon: Zap, labelKey: "dashboard.dealVelocity", val: "+38%" },
                  ].map((r) => (
                    <div key={r.labelKey} className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
                        <r.icon className="h-4 w-4" /> {t(r.labelKey)}
                      </span>
                      <span className="font-display font-bold">{r.val}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="ring-gradient card p-6 text-center">
                <Sparkles className="mx-auto h-7 w-7 text-cyan-glow" />
                <h3 className="mt-2 font-display font-semibold">{t("dashboard.upgradeEnterprise")}</h3>
                <p className="mt-1 text-xs text-[var(--text-muted)]">{t("dashboard.upgradeEnterpriseDesc")}</p>
                <Link to="/pricing" className="btn btn-primary btn-sm mt-4 w-full">{t("dashboard.viewPlans")}</Link>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </div>
  );
}
