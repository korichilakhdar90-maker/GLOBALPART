export type LangCode = "en" | "fr" | "de" | "nl" | "es" | "zh" | "ru" | "hi" | "ar" | "ja" | "ko" | "pt" | "it" | "pl" | "tr";

/**
 * "active"  — surfaced in the language switcher UI (Europe-first launch set).
 * "reserve" — fully translated and loadable, but hidden from the switcher.
 *             Kept in the system as strategic capacity for future market
 *             expansion (see /roadmap) without re-doing translation work
 *             when a market is activated.
 */
export type LangTier = "active" | "reserve";

export interface LangMeta {
  code: LangCode;
  name: string;
  native: string;
  flag: string;
  dir: "ltr" | "rtl";
  tier: LangTier;
}

// Order matters for the switcher (active languages) and for the "reserve"
// grouping reflects the planned activation sequence from the roadmap:
// Year 2 → zh, ru · Year 3 → hi, ar · additional reserve → ja, ko.
export const LANGUAGES: LangMeta[] = [
  // --- Active: Europe-first launch set, now expanded --------------------
  { code: "en", name: "English", native: "English", flag: "🇬🇧", dir: "ltr", tier: "active" },
  { code: "fr", name: "French", native: "Français", flag: "🇫🇷", dir: "ltr", tier: "active" },
  { code: "de", name: "German", native: "Deutsch", flag: "🇩🇪", dir: "ltr", tier: "active" },
  { code: "nl", name: "Dutch", native: "Nederlands", flag: "🇳🇱", dir: "ltr", tier: "active" },
  { code: "es", name: "Spanish", native: "Español", flag: "🇪🇸", dir: "ltr", tier: "active" },
  { code: "it", name: "Italian", native: "Italiano", flag: "🇮🇹", dir: "ltr", tier: "active" },
  { code: "pl", name: "Polish", native: "Polski", flag: "🇵🇱", dir: "ltr", tier: "active" },
  { code: "pt", name: "Portuguese", native: "Português", flag: "🇵🇹", dir: "ltr", tier: "active" },
  { code: "tr", name: "Turkish", native: "Türkçe", flag: "🇹🇷", dir: "ltr", tier: "active" },

  // --- Reserve: built, translated, and ready — activated by roadmap stage
  { code: "zh", name: "Chinese", native: "中文", flag: "🇨🇳", dir: "ltr", tier: "reserve" },
  { code: "ru", name: "Russian", native: "Русский", flag: "🇷🇺", dir: "ltr", tier: "reserve" },
  { code: "hi", name: "Hindi", native: "हिन्दी", flag: "🇮🇳", dir: "ltr", tier: "reserve" },
  { code: "ar", name: "Arabic", native: "العربية", flag: "🇸🇦", dir: "rtl", tier: "reserve" },
  { code: "ja", name: "Japanese", native: "日本語", flag: "🇯🇵", dir: "ltr", tier: "reserve" },
  { code: "ko", name: "Korean", native: "한국어", flag: "🇰🇷", dir: "ltr", tier: "reserve" },
];

/** Only the languages shown in the language switcher (Europe-first set). */
export const ACTIVE_LANGUAGES: LangMeta[] = LANGUAGES.filter((l) => l.tier === "active");

/** Fully-built languages kept out of the switcher for future activation. */
export const RESERVE_LANGUAGES: LangMeta[] = LANGUAGES.filter((l) => l.tier === "reserve");

export function getLangMeta(code: LangCode): LangMeta | undefined {
  return LANGUAGES.find((l) => l.code === code);
}

export function isReserveLang(code: string): code is LangCode {
  return RESERVE_LANGUAGES.some((l) => l.code === code);
}

export function isActiveLang(code: string): code is LangCode {
  return ACTIVE_LANGUAGES.some((l) => l.code === code);
}

export type Dict = Record<string, string>;

// English ships in the main bundle (it's the fallback for missing keys in
// any language, and the default language), but every other language's ~40KB
// dictionary is only downloaded when actually selected — see loadDict below.
// This keeps unused language dictionaries out of everyone's initial page
// load instead of bundling all 12 languages upfront. Reserve languages use
// the exact same lazy-load mechanism as active ones: nothing about "reserve"
// status changes how the dictionary itself is built or loaded, only whether
// it's surfaced in the switcher (see ACTIVE_LANGUAGES above).
import enDict from "./i18n-data/en";

const cache = new Map<LangCode, Dict>([["en", enDict]]);

const loaders: Record<Exclude<LangCode, "en">, () => Promise<{ default: Dict }>> = {
  fr: () => import("./i18n-data/fr"),
  de: () => import("./i18n-data/de"),
  nl: () => import("./i18n-data/nl"),
  es: () => import("./i18n-data/es"),
  zh: () => import("./i18n-data/zh"),
  ru: () => import("./i18n-data/ru"),
  hi: () => import("./i18n-data/hi"),
  ar: () => import("./i18n-data/ar"),
  ja: () => import("./i18n-data/ja"),
  ko: () => import("./i18n-data/ko"),
  pt: () => import("./i18n-data/pt"),
  it: () => import("./i18n-data/it"),
  pl: () => import("./i18n-data/pl"),
  tr: () => import("./i18n-data/tr"),
};

/** Returns the cached dictionary for a language, loading it on first use. */
export async function loadDict(lang: LangCode): Promise<Dict> {
  const cached = cache.get(lang);
  if (cached) return cached;
  const mod = await loaders[lang as Exclude<LangCode, "en">]();
  cache.set(lang, mod.default);
  return mod.default;
}

/** Synchronous accessor for a dictionary already loaded into the cache. */
export function getCachedDict(lang: LangCode): Dict | undefined {
  return cache.get(lang);
}

export const englishDict = enDict;
