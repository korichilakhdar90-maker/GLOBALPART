# Company directory: real-data import pipeline

This folder contains the tooling to populate `Company` with **real**
European (+ Turkey) companies from a genuine external source, and to keep
that table within the directory's strict scope rules. Nothing here
generates or invents company data — that's a deliberate choice, not a
missing feature. See `docs/compliance/README.md` for the same principle
applied elsewhere in this project.

## The pipeline, in order

### 1. Get a real source file
You need an actual export from one of:
- A national commercial registry: Handelsregister (Germany), INSEE/SIRENE
  (France), Companies House (UK), KVK (Netherlands), MERSİS (Turkey), etc.
- A licensed B2B data provider (Dun & Bradstreet, Kompass, and similar).
- An OpenCorporates bulk/API export.

This is a data-licensing/access step, not a coding step — nobody, AI or
otherwise, should synthesize 500 or 10,000 "real-looking" company records
and pass them off as genuine. That would misrepresent fictional or
unverified entities as real businesses on a platform whose entire premise
is trustworthy verification.

### 2. Shape it to match `companies-import-template.csv`
The template in this folder shows the exact columns expected (`name`,
`registrationNo`, `countryCode`, `countryName`, `region`, `city`,
`industry`, `description`, `employees`, `founded`, `sourceRegistry`,
`sourceUrl`). JSON input (an array of the same fields) also works.

### 3. Dry-run the import first
```bash
npm run import-companies -- --file=./your-real-export.csv --dry-run
```
Read the summary. It tells you exactly how many rows would be inserted,
skipped as out-of-scope (not Europe/Turkey), skipped as invalid (missing
required fields), and skipped as duplicates (matched on
`countryCode` + `registrationNo` against what's already in the table).

### 4. Run it for real
```bash
npm run import-companies -- --file=./your-real-export.csv
```
Every inserted row lands as `profileStatus: DIRECTORY_LISTED`,
`verified: false` — importing a company is not verifying it. The company's
real owner still has to find their listing, click "Claim this profile",
and pass full KYB before it becomes a `VERIFIED_PARTNER` (see
`src/routes/companies.routes.ts` and `src/routes/kyb.routes.ts`).

### 5. Enforce scope and the top-500 cap
```bash
npm run enforce-geo-scope
```
Deletes anything outside Europe+Turkey (belt-and-suspenders — the import
script already filters this, but this also catches rows that entered the
table any other way) and caps the directory to the top 500, ranked
Verified Partners first, then by trust score.

## Files

| File | Purpose |
|---|---|
| `importCompanies.ts` | The importer described above. |
| `companies-import-template.csv` | Expected column shape. **The two rows in it are clearly-labeled placeholders — do not import this file as-is.** |
| `enforceGeographicScope.ts` | Scope + top-500 enforcement, safe to re-run any time. |
