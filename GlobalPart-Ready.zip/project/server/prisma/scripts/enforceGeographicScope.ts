/**
 * One-off / periodic maintenance script enforcing the directory's strict
 * scope rule:
 *   1. Delete every Company row outside EUROPEAN_COUNTRY_CODES (Europe +
 *      the explicit Turkey exception).
 *   2. Cap what remains to the top 500, ranked by trustScore (Verified
 *      Partners first, then by score) -- everything beyond #500 is deleted.
 *
 * IMPORTANT -- what this script does NOT do: it does not invent or import
 * company data. It only filters/prunes rows that are ALREADY in the
 * `Company` table. Populating that table with 500 genuine, verified
 * European companies (real registration numbers, real addresses) is a data
 * -sourcing task -- e.g. a licensed feed from national commercial
 * registries (Handelsregister, INSEE/SIRENE, Companies House, KVK, MERSİS
 * for Turkey) or a B2B data provider -- not something this script or any
 * AI-generated seed data can safely stand in for. Feeding this table with
 * fabricated "real-looking" company records would misrepresent them as
 * genuine businesses, which this project has deliberately avoided
 * elsewhere (see docs/compliance/README.md's stance on not overstating
 * what's actually true).
 *
 * Run with: npm run enforce-geo-scope --workspace=server
 * (add --dry-run to only print what WOULD be deleted, without deleting)
 */
import { prisma } from "../../src/lib/prisma.js";
import { isInDirectoryScope } from "../../src/utils/geoScope.js";

const DIRECTORY_CAP = 500;
const dryRun = process.argv.includes("--dry-run");

async function main() {
  console.log(`Enforcing directory geographic scope (Europe + Turkey)${dryRun ? " [DRY RUN]" : ""}...`);

  const all = await prisma.company.findMany({
    select: { id: true, name: true, countryCode: true, trustScore: true, profileStatus: true },
  });

  const outOfScope = all.filter((c) => !isInDirectoryScope(c.countryCode));
  console.log(`Found ${outOfScope.length} companies outside the Europe+Turkey scope.`);
  if (outOfScope.length && !dryRun) {
    const result = await prisma.company.deleteMany({ where: { id: { in: outOfScope.map((c) => c.id) } } });
    console.log(`Deleted ${result.count} out-of-scope companies.`);
  }

  const inScope = all.filter((c) => isInDirectoryScope(c.countryCode));
  // Verified Partners are never pruned ahead of Directory Listed rows at
  // the same trust score -- a claimed, KYB-verified company should never
  // lose its spot to an unclaimed one just because of ranking noise.
  const ranked = [...inScope].sort((a, b) => {
    if (a.profileStatus !== b.profileStatus) return a.profileStatus === "VERIFIED_PARTNER" ? -1 : 1;
    return b.trustScore - a.trustScore;
  });
  const overCap = ranked.slice(DIRECTORY_CAP);
  console.log(`${ranked.length} companies remain in scope; ${overCap.length} exceed the top-${DIRECTORY_CAP} cap.`);
  if (overCap.length && !dryRun) {
    const result = await prisma.company.deleteMany({ where: { id: { in: overCap.map((c) => c.id) } } });
    console.log(`Deleted ${result.count} companies beyond the top ${DIRECTORY_CAP}.`);
  }

  console.log("Done.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
