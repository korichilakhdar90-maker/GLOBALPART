/**
 * Bulk import pipeline for populating the Company directory from a REAL
 * external source -- a licensed B2B data feed, an export from a national
 * commercial registry (Handelsregister, INSEE/SIRENE, Companies House,
 * KVK, MERSİS for Turkey, etc.), or an OpenCorporates bulk export.
 *
 * This script does NOT generate, invent, or guess company data. It only
 * validates and inserts rows that are already in your input file. If you
 * don't have a real source file yet, see companies-import-template.csv in
 * this folder for the exact shape this script expects -- it is a template
 * with clearly-fake placeholder rows, not something to import as-is.
 *
 * Every imported row is inserted as `profileStatus: DIRECTORY_LISTED` and
 * `verified: false` -- matching real companies still have to be claimed
 * and go through full KYB before becoming a Verified Partner (see
 * companies.routes.ts POST /:id/claim and kyb.routes.ts). Importing a
 * company here is not verifying it.
 *
 * Usage:
 *   npm run import-companies -- --file=./real-companies.csv
 *   npm run import-companies -- --file=./real-companies.csv --dry-run
 *   npm run import-companies -- --file=./real-companies.json
 *
 * After importing, run `npm run enforce-geo-scope` to prune anything out
 * of scope and cap the directory to the top 500 (see
 * enforceGeographicScope.ts) -- this script deliberately does NOT apply
 * the cap itself, so you can import in batches from multiple sources
 * before making the final cut.
 */
import { readFileSync } from "fs";
import { parse } from "csv-parse/sync";
import { prisma } from "../../src/lib/prisma.js";
import { isInDirectoryScope } from "../../src/utils/geoScope.js";

interface ImportRow {
  name: string;
  registrationNo: string;
  countryCode: string;
  countryName: string;
  region?: string;
  city?: string;
  industry: string;
  description?: string;
  employees?: string;
  founded?: string;
  sourceRegistry?: string;
  sourceUrl?: string;
}

const REQUIRED_COLUMNS: (keyof ImportRow)[] = ["name", "registrationNo", "countryCode", "countryName", "industry"];

function loadRows(filePath: string): ImportRow[] {
  const raw = readFileSync(filePath, "utf-8");
  if (filePath.endsWith(".json")) {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) throw new Error("JSON input must be an array of company objects");
    return parsed as ImportRow[];
  }
  return parse(raw, { columns: true, skip_empty_lines: true, trim: true }) as ImportRow[];
}

function validateRow(row: ImportRow, lineNumber: number): string | null {
  for (const col of REQUIRED_COLUMNS) {
    if (!row[col] || String(row[col]).trim() === "") {
      return `Row ${lineNumber}: missing required column "${col}"`;
    }
  }
  if (!isInDirectoryScope(row.countryCode)) {
    return `Row ${lineNumber}: countryCode "${row.countryCode}" is outside the Europe+Turkey directory scope -- skipped, not an error to fix in the source data unless it's a typo.`;
  }
  return null;
}

async function main() {
  const fileArg = process.argv.find((a) => a.startsWith("--file="));
  const dryRun = process.argv.includes("--dry-run");
  if (!fileArg) {
    console.error("Usage: npm run import-companies -- --file=./path/to/companies.csv [--dry-run]");
    process.exitCode = 1;
    return;
  }
  const filePath = fileArg.replace("--file=", "");

  console.log(`Loading rows from ${filePath}${dryRun ? " [DRY RUN]" : ""}...`);
  const rows = loadRows(filePath);
  console.log(`${rows.length} rows read.`);

  let inserted = 0;
  let skippedOutOfScope = 0;
  let skippedInvalid = 0;
  let skippedDuplicate = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const lineNumber = i + 2; // +1 for header, +1 for 1-indexing
    const error = validateRow(row, lineNumber);
    if (error) {
      if (error.includes("outside the Europe+Turkey")) {
        skippedOutOfScope++;
      } else {
        console.warn(error);
        skippedInvalid++;
      }
      continue;
    }

    // Dedupe on (countryCode, registrationNo) -- the actual stable
    // identity of a real company, not its name (names collide/change).
    const existing = await prisma.company.findFirst({
      where: { countryCode: row.countryCode.toUpperCase(), registrationNo: row.registrationNo.trim() },
      select: { id: true },
    });
    if (existing) {
      skippedDuplicate++;
      continue;
    }

    if (!dryRun) {
      await prisma.company.create({
        data: {
          name: row.name.trim(),
          registrationNo: row.registrationNo.trim(),
          countryCode: row.countryCode.toUpperCase(),
          countryName: row.countryName.trim(),
          region: row.region?.trim() || "Europe",
          city: row.city?.trim(),
          industry: row.industry.trim(),
          description: row.description?.trim() || "",
          employees: row.employees?.trim(),
          founded: row.founded ? parseInt(row.founded, 10) : undefined,
          sourceRegistry: row.sourceRegistry?.trim(),
          sourceUrl: row.sourceUrl?.trim(),
          // Always the honest starting point for imported real companies:
          // unclaimed, unverified, and a neutral baseline trust score
          // until/unless the owner claims it and passes KYB.
          profileStatus: "DIRECTORY_LISTED",
          verified: false,
          trustScore: 60,
        },
      });
    }
    inserted++;
  }

  console.log("\n--- Import summary ---");
  console.log(`Inserted:              ${inserted}${dryRun ? " (dry run -- nothing written)" : ""}`);
  console.log(`Skipped (out of scope): ${skippedOutOfScope}`);
  console.log(`Skipped (invalid row):  ${skippedInvalid}`);
  console.log(`Skipped (duplicate):    ${skippedDuplicate}`);
  console.log("\nNext: run `npm run enforce-geo-scope` to prune out-of-scope rows and cap the directory to the top 500.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
