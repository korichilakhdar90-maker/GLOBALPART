import bcrypt from "bcryptjs";
import type { PrismaClient } from "@prisma/client";

/**
 * QA / manual-testing fixtures.
 *
 * Everything created here is deliberately, obviously fake: names are
 * "Test Company N", emails are `@example.com` (an IANA-reserved domain
 * that can never receive real mail), and registration numbers are
 * prefixed "TEST-". That naming is load-bearing, not cosmetic -- this is
 * a trust-verification platform, and data that *looked* like real
 * companies sitting in a directory of "verified" businesses would
 * misrepresent them. The same reasoning is documented in
 * docs/compliance/README.md and prisma/scripts/README.md.
 *
 * For real directory data, use prisma/scripts/importCompanies.ts with an
 * actual licensed source.
 *
 * Idempotent: every record uses a deterministic `test-*` id with upsert,
 * so re-running the seed updates rather than duplicates.
 */

const TEST_PASSWORD = "TestPass123!";

const STANDARD_COUNT = 10;
const CORPORATE_COUNT = 5;
const GOVERNMENT_COUNT = 3;
const NOTIFICATION_COUNT = 50;
const AUDIT_LOG_COUNT = 100;
const INVITATION_COUNT = 30;
const CREDIT_ENTRY_COUNT = 50;

/** Deterministic pseudo-random so repeated runs produce identical fixtures. */
function seeded(n: number): number {
  let h = 2166136261 ^ n;
  h = Math.imul(h, 16777619);
  return Math.abs(h);
}

const EU_COUNTRIES = [
  { code: "DE", name: "Germany" },
  { code: "FR", name: "France" },
  { code: "NL", name: "Netherlands" },
  { code: "IT", name: "Italy" },
  { code: "ES", name: "Spain" },
  { code: "PL", name: "Poland" },
  { code: "TR", name: "Türkiye" },
];

const INDUSTRIES = ["Manufacturing", "Logistics & Supply Chain", "Technology", "Energy & Renewables", "Food & Beverage"];

export async function seedTestData(prisma: PrismaClient, adminId: string) {
  const passwordHash = await bcrypt.hash(TEST_PASSWORD, 12);
  const createdUserIds: string[] = [];
  const createdSubmissionIds: string[] = [];

  // ---- Tier 1: Standard (individuals / small businesses) ----
  for (let i = 1; i <= STANDARD_COUNT; i++) {
    const s = seeded(i);
    const country = EU_COUNTRIES[s % EU_COUNTRIES.length];
    const userId = `test-user-std-${i}`;
    const email = `test.standard${i}@example.com`;

    await prisma.user.upsert({
      where: { email },
      create: {
        id: userId,
        email,
        passwordHash,
        name: `Test Standard User ${i}`,
        company: `Test Company ${i}`,
        accountCategory: "INDIVIDUAL",
        accountStatus: "ACTIVE",
        emailVerified: true,
      },
      update: {},
    });
    createdUserIds.push(userId);

    // Mix of statuses so the admin queue has something to act on and the
    // applicant dashboards show all the states a real reviewer would see.
    const status = i <= 4 ? "PENDING" : i <= 6 ? "IN_REVIEW" : i <= 8 ? "APPROVED" : "REJECTED";
    const submissionId = `test-kyb-std-${i}`;
    await prisma.kybSubmission.upsert({
      where: { id: submissionId },
      create: {
        id: submissionId,
        userId,
        companyName: `Test Company ${i}`,
        registrationNo: `TEST-STD-${String(i).padStart(4, "0")}`,
        email,
        phone: `+49 30 000${String(i).padStart(4, "0")}`,
        countries: country.name,
        address: `${i} Test Street, ${country.name}`,
        status: status as never,
        trustScore: status === "APPROVED" ? 95 : null,
        rejectionReason: status === "REJECTED" ? "Test rejection: submitted registration number could not be matched against the public register." : null,
        bankAccountVerified: status === "APPROVED",
        physicalAddressConfirmed: status === "APPROVED",
        reviewedById: status === "APPROVED" || status === "REJECTED" ? adminId : null,
        reviewedAt: status === "APPROVED" || status === "REJECTED" ? new Date() : null,
        assignedToId: status === "IN_REVIEW" ? adminId : null,
      },
      update: {},
    });
    createdSubmissionIds.push(submissionId);

    await prisma.document.upsert({
      where: { storageKey: `test-storage-std-${i}-registration` },
      create: {
        userId,
        kybSubmissionId: submissionId,
        fileName: `test-business-registration-${i}.pdf`,
        storageKey: `test-storage-std-${i}-registration`,
        mimeType: "application/pdf",
        sizeBytes: 128_000 + (s % 400_000),
        docCategory: "business_registration",
      },
      update: {},
    });
  }
  console.log(`✅ Seeded ${STANDARD_COUNT} Standard-tier test companies (with KYB submissions + documents)`);

  // ---- Tier 2: Corporate ----
  for (let i = 1; i <= CORPORATE_COUNT; i++) {
    const s = seeded(1000 + i);
    const country = EU_COUNTRIES[s % EU_COUNTRIES.length];
    const userId = `test-user-corp-${i}`;
    // Corporate registration is domain-restricted (no free providers --
    // see domainPolicy.ts), so these use a corporate-shaped example.com
    // subdomain rather than a gmail-style address.
    const email = `finance@test-corp-${i}.example.com`;

    await prisma.user.upsert({
      where: { email },
      create: {
        id: userId,
        email,
        passwordHash,
        name: `Test Corporate Officer ${i}`,
        company: `Test Corporation ${i}`,
        accountCategory: "ENTERPRISE",
        accountStatus: i <= 3 ? "ACTIVE" : "PENDING_KYB",
        emailVerified: true,
        twoFactorEnabled: i <= 3, // Enterprise requires MFA for full access
      },
      update: {},
    });
    createdUserIds.push(userId);

    const status = i <= 2 ? "APPROVED" : i === 3 ? "IN_REVIEW" : "PENDING";
    const submissionId = `test-kyb-corp-${i}`;
    await prisma.kybSubmission.upsert({
      where: { id: submissionId },
      create: {
        id: submissionId,
        userId,
        companyName: `Test Corporation ${i}`,
        registrationNo: `TEST-CORP-${String(i).padStart(4, "0")}`,
        email,
        phone: `+33 1 0000${String(i).padStart(4, "0")}`,
        countries: country.name,
        address: `${i} Test Corporate Plaza, ${country.name}`,
        status: status as never,
        // Corporate formula: 30 base + 20 audit + 15 certs + 25 PEP clear
        trustScore: status === "APPROVED" ? 90 : null,
        financialAuditCompleted: status === "APPROVED",
        certificationsVerified: status === "APPROVED",
        pepScreeningStatus: status === "APPROVED" ? "CLEAR" : "NOT_STARTED",
        complianceAcknowledged: true,
        reviewedById: status === "APPROVED" ? adminId : null,
        reviewedAt: status === "APPROVED" ? new Date() : null,
        assignedToId: status === "IN_REVIEW" ? adminId : null,
      },
      update: {},
    });
    createdSubmissionIds.push(submissionId);

    for (const doc of ["financial_audit", "certifications", "business_registration"]) {
      await prisma.document.upsert({
        where: { storageKey: `test-storage-corp-${i}-${doc}` },
        create: {
          userId,
          kybSubmissionId: submissionId,
          fileName: `test-${doc.replace(/_/g, "-")}-${i}.pdf`,
          storageKey: `test-storage-corp-${i}-${doc}`,
          mimeType: "application/pdf",
          sizeBytes: 512_000 + (s % 900_000),
          docCategory: doc,
        },
        update: {},
      });
    }
  }
  console.log(`✅ Seeded ${CORPORATE_COUNT} Corporate-tier test companies (with financial/certification documents)`);

  // ---- Tier 3: Government (Sovereign) ----
  for (let i = 1; i <= GOVERNMENT_COUNT; i++) {
    const s = seeded(2000 + i);
    const country = EU_COUNTRIES[s % EU_COUNTRIES.length];
    const userId = `test-user-gov-${i}`;
    // Government registration is restricted to sovereign domains
    // (domainPolicy.ts), so these use a .gov-shaped test address.
    const email = `official${i}@test-ministry-${i}.gov`;

    await prisma.user.upsert({
      where: { email },
      create: {
        id: userId,
        email,
        passwordHash,
        name: `Test Government Official ${i}`,
        company: `Test Ministry ${i}`,
        accountCategory: "GOVERNMENT",
        accountStatus: i === 1 ? "ACTIVE" : "PENDING_SOVEREIGN_APPROVAL",
        emailVerified: true,
        twoFactorEnabled: true, // MFA is mandatory for all government users
        sovereignApprovedAt: i === 1 ? new Date() : null,
        sovereignApprovedById: i === 1 ? adminId : null,
      },
      update: {},
    });
    createdUserIds.push(userId);

    const status = i === 1 ? "APPROVED" : i === 2 ? "IN_REVIEW" : "PENDING";
    const submissionId = `test-kyb-gov-${i}`;
    await prisma.kybSubmission.upsert({
      where: { id: submissionId },
      create: {
        id: submissionId,
        userId,
        companyName: `Test Ministry ${i}`,
        registrationNo: `TEST-GOV-${String(i).padStart(4, "0")}`,
        email,
        phone: `+34 91 000${String(i).padStart(4, "0")}`,
        countries: country.code,
        address: `Test Ministry ${i}, ${country.name}`,
        status: status as never,
        // Sovereign formula: 40 diplomatic + 30 FSC + 20 PSC + 10 frameworks
        trustScore: status === "APPROVED" ? 100 : null,
        fscLevel: "NATO_SECRET",
        fscIssuingAuthority: `Test National Security Authority, ${country.name}`,
        fscIssueDate: new Date("2024-01-15"),
        fscExpiryDate: new Date("2030-01-15"),
        fscReferenceNumber: `TEST-NSA-FSC-${String(i).padStart(4, "0")}`,
        fscValidated: status === "APPROVED",
        pscAllValidated: status === "APPROVED",
        diplomaticVerificationCompleted: status === "APPROVED",
        dataClassificationPolicy: "CONFIDENTIAL",
        securityOfficerName: `Test Security Officer ${i}`,
        reviewedById: status === "APPROVED" ? adminId : null,
        reviewedAt: status === "APPROVED" ? new Date() : null,
        assignedToId: status === "IN_REVIEW" ? adminId : null,
      },
      update: {},
    });
    createdSubmissionIds.push(submissionId);

    // Two personnel per ministry -- the pathway's own minimum, including
    // at least one Sovereign Administrator.
    for (const [j, role] of (["SOVEREIGN_ADMIN", "PROCUREMENT_OFFICER"] as const).entries()) {
      await prisma.governmentPersonnel.upsert({
        where: { id: `test-gov-personnel-${i}-${j}` },
        create: {
          id: `test-gov-personnel-${i}-${j}`,
          kybSubmissionId: submissionId,
          fullName: `Test Personnel ${i}-${j + 1}`,
          officialTitle: role === "SOVEREIGN_ADMIN" ? "Director" : "Procurement Analyst",
          userRole: role,
          pscLevel: "SECRET",
          pscIssuingAuthority: `Test Ministry of Interior, ${country.name}`,
          pscIssueDate: new Date("2024-01-01"),
          pscExpiryDate: new Date("2030-01-01"),
        },
        update: {},
      });
    }

    for (const key of ["PRIVACY_POLICY", "DATA_PROCESSING_AGREEMENT", "SOVEREIGN_TRUST_FRAMEWORK", "SECURITY_PROTOCOL_COMMITMENT", "DATA_ISOLATION_POLICY"] as const) {
      await prisma.sovereignFrameworkAcceptance.upsert({
        where: { kybSubmissionId_frameworkKey: { kybSubmissionId: submissionId, frameworkKey: key } },
        create: { kybSubmissionId: submissionId, frameworkKey: key },
        update: {},
      });
    }

    for (const doc of ["sovereignStatusLetter", "entityRegistrationDoc", "fscCertificate"]) {
      await prisma.document.upsert({
        where: { storageKey: `test-storage-gov-${i}-${doc}` },
        create: {
          userId,
          kybSubmissionId: submissionId,
          fileName: `test-${doc}-${i}.pdf`,
          storageKey: `test-storage-gov-${i}-${doc}`,
          mimeType: "application/pdf",
          sizeBytes: 256_000 + (s % 600_000),
          docCategory: doc,
        },
        update: {},
      });
    }
  }
  console.log(`✅ Seeded ${GOVERNMENT_COUNT} Government-tier test entities (with FSC/PSC data + framework acceptances)`);

  // ---- Extra users to reach 20 total across the tiers ----
  const extraUsersNeeded = 20 - createdUserIds.length;
  for (let i = 1; i <= extraUsersNeeded; i++) {
    const email = `test.member${i}@example.com`;
    const userId = `test-user-extra-${i}`;
    await prisma.user.upsert({
      where: { email },
      create: {
        id: userId,
        email,
        passwordHash,
        name: `Test Team Member ${i}`,
        company: `Test Company ${i}`,
        accountCategory: "INDIVIDUAL",
        emailVerified: i % 2 === 0, // deliberately mixed, so the verification gate is testable
      },
      update: {},
    });
    createdUserIds.push(userId);
  }
  console.log(`✅ ${createdUserIds.length} test users total`);

  // ---- Notifications ----
  const notifTypes = ["KYB_SUBMITTED", "KYB_ASSIGNED", "KYB_APPROVED", "KYB_REJECTED", "INVITATION_ACCEPTED"] as const;
  await prisma.notification.deleteMany({ where: { id: { startsWith: "test-notif-" } } });
  await prisma.notification.createMany({
    data: Array.from({ length: NOTIFICATION_COUNT }, (_, n) => {
      const s = seeded(3000 + n);
      const type = notifTypes[s % notifTypes.length];
      return {
        id: `test-notif-${n + 1}`,
        userId: createdUserIds[s % createdUserIds.length],
        type,
        title: `Test notification ${n + 1}`,
        body: `This is test notification ${n + 1} of type ${type}, created by the seed script for QA.`,
        read: n % 3 === 0,
        kybSubmissionId: createdSubmissionIds[s % createdSubmissionIds.length],
      };
    }),
    skipDuplicates: true,
  });
  console.log(`✅ Seeded ${NOTIFICATION_COUNT} test notifications`);

  // ---- Admin audit log ----
  const actions = ["kyb.assigned", "kyb.approved", "kyb.rejected", "government.step1_completed", "government.submitted_for_review"];
  await prisma.adminAuditEvent.deleteMany({ where: { id: { startsWith: "test-audit-" } } });
  await prisma.adminAuditEvent.createMany({
    data: Array.from({ length: AUDIT_LOG_COUNT }, (_, n) => {
      const s = seeded(4000 + n);
      const entityId = createdSubmissionIds[s % createdSubmissionIds.length];
      return {
        id: `test-audit-${n + 1}`,
        adminId,
        action: actions[s % actions.length],
        entityType: "KybSubmission",
        entityId,
        entityName: `Test entity for audit event ${n + 1}`,
        notes: n % 4 === 0 ? `Test reviewer note ${n + 1}` : null,
        // Spread over the past ~100 days so the audit log's date sorting
        // and filtering are actually exercisable.
        createdAt: new Date(Date.now() - n * 24 * 60 * 60 * 1000),
      };
    }),
    skipDuplicates: true,
  });
  console.log(`✅ Seeded ${AUDIT_LOG_COUNT} test audit log entries`);

  // ---- Partner invitations ----
  const inviteStatuses = ["PENDING", "ACCEPTED", "EXPIRED"] as const;
  await prisma.partnerInvitation.deleteMany({ where: { id: { startsWith: "test-invite-" } } });
  await prisma.partnerInvitation.createMany({
    data: Array.from({ length: INVITATION_COUNT }, (_, n) => {
      const s = seeded(5000 + n);
      const status = inviteStatuses[s % inviteStatuses.length];
      const expired = status === "EXPIRED";
      return {
        id: `test-invite-${n + 1}`,
        inviterId: createdUserIds[s % createdUserIds.length],
        inviteeEmail: `test.invitee${n + 1}@example.com`,
        inviteeType: (["INDIVIDUAL", "ENTERPRISE", "GOVERNMENT"] as const)[s % 3],
        token: `test-invite-token-${n + 1}-${s.toString(36)}`,
        status,
        expiresAt: expired ? new Date(Date.now() - 24 * 60 * 60 * 1000) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        acceptedAt: status === "ACCEPTED" ? new Date(Date.now() - (s % 20) * 24 * 60 * 60 * 1000) : null,
      };
    }),
    skipDuplicates: true,
  });
  console.log(`✅ Seeded ${INVITATION_COUNT} test partner invitations (Pending / Accepted / Expired)`);

  // ---- Referral credit ledger ----
  await prisma.referralCredit.deleteMany({ where: { id: { startsWith: "test-credit-" } } });
  await prisma.referralCredit.createMany({
    data: Array.from({ length: CREDIT_ENTRY_COUNT }, (_, n) => {
      const s = seeded(6000 + n);
      // Mostly earned entries with occasional redemptions, so a balance
      // computed as SUM(amountCents) is a non-trivial number rather than
      // just count × 5000.
      const redeemed = n % 5 === 0;
      return {
        id: `test-credit-${n + 1}`,
        userId: createdUserIds[s % createdUserIds.length],
        amountCents: redeemed ? -2500 : 5000,
        reason: redeemed ? "redeemed_against_kyb_fee" : "invitation_accepted",
        invitationId: `test-invite-${(s % INVITATION_COUNT) + 1}`,
      };
    }),
    skipDuplicates: true,
  });
  console.log(`✅ Seeded ${CREDIT_ENTRY_COUNT} test referral credit ledger entries`);

  console.log(`\n🧪 Test fixtures ready. All test accounts share the password: ${TEST_PASSWORD}`);
  console.log("   Every record above is prefixed \"test-\" / \"Test \" and uses @example.com or .gov test domains — safe to delete wholesale.");
}
