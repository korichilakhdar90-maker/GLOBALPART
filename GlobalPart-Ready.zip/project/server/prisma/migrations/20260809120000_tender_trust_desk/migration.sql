-- Tender Trust Desk: Trust Passport, Evidence Locker, Explainable Trust
-- Score, Disputes & Correction workflow, Post-Collaboration Performance.
-- Purely additive: no existing table, column, or constraint is altered
-- or dropped. Safe to run against a populated database.

-- CreateEnum
CREATE TYPE "EvidenceStatus" AS ENUM ('PENDING', 'VERIFIED', 'REJECTED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "ReviewCaseType" AS ENUM ('APPEAL', 'CORRECTION_REQUEST', 'ADDITIONAL_EVIDENCE', 'FRAUD_REPORT');

-- CreateEnum
CREATE TYPE "ReviewCaseStatus" AS ENUM ('OPEN', 'IN_REVIEW', 'RESOLVED', 'REJECTED', 'ESCALATED');

-- CreateTable
CREATE TABLE "TrustPassport" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "legalName" TEXT NOT NULL,
    "registryNumber" TEXT,
    "registryCountry" TEXT,
    "incorporationDate" TIMESTAMP(3),
    "headquartersAddress" TEXT,
    "logisticsSummary" TEXT,
    "financialReadiness" TEXT,
    "isPublished" BOOLEAN NOT NULL DEFAULT false,
    "shareToken" TEXT NOT NULL,
    "lastReviewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TrustPassport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UboEntry" (
    "id" TEXT NOT NULL,
    "trustPassportId" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "nationality" TEXT,
    "ownershipPercent" DOUBLE PRECISION NOT NULL,
    "role" TEXT,
    "verifiedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UboEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CertificationEntry" (
    "id" TEXT NOT NULL,
    "trustPassportId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "issuingBody" TEXT,
    "certificateNumber" TEXT,
    "issuedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "status" "EvidenceStatus" NOT NULL DEFAULT 'PENDING',
    "evidenceItemId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CertificationEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EvidenceItem" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "documentId" TEXT,
    "category" TEXT NOT NULL,
    "sourceType" TEXT NOT NULL,
    "sourceName" TEXT,
    "issuedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "status" "EvidenceStatus" NOT NULL DEFAULT 'PENDING',
    "confidenceScore" INTEGER,
    "reviewedById" TEXT,
    "reviewNotes" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "previousVersionId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EvidenceItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TrustAssessment" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "previousScore" INTEGER,
    "isCurrent" BOOLEAN NOT NULL DEFAULT true,
    "triggeredBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TrustAssessment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TrustScoreFactor" (
    "id" TEXT NOT NULL,
    "trustAssessmentId" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "weightBps" INTEGER NOT NULL,
    "pointsAwarded" INTEGER NOT NULL,
    "pointsPossible" INTEGER NOT NULL,
    "explanation" TEXT NOT NULL,
    "evidenceItemId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TrustScoreFactor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReviewCase" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "openedById" TEXT NOT NULL,
    "type" "ReviewCaseType" NOT NULL,
    "status" "ReviewCaseStatus" NOT NULL DEFAULT 'OPEN',
    "subject" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "relatedEvidenceItemId" TEXT,
    "resolvedAt" TIMESTAMP(3),
    "resolutionNotes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ReviewCase_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReviewCaseEvent" (
    "id" TEXT NOT NULL,
    "reviewCaseId" TEXT NOT NULL,
    "actorId" TEXT,
    "eventType" TEXT NOT NULL,
    "payload" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ReviewCaseEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PerformanceRecord" (
    "id" TEXT NOT NULL,
    "dealRoomId" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "submittedById" TEXT NOT NULL,
    "deliveryRating" INTEGER NOT NULL,
    "qualityRating" INTEGER NOT NULL,
    "conductRating" INTEGER NOT NULL,
    "hadDispute" BOOLEAN NOT NULL DEFAULT false,
    "comments" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PerformanceRecord_pkey" PRIMARY KEY ("id")
);

-- CreateIndex (unique)
CREATE UNIQUE INDEX "TrustPassport_companyId_key" ON "TrustPassport"("companyId");
CREATE UNIQUE INDEX "TrustPassport_shareToken_key" ON "TrustPassport"("shareToken");
CREATE UNIQUE INDEX "CertificationEntry_evidenceItemId_key" ON "CertificationEntry"("evidenceItemId");
CREATE UNIQUE INDEX "EvidenceItem_documentId_key" ON "EvidenceItem"("documentId");
CREATE UNIQUE INDEX "EvidenceItem_previousVersionId_key" ON "EvidenceItem"("previousVersionId");
CREATE UNIQUE INDEX "PerformanceRecord_dealRoomId_submittedById_key" ON "PerformanceRecord"("dealRoomId", "submittedById");

-- CreateIndex (lookup)
CREATE INDEX "UboEntry_trustPassportId_idx" ON "UboEntry"("trustPassportId");
CREATE INDEX "CertificationEntry_trustPassportId_idx" ON "CertificationEntry"("trustPassportId");
CREATE INDEX "EvidenceItem_companyId_idx" ON "EvidenceItem"("companyId");
CREATE INDEX "EvidenceItem_category_idx" ON "EvidenceItem"("category");
CREATE INDEX "EvidenceItem_status_idx" ON "EvidenceItem"("status");
CREATE INDEX "EvidenceItem_expiresAt_idx" ON "EvidenceItem"("expiresAt");
CREATE INDEX "TrustAssessment_companyId_isCurrent_idx" ON "TrustAssessment"("companyId", "isCurrent");
CREATE INDEX "TrustScoreFactor_trustAssessmentId_idx" ON "TrustScoreFactor"("trustAssessmentId");
CREATE INDEX "ReviewCase_companyId_idx" ON "ReviewCase"("companyId");
CREATE INDEX "ReviewCase_status_idx" ON "ReviewCase"("status");
CREATE INDEX "ReviewCase_type_idx" ON "ReviewCase"("type");
CREATE INDEX "ReviewCaseEvent_reviewCaseId_idx" ON "ReviewCaseEvent"("reviewCaseId");
CREATE INDEX "PerformanceRecord_companyId_idx" ON "PerformanceRecord"("companyId");

-- AddForeignKey
ALTER TABLE "TrustPassport" ADD CONSTRAINT "TrustPassport_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "UboEntry" ADD CONSTRAINT "UboEntry_trustPassportId_fkey" FOREIGN KEY ("trustPassportId") REFERENCES "TrustPassport"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CertificationEntry" ADD CONSTRAINT "CertificationEntry_trustPassportId_fkey" FOREIGN KEY ("trustPassportId") REFERENCES "TrustPassport"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CertificationEntry" ADD CONSTRAINT "CertificationEntry_evidenceItemId_fkey" FOREIGN KEY ("evidenceItemId") REFERENCES "EvidenceItem"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "EvidenceItem" ADD CONSTRAINT "EvidenceItem_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "EvidenceItem" ADD CONSTRAINT "EvidenceItem_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "Document"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "EvidenceItem" ADD CONSTRAINT "EvidenceItem_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "EvidenceItem" ADD CONSTRAINT "EvidenceItem_previousVersionId_fkey" FOREIGN KEY ("previousVersionId") REFERENCES "EvidenceItem"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "TrustAssessment" ADD CONSTRAINT "TrustAssessment_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TrustScoreFactor" ADD CONSTRAINT "TrustScoreFactor_trustAssessmentId_fkey" FOREIGN KEY ("trustAssessmentId") REFERENCES "TrustAssessment"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "TrustScoreFactor" ADD CONSTRAINT "TrustScoreFactor_evidenceItemId_fkey" FOREIGN KEY ("evidenceItemId") REFERENCES "EvidenceItem"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "ReviewCase" ADD CONSTRAINT "ReviewCase_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ReviewCase" ADD CONSTRAINT "ReviewCase_openedById_fkey" FOREIGN KEY ("openedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "ReviewCase" ADD CONSTRAINT "ReviewCase_relatedEvidenceItemId_fkey" FOREIGN KEY ("relatedEvidenceItemId") REFERENCES "EvidenceItem"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "ReviewCaseEvent" ADD CONSTRAINT "ReviewCaseEvent_reviewCaseId_fkey" FOREIGN KEY ("reviewCaseId") REFERENCES "ReviewCase"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ReviewCaseEvent" ADD CONSTRAINT "ReviewCaseEvent_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "PerformanceRecord" ADD CONSTRAINT "PerformanceRecord_dealRoomId_fkey" FOREIGN KEY ("dealRoomId") REFERENCES "DealRoom"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "PerformanceRecord" ADD CONSTRAINT "PerformanceRecord_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "PerformanceRecord" ADD CONSTRAINT "PerformanceRecord_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
