-- Security fix: storageKey must be unique so files.routes.ts can look up
-- the owning Document for an authorization check before serving a file
-- (previously any authenticated user could read any file by storageKey
-- with no ownership check at all). storageKey is a randomly generated
-- UUID-based value per upload, so this should never conflict with
-- existing data; if it somehow does on a populated database, dedupe
-- affected rows before applying.

-- AlterTable
CREATE UNIQUE INDEX "Document_storageKey_key" ON "Document"("storageKey");
