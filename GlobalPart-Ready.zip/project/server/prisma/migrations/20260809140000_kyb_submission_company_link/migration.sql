-- Links a KYB submission to its Company directory row, so an approved
-- submission can be traced to the Company whose Explainable Trust Score
-- it should update. Purely additive: nullable column, no data loss, no
-- existing constraint touched. Safe to run against a populated database;
-- existing rows get companyId = NULL until the app backfills or a new
-- submission sets it going forward.

-- AlterTable
ALTER TABLE "KybSubmission" ADD COLUMN "companyId" TEXT;

-- CreateIndex
CREATE INDEX "KybSubmission_companyId_idx" ON "KybSubmission"("companyId");

-- AddForeignKey
-- ON DELETE SET NULL: if a Company directory row is ever deleted, the
-- historical KYB submission record survives (companyName / registrationNo
-- / etc. stay intact) — it just loses its link to a company, since KYB
-- history is a compliance record and shouldn't disappear because a
-- directory listing did.
ALTER TABLE "KybSubmission" ADD CONSTRAINT "KybSubmission_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE SET NULL ON UPDATE CASCADE;
