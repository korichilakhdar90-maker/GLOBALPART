import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { TRUST_SCORE_CATEGORIES } from "../src/lib/trustCategories.js";
import { computeWeightedScore } from "../src/services/trustScore.service.js";
import { seedTestData } from "./seedTestData.js";

const prisma = new PrismaClient();

// Mirrors src/data.ts on the frontend exactly, so seeded data matches what
// the UI previously showed as mock data — just now backed by a real table.
const COUNTRIES = [
  { code: "US", name: "United States", region: "North America" },
  { code: "CA", name: "Canada", region: "North America" },
  { code: "MX", name: "Mexico", region: "North America" },
  { code: "BR", name: "Brazil", region: "South America" },
  { code: "AR", name: "Argentina", region: "South America" },
  { code: "CL", name: "Chile", region: "South America" },
  { code: "GB", name: "United Kingdom", region: "Europe" },
  { code: "DE", name: "Germany", region: "Europe" },
  { code: "FR", name: "France", region: "Europe" },
  { code: "IT", name: "Italy", region: "Europe" },
  { code: "ES", name: "Spain", region: "Europe" },
  { code: "NL", name: "Netherlands", region: "Europe" },
  { code: "SE", name: "Sweden", region: "Europe" },
  { code: "CH", name: "Switzerland", region: "Europe" },
  { code: "PL", name: "Poland", region: "Europe" },
  { code: "TR", name: "Türkiye", region: "Europe" },
  { code: "IE", name: "Ireland", region: "Europe" },
  { code: "AE", name: "United Arab Emirates", region: "GCC" },
  { code: "SA", name: "Saudi Arabia", region: "GCC" },
  { code: "QA", name: "Qatar", region: "GCC" },
  { code: "KW", name: "Kuwait", region: "GCC" },
  { code: "BH", name: "Bahrain", region: "GCC" },
  { code: "OM", name: "Oman", region: "GCC" },
  { code: "EG", name: "Egypt", region: "North Africa" },
  { code: "MA", name: "Morocco", region: "North Africa" },
  { code: "DZ", name: "Algeria", region: "North Africa" },
  { code: "TN", name: "Tunisia", region: "North Africa" },
  { code: "ZA", name: "South Africa", region: "Africa" },
  { code: "NG", name: "Nigeria", region: "Africa" },
  { code: "KE", name: "Kenya", region: "Africa" },
  { code: "CN", name: "China", region: "Asia" },
  { code: "JP", name: "Japan", region: "Asia" },
  { code: "KR", name: "South Korea", region: "Asia" },
  { code: "IN", name: "India", region: "Asia" },
  { code: "SG", name: "Singapore", region: "Southeast Asia" },
  { code: "MY", name: "Malaysia", region: "Southeast Asia" },
  { code: "ID", name: "Indonesia", region: "Southeast Asia" },
  { code: "TH", name: "Thailand", region: "Southeast Asia" },
  { code: "VN", name: "Vietnam", region: "Southeast Asia" },
  { code: "PH", name: "Philippines", region: "Southeast Asia" },
  { code: "HK", name: "Hong Kong", region: "Asia" },
  { code: "AU", name: "Australia", region: "Oceania" },
  { code: "NZ", name: "New Zealand", region: "Oceania" },
  { code: "RU", name: "Russia", region: "Eurasia" },
  { code: "IL", name: "Israel", region: "Middle East" },
];

const INDUSTRIES = [
  "Technology", "Manufacturing", "Energy & Renewables", "Logistics & Supply Chain",
  "Finance & Fintech", "Pharmaceuticals", "Construction & Materials", "Automotive",
  "Aerospace & Defense", "Agriculture & AgriTech", "Food & Beverage", "Textiles & Apparel",
  "Mining & Metals", "Telecommunications", "Biotechnology", "Electronics",
];

const PREFIXES = [
  "Nexora", "Vertex", "Quantum", "Aurora", "Helix", "Stellar", "Atlas", "Zenith",
  "Apex", "Orbit", "Nova", "Pinnacle", "Cobalt", "Meridian", "Solstice", "Vanguard",
  "Catalyst", "Summit", "Beacon", "Horizon", "Pioneer", "Crestline", "Ironclad",
  "Lumen", "Forge", "Cipher", "Polaris", "Equinox", "Granite", "Onyx", "Sapphire",
  "Verdant", "Azure", "Crimson", "Saffron", "Indigo", "Emerald", "Amber", "Titan",
  "Aramco", "Stenama", "Sinopec", "Cosco", "Maersk", "Bayer", "Siemens", "Honeywell",
];
const SUFFIXES = ["Global", "Industries", "Systems", "Group", "Technologies", "Partners", "Trade", "International", "Solutions", "Holdings", "Logistics", "Dynamics"];

const DESCRIPTIONS: Record<string, string> = {
  Technology: "A leading software and cloud innovator delivering enterprise digital transformation across global markets.",
  Manufacturing: "Precision manufacturer of industrial components with a fully certified supply chain and global export capacity.",
  "Energy & Renewables": "Renewable energy developer advancing solar, wind, and green hydrogen projects at utility scale.",
  "Logistics & Supply Chain": "End-to-end logistics operator managing freight, warehousing, and customs across 40+ corridors.",
  "Finance & Fintech": "Regulated fintech providing cross-border payments, trade finance, and embedded banking infrastructure.",
  Pharmaceuticals: "GMP-certified pharmaceutical producer exporting generic and specialty medicines worldwide.",
  "Construction & Materials": "Integrated construction and building materials supplier for mega-projects and infrastructure.",
  Automotive: "Automotive parts and EV component manufacturer serving Tier-1 OEMs globally.",
  "Aerospace & Defense": "Aerospace engineering firm producing precision components to AS9100 standards.",
  "Agriculture & AgriTech": "AgriTech producer optimizing yields with smart farming and sustainable practices.",
  "Food & Beverage": "Food producer with HACCP and ISO 22000 certified export operations.",
  "Textiles & Apparel": "Vertically integrated textile manufacturer with ethical and sustainable sourcing.",
  "Mining & Metals": "Mining and metals processor supplying critical raw materials to global industry.",
  Telecommunications: "Telecommunications infrastructure provider enabling next-generation connectivity.",
  Biotechnology: "Biotech research and manufacturing organization advancing diagnostics and therapeutics.",
  Electronics: "Electronics manufacturer producing semiconductors, PCBs, and smart devices at scale.",
};

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}
function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

async function main() {
  console.log("🌱 Seeding database...");

  const sizes = ["11-50", "51-200", "201-500", "501-1,000", "1,001-5,000", "5,000+"];
  for (let i = 0; i < 108; i++) {
    const seed = hash(`company-${i}-globalpart`);
    const name = `${pick(PREFIXES, seed >> 3)} ${pick(SUFFIXES, seed >> 7)}`;
    const country = pick(COUNTRIES, seed >> 5);
    const industry = pick(INDUSTRIES, seed >> 2);
    const trustScore = 62 + (seed % 38);

    await prisma.company.upsert({
      where: { id: `co-${i + 1}` },
      create: {
        id: `co-${i + 1}`,
        name,
        industry,
        countryCode: country.code,
        countryName: country.name,
        region: country.region,
        description: DESCRIPTIONS[industry],
        employees: pick(sizes, seed >> 4),
        founded: 1968 + (seed % 55),
        trustScore,
        verified: trustScore >= 74,
      },
      update: {},
    });
  }
  console.log("✅ Seeded 108 companies");

  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? "admin@globalpart.io";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe123!";
  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    create: { name: "Platform Admin", email: adminEmail, passwordHash, role: "ADMIN", emailVerified: true },
    update: {},
  });
  console.log(`✅ Admin account ready: ${adminEmail} (change SEED_ADMIN_PASSWORD before running in production!)`);

  await seedTrustDesk(admin.id);

  // QA fixtures are opt-in rather than default: a production `npm run seed`
  // should populate the platform's own baseline data, not 20 fake accounts
  // and 100 fake audit entries. Enable with:
  //   npm run seed:test        (or SEED_TEST_DATA=true npm run seed)
  if (process.env.SEED_TEST_DATA === "true") {
    await seedTestData(prisma, admin.id);
  } else {
    console.log("ℹ️  Skipping QA test fixtures. Run `npm run seed:test` to include them.");
  }
}

// Seeds one fully worked example of the Tender Trust Desk -- a Trust
// Passport, a couple of pieces of evidence, and an initial (explainable)
// Trust Assessment -- on top of company "co-1" from the directory seed
// above, so the feature has something real to look at out of the box
// without backfilling all 108 seeded companies.
//
// Every write here is a fixed-id upsert, so re-running `npm run seed`
// updates this same demo record in place instead of creating duplicates
// or throwing on a unique-constraint conflict.
async function seedTrustDesk(reviewerId: string) {
  const DEMO_COMPANY_ID = "co-1";
  const company = await prisma.company.findUnique({ where: { id: DEMO_COMPANY_ID } });
  if (!company) {
    console.warn(`⚠️  Skipping Trust Desk seed: company "${DEMO_COMPANY_ID}" not found (run company seed first).`);
    return;
  }

  // --- Trust Passport ---
  const passport = await prisma.trustPassport.upsert({
    where: { companyId: DEMO_COMPANY_ID },
    create: {
      id: "tp-co-1",
      companyId: DEMO_COMPANY_ID,
      legalName: `${company.name} Ltd.`,
      registryNumber: "REG-0001-DEMO",
      registryCountry: company.countryCode,
      incorporationDate: new Date(`${company.founded ?? 2005}-03-14T00:00:00.000Z`),
      headquartersAddress: `1 Harbor Way, ${company.city ?? company.countryName}`,
      logisticsSummary: "Owns 2 bonded warehouses; ships via 3 pre-qualified freight partners.",
      financialReadiness: "Audited financials for the last 3 fiscal years; no outstanding liens.",
      isPublished: true,
      shareToken: "share-co-1-demo",
      lastReviewedAt: new Date(),
    },
    update: {},
  });

  // --- Evidence Locker: one item per category backing the assessment below ---
  const evidenceSpecs = [
    { id: "ev-co-1-legal", category: "kyb_verification", sourceType: "government_registry", sourceName: "National Business Registry", confidenceScore: 95 },
    { id: "ev-co-1-registry", category: "registry", sourceType: "government_registry", sourceName: "Chamber of Commerce Extract", confidenceScore: 90 },
    { id: "ev-co-1-financials", category: "financials", sourceType: "third_party_provider", sourceName: "Audited Financial Statements", confidenceScore: 80 },
  ] as const;

  const evidenceItems: Record<string, { id: string }> = {};
  for (const spec of evidenceSpecs) {
    const item = await prisma.evidenceItem.upsert({
      where: { id: spec.id },
      create: {
        id: spec.id,
        companyId: DEMO_COMPANY_ID,
        category: spec.category,
        sourceType: spec.sourceType,
        sourceName: spec.sourceName,
        issuedAt: new Date("2024-01-15T00:00:00.000Z"),
        expiresAt: new Date("2027-01-15T00:00:00.000Z"),
        status: "VERIFIED",
        confidenceScore: spec.confidenceScore,
        reviewedById: reviewerId,
        reviewedAt: new Date(),
      },
      update: {},
    });
    evidenceItems[spec.category] = item;
  }

  // --- One UBO on the passport ---
  await prisma.uboEntry.upsert({
    where: { id: "ubo-co-1-1" },
    create: {
      id: "ubo-co-1-1",
      trustPassportId: passport.id,
      fullName: "Demo Beneficial Owner",
      nationality: company.countryCode,
      ownershipPercent: 100,
      role: "Founder & CEO",
      verifiedAt: new Date(),
    },
    update: {},
  });

  // --- Initial Explainable Trust Assessment ---
  // isCurrent flip is manual here since this is the only assessment for
  // this company; the sync service handles flipping isCurrent off on the
  // previous row whenever a *new* assessment is created after this one.
  const factorSpecs = [
    { category: "kyb_verification", pointsAwarded: 27, pointsPossible: 30, explanation: "KYB approved: legal identity, registration, and contact details confirmed against official records.", evidenceKey: "kyb_verification" },
    { category: "registry", pointsAwarded: 18, pointsPossible: 20, explanation: "Commercial registry extract verified and current.", evidenceKey: "registry" },
    { category: "financials", pointsAwarded: 15, pointsPossible: 20, explanation: "Audited statements on file; one ratio below the preferred threshold.", evidenceKey: "financials" },
    { category: "certifications", pointsAwarded: 10, pointsPossible: 15, explanation: "No certifications submitted yet -- partial credit for a clean compliance history.", evidenceKey: null },
    { category: "past_projects", pointsAwarded: 15, pointsPossible: 20, explanation: "No completed deals on GlobalPart yet -- score reflects external references only.", evidenceKey: null },
    { category: "logistics", pointsAwarded: 10, pointsPossible: 10, explanation: "Warehouse and freight-partner capacity confirmed.", evidenceKey: null },
  ] as const;

  // Derived from the same weighted formula the runtime service uses --
  // never hand-typed, so seed data can't quietly drift from real scoring
  // logic the way a hardcoded number could.
  const TARGET_SCORE = computeWeightedScore(
    factorSpecs.map((f) => ({
      category: f.category,
      pointsAwarded: f.pointsAwarded,
      pointsPossible: f.pointsPossible,
      explanation: f.explanation,
    }))
  );

  const previous = await prisma.trustAssessment.findFirst({
    where: { companyId: DEMO_COMPANY_ID, isCurrent: true },
  });

  const assessment = await prisma.trustAssessment.upsert({
    where: { id: "ta-co-1-initial" },
    create: {
      id: "ta-co-1-initial",
      companyId: DEMO_COMPANY_ID,
      score: TARGET_SCORE,
      previousScore: previous?.score ?? null,
      isCurrent: true,
      triggeredBy: "kyb_approval",
    },
    update: {},
  });

  for (const [i, spec] of factorSpecs.entries()) {
    const category = TRUST_SCORE_CATEGORIES.find((c) => c.key === spec.category)!;
    await prisma.trustScoreFactor.upsert({
      where: { id: `tsf-co-1-${i + 1}` },
      create: {
        id: `tsf-co-1-${i + 1}`,
        trustAssessmentId: assessment.id,
        category: category.key,
        weightBps: category.weightBps,
        pointsAwarded: spec.pointsAwarded,
        pointsPossible: spec.pointsPossible,
        explanation: spec.explanation,
        evidenceItemId: spec.evidenceKey ? evidenceItems[spec.evidenceKey].id : null,
      },
      update: {},
    });
  }

  // --- Hybrid sync: mirror the finalized assessment score onto the fast-read cache ---
  await prisma.company.update({
    where: { id: DEMO_COMPANY_ID },
    data: { trustScore: TARGET_SCORE, verified: true },
  });

  console.log(`✅ Seeded Trust Desk demo on "${company.name}" (${DEMO_COMPANY_ID}): passport, ${evidenceSpecs.length} evidence items, 1 assessment, ${factorSpecs.length} score factors.`);
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
