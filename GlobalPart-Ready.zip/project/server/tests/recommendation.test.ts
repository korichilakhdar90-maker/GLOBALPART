import { describe, it, expect } from "vitest";
import { scoreCompanies } from "../src/services/recommendation.service.js";
import type { Company } from "@prisma/client";

function makeCompany(overrides: Partial<Company>): Company {
  return {
    id: "co-1",
    name: "Test Co",
    industry: "Technology",
    countryCode: "US",
    countryName: "United States",
    region: "North America",
    city: null,
    description: "A test company",
    employees: "51-200",
    founded: 2010,
    trustScore: 80,
    verified: true,
    logoSeed: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  } as Company;
}

describe("scoreCompanies", () => {
  it("ranks a full industry+country match above a partial match", () => {
    const exact = makeCompany({ id: "exact", industry: "Technology", countryCode: "US", trustScore: 80 });
    const partial = makeCompany({ id: "partial", industry: "Manufacturing", countryCode: "DE", trustScore: 80 });

    const results = scoreCompanies([exact, partial], {
      preferredIndustries: ["Technology"],
      preferredCountryCodes: ["US"],
    });

    expect(results[0].company.id).toBe("exact");
    expect(results[0].score).toBeGreaterThan(results[1].score);
  });

  it("weighs a higher trust score as a tiebreaker between equally-matched companies", () => {
    const highTrust = makeCompany({ id: "high", trustScore: 95 });
    const lowTrust = makeCompany({ id: "low", trustScore: 65 });

    const results = scoreCompanies([highTrust, lowTrust], {
      preferredIndustries: [],
      preferredCountryCodes: [],
    });

    expect(results[0].company.id).toBe("high");
  });

  it("excludes explicitly excluded company ids (e.g. already-favorited)", () => {
    const a = makeCompany({ id: "a" });
    const b = makeCompany({ id: "b" });

    const results = scoreCompanies([a, b], {
      preferredIndustries: [],
      preferredCountryCodes: [],
      excludeCompanyIds: ["a"],
    });

    expect(results.map((r) => r.company.id)).toEqual(["b"]);
  });

  it("never produces a score outside the 0-100 range", () => {
    const company = makeCompany({ trustScore: 100, industry: "Technology", countryCode: "US" });
    const results = scoreCompanies([company], {
      preferredIndustries: ["Technology"],
      preferredCountryCodes: ["US"],
      preferredRegions: ["north america"],
    });
    expect(results[0].score).toBeLessThanOrEqual(100);
    expect(results[0].score).toBeGreaterThanOrEqual(0);
  });
});
