import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createApp } from "../../src/app.js";
import { prisma } from "../../src/lib/prisma.js";
import bcrypt from "bcryptjs";
import { generate as generateTotp } from "otplib";

const app = createApp();

/**
 * Government (Sovereign) pathway, full flow: register on a recognized
 * sovereign domain → verify email → mandatory MFA setup → all 6 wizard
 * steps (each persisted individually, per Task 9's progressive-save
 * requirement) → application appears in the admin queue → admin approves
 * with manual verification of every checklist item → Trust Score matches
 * the documented 40/30/20/10 weighted formula → applicant is notified.
 *
 * Same environment caveat as the other two e2e files: run with
 * `npm run test:e2e` against a dedicated test database, not here.
 */
describe("Government KYB pathway: register → verify → MFA → 6 steps → approve", () => {
  const timestamp = Date.now();
  const applicantEmail = `admin-${timestamp}@ministry.gov`; // matches the default ".gov" sovereign suffix in geoScope-adjacent domainPolicy.ts
  const adminEmail = `e2e-admin-gov-${timestamp}@example.com`;
  const password = "SuperSecret123!";

  let applicantToken: string;
  let applicantUserId: string;
  let adminToken: string;
  let draftId: string;

  beforeAll(async () => {
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({
      data: { name: "E2E Admin", email: adminEmail, passwordHash, role: "ADMIN", emailVerified: true },
    });
    const adminLogin = await request(app).post("/api/auth/login").send({ email: adminEmail, password });
    adminToken = adminLogin.body.accessToken;

    const register = await request(app)
      .post("/api/auth/register")
      .send({ name: "Ministry Official", email: applicantEmail, password, accountCategory: "GOVERNMENT" });
    expect(register.status).toBe(201);
    expect(register.body.sessionIssued).toBe(false); // Government: no session until email is verified
    expect(register.body.user.accountStatus).toBe("PENDING_SOVEREIGN_APPROVAL");
    applicantUserId = register.body.user.id;
  });

  afterAll(async () => {
    await prisma.notification.deleteMany({ where: { userId: applicantUserId } });
    if (draftId) await prisma.adminAuditEvent.deleteMany({ where: { entityId: draftId } });
    await prisma.kybSubmission.deleteMany({ where: { userId: applicantUserId } });
    await prisma.user.deleteMany({ where: { email: { in: [applicantEmail, adminEmail] } } });
    await prisma.$disconnect();
  });

  it("rejects registration from a non-sovereign domain", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Should Fail", email: `nope-${timestamp}@gmail.com`, password, accountCategory: "GOVERNMENT" });
    expect(res.status).toBe(403);
  });

  it("blocks login entirely before email verification", async () => {
    const res = await request(app).post("/api/auth/login").send({ email: applicantEmail, password });
    expect(res.status).toBe(403);
  });

  it("logs in and sets up mandatory MFA once email is verified", async () => {
    await prisma.user.update({ where: { id: applicantUserId }, data: { emailVerified: true } });

    const login = await request(app).post("/api/auth/login").send({ email: applicantEmail, password });
    expect(login.status).toBe(200);
    expect(login.body.twoFactorRequired).toBe(false); // 2FA not enabled yet -- real session issued so MFA setup itself is reachable
    applicantToken = login.body.accessToken;

    // Government access is blocked everywhere else until MFA is enabled --
    // prove that here before setting it up.
    const blockedAttempt = await request(app)
      .post("/api/government/draft")
      .set("Authorization", `Bearer ${applicantToken}`)
      .field("entityName", "Ministry of Testing")
      .field("countryCode", "ES")
      .field("registrationNo", "MIN-0001")
      .field("officialContactName", "Ministry Official")
      .field("officialTitle", "Director")
      .field("officialEmail", applicantEmail)
      .field("officialPhone", "+34 91 000 0000");
    expect(blockedAttempt.status).toBe(403);

    const setup = await request(app).post("/api/auth/2fa/setup").set("Authorization", `Bearer ${applicantToken}`);
    expect(setup.status).toBe(200);
    const code = await generateTotp({ secret: setup.body.secret });
    const enable = await request(app).post("/api/auth/2fa/enable").set("Authorization", `Bearer ${applicantToken}`).send({ code });
    expect(enable.status).toBe(200);
    expect(enable.body.twoFactorEnabled).toBe(true);
  });

  it("Step 1 — creates the draft with sovereign identity documents", async () => {
    const res = await request(app)
      .post("/api/government/draft")
      .set("Authorization", `Bearer ${applicantToken}`)
      .field("entityName", "Ministry of Testing")
      .field("countryCode", "ES")
      .field("registrationNo", "MIN-0001")
      .field("officialContactName", "Ministry Official")
      .field("officialTitle", "Director")
      .field("officialEmail", applicantEmail)
      .field("officialPhone", "+34 91 000 0000")
      .attach("sovereignStatusLetter", Buffer.from("letter"), "status-letter.pdf")
      .attach("entityRegistrationDoc", Buffer.from("registration"), "registration.pdf");
    expect(res.status).toBe(201);
    expect(res.body.status).toBe("DRAFT");
    draftId = res.body.id;
  });

  it("Step 2 — saves Facility Security Clearance", async () => {
    const res = await request(app)
      .patch(`/api/government/draft/${draftId}/fsc`)
      .set("Authorization", `Bearer ${applicantToken}`)
      .field("fscLevel", "NATO_SECRET")
      .field("fscIssuingAuthority", "National Security Authority")
      .field("fscIssueDate", "2024-01-15")
      .field("fscExpiryDate", "2030-01-15")
      .field("fscReferenceNumber", "NSA-0001");
    expect(res.status).toBe(200);
    expect(res.body.saved).toBe(true);
  });

  it("Step 3 — adds personnel (Sovereign Administrator + one other)", async () => {
    const admin = await request(app)
      .post(`/api/government/draft/${draftId}/personnel`)
      .set("Authorization", `Bearer ${applicantToken}`)
      .send({
        fullName: "Sovereign Admin Person", officialTitle: "Director", userRole: "SOVEREIGN_ADMIN",
        pscLevel: "SECRET", pscIssuingAuthority: "Ministry of Interior", pscIssueDate: "2024-01-01", pscExpiryDate: "2030-01-01",
      });
    expect(admin.status).toBe(201);

    const officer = await request(app)
      .post(`/api/government/draft/${draftId}/personnel`)
      .set("Authorization", `Bearer ${applicantToken}`)
      .send({
        fullName: "Procurement Officer Person", officialTitle: "Analyst", userRole: "PROCUREMENT_OFFICER",
        pscLevel: "SECRET", pscIssuingAuthority: "Ministry of Interior", pscIssueDate: "2024-01-01", pscExpiryDate: "2030-01-01",
      });
    expect(officer.status).toBe(201);
  });

  it("Step 4 — saves access control settings", async () => {
    const res = await request(app)
      .patch(`/api/government/draft/${draftId}/access`)
      .set("Authorization", `Bearer ${applicantToken}`)
      .send({ dataClassificationPolicy: "CONFIDENTIAL", securityOfficerName: "Sovereign Admin Person", dataSharingConsent: true, accessLoggingConsent: true });
    expect(res.status).toBe(200);
  });

  it("Step 5 — accepts all five legal frameworks individually", async () => {
    const keys = ["PRIVACY_POLICY", "DATA_PROCESSING_AGREEMENT", "SOVEREIGN_TRUST_FRAMEWORK", "SECURITY_PROTOCOL_COMMITMENT", "DATA_ISOLATION_POLICY"];
    for (const key of keys) {
      const res = await request(app).post(`/api/government/draft/${draftId}/frameworks/${key}/accept`).set("Authorization", `Bearer ${applicantToken}`);
      expect(res.status).toBe(201);
    }
  });

  it("Step 6 — submits for final review", async () => {
    const res = await request(app).post(`/api/government/draft/${draftId}/submit`).set("Authorization", `Bearer ${applicantToken}`);
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("PENDING");
  });

  it("appears in the admin queue", async () => {
    const res = await request(app).get("/api/kyb?status=PENDING").set("Authorization", `Bearer ${adminToken}`);
    expect(res.body.some((s: { id: string }) => s.id === draftId)).toBe(true);
  });

  it("approves with full manual verification and computes the 40/30/20/10 formula (=100)", async () => {
    const res = await request(app)
      .patch(`/api/kyb/${draftId}/review`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ status: "APPROVED", diplomaticVerificationCompleted: true, fscValidated: true, pscAllValidated: true });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("APPROVED");
    expect(res.body.trustScore).toBe(100); // 40 + 30 + 20 + 10 (5/5 frameworks already accepted)

    const applicant = await prisma.user.findUnique({ where: { id: applicantUserId } });
    expect(applicant?.accountStatus).toBe("ACTIVE");

    const notifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${applicantToken}`);
    expect(notifs.body.notifications.some((n: { type: string }) => n.type === "KYB_APPROVED")).toBe(true);
  });
});
