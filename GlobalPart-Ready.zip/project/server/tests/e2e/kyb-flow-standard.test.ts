import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createApp } from "../../src/app.js";
import { prisma } from "../../src/lib/prisma.js";
import bcrypt from "bcryptjs";

const app = createApp();

/**
 * Standard (INDIVIDUAL) pathway, full flow: register → verify email →
 * submit KYB with a document → admin sees it in the queue → admin
 * approves → Trust Score matches the documented formula (50 base + 10 per
 * completed step + 5 per document, capped at 100) → applicant is
 * notified.
 *
 * As with kyb-flow.test.ts, this cannot run in the current sandboxed
 * environment (no live Postgres connection here). Run it yourself with:
 *   npm run test:e2e
 * IMPORTANT: point DATABASE_URL at a dedicated test database before
 * running -- this test creates and deletes real rows, and while it cleans
 * up everything it created in afterAll, running any integration test
 * against a production database is a bad habit worth avoiding entirely.
 */
describe("Standard KYB pathway: register → verify → submit → approve", () => {
  const timestamp = Date.now();
  const applicantEmail = `standard-${timestamp}@example.com`;
  const adminEmail = `e2e-admin-standard-${timestamp}@example.com`;
  const password = "SuperSecret123!";

  let applicantToken: string;
  let applicantUserId: string;
  let adminToken: string;
  let kybSubmissionId: string;

  beforeAll(async () => {
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({
      data: { name: "E2E Admin", email: adminEmail, passwordHash, role: "ADMIN", emailVerified: true },
    });
    const adminLogin = await request(app).post("/api/auth/login").send({ email: adminEmail, password });
    adminToken = adminLogin.body.accessToken;

    const register = await request(app)
      .post("/api/auth/register")
      .send({ name: "E2E Individual", email: applicantEmail, password, accountCategory: "INDIVIDUAL" });
    expect(register.status).toBe(201);
    expect(register.body.sessionIssued).toBe(true); // Standard: frictionless, immediate session
    expect(register.body.user.accountStatus).toBe("ACTIVE"); // no PENDING_KYB gate for individuals
    applicantToken = register.body.accessToken;
    applicantUserId = register.body.user.id;

    // Bypasses the real email-link click, same shortcut used to isolate
    // KYB-flow testing in kyb-flow.test.ts (there via TrustBadgeSubscription).
    // Task 9 requires email verification before a Standard account can
    // submit a full application, so this step is load-bearing for the test.
    await prisma.user.update({ where: { id: applicantUserId }, data: { emailVerified: true } });
  });

  afterAll(async () => {
    await prisma.notification.deleteMany({ where: { userId: applicantUserId } });
    await prisma.adminAuditEvent.deleteMany({ where: { entityId: kybSubmissionId } });
    await prisma.trustBadgeSubscription.deleteMany({ where: { userId: applicantUserId } });
    await prisma.kybSubmission.deleteMany({ where: { userId: applicantUserId } });
    await prisma.user.deleteMany({ where: { email: { in: [applicantEmail, adminEmail] } } });
    await prisma.$disconnect();
  });

  it("blocks KYB submission before email verification", async () => {
    // Register a second, unverified individual just to prove the gate
    // exists, independent of the main flow above.
    const unverified = await request(app)
      .post("/api/auth/register")
      .send({ name: "Unverified", email: `unverified-${timestamp}@example.com`, password, accountCategory: "INDIVIDUAL" });
    const res = await request(app)
      .post("/api/kyb")
      .set("Authorization", `Bearer ${unverified.body.accessToken}`)
      .field("companyName", "Should Fail Co")
      .field("registrationNo", "REG-0001")
      .field("email", "contact@shouldfail.example.com")
      .field("phone", "+1 555 0000000")
      .field("countries", "United States")
      .field("address", "1 Test Street");
    expect(res.status).toBe(403);
    await prisma.user.delete({ where: { email: `unverified-${timestamp}@example.com` } });
  });

  it("submits KYB with a document once verified", async () => {
    const res = await request(app)
      .post("/api/kyb")
      .set("Authorization", `Bearer ${applicantToken}`)
      .field("companyName", "E2E Standard Trading Co")
      .field("registrationNo", "REG-STD-0001")
      .field("email", applicantEmail)
      .field("phone", "+1 555 0100000")
      .field("countries", "United States")
      .field("address", "1 Test Street, New York")
      .attach("documents", Buffer.from("test file contents"), "export-license.pdf");
    expect(res.status).toBe(201);
    expect(res.body.status).toBe("PENDING");
    kybSubmissionId = res.body.id;
  });

  it("appears in the admin queue", async () => {
    const res = await request(app).get("/api/kyb?status=PENDING").set("Authorization", `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.some((s: { id: string }) => s.id === kybSubmissionId)).toBe(true);
  });

  it("approves and computes the documented Standard trust score (50 + 4×10 + 1×5 = 95)", async () => {
    // Non-Government approvals require an active Trust Badge subscription
    // (see kyb.routes.ts) -- activated directly here to isolate testing
    // the approval/scoring logic from the separate billing flow, same
    // shortcut used in kyb-flow.test.ts.
    await prisma.trustBadgeSubscription.upsert({
      where: { userId: applicantUserId },
      create: { userId: applicantUserId, status: "active" },
      update: { status: "active" },
    });

    const res = await request(app)
      .patch(`/api/kyb/${kybSubmissionId}/review`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ status: "APPROVED", bankAccountVerified: false, physicalAddressConfirmed: true });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("APPROVED");
    // registrationNo + email + phone + address = 4 completed steps (bank
    // left unverified on purpose to keep this a clean, exact number) =
    // 50 + 40 = 90, plus 1 uploaded document × 5 = 95.
    expect(res.body.trustScore).toBe(95);

    const notifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${applicantToken}`);
    expect(notifs.body.notifications.some((n: { type: string }) => n.type === "KYB_APPROVED")).toBe(true);
  });
});
