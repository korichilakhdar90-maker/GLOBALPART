import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createApp } from "../../src/app.js";
import { prisma } from "../../src/lib/prisma.js";

const app = createApp();

describe("Health check", () => {
  it("GET /api/health returns ok", async () => {
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });
});

describe("Auth flow", () => {
  const testEmail = `e2e-${Date.now()}@example.com`;
  const password = "SuperSecret123!";

  afterAll(async () => {
    await prisma.user.deleteMany({ where: { email: testEmail } });
    await prisma.$disconnect();
  });

  it("registers a new user and returns an access token", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "E2E Test", email: testEmail, password });

    expect(res.status).toBe(201);
    expect(res.body.accessToken).toBeTruthy();
    expect(res.body.user.email).toBe(testEmail);
    expect(res.body.user.emailVerified).toBe(false);
  });

  it("rejects registering the same email twice", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "E2E Test 2", email: testEmail, password });
    expect(res.status).toBe(409);
  });

  it("rejects login with the wrong password", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: testEmail, password: "wrong-password" });
    expect(res.status).toBe(401);
  });

  it("logs in with correct credentials and can access a protected route", async () => {
    const loginRes = await request(app).post("/api/auth/login").send({ email: testEmail, password });
    expect(loginRes.status).toBe(200);
    const token = loginRes.body.accessToken;

    const meRes = await request(app).get("/api/auth/me").set("Authorization", `Bearer ${token}`);
    expect(meRes.status).toBe(200);
    expect(meRes.body.email).toBe(testEmail);
  });

  it("rejects protected routes with no token", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });

  it("rejects protected routes with a malformed token", async () => {
    const res = await request(app).get("/api/auth/me").set("Authorization", "Bearer not-a-real-token");
    expect(res.status).toBe(401);
  });
});

describe("Companies API", () => {
  beforeAll(async () => {
    // Ensure at least one company exists to paginate over, without
    // depending on the full seed script having been run.
    await prisma.company.upsert({
      where: { id: "e2e-test-company" },
      create: {
        id: "e2e-test-company",
        name: "E2E Test Co",
        industry: "Technology",
        countryCode: "US",
        countryName: "United States",
        region: "North America",
        description: "A company created for automated testing.",
        trustScore: 85,
        verified: true,
      },
      update: {},
    });
  });

  it("lists companies with pagination metadata", async () => {
    const res = await request(app).get("/api/companies?page=1&perPage=5");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.items)).toBe(true);
    expect(res.body).toHaveProperty("total");
    expect(res.body).toHaveProperty("totalPages");
  });

  it("returns a single company by id", async () => {
    const res = await request(app).get("/api/companies/e2e-test-company");
    expect(res.status).toBe(200);
    expect(res.body.name).toBe("E2E Test Co");
  });

  it("returns 404 for a nonexistent company id", async () => {
    const res = await request(app).get("/api/companies/does-not-exist");
    expect(res.status).toBe(404);
  });

  it("filters by search term", async () => {
    const res = await request(app).get("/api/companies?search=E2E Test Co");
    expect(res.status).toBe(200);
    expect(res.body.items.some((c: { id: string }) => c.id === "e2e-test-company")).toBe(true);
  });
});

describe("Favorites API requires auth", () => {
  it("rejects unauthenticated favorite requests", async () => {
    const res = await request(app).get("/api/favorites");
    expect(res.status).toBe(401);
  });
});

describe("Admin API requires admin role", () => {
  const email = `e2e-user-${Date.now()}@example.com`;
  const password = "SuperSecret123!";
  let token: string;

  beforeAll(async () => {
    await request(app).post("/api/auth/register").send({ name: "Regular User", email, password });
    const loginRes = await request(app).post("/api/auth/login").send({ email, password });
    token = loginRes.body.accessToken;
  });

  afterAll(async () => {
    await prisma.user.deleteMany({ where: { email } });
  });

  it("rejects a non-admin user from admin stats", async () => {
    const res = await request(app).get("/api/admin/stats").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
  });
});
