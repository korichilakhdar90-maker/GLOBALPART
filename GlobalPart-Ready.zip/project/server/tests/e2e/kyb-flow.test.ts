import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createApp } from "../../src/app.js";
import { prisma } from "../../src/lib/prisma.js";
import bcrypt from "bcryptjs";

const app = createApp();

/**
 * Exercises the full Corporate pathway end-to-end against real routes and
 * a real database: register (Enterprise tier) → submit KYB → admin gets
 * notified → admin assigns ("Review") → admin approves with the
 * Corporate-tier checklist → trust score matches the documented formula
 * (30 + 20 + 15 + 25 = 90) → applicant's account flips PENDING_KYB →
 * ACTIVE → applicant receives an approval notification → every step wrote
 * an AdminAuditEvent row. Also covers the rejection-reason requirement.
 *
 * This file cannot be executed in the current sandboxed environment (no
 * live Postgres connection / generated Prisma client here — see
 * server/README.md and every prior session's notes on this). It's written
 * to run correctly against a real `npm run test:e2e` once the project is
 * running on an actual database.
 */
describe("Corporate KYB pathway: submit → notify → assign → approve", () => {
  const timestamp = Date.now();
  const applicantEmail = `finance@e2e-corp-${timestamp}.example.com`;
  const adminEmail = `e2e-admin-${timestamp}@example.com`;
  const password = "SuperSecret123!";

  let applicantToken: string;
  let applicantUserId: string;
  let adminToken: string;
  let kybSubmissionId: string;

  beforeAll(async () => {
    // Admin user created directly via Prisma (mirrors prisma/seed.ts) --
    // there's deliberately no API endpoint that lets anyone self-promote
    // to ADMIN.
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({
      data: { name: "E2E Admin", email: adminEmail, passwordHash, role: "ADMIN", emailVerified: true },
    });
    const adminLogin = await request(app).post("/api/auth/login").send({ email: adminEmail, password });
    adminToken = adminLogin.body.accessToken;

    const register = await request(app)
      .post("/api/auth/register")
      .send({ name: "E2E Finance Officer", email: applicantEmail, password, company: "E2E Corp", accountCategory: "ENTERPRISE" });
    expect(register.status).toBe(201);
    expect(register.body.sessionIssued).toBe(true);
    expect(register.body.user.accountCategory).toBe("ENTERPRISE");
    expect(register.body.user.accountStatus).toBe("PENDING_KYB");
    applicantToken = register.body.accessToken;
    applicantUserId = register.body.user.id;

    // Task 9 added requireVerifiedEmail to POST /api/kyb (Corporate/
    // Standard can't submit a full application unverified) -- bypassed
    // here the same way TrustBadgeSubscription is bypassed below, to keep
    // this test focused on the KYB workflow itself rather than the
    // separate email-verification flow.
    await prisma.user.update({ where: { id: applicantUserId }, data: { emailVerified: true } });
  });

  afterAll(async () => {
    await prisma.notification.deleteMany({ where: { userId: { in: [applicantUserId] } } });
    await prisma.adminAuditEvent.deleteMany({ where: { entityId: kybSubmissionId } });
    await prisma.kybSubmission.deleteMany({ where: { userId: applicantUserId } });
    await prisma.user.deleteMany({ where: { email: { in: [applicantEmail, adminEmail] } } });
    await prisma.$disconnect();
  });

  it("rejects Enterprise registration with a free email provider", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Should Fail", email: `nope-${timestamp}@gmail.com`, password, accountCategory: "ENTERPRISE" });
    expect(res.status).toBe(400);
  });

  it("submits a Corporate KYB application and notifies all admins", async () => {
    const res = await request(app)
      .post("/api/kyb")
      .set("Authorization", `Bearer ${applicantToken}`)
      .field("companyName", "E2E Corp")
      .field("registrationNo", "HRB-E2E-0001")
      .field("email", applicantEmail)
      .field("phone", "+49 30 0000000")
      .field("countries", "Germany")
      .field("address", "Teststraße 1, Berlin");
    expect(res.status).toBe(201);
    expect(res.body.status).toBe("PENDING");
    kybSubmissionId = res.body.id;

    const adminNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${adminToken}`);
    expect(adminNotifs.status).toBe(200);
    expect(adminNotifs.body.notifications.some((n: { type: string; kybSubmissionId: string }) => n.type === "KYB_SUBMITTED" && n.kybSubmissionId === kybSubmissionId)).toBe(true);
  });

  it("lets an admin assign ('Review') the submission and notifies the applicant", async () => {
    const res = await request(app).post(`/api/kyb/${kybSubmissionId}/assign`).set("Authorization", `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("IN_REVIEW");
    expect(res.body.assignedToId).toBeTruthy();

    const applicantNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${applicantToken}`);
    expect(applicantNotifs.body.notifications.some((n: { type: string }) => n.type === "KYB_ASSIGNED")).toBe(true);

    const auditRes = await request(app)
      .get("/api/admin/audit-log?action=kyb.assigned")
      .set("Authorization", `Bearer ${adminToken}`);
    expect(auditRes.body.some((e: { entityId: string }) => e.entityId === kybSubmissionId)).toBe(true);
  });

  it("requires a rejection reason before rejecting", async () => {
    const res = await request(app)
      .patch(`/api/kyb/${kybSubmissionId}/review`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ status: "REJECTED" });
    expect(res.status).toBe(400);
  });

  it("approves with the Corporate checklist and computes the documented trust score (30+20+15+25=90)", async () => {
    // A Trust Badge subscription is required for a non-government approval
    // (see kyb.routes.ts) -- activate one directly so this test exercises
    // the approval logic itself, not the billing flow.
    await prisma.trustBadgeSubscription.upsert({
      where: { userId: applicantUserId },
      create: { userId: applicantUserId, status: "active" },
      update: { status: "active" },
    });

    const res = await request(app)
      .patch(`/api/kyb/${kybSubmissionId}/review`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({
        status: "APPROVED",
        financialAuditCompleted: true,
        certificationsVerified: true,
        pepScreeningStatus: "CLEAR",
      });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("APPROVED");
    expect(res.body.trustScore).toBe(90);
    expect(res.body.assignedToId).toBeNull();

    const applicant = await prisma.user.findUnique({ where: { id: applicantUserId } });
    expect(applicant?.accountStatus).toBe("ACTIVE");

    const applicantNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${applicantToken}`);
    expect(applicantNotifs.body.notifications.some((n: { type: string }) => n.type === "KYB_APPROVED")).toBe(true);

    const auditRes = await request(app).get("/api/admin/audit-log?action=kyb.approved").set("Authorization", `Bearer ${adminToken}`);
    expect(auditRes.body.some((e: { entityId: string }) => e.entityId === kybSubmissionId)).toBe(true);
  });
});
