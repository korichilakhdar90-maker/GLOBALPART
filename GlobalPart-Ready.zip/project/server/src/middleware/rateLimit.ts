import rateLimit from "express-rate-limit";
import { RedisStore } from "rate-limit-redis";
// Named import rather than default: ioredis re-exports the class under
// both, but only the named export is usable as a *type* under
// NodeNext module resolution (`let x: Redis` fails with the default).
import { Redis } from "ioredis";
import { env } from "../config/env.js";

/**
 * A single shared Redis connection (when REDIS_URL is set) backing every
 * rate limiter in this app. Without this, express-rate-limit's default
 * in-memory store keeps counters per-process -- correct for exactly one
 * instance, silently wrong the moment you run more than one replica
 * behind a load balancer (each replica has its own counter, so the
 * effective limit becomes limit × replica count, not the number you
 * configured). Falling back to in-memory when REDIS_URL is unset keeps
 * local dev and single-instance deployments working with zero setup.
 */
let redisClient: Redis | null = null;
function getRedisStore() {
  if (!env.REDIS_URL) return undefined;
  if (!redisClient) {
    redisClient = new Redis(env.REDIS_URL, { maxRetriesPerRequest: 2, lazyConnect: false });
    redisClient.on("error", (err: Error) => {
      console.error("Redis connection error (rate limiting will fall back to allowing requests through on Redis failure):", err.message);
    });
  }
  return new RedisStore({
    // rate-limit-redis expects Promise<RedisReply>; ioredis's generic
    // `.call()` is typed as (command, ...args) rather than a single
    // string[] rest, so the first element is split out explicitly here --
    // spreading the whole array fails typecheck under strict mode.
    sendCommand: (command: string, ...args: string[]) =>
      redisClient!.call(command, ...args) as Promise<string | number | boolean | (string | number | boolean)[]>,
    prefix: "gp-rl:",
  });
}

if (env.REDIS_URL) {
  console.log("Rate limiting: using Redis-backed store (safe for multi-instance deployments).");
} else {
  console.warn(
    "⚠️  Rate limiting: no REDIS_URL set — using in-memory counters. This is fine for local dev or a single instance, " +
      "but if you deploy more than one replica behind a load balancer, effective rate limits are multiplied by the replica " +
      "count. Set REDIS_URL before scaling horizontally."
  );
}

/**
 * Generous global baseline applied to all of /api in app.ts. Tighten
 * per-route if production logs show abuse.
 */
export const apiRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
  store: getRedisStore(),
});

/**
 * Tight limiter for login/register/password-reset — these are the routes an
 * attacker would actually brute-force, so they get a much stricter budget
 * than the general API rate limit above.
 */
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again in a few minutes." },
  // Key by email+IP when available so one user's repeated attempts don't
  // lock out everyone behind the same NAT/IP.
  keyGenerator: (req) => `${req.ip}:${(req.body?.email as string | undefined) ?? ""}`,
  store: getRedisStore(),
});
