import type { Request, Response, NextFunction } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "./errorHandler.js";

/**
 * Error codes the frontend switches on to decide which modal to show.
 * Keep these stable -- src/context.tsx and src/lib/api.ts match against
 * these exact strings.
 */
export const AccountPolicyErrorCode = {
  EMAIL_VERIFICATION_REQUIRED: "EMAIL_VERIFICATION_REQUIRED",
  TWO_FACTOR_SETUP_REQUIRED: "TWO_FACTOR_SETUP_REQUIRED",
  ACCOUNT_PENDING_APPROVAL: "ACCOUNT_PENDING_APPROVAL",
} as const;

/**
 * CRITICAL GATE for INDIVIDUAL / freelancer accounts (and a baseline check
 * for everyone else too). Individuals get frictionless signup and full
 * dashboard browsing with emailVerified=false -- this middleware is what
 * intercepts them ONLY at the moment they attempt a sensitive action
 * (create a contract, send a quote, start a financial transaction). It
 * does not block login, browsing, or the dashboard itself.
 *
 * Apply this to specific routes, not globally -- e.g.
 * dealsRouter.post("/", requireAuth, requireVerifiedEmail, ...).
 */
export const requireVerifiedEmail = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { emailVerified: true, email: true } });
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  if (!user.emailVerified) {
    res.status(403).json({
      error: "Please verify your email before continuing.",
      code: AccountPolicyErrorCode.EMAIL_VERIFICATION_REQUIRED,
    });
    return;
  }
  next();
});

/**
 * MFA-gated dashboard access for the two restricted tiers: email verified
 * AND 2FA enabled, both mandatory before "full access to the [Enterprise/
 * Sovereign] dashboard" per the product requirement. GOVERNMENT is
 * included here deliberately -- "MFA is mandatory for all government
 * users to ensure the highest level of security" is a hard requirement,
 * not a recommendation, so a government account can never reach the full
 * dashboard with 2FA still disabled, exactly like an enterprise account
 * can't. Apply to enterprise/sovereign-dashboard routes (not to
 * registration, login, or the 2FA setup routes themselves -- those have
 * to be reachable precisely because this gate isn't satisfied yet).
 */
export const requireSovereignOrEnterpriseAccess = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: { emailVerified: true, twoFactorEnabled: true, accountCategory: true },
  });
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  if (!user.emailVerified) {
    res.status(403).json({ error: "Please verify your email before continuing.", code: AccountPolicyErrorCode.EMAIL_VERIFICATION_REQUIRED });
    return;
  }
  if ((user.accountCategory === "ENTERPRISE" || user.accountCategory === "GOVERNMENT") && !user.twoFactorEnabled) {
    res.status(403).json({
      error:
        user.accountCategory === "GOVERNMENT"
          ? "MFA is mandatory for all government users to ensure the highest level of security."
          : "Two-factor authentication is required for enterprise accounts before you can access the full dashboard.",
      code: AccountPolicyErrorCode.TWO_FACTOR_SETUP_REQUIRED,
    });
    return;
  }
  next();
});

/**
 * Blocks publish/contract-type actions for accounts still in a pending
 * lifecycle state (ENTERPRISE awaiting KYB, GOVERNMENT awaiting Super
 * Admin sign-off). Distinct from requireVerifiedEmail/requireEnterpriseAccess
 * because a PENDING_KYB or PENDING_SOVEREIGN_APPROVAL account may already
 * be fully email-verified (and 2FA-enabled) -- they're just not cleared to
 * transact yet. Apply this alongside the other gates on the same route
 * when the action is specifically "publish a listing" or "create/sign a
 * contract", not on read-only dashboard routes.
 */
export const requireActiveAccount = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { accountStatus: true, accountCategory: true } });
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  if (user.accountStatus !== "ACTIVE") {
    const reason =
      user.accountStatus === "PENDING_KYB"
        ? "Your enterprise account is pending KYB verification. Publishing and contracting are unlocked once your business documents are approved."
        : user.accountStatus === "PENDING_SOVEREIGN_APPROVAL"
          ? "Your government account is pending Super Admin approval. Publishing and contracting are unlocked once approved."
          : "Your account is currently suspended.";
    res.status(403).json({ error: reason, code: AccountPolicyErrorCode.ACCOUNT_PENDING_APPROVAL, accountStatus: user.accountStatus });
    return;
  }
  next();
});

/**
 * Government-only, router-wide gate: "completely blocked from any access
 * until email verification AND MFA are both completed." Safe to mount
 * broadly (kybRouter, governmentRouter, dealsRouter, notificationsRouter)
 * because it's a no-op for every other tier -- it only ever blocks when
 * accountCategory is GOVERNMENT, so Standard/Enterprise traffic through
 * the same routers is completely unaffected.
 *
 * This is intentionally stricter than requireSovereignOrEnterpriseAccess
 * above: that gate guards a specific "full dashboard" boundary shared with
 * Enterprise, while this one blocks a Government account from essentially
 * everything post-login until both conditions are met, per the explicit
 * "government users get the strictest tier" product decision.
 */
export const blockUnverifiedGovernment = asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: { accountCategory: true, emailVerified: true, twoFactorEnabled: true },
  });
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  if (user.accountCategory !== "GOVERNMENT") {
    next();
    return;
  }
  if (!user.emailVerified) {
    res.status(403).json({
      error: "Government accounts are blocked from all platform access until email verification is complete.",
      code: AccountPolicyErrorCode.EMAIL_VERIFICATION_REQUIRED,
    });
    return;
  }
  if (!user.twoFactorEnabled) {
    res.status(403).json({
      error: "MFA is mandatory for all government users to ensure the highest level of security.",
      code: AccountPolicyErrorCode.TWO_FACTOR_SETUP_REQUIRED,
    });
    return;
  }
  next();
});
