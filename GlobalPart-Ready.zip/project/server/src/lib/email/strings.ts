/**
 * Server-side email copy, translated for the 9 active platform languages
 * (see src/i18n.ts on the frontend for the active/reserve split -- these
 * are the same nine that appear in the language switcher).
 *
 * Deliberately kept separate from the frontend's i18n-data/*.ts: those
 * dictionaries are ~780 keys each and get code-split into the browser
 * bundle, which the server has no reason to load. Email copy is a small,
 * self-contained set that only ever runs server-side.
 *
 * Falls back to English for any language not listed (including the
 * "reserve" languages), so an unexpected locale never produces an empty
 * email -- see t() at the bottom.
 */

export type EmailLang = "en" | "fr" | "de" | "nl" | "es" | "it" | "pl" | "pt" | "tr";

export interface EmailStrings {
  // shared chrome
  footerTagline: string;
  footerAutomated: string;
  footerRights: string;
  // verification
  verifySubject: string;
  verifyHeading: string;
  verifyBody: string;
  verifyCta: string;
  verifyExpiry: string;
  // password reset
  resetSubject: string;
  resetHeading: string;
  resetBody: string;
  resetCta: string;
  resetExpiry: string;
  resetIgnore: string;
  // OTP
  otpSubject: string;
  otpHeading: string;
  otpBody: string;
  otpExpiry: string;
  // KYB status change (generic)
  statusSubject: string;
  statusHeading: string;
  // approval
  approvedSubject: string;
  approvedHeading: string;
  approvedBody: string;
  approvedCta: string;
  // rejection
  rejectedSubject: string;
  rejectedHeading: string;
  rejectedBody: string;
  rejectedReasonLabel: string;
  rejectedCta: string;
  // admin alert
  adminAlertSubject: string;
  adminAlertHeading: string;
  adminAlertBody: string;
  adminAlertCta: string;
  // partner invitation
  inviteSubject: string;
  inviteHeading: string;
  inviteBody: string;
  inviteCta: string;
  inviteExpiry: string;
}

const en: EmailStrings = {
  footerTagline: "Sovereign trust infrastructure for cross-border trade.",
  footerAutomated: "This is an automated message — please don't reply directly to it.",
  footerRights: "All rights reserved.",
  verifySubject: "Verify your GlobalPart email",
  verifyHeading: "Confirm your email address",
  verifyBody: "Welcome to GlobalPart. Please confirm your email address to activate your account.",
  verifyCta: "Verify email address",
  verifyExpiry: "This link expires in 24 hours.",
  resetSubject: "Reset your GlobalPart password",
  resetHeading: "Reset your password",
  resetBody: "We received a request to reset the password for your GlobalPart account.",
  resetCta: "Set a new password",
  resetExpiry: "This link expires in 1 hour.",
  resetIgnore: "If you didn't request this, you can safely ignore this email — your password won't change.",
  otpSubject: "Your GlobalPart verification code",
  otpHeading: "Your verification code",
  otpBody: "Enter this code to continue with the action you started:",
  otpExpiry: "This code expires in 10 minutes.",
  statusSubject: "Update on your GlobalPart application",
  statusHeading: "Your application status has changed",
  approvedSubject: "Your GlobalPart application has been approved",
  approvedHeading: "You're verified",
  approvedBody: "Congratulations — {company} has completed verification and is now a Verified Partner on GlobalPart.",
  approvedCta: "View your dashboard",
  rejectedSubject: "Update on your GlobalPart application",
  rejectedHeading: "Your application wasn't approved",
  rejectedBody: "We reviewed the application for {company} and weren't able to approve it at this time.",
  rejectedReasonLabel: "Reason given by our review team:",
  rejectedCta: "Review your application",
  adminAlertSubject: "New application awaiting review",
  adminAlertHeading: "New application submitted",
  adminAlertBody: "{company} has submitted a new application that's waiting in the review queue.",
  adminAlertCta: "Open the admin console",
  inviteSubject: "{inviter} invited you to join GlobalPart",
  inviteHeading: "You've been invited",
  inviteBody: "{inviter} uses GlobalPart to verify and work with trusted trade partners, and has invited {company} to join them.",
  inviteCta: "Accept the invitation",
  inviteExpiry: "This invitation link expires in 30 days.",
};

const fr: EmailStrings = {
  footerTagline: "Infrastructure de confiance souveraine pour le commerce transfrontalier.",
  footerAutomated: "Ceci est un message automatique — merci de ne pas y répondre directement.",
  footerRights: "Tous droits réservés.",
  verifySubject: "Vérifiez votre adresse e-mail GlobalPart",
  verifyHeading: "Confirmez votre adresse e-mail",
  verifyBody: "Bienvenue sur GlobalPart. Veuillez confirmer votre adresse e-mail pour activer votre compte.",
  verifyCta: "Vérifier l'adresse e-mail",
  verifyExpiry: "Ce lien expire dans 24 heures.",
  resetSubject: "Réinitialisez votre mot de passe GlobalPart",
  resetHeading: "Réinitialisez votre mot de passe",
  resetBody: "Nous avons reçu une demande de réinitialisation du mot de passe de votre compte GlobalPart.",
  resetCta: "Définir un nouveau mot de passe",
  resetExpiry: "Ce lien expire dans 1 heure.",
  resetIgnore: "Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail — votre mot de passe restera inchangé.",
  otpSubject: "Votre code de vérification GlobalPart",
  otpHeading: "Votre code de vérification",
  otpBody: "Saisissez ce code pour poursuivre l'action que vous avez commencée :",
  otpExpiry: "Ce code expire dans 10 minutes.",
  statusSubject: "Mise à jour de votre demande GlobalPart",
  statusHeading: "Le statut de votre demande a changé",
  approvedSubject: "Votre demande GlobalPart a été approuvée",
  approvedHeading: "Vous êtes vérifié",
  approvedBody: "Félicitations — {company} a terminé sa vérification et est désormais Partenaire Vérifié sur GlobalPart.",
  approvedCta: "Voir votre tableau de bord",
  rejectedSubject: "Mise à jour de votre demande GlobalPart",
  rejectedHeading: "Votre demande n'a pas été approuvée",
  rejectedBody: "Nous avons examiné la demande de {company} et n'avons pas pu l'approuver pour le moment.",
  rejectedReasonLabel: "Motif indiqué par notre équipe d'examen :",
  rejectedCta: "Consulter votre demande",
  adminAlertSubject: "Nouvelle demande en attente d'examen",
  adminAlertHeading: "Nouvelle demande soumise",
  adminAlertBody: "{company} a soumis une nouvelle demande en attente dans la file d'examen.",
  adminAlertCta: "Ouvrir la console d'administration",
  inviteSubject: "{inviter} vous invite à rejoindre GlobalPart",
  inviteHeading: "Vous avez été invité",
  inviteBody: "{inviter} utilise GlobalPart pour vérifier et travailler avec des partenaires commerciaux de confiance, et a invité {company} à les rejoindre.",
  inviteCta: "Accepter l'invitation",
  inviteExpiry: "Ce lien d'invitation expire dans 30 jours.",
};

const de: EmailStrings = {
  footerTagline: "Souveräne Vertrauensinfrastruktur für den grenzüberschreitenden Handel.",
  footerAutomated: "Dies ist eine automatische Nachricht — bitte antworten Sie nicht direkt darauf.",
  footerRights: "Alle Rechte vorbehalten.",
  verifySubject: "Bestätigen Sie Ihre GlobalPart-E-Mail-Adresse",
  verifyHeading: "Bestätigen Sie Ihre E-Mail-Adresse",
  verifyBody: "Willkommen bei GlobalPart. Bitte bestätigen Sie Ihre E-Mail-Adresse, um Ihr Konto zu aktivieren.",
  verifyCta: "E-Mail-Adresse bestätigen",
  verifyExpiry: "Dieser Link läuft in 24 Stunden ab.",
  resetSubject: "Setzen Sie Ihr GlobalPart-Passwort zurück",
  resetHeading: "Passwort zurücksetzen",
  resetBody: "Wir haben eine Anfrage zum Zurücksetzen des Passworts für Ihr GlobalPart-Konto erhalten.",
  resetCta: "Neues Passwort festlegen",
  resetExpiry: "Dieser Link läuft in 1 Stunde ab.",
  resetIgnore: "Falls Sie dies nicht angefordert haben, können Sie diese E-Mail ignorieren — Ihr Passwort bleibt unverändert.",
  otpSubject: "Ihr GlobalPart-Bestätigungscode",
  otpHeading: "Ihr Bestätigungscode",
  otpBody: "Geben Sie diesen Code ein, um die begonnene Aktion fortzusetzen:",
  otpExpiry: "Dieser Code läuft in 10 Minuten ab.",
  statusSubject: "Update zu Ihrem GlobalPart-Antrag",
  statusHeading: "Der Status Ihres Antrags hat sich geändert",
  approvedSubject: "Ihr GlobalPart-Antrag wurde genehmigt",
  approvedHeading: "Sie sind verifiziert",
  approvedBody: "Herzlichen Glückwunsch — {company} hat die Verifizierung abgeschlossen und ist jetzt Verifizierter Partner bei GlobalPart.",
  approvedCta: "Zum Dashboard",
  rejectedSubject: "Update zu Ihrem GlobalPart-Antrag",
  rejectedHeading: "Ihr Antrag wurde nicht genehmigt",
  rejectedBody: "Wir haben den Antrag für {company} geprüft und konnten ihn derzeit nicht genehmigen.",
  rejectedReasonLabel: "Begründung unseres Prüfungsteams:",
  rejectedCta: "Antrag ansehen",
  adminAlertSubject: "Neuer Antrag wartet auf Prüfung",
  adminAlertHeading: "Neuer Antrag eingereicht",
  adminAlertBody: "{company} hat einen neuen Antrag eingereicht, der in der Prüfungswarteschlange wartet.",
  adminAlertCta: "Admin-Konsole öffnen",
  inviteSubject: "{inviter} hat Sie zu GlobalPart eingeladen",
  inviteHeading: "Sie wurden eingeladen",
  inviteBody: "{inviter} nutzt GlobalPart, um vertrauenswürdige Handelspartner zu verifizieren und mit ihnen zu arbeiten, und hat {company} eingeladen.",
  inviteCta: "Einladung annehmen",
  inviteExpiry: "Dieser Einladungslink läuft in 30 Tagen ab.",
};

const nl: EmailStrings = {
  footerTagline: "Soevereine vertrouwensinfrastructuur voor grensoverschrijdende handel.",
  footerAutomated: "Dit is een automatisch bericht — beantwoord het niet rechtstreeks.",
  footerRights: "Alle rechten voorbehouden.",
  verifySubject: "Bevestig je GlobalPart e-mailadres",
  verifyHeading: "Bevestig je e-mailadres",
  verifyBody: "Welkom bij GlobalPart. Bevestig je e-mailadres om je account te activeren.",
  verifyCta: "E-mailadres bevestigen",
  verifyExpiry: "Deze link verloopt over 24 uur.",
  resetSubject: "Stel je GlobalPart-wachtwoord opnieuw in",
  resetHeading: "Wachtwoord opnieuw instellen",
  resetBody: "We hebben een verzoek ontvangen om het wachtwoord van je GlobalPart-account opnieuw in te stellen.",
  resetCta: "Nieuw wachtwoord instellen",
  resetExpiry: "Deze link verloopt over 1 uur.",
  resetIgnore: "Als je dit niet hebt aangevraagd, kun je deze e-mail negeren — je wachtwoord verandert niet.",
  otpSubject: "Je GlobalPart-verificatiecode",
  otpHeading: "Je verificatiecode",
  otpBody: "Voer deze code in om verder te gaan met de actie die je bent gestart:",
  otpExpiry: "Deze code verloopt over 10 minuten.",
  statusSubject: "Update over je GlobalPart-aanvraag",
  statusHeading: "De status van je aanvraag is gewijzigd",
  approvedSubject: "Je GlobalPart-aanvraag is goedgekeurd",
  approvedHeading: "Je bent geverifieerd",
  approvedBody: "Gefeliciteerd — {company} heeft de verificatie afgerond en is nu Geverifieerde Partner op GlobalPart.",
  approvedCta: "Bekijk je dashboard",
  rejectedSubject: "Update over je GlobalPart-aanvraag",
  rejectedHeading: "Je aanvraag is niet goedgekeurd",
  rejectedBody: "We hebben de aanvraag voor {company} beoordeeld en konden deze op dit moment niet goedkeuren.",
  rejectedReasonLabel: "Reden van ons beoordelingsteam:",
  rejectedCta: "Bekijk je aanvraag",
  adminAlertSubject: "Nieuwe aanvraag wacht op beoordeling",
  adminAlertHeading: "Nieuwe aanvraag ingediend",
  adminAlertBody: "{company} heeft een nieuwe aanvraag ingediend die in de beoordelingswachtrij staat.",
  adminAlertCta: "Open de beheerconsole",
  inviteSubject: "{inviter} heeft je uitgenodigd voor GlobalPart",
  inviteHeading: "Je bent uitgenodigd",
  inviteBody: "{inviter} gebruikt GlobalPart om betrouwbare handelspartners te verifiëren en ermee samen te werken, en heeft {company} uitgenodigd.",
  inviteCta: "Uitnodiging accepteren",
  inviteExpiry: "Deze uitnodigingslink verloopt over 30 dagen.",
};

const es: EmailStrings = {
  footerTagline: "Infraestructura de confianza soberana para el comercio transfronterizo.",
  footerAutomated: "Este es un mensaje automático — por favor, no respondas directamente.",
  footerRights: "Todos los derechos reservados.",
  verifySubject: "Verifica tu correo electrónico de GlobalPart",
  verifyHeading: "Confirma tu dirección de correo",
  verifyBody: "Bienvenido a GlobalPart. Confirma tu dirección de correo electrónico para activar tu cuenta.",
  verifyCta: "Verificar correo electrónico",
  verifyExpiry: "Este enlace caduca en 24 horas.",
  resetSubject: "Restablece tu contraseña de GlobalPart",
  resetHeading: "Restablece tu contraseña",
  resetBody: "Hemos recibido una solicitud para restablecer la contraseña de tu cuenta de GlobalPart.",
  resetCta: "Establecer nueva contraseña",
  resetExpiry: "Este enlace caduca en 1 hora.",
  resetIgnore: "Si no has solicitado esto, puedes ignorar este correo — tu contraseña no cambiará.",
  otpSubject: "Tu código de verificación de GlobalPart",
  otpHeading: "Tu código de verificación",
  otpBody: "Introduce este código para continuar con la acción que iniciaste:",
  otpExpiry: "Este código caduca en 10 minutos.",
  statusSubject: "Actualización sobre tu solicitud de GlobalPart",
  statusHeading: "El estado de tu solicitud ha cambiado",
  approvedSubject: "Tu solicitud de GlobalPart ha sido aprobada",
  approvedHeading: "Estás verificado",
  approvedBody: "Enhorabuena — {company} ha completado la verificación y ahora es Socio Verificado en GlobalPart.",
  approvedCta: "Ver tu panel",
  rejectedSubject: "Actualización sobre tu solicitud de GlobalPart",
  rejectedHeading: "Tu solicitud no fue aprobada",
  rejectedBody: "Hemos revisado la solicitud de {company} y no hemos podido aprobarla en este momento.",
  rejectedReasonLabel: "Motivo indicado por nuestro equipo de revisión:",
  rejectedCta: "Revisar tu solicitud",
  adminAlertSubject: "Nueva solicitud pendiente de revisión",
  adminAlertHeading: "Nueva solicitud enviada",
  adminAlertBody: "{company} ha enviado una nueva solicitud que está en la cola de revisión.",
  adminAlertCta: "Abrir la consola de administración",
  inviteSubject: "{inviter} te ha invitado a unirte a GlobalPart",
  inviteHeading: "Has sido invitado",
  inviteBody: "{inviter} usa GlobalPart para verificar y trabajar con socios comerciales de confianza, y ha invitado a {company} a unirse.",
  inviteCta: "Aceptar la invitación",
  inviteExpiry: "Este enlace de invitación caduca en 30 días.",
};

const it: EmailStrings = {
  footerTagline: "Infrastruttura di fiducia sovrana per il commercio transfrontaliero.",
  footerAutomated: "Questo è un messaggio automatico — ti preghiamo di non rispondere direttamente.",
  footerRights: "Tutti i diritti riservati.",
  verifySubject: "Verifica la tua email GlobalPart",
  verifyHeading: "Conferma il tuo indirizzo email",
  verifyBody: "Benvenuto su GlobalPart. Conferma il tuo indirizzo email per attivare il tuo account.",
  verifyCta: "Verifica indirizzo email",
  verifyExpiry: "Questo link scade tra 24 ore.",
  resetSubject: "Reimposta la tua password GlobalPart",
  resetHeading: "Reimposta la password",
  resetBody: "Abbiamo ricevuto una richiesta di reimpostazione della password del tuo account GlobalPart.",
  resetCta: "Imposta una nuova password",
  resetExpiry: "Questo link scade tra 1 ora.",
  resetIgnore: "Se non hai richiesto questa operazione, puoi ignorare questa email — la tua password non cambierà.",
  otpSubject: "Il tuo codice di verifica GlobalPart",
  otpHeading: "Il tuo codice di verifica",
  otpBody: "Inserisci questo codice per continuare con l'azione che hai iniziato:",
  otpExpiry: "Questo codice scade tra 10 minuti.",
  statusSubject: "Aggiornamento sulla tua domanda GlobalPart",
  statusHeading: "Lo stato della tua domanda è cambiato",
  approvedSubject: "La tua domanda GlobalPart è stata approvata",
  approvedHeading: "Sei verificato",
  approvedBody: "Congratulazioni — {company} ha completato la verifica ed è ora Partner Verificato su GlobalPart.",
  approvedCta: "Vedi la tua dashboard",
  rejectedSubject: "Aggiornamento sulla tua domanda GlobalPart",
  rejectedHeading: "La tua domanda non è stata approvata",
  rejectedBody: "Abbiamo esaminato la domanda per {company} e non siamo riusciti ad approvarla in questo momento.",
  rejectedReasonLabel: "Motivo indicato dal nostro team di revisione:",
  rejectedCta: "Rivedi la tua domanda",
  adminAlertSubject: "Nuova domanda in attesa di revisione",
  adminAlertHeading: "Nuova domanda inviata",
  adminAlertBody: "{company} ha inviato una nuova domanda che è in coda per la revisione.",
  adminAlertCta: "Apri la console di amministrazione",
  inviteSubject: "{inviter} ti ha invitato a unirti a GlobalPart",
  inviteHeading: "Sei stato invitato",
  inviteBody: "{inviter} usa GlobalPart per verificare e lavorare con partner commerciali affidabili, e ha invitato {company} a unirsi.",
  inviteCta: "Accetta l'invito",
  inviteExpiry: "Questo link di invito scade tra 30 giorni.",
};

const pl: EmailStrings = {
  footerTagline: "Suwerenna infrastruktura zaufania dla handlu transgranicznego.",
  footerAutomated: "To jest wiadomość automatyczna — prosimy nie odpowiadać bezpośrednio.",
  footerRights: "Wszelkie prawa zastrzeżone.",
  verifySubject: "Zweryfikuj swój e-mail GlobalPart",
  verifyHeading: "Potwierdź swój adres e-mail",
  verifyBody: "Witamy w GlobalPart. Potwierdź swój adres e-mail, aby aktywować konto.",
  verifyCta: "Zweryfikuj adres e-mail",
  verifyExpiry: "Ten link wygasa za 24 godziny.",
  resetSubject: "Zresetuj swoje hasło GlobalPart",
  resetHeading: "Zresetuj hasło",
  resetBody: "Otrzymaliśmy prośbę o zresetowanie hasła do Twojego konta GlobalPart.",
  resetCta: "Ustaw nowe hasło",
  resetExpiry: "Ten link wygasa za 1 godzinę.",
  resetIgnore: "Jeśli to nie Ty wysłałeś tę prośbę, zignoruj tę wiadomość — Twoje hasło pozostanie bez zmian.",
  otpSubject: "Twój kod weryfikacyjny GlobalPart",
  otpHeading: "Twój kod weryfikacyjny",
  otpBody: "Wprowadź ten kod, aby kontynuować rozpoczętą czynność:",
  otpExpiry: "Ten kod wygasa za 10 minut.",
  statusSubject: "Aktualizacja Twojego wniosku GlobalPart",
  statusHeading: "Status Twojego wniosku uległ zmianie",
  approvedSubject: "Twój wniosek GlobalPart został zatwierdzony",
  approvedHeading: "Jesteś zweryfikowany",
  approvedBody: "Gratulacje — {company} zakończyła weryfikację i jest teraz Zweryfikowanym Partnerem na GlobalPart.",
  approvedCta: "Zobacz swój panel",
  rejectedSubject: "Aktualizacja Twojego wniosku GlobalPart",
  rejectedHeading: "Twój wniosek nie został zatwierdzony",
  rejectedBody: "Rozpatrzyliśmy wniosek dla {company} i nie mogliśmy go obecnie zatwierdzić.",
  rejectedReasonLabel: "Powód podany przez nasz zespół weryfikacyjny:",
  rejectedCta: "Przejrzyj swój wniosek",
  adminAlertSubject: "Nowy wniosek oczekuje na weryfikację",
  adminAlertHeading: "Złożono nowy wniosek",
  adminAlertBody: "{company} złożyła nowy wniosek, który oczekuje w kolejce do weryfikacji.",
  adminAlertCta: "Otwórz konsolę administratora",
  inviteSubject: "{inviter} zaprasza Cię do GlobalPart",
  inviteHeading: "Zostałeś zaproszony",
  inviteBody: "{inviter} korzysta z GlobalPart, aby weryfikować zaufanych partnerów handlowych i z nimi współpracować, i zaprosił {company} do dołączenia.",
  inviteCta: "Zaakceptuj zaproszenie",
  inviteExpiry: "Ten link z zaproszeniem wygasa za 30 dni.",
};

const pt: EmailStrings = {
  footerTagline: "Infraestrutura de confiança soberana para o comércio transfronteiriço.",
  footerAutomated: "Esta é uma mensagem automática — por favor, não responda diretamente.",
  footerRights: "Todos os direitos reservados.",
  verifySubject: "Verifique o seu e-mail GlobalPart",
  verifyHeading: "Confirme o seu endereço de e-mail",
  verifyBody: "Bem-vindo à GlobalPart. Confirme o seu endereço de e-mail para ativar a sua conta.",
  verifyCta: "Verificar endereço de e-mail",
  verifyExpiry: "Este link expira em 24 horas.",
  resetSubject: "Redefina a sua palavra-passe GlobalPart",
  resetHeading: "Redefinir a palavra-passe",
  resetBody: "Recebemos um pedido para redefinir a palavra-passe da sua conta GlobalPart.",
  resetCta: "Definir nova palavra-passe",
  resetExpiry: "Este link expira em 1 hora.",
  resetIgnore: "Se não solicitou isto, pode ignorar este e-mail — a sua palavra-passe não será alterada.",
  otpSubject: "O seu código de verificação GlobalPart",
  otpHeading: "O seu código de verificação",
  otpBody: "Introduza este código para continuar a ação que iniciou:",
  otpExpiry: "Este código expira em 10 minutos.",
  statusSubject: "Atualização sobre a sua candidatura GlobalPart",
  statusHeading: "O estado da sua candidatura mudou",
  approvedSubject: "A sua candidatura GlobalPart foi aprovada",
  approvedHeading: "Está verificado",
  approvedBody: "Parabéns — {company} concluiu a verificação e é agora Parceiro Verificado na GlobalPart.",
  approvedCta: "Ver o seu painel",
  rejectedSubject: "Atualização sobre a sua candidatura GlobalPart",
  rejectedHeading: "A sua candidatura não foi aprovada",
  rejectedBody: "Analisámos a candidatura de {company} e não foi possível aprová-la neste momento.",
  rejectedReasonLabel: "Motivo indicado pela nossa equipa de análise:",
  rejectedCta: "Rever a sua candidatura",
  adminAlertSubject: "Nova candidatura a aguardar análise",
  adminAlertHeading: "Nova candidatura submetida",
  adminAlertBody: "{company} submeteu uma nova candidatura que aguarda na fila de análise.",
  adminAlertCta: "Abrir a consola de administração",
  inviteSubject: "{inviter} convidou-o para se juntar à GlobalPart",
  inviteHeading: "Foi convidado",
  inviteBody: "{inviter} usa a GlobalPart para verificar e trabalhar com parceiros comerciais de confiança, e convidou {company} a juntar-se.",
  inviteCta: "Aceitar o convite",
  inviteExpiry: "Este link de convite expira em 30 dias.",
};

const tr: EmailStrings = {
  footerTagline: "Sınır ötesi ticaret için egemen güven altyapısı.",
  footerAutomated: "Bu otomatik bir mesajdır — lütfen doğrudan yanıtlamayın.",
  footerRights: "Tüm hakları saklıdır.",
  verifySubject: "GlobalPart e-postanızı doğrulayın",
  verifyHeading: "E-posta adresinizi onaylayın",
  verifyBody: "GlobalPart'a hoş geldiniz. Hesabınızı etkinleştirmek için lütfen e-posta adresinizi onaylayın.",
  verifyCta: "E-posta adresini doğrula",
  verifyExpiry: "Bu bağlantı 24 saat içinde sona erer.",
  resetSubject: "GlobalPart şifrenizi sıfırlayın",
  resetHeading: "Şifrenizi sıfırlayın",
  resetBody: "GlobalPart hesabınızın şifresini sıfırlamak için bir talep aldık.",
  resetCta: "Yeni şifre belirle",
  resetExpiry: "Bu bağlantı 1 saat içinde sona erer.",
  resetIgnore: "Bu talebi siz yapmadıysanız bu e-postayı yok sayabilirsiniz — şifreniz değişmeyecektir.",
  otpSubject: "GlobalPart doğrulama kodunuz",
  otpHeading: "Doğrulama kodunuz",
  otpBody: "Başlattığınız işleme devam etmek için bu kodu girin:",
  otpExpiry: "Bu kod 10 dakika içinde sona erer.",
  statusSubject: "GlobalPart başvurunuzla ilgili güncelleme",
  statusHeading: "Başvurunuzun durumu değişti",
  approvedSubject: "GlobalPart başvurunuz onaylandı",
  approvedHeading: "Doğrulandınız",
  approvedBody: "Tebrikler — {company} doğrulamayı tamamladı ve artık GlobalPart'ta Doğrulanmış Partner.",
  approvedCta: "Kontrol panelinizi görüntüleyin",
  rejectedSubject: "GlobalPart başvurunuzla ilgili güncelleme",
  rejectedHeading: "Başvurunuz onaylanmadı",
  rejectedBody: "{company} için yapılan başvuruyu inceledik ve şu anda onaylayamadık.",
  rejectedReasonLabel: "İnceleme ekibimizin belirttiği gerekçe:",
  rejectedCta: "Başvurunuzu inceleyin",
  adminAlertSubject: "İnceleme bekleyen yeni başvuru",
  adminAlertHeading: "Yeni başvuru gönderildi",
  adminAlertBody: "{company} inceleme kuyruğunda bekleyen yeni bir başvuru gönderdi.",
  adminAlertCta: "Yönetim konsolunu aç",
  inviteSubject: "{inviter} sizi GlobalPart'a davet etti",
  inviteHeading: "Davet edildiniz",
  inviteBody: "{inviter}, güvenilir ticaret ortaklarını doğrulamak ve onlarla çalışmak için GlobalPart kullanıyor ve {company} şirketini katılmaya davet etti.",
  inviteCta: "Daveti kabul et",
  inviteExpiry: "Bu davet bağlantısı 30 gün içinde sona erer.",
};

const DICTIONARIES: Record<EmailLang, EmailStrings> = { en, fr, de, nl, es, it, pl, pt, tr };

/**
 * Returns the strings for a language, falling back to English for
 * anything unrecognized (including the platform's "reserve" languages,
 * which have full UI translations but no email copy yet). An email in
 * English is always better than an email with missing text.
 */
export function emailStrings(lang?: string | null): EmailStrings {
  if (lang && lang in DICTIONARIES) return DICTIONARIES[lang as EmailLang];
  return en;
}

/** Simple {placeholder} interpolation, mirroring the frontend's t(). */
export function interpolate(template: string, params: Record<string, string> = {}): string {
  let out = template;
  for (const [k, v] of Object.entries(params)) out = out.replaceAll(`{${k}}`, v);
  return out;
}
