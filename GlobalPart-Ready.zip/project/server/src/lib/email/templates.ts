import { env } from "../../config/env.js";
import { emailStrings, interpolate, type EmailStrings } from "./strings.js";

/**
 * Branded HTML email templates in GlobalPart's identity (dark navy
 * #05080f / #0c1426, gold #f6c453 — the same tokens as src/index.css).
 *
 * Written as table-based HTML with inline styles on purpose: that's the
 * only reliably-rendering approach across Outlook, Gmail's clipping, and
 * Apple Mail. Modern CSS (flex/grid, CSS variables, <style> blocks) is
 * stripped or ignored by enough clients that using it here would produce
 * a broken layout for a meaningful share of recipients, so none of the
 * app's Tailwind/token system carries over into these files.
 */

const COLORS = {
  bg: "#05080f",
  card: "#0c1426",
  border: "#1e2a42",
  gold: "#f6c453",
  goldDeep: "#e0a92e",
  text: "#f3f6fc",
  textMuted: "#97a3bd",
  textFaint: "#647189",
};

interface LayoutInput {
  heading: string;
  bodyHtml: string;
  s: EmailStrings;
  preheader?: string;
}

/** Shared chrome: logo header, card body, legal footer. */
function layout({ heading, bodyHtml, s, preheader }: LayoutInput): string {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(heading)}</title>
</head>
<body style="margin:0;padding:0;background-color:${COLORS.bg};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
${preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(preheader)}</div>` : ""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:${COLORS.bg};padding:32px 16px;">
  <tr>
    <td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;">
        <tr>
          <td align="center" style="padding-bottom:24px;">
            <span style="font-size:20px;font-weight:700;color:${COLORS.text};letter-spacing:-0.02em;">Global<span style="color:${COLORS.gold};">Part</span></span>
          </td>
        </tr>
        <tr>
          <td style="background-color:${COLORS.card};border:1px solid ${COLORS.border};border-radius:16px;padding:32px;">
            <h1 style="margin:0 0 16px;font-size:22px;line-height:1.3;font-weight:700;color:${COLORS.text};">${escapeHtml(heading)}</h1>
            ${bodyHtml}
          </td>
        </tr>
        <tr>
          <td style="padding-top:24px;text-align:center;">
            <p style="margin:0 0 6px;font-size:12px;color:${COLORS.textFaint};">${escapeHtml(s.footerTagline)}</p>
            <p style="margin:0 0 6px;font-size:12px;color:${COLORS.textFaint};">${escapeHtml(s.footerAutomated)}</p>
            <p style="margin:0;font-size:12px;color:${COLORS.textFaint};">&copy; ${new Date().getFullYear()} GlobalPart. ${escapeHtml(s.footerRights)}</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>`;
}

function paragraph(text: string): string {
  return `<p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:${COLORS.textMuted};">${escapeHtml(text)}</p>`;
}

function button(label: string, href: string): string {
  // Table-wrapped rather than a styled <a> so Outlook renders the filled
  // background rather than a bare link.
  return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 20px;">
  <tr>
    <td style="background-color:${COLORS.gold};border-radius:10px;">
      <a href="${escapeAttr(href)}" style="display:inline-block;padding:12px 24px;font-size:15px;font-weight:600;color:#0a1020;text-decoration:none;border-radius:10px;">${escapeHtml(label)}</a>
    </td>
  </tr>
</table>`;
}

/** Fallback for clients/recipients where the button doesn't render or isn't clickable. */
function rawLink(href: string): string {
  return `<p style="margin:0 0 16px;font-size:12px;line-height:1.5;color:${COLORS.textFaint};word-break:break-all;">${escapeHtml(href)}</p>`;
}

function note(text: string): string {
  return `<p style="margin:0;font-size:13px;line-height:1.5;color:${COLORS.textFaint};">${escapeHtml(text)}</p>`;
}

function escapeHtml(v: string): string {
  return v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function escapeAttr(v: string): string {
  return escapeHtml(v);
}

// ---------- Template builders ----------
// Each returns { subject, html } so callers never have to hand-assemble a
// subject line separately from the body it belongs to.

export interface RenderedEmail {
  subject: string;
  html: string;
}

export function verificationEmail(link: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  return {
    subject: s.verifySubject,
    html: layout({
      heading: s.verifyHeading,
      preheader: s.verifyBody,
      s,
      bodyHtml: paragraph(s.verifyBody) + button(s.verifyCta, link) + rawLink(link) + note(s.verifyExpiry),
    }),
  };
}

export function passwordResetEmail(link: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  return {
    subject: s.resetSubject,
    html: layout({
      heading: s.resetHeading,
      preheader: s.resetBody,
      s,
      bodyHtml: paragraph(s.resetBody) + button(s.resetCta, link) + rawLink(link) + note(`${s.resetExpiry} ${s.resetIgnore}`),
    }),
  };
}

export function otpEmail(code: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  const codeBlock = `<p style="margin:0 0 16px;padding:16px;background-color:${COLORS.bg};border:1px solid ${COLORS.border};border-radius:10px;text-align:center;font-size:30px;font-weight:700;letter-spacing:8px;color:${COLORS.gold};font-family:monospace;">${escapeHtml(code)}</p>`;
  return {
    subject: s.otpSubject,
    html: layout({ heading: s.otpHeading, preheader: s.otpBody, s, bodyHtml: paragraph(s.otpBody) + codeBlock + note(s.otpExpiry) }),
  };
}

/**
 * Fallback for status notifications that don't have a dedicated template
 * (e.g. "your application is now under review"). Uses whatever title/body
 * the caller already computed, wrapped in the same branded chrome as
 * every other email rather than sent as bare markup.
 */
export function genericStatusEmail(title: string, body: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  return {
    subject: title || s.statusSubject,
    html: layout({
      heading: title || s.statusHeading,
      preheader: body,
      s,
      bodyHtml: paragraph(body) + button(s.approvedCta, `${env.APP_URL}/my-application`),
    }),
  };
}

export function kybApprovedEmail(company: string, lang?: string | null): RenderedEmail {  const s = emailStrings(lang);
  const body = interpolate(s.approvedBody, { company });
  return {
    subject: s.approvedSubject,
    html: layout({
      heading: s.approvedHeading,
      preheader: body,
      s,
      bodyHtml: paragraph(body) + button(s.approvedCta, `${env.APP_URL}/my-application`),
    }),
  };
}

export function kybRejectedEmail(company: string, reason: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  const body = interpolate(s.rejectedBody, { company });
  const reasonBlock = `<p style="margin:0 0 8px;font-size:13px;font-weight:600;color:${COLORS.text};">${escapeHtml(s.rejectedReasonLabel)}</p>
<p style="margin:0 0 20px;padding:14px;background-color:${COLORS.bg};border-left:3px solid ${COLORS.goldDeep};border-radius:6px;font-size:14px;line-height:1.6;color:${COLORS.textMuted};">${escapeHtml(reason)}</p>`;
  return {
    subject: s.rejectedSubject,
    html: layout({
      heading: s.rejectedHeading,
      preheader: body,
      s,
      bodyHtml: paragraph(body) + reasonBlock + button(s.rejectedCta, `${env.APP_URL}/my-application`),
    }),
  };
}

export function adminNewApplicationEmail(company: string, lang?: string | null): RenderedEmail {
  const s = emailStrings(lang);
  const body = interpolate(s.adminAlertBody, { company });
  return {
    subject: s.adminAlertSubject,
    html: layout({
      heading: s.adminAlertHeading,
      preheader: body,
      s,
      bodyHtml: paragraph(body) + button(s.adminAlertCta, `${env.APP_URL}/admin`),
    }),
  };
}

export function partnerInvitationEmail(
  input: { inviterName: string; invitedCompany: string; link: string },
  lang?: string | null
): RenderedEmail {
  const s = emailStrings(lang);
  const body = interpolate(s.inviteBody, { inviter: input.inviterName, company: input.invitedCompany });
  return {
    subject: interpolate(s.inviteSubject, { inviter: input.inviterName }),
    html: layout({
      heading: s.inviteHeading,
      preheader: body,
      s,
      bodyHtml: paragraph(body) + button(s.inviteCta, input.link) + rawLink(input.link) + note(s.inviteExpiry),
    }),
  };
}
