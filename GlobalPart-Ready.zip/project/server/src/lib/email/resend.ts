import { env } from "../../config/env.js";

/**
 * Resend transport with retry, timeout, and structured logging.
 *
 * Sits behind sendEmail() in ../email.ts rather than replacing it, so the
 * existing console-provider fallback (which makes the whole signup/reset
 * flow testable with zero external accounts) keeps working unchanged.
 */

interface SendInput {
  to: string;
  subject: string;
  html: string;
}

const MAX_ATTEMPTS = 3;
const TIMEOUT_MS = 10_000;

/** 4xx responses are permanent (bad key, invalid address) -- retrying them just wastes time and rate limit. */
function isRetryable(status: number): boolean {
  return status === 429 || status >= 500;
}

function backoffMs(attempt: number): number {
  return Math.min(1000 * 2 ** (attempt - 1), 4000); // 1s, 2s, 4s
}

export async function sendViaResend({ to, subject, html }: SendInput): Promise<void> {
  if (!env.RESEND_API_KEY) {
    throw new Error("EMAIL_PROVIDER=resend but RESEND_API_KEY is not set");
  }

  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    // AbortSignal.timeout so a hung connection can't stall a request
    // handler indefinitely -- email sends happen inline in several routes
    // (registration, KYB review), so a stuck fetch would hold the
    // response open too.
    const signal = AbortSignal.timeout(TIMEOUT_MS);
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${env.RESEND_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ from: env.EMAIL_FROM, to, subject, html }),
        signal,
      });

      if (res.ok) {
        const data = (await res.json().catch(() => ({}))) as { id?: string };
        console.log(`📧 Email sent via Resend | to=${to} | subject="${subject}" | id=${data.id ?? "unknown"} | attempt=${attempt}`);
        return;
      }

      const bodyText = await res.text().catch(() => "");
      const err = new Error(`Resend API error (${res.status}): ${bodyText}`);

      if (!isRetryable(res.status)) {
        console.error(`📧 Email FAILED permanently | to=${to} | subject="${subject}" | status=${res.status} | ${bodyText}`);
        throw err;
      }
      lastError = err;
      console.warn(`📧 Email attempt ${attempt}/${MAX_ATTEMPTS} failed (retryable) | to=${to} | status=${res.status}`);
    } catch (err) {
      // Network failure or timeout -- also retryable. A thrown permanent
      // error from the 4xx branch above is re-thrown immediately rather
      // than being caught here and retried.
      if (err instanceof Error && err.message.startsWith("Resend API error (4")) throw err;
      lastError = err instanceof Error ? err : new Error(String(err));
      console.warn(`📧 Email attempt ${attempt}/${MAX_ATTEMPTS} failed (network/timeout) | to=${to} | ${lastError.message}`);
    }

    if (attempt < MAX_ATTEMPTS) {
      await new Promise((r) => setTimeout(r, backoffMs(attempt)));
    }
  }

  console.error(`📧 Email FAILED after ${MAX_ATTEMPTS} attempts | to=${to} | subject="${subject}"`);
  throw lastError ?? new Error("Email send failed for an unknown reason");
}
