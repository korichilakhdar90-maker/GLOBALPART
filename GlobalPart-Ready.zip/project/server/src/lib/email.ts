import { env } from "../config/env.js";
import { sendViaResend } from "./email/resend.js";
import { verificationEmail, passwordResetEmail } from "./email/templates.js";

interface SendEmailInput {
  to: string;
  subject: string;
  html: string;
}

/**
 * Pluggable email sender. Ships with a "console" provider so the full
 * signup/reset flow is testable end-to-end with zero external accounts.
 * Switch EMAIL_PROVIDER=resend (+ RESEND_API_KEY) to send real email in
 * production — no other code needs to change.
 *
 * The resend path delegates to ./email/resend.ts, which adds retry with
 * backoff, a request timeout, and structured logging.
 */
export async function sendEmail({ to, subject, html }: SendEmailInput): Promise<void> {
  if (env.EMAIL_PROVIDER === "console") {
    console.log(`\n📧 [console email provider] To: ${to}\nSubject: ${subject}\n${html}\n`);
    return;
  }

  if (env.EMAIL_PROVIDER === "resend") {
    await sendViaResend({ to, subject, html });
    return;
  }
}

// ---- Backward-compatible helpers ----
// These predate the branded template system in ./email/templates.ts and
// are still called from auth.routes.ts. They now return the branded HTML
// rather than the old bare-<p> markup, so existing call sites get the new
// design without any change at the call site. New code should prefer
// importing from ./email/templates.js directly, since those builders
// return { subject, html } together and accept a language.

export function verificationEmailHtml(link: string, lang?: string | null) {
  return verificationEmail(link, lang).html;
}

export function passwordResetEmailHtml(link: string, lang?: string | null) {
  return passwordResetEmail(link, lang).html;
}
