import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomUUID } from "crypto";
import { mkdir, writeFile, unlink, readFile } from "fs/promises";
import path from "path";
import { env } from "../config/env.js";

const LOCAL_DIR = path.resolve(process.cwd(), "uploads");

let s3Client: S3Client | null = null;
function getS3Client(): S3Client {
  if (!s3Client) {
    if (!env.S3_BUCKET || !env.S3_REGION || !env.S3_ACCESS_KEY_ID || !env.S3_SECRET_ACCESS_KEY) {
      throw new Error(
        "STORAGE_PROVIDER=s3 requires S3_BUCKET, S3_REGION, S3_ACCESS_KEY_ID, and S3_SECRET_ACCESS_KEY to be set."
      );
    }
    s3Client = new S3Client({
      region: env.S3_REGION,
      endpoint: env.S3_ENDPOINT, // set for Cloudflare R2 / MinIO / other S3-compatible providers
      credentials: {
        accessKeyId: env.S3_ACCESS_KEY_ID,
        secretAccessKey: env.S3_SECRET_ACCESS_KEY,
      },
    });
  }
  return s3Client;
}

export interface StoredFile {
  storageKey: string;
}

/** Uploads a file buffer and returns the key used to retrieve it later. */
export async function uploadFile(buffer: Buffer, originalName: string, mimeType: string): Promise<StoredFile> {
  const ext = path.extname(originalName);
  const key = `${randomUUID()}${ext}`;

  if (env.STORAGE_PROVIDER === "local") {
    await mkdir(LOCAL_DIR, { recursive: true });
    await writeFile(path.join(LOCAL_DIR, key), buffer);
    return { storageKey: key };
  }

  await getS3Client().send(
    new PutObjectCommand({
      Bucket: env.S3_BUCKET,
      Key: key,
      Body: buffer,
      ContentType: mimeType,
    })
  );
  return { storageKey: key };
}

/** Returns a URL the client can use to download/view the file. */
export async function getFileUrl(storageKey: string): Promise<string> {
  if (env.STORAGE_PROVIDER === "local") {
    return `/api/files/local/${storageKey}`;
  }
  const client = getS3Client();
  return getSignedUrl(
    client,
    new GetObjectCommand({ Bucket: env.S3_BUCKET, Key: storageKey }),
    { expiresIn: 3600 }
  );
}

export async function readLocalFile(storageKey: string): Promise<Buffer> {
  return readFile(path.join(LOCAL_DIR, storageKey));
}

export async function deleteFile(storageKey: string): Promise<void> {
  if (env.STORAGE_PROVIDER === "local") {
    await unlink(path.join(LOCAL_DIR, storageKey)).catch(() => {});
    return;
  }
  await getS3Client().send(new DeleteObjectCommand({ Bucket: env.S3_BUCKET, Key: storageKey }));
}
