import { generateSecret, generateURI, verify } from "otplib";
import QRCode from "qrcode";

const ISSUER = "GlobalPart";
const TOTP_EPOCH_TOLERANCE_SECONDS = 30; // accept 1 step of clock drift (±30s) either side

/** Generates a fresh Base32 TOTP secret for a user beginning 2FA setup. Not yet "enabled" until they prove possession. */
export function generateTwoFactorSecret(): string {
  return generateSecret();
}

export function buildOtpAuthUrl(email: string, secret: string): string {
  return generateURI({ issuer: ISSUER, label: email, secret });
}

/** Renders the otpauth:// URL as a scannable QR code data URL for the setup screen. */
export async function generateQrCodeDataUrl(otpAuthUrl: string): Promise<string> {
  return QRCode.toDataURL(otpAuthUrl);
}

export async function verifyTotpCode(secret: string, code: string): Promise<boolean> {
  try {
    const result = await verify({ secret, token: code, epochTolerance: TOTP_EPOCH_TOLERANCE_SECONDS });
    return result.valid;
  } catch {
    return false;
  }
}
