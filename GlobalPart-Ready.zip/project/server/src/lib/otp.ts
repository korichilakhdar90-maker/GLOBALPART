import bcrypt from "bcryptjs";
import { randomInt } from "crypto";
import { prisma } from "./prisma.js";
import { sendEmail } from "./email.js";

const OTP_TTL_MINUTES = 10;

/** 6-digit numeric code -- short enough to type quickly in the sensitive-action modal. */
function generateOtpCode(): string {
  return randomInt(0, 1_000_000).toString().padStart(6, "0");
}

/**
 * Creates and emails a fresh OTP for the given purpose, invalidating any
 * still-open codes of the same purpose first so a user can't have several
 * valid codes floating around (and so an old, possibly-leaked code from an
 * abandoned attempt can't still be redeemed).
 */
export async function issueOtp(userId: string, email: string, purpose: "SENSITIVE_ACTION"): Promise<void> {
  await prisma.otpCode.updateMany({
    where: { userId, purpose, consumedAt: null },
    data: { consumedAt: new Date() }, // mark superseded codes as consumed so they can't be replayed
  });

  const code = generateOtpCode();
  const codeHash = await bcrypt.hash(code, 10);
  await prisma.otpCode.create({
    data: {
      userId,
      purpose,
      codeHash,
      expiresAt: new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000),
    },
  });

  await sendEmail({
    to: email,
    subject: "Your GlobalPart verification code",
    html: `<p>Your verification code is:</p><p style="font-size:28px;font-weight:700;letter-spacing:4px">${code}</p><p>This code expires in ${OTP_TTL_MINUTES} minutes. If you didn't request this, you can ignore this email.</p>`,
  });
}

/**
 * Verifies a submitted code against the most recent unconsumed OTP of that
 * purpose. On success, marks it consumed (single use) and returns true.
 */
export async function verifyOtp(userId: string, purpose: "SENSITIVE_ACTION", submittedCode: string): Promise<boolean> {
  const record = await prisma.otpCode.findFirst({
    where: { userId, purpose, consumedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
  });
  if (!record) return false;

  const valid = await bcrypt.compare(submittedCode, record.codeHash);
  if (!valid) return false;

  await prisma.otpCode.update({ where: { id: record.id }, data: { consumedAt: new Date() } });
  return true;
}
