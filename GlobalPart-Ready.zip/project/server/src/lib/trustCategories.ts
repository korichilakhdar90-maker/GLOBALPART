// The five categories the Explainable Trust Score is broken down into.
// Weights are in basis points and must sum to 10000 (100%).
//
// This is the single source of truth for category names/weights — both
// prisma/seed.ts and services/trustScore.service.ts import from here so
// EvidenceItem.category / TrustScoreFactor.category never drift out of
// sync with each other. Deliberately NOT defined inside prisma/seed.ts:
// that file calls its `main()` seeding routine unconditionally at module
// load, so importing anything from it at runtime would silently re-run
// the seed script (reset the admin password, re-touch 108 companies)
// every time the server boots.
export const TRUST_SCORE_CATEGORIES = [
  { key: "kyb_verification", label: "KYB Verification", weightBps: 3000 },
  { key: "registry", label: "Commercial Registry", weightBps: 1500 },
  { key: "financials", label: "Financial Readiness", weightBps: 2000 },
  { key: "certifications", label: "Certifications", weightBps: 1500 },
  { key: "past_projects", label: "Past Project Performance", weightBps: 1500 },
  { key: "logistics", label: "Logistics Capability", weightBps: 500 },
] as const;
