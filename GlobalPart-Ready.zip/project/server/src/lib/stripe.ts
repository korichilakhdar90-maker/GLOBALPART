import Stripe from "stripe";
import { env } from "../config/env.js";

let stripeClient: Stripe | null = null;

export function isBillingConfigured(): boolean {
  return Boolean(env.STRIPE_SECRET_KEY);
}

export function getStripe(): Stripe {
  if (!env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not configured on the server.");
  }
  if (!stripeClient) {
    stripeClient = new Stripe(env.STRIPE_SECRET_KEY);
  }
  return stripeClient;
}

// Map internal plan tiers to Stripe Price IDs. Create these Products/Prices
// in your Stripe Dashboard (test mode first), then paste the price IDs here
// or move them to env vars if you prefer not to redeploy to change pricing.
export const PLAN_PRICE_IDS: Record<"PROFESSIONAL" | "ENTERPRISE", string | undefined> = {
  PROFESSIONAL: process.env.STRIPE_PRICE_PROFESSIONAL,
  ENTERPRISE: process.env.STRIPE_PRICE_ENTERPRISE,
};

// Feature 1: Verified Trust Badge, $100/mo recurring.
export const TRUST_BADGE_PRICE_ID: string | undefined = process.env.STRIPE_PRICE_TRUST_BADGE;

// Feature 3: White-label licensing, annual recurring — set per-tenant deal
// size varies enough in practice that most teams price this by hand in
// Stripe rather than a single fixed price; default price ID below is a
// sane starting point you can override per checkout call.
export const TENANT_LICENSE_PRICE_ID: string | undefined = process.env.STRIPE_PRICE_TENANT_LICENSE;
