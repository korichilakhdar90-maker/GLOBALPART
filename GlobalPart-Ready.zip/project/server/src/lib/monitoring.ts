import * as Sentry from "@sentry/node";
import { env } from "../config/env.js";

export function initMonitoring() {
  if (!env.SENTRY_DSN) return;
  Sentry.init({
    dsn: env.SENTRY_DSN,
    environment: env.NODE_ENV,
    tracesSampleRate: env.NODE_ENV === "production" ? 0.2 : 0,
  });
}

/** Reports an error to Sentry if configured; always also logs to console. */
export function captureError(err: unknown, context?: Record<string, unknown>) {
  console.error("Error:", err, context ?? "");
  if (env.SENTRY_DSN) {
    Sentry.captureException(err, context ? { extra: context } : undefined);
  }
}

export { Sentry };
