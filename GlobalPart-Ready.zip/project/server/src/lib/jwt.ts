import jwt from "jsonwebtoken";
import { randomBytes } from "crypto";
import { env } from "../config/env.js";

export interface AccessTokenPayload {
  sub: string; // user id
  role: "USER" | "ADMIN";
  email: string;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, { expiresIn: env.ACCESS_TOKEN_TTL as jwt.SignOptions["expiresIn"] });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload;
}

/**
 * Refresh tokens are opaque random strings stored (hashed by DB row lookup,
 * not by value transformation) in the RefreshToken table, NOT JWTs. This
 * makes them trivially revocable (delete/mark-revoked the DB row) — a real
 * security requirement that self-contained JWTs can't satisfy without an
 * extra denylist layer anyway.
 */
export function generateRefreshTokenValue(): string {
  return randomBytes(48).toString("hex");
}

export function generateOneTimeToken(): string {
  return randomBytes(32).toString("hex");
}

// ---- 2FA login step-up token ----
// When a user with twoFactorEnabled logs in with a correct password, we
// do NOT issue a real access/refresh token yet -- only this short-lived,
// single-purpose token proving "password already checked, TOTP still
// owed". A real session is only issued after POST /api/auth/2fa/verify-login
// accepts a valid TOTP code alongside it. Kept as a JWT (not a DB row) since
// it's intentionally short-lived and doesn't need to be revocable.
interface TwoFactorPendingPayload {
  sub: string;
  purpose: "2fa_pending";
}

export function signTwoFactorPendingToken(userId: string): string {
  return jwt.sign({ sub: userId, purpose: "2fa_pending" } satisfies TwoFactorPendingPayload, env.JWT_ACCESS_SECRET, {
    expiresIn: "5m",
  });
}

export function verifyTwoFactorPendingToken(token: string): string {
  const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as TwoFactorPendingPayload;
  if (payload.purpose !== "2fa_pending") throw new Error("Not a 2FA pending token");
  return payload.sub;
}
