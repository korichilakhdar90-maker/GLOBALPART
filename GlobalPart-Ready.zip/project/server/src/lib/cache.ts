import { env } from "../config/env.js";

// Minimal in-process TTL cache for read-heavy GET endpoints.
//
// Why this exists: company search and trade-signal reads are the most
// frequent queries in the app and change far less often than they're read.
// Caching them for a short TTL cuts database load dramatically under
// concurrent traffic without adding any new infrastructure.
//
// Scaling beyond one instance: this cache is per-process, so behind a load
// balancer with N server instances you get N independent caches (still
// correct, just less effective). When REDIS_URL is set (see config/env.ts),
// swap the Map below for an ioredis-backed store with the same get/set/del
// interface — every call site here stays unchanged.
//
// Bounded size: capped at MAX_ENTRIES with simple FIFO eviction so a cache
// key explosion (e.g. many distinct search queries) can't grow unbounded
// memory usage on a long-running process.
const MAX_ENTRIES = 500;

type Entry<T> = { value: T; expiresAt: number };

const store = new Map<string, Entry<unknown>>();

export function cacheGet<T>(key: string): T | undefined {
  const entry = store.get(key);
  if (!entry) return undefined;
  if (Date.now() > entry.expiresAt) {
    store.delete(key);
    return undefined;
  }
  return entry.value as T;
}

export function cacheSet<T>(key: string, value: T, ttlSeconds: number = env.CACHE_TTL_SECONDS): void {
  if (store.size >= MAX_ENTRIES && !store.has(key)) {
    const oldestKey = store.keys().next().value;
    if (oldestKey !== undefined) store.delete(oldestKey);
  }
  store.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
}

// Call after any write that could make a cached read stale (e.g. admin
// publishes a new trade signal). Prefix-based so `invalidate("signals:")`
// clears every cached signals query, not just one exact key.
export function cacheInvalidate(prefix: string): void {
  for (const key of store.keys()) {
    if (key.startsWith(prefix)) store.delete(key);
  }
}

// Wraps an async DB read with cache-aside: return the cached value if fresh,
// otherwise compute, store, and return it. This is the call sites' main
// entry point so route handlers don't touch cacheGet/cacheSet directly.
export async function cached<T>(key: string, ttlSeconds: number, fn: () => Promise<T>): Promise<T> {
  const hit = cacheGet<T>(key);
  if (hit !== undefined) return hit;
  const value = await fn();
  cacheSet(key, value, ttlSeconds);
  return value;
}
