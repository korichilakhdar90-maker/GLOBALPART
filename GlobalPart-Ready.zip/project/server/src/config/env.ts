import "dotenv/config";
import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().default(4000),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required (PostgreSQL connection string)"),

  JWT_ACCESS_SECRET: z.string().min(32, "JWT_ACCESS_SECRET must be at least 32 characters"),
  JWT_REFRESH_SECRET: z.string().min(32, "JWT_REFRESH_SECRET must be at least 32 characters"),
  ACCESS_TOKEN_TTL: z.string().default("15m"),
  REFRESH_TOKEN_TTL_DAYS: z.coerce.number().default(30),

  CORS_ORIGIN: z.string().default("http://localhost:5173"),

  // Optional integrations — the app degrades gracefully (with clear console
  // warnings) when these are not configured, instead of crashing.
  ANTHROPIC_API_KEY: z.string().optional(),
  ANTHROPIC_MODEL: z.string().default("claude-sonnet-5"),
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),

  EMAIL_PROVIDER: z.enum(["console", "resend"]).default("console"),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default("GlobalPart <noreply@globalpart.io>"),

  STORAGE_PROVIDER: z.enum(["local", "s3"]).default("local"),
  S3_BUCKET: z.string().optional(),
  S3_REGION: z.string().optional(),
  S3_ENDPOINT: z.string().optional(),
  S3_ACCESS_KEY_ID: z.string().optional(),
  S3_SECRET_ACCESS_KEY: z.string().optional(),

  // Optional third-party KYB verification provider (e.g. Middesk, Trulioo).
  // When unset, KYB submissions fall back to human-review-only workflow.
  KYB_PROVIDER: z.enum(["none", "middesk", "trulioo"]).default("none"),
  KYB_PROVIDER_API_KEY: z.string().optional(),

  APP_URL: z.string().default("http://localhost:5173"),

  // Optional error monitoring — when unset, errors just log to console (current behavior).
  SENTRY_DSN: z.string().optional(),

  // Read-through cache for expensive/read-heavy GET endpoints (company
  // directory, trade signals). Defaults to an in-process cache that works
  // with zero setup; set REDIS_URL when running multiple server instances
  // behind a load balancer so all instances share one cache instead of each
  // holding a stale copy.
  CACHE_TTL_SECONDS: z.coerce.number().default(60),
  REDIS_URL: z.string().optional(),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error("❌ Invalid environment configuration:");
  console.error(parsed.error.flatten().fieldErrors);
  throw new Error("Environment validation failed — see errors above. Check server/.env against .env.example.");
}

export const env = parsed.data;

// Non-fatal warnings for optional-but-important integrations left unconfigured.
if (!env.ANTHROPIC_API_KEY) {
  console.warn("⚠️  ANTHROPIC_API_KEY not set — AI assistant/recommendation endpoints will return a friendly fallback instead of real AI output.");
}
if (!env.STRIPE_SECRET_KEY) {
  console.warn("⚠️  STRIPE_SECRET_KEY not set — billing endpoints are disabled.");
}
if (env.EMAIL_PROVIDER === "console") {
  console.warn("⚠️  EMAIL_PROVIDER=console — verification/reset emails are logged to the server console, not actually sent. Set EMAIL_PROVIDER=resend + RESEND_API_KEY for real delivery.");
}
if (env.STORAGE_PROVIDER === "local") {
  console.warn("⚠️  STORAGE_PROVIDER=local — uploaded files are stored on local disk (./uploads), which will NOT persist across most hosting redeploys. Set STORAGE_PROVIDER=s3 for production.");
}
if (env.KYB_PROVIDER === "none") {
  console.warn("⚠️  KYB_PROVIDER=none — KYB submissions go straight to human-review-only workflow (no automated identity verification call).");
}
if (!env.SENTRY_DSN) {
  console.warn("⚠️  SENTRY_DSN not set — errors are only logged to the console, with no alerting/monitoring dashboard. Set SENTRY_DSN in production.");
}
