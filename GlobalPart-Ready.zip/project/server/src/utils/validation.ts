import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email(),
  password: z.string().min(8, "Password must be at least 8 characters"),
  company: z.string().max(200).optional(),
  // Defaults to INDIVIDUAL so existing clients that don't send this field
  // keep getting today's frictionless individual/freelancer flow unchanged.
  accountCategory: z.enum(["INDIVIDUAL", "ENTERPRISE", "GOVERNMENT"]).default("INDIVIDUAL"),
});

export const otpRequestSchema = z.object({
  purpose: z.literal("SENSITIVE_ACTION").default("SENSITIVE_ACTION"),
});

export const otpVerifySchema = z.object({
  code: z.string().length(6, "Code must be 6 digits"),
  purpose: z.literal("SENSITIVE_ACTION").default("SENSITIVE_ACTION"),
});

export const twoFactorEnableSchema = z.object({
  code: z.string().length(6, "Code must be 6 digits"),
});

export const twoFactorVerifyLoginSchema = z.object({
  pendingToken: z.string().min(1),
  code: z.string().length(6, "Code must be 6 digits"),
});

export const sovereignDomainSchema = z.object({
  domain: z.string().min(3).max(120),
  label: z.string().max(200).optional(),
});

export const waitlistSchema = z.object({
  email: z.string().email(),
  company: z.string().max(200).optional(),
  country: z.string().max(120).optional(),
  note: z.string().max(500).optional(),
});

export const feedbackSchema = z.object({
  email: z.string().email().optional(),
  liked: z.string().max(1000).optional(),
  issues: z.string().max(1000).optional(),
  suggestions: z.string().max(1000).optional(),
});

export const invitationCreateSchema = z.object({
  inviteeEmail: z.string().email(),
  inviteeType: z.enum(["INDIVIDUAL", "ENTERPRISE", "GOVERNMENT"]).default("INDIVIDUAL"),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// GDPR: one row per purpose, never a single bundled "accept everything" flag.
export const consentSchema = z.object({
  email: z.string().email().optional(),
  purpose: z.enum(["marketing_emails", "terms_of_service", "privacy_policy", "kyb_data_processing", "cookies_analytics"]),
  granted: z.boolean(),
  version: z.string().min(1).max(40),
});

export const erasureRequestSchema = z.object({
  reason: z.string().max(500).optional(),
});

export const erasureResolveSchema = z.object({
  action: z.enum(["complete", "reject"]),
  rejectionNote: z.string().max(500).optional(),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email(),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1),
  password: z.string().min(8),
});

export const kybSubmitSchema = z.object({
  companyName: z.string().min(2),
  registrationNo: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(3),
  countries: z.string().min(1),
  address: z.string().min(3),
  // Set when this KYB submission is claiming an existing Directory Listed
  // company (see POST /api/companies/:id/claim) rather than registering a
  // brand-new profile from scratch.
  claimedCompanyId: z.string().min(1).optional(),
});

// Government pathway (Steps 1, 2, 4 of the wizard — Step 3/personnel and
// Step 5/framework acceptance are their own arrays below). Sent as
// multipart/form-data alongside file uploads, so this validates the
// JSON-parsed text fields only.
const clearanceLevel = z.enum(["CONFIDENTIAL", "SECRET", "NATO_SECRET", "TOP_SECRET"]);

// Government pathway — Step 1 (Sovereign Identity). Sent alone when the
// draft is first created; Steps 2/4 are separate PATCH calls below so each
// step persists the moment it's completed, not just at final submission.
export const governmentStep1Schema = z.object({
  entityName: z.string().min(3).max(200),
  countryCode: z.string().length(2),
  registrationNo: z.string().min(1),
  officialContactName: z.string().min(2),
  officialTitle: z.string().min(2),
  officialEmail: z.string().email(),
  officialPhone: z.string().min(3),
});

// Step 2 — Facility Security Clearance
export const governmentStep2Schema = z.object({
  fscLevel: clearanceLevel,
  fscIssuingAuthority: z.string().min(2),
  fscIssueDate: z.string().refine((d) => new Date(d) < new Date(), "FSC issue date must be in the past"),
  fscExpiryDate: z.string().refine((d) => new Date(d) > new Date(), "FSC expiry date must be in the future"),
  fscReferenceNumber: z.string().min(1).optional(), // optional when a justification document is provided instead of a certificate
  fscJustificationProvided: z.boolean().default(false),
});

// Step 4 — Need-to-Know Access Protocols
export const governmentStep4Schema = z.object({
  dataClassificationPolicy: z.enum(["PUBLIC", "INTERNAL", "CONFIDENTIAL", "SECRET"]).default("CONFIDENTIAL"),
  securityOfficerName: z.string().min(2),
  dataSharingConsent: z.literal(true, { errorMap: () => ({ message: "Data sharing consent is required" }) }),
  accessLoggingConsent: z.literal(true, { errorMap: () => ({ message: "Access logging consent is required" }) }),
});

export const governmentPersonnelSchema = z.object({
  fullName: z.string().min(2),
  officialTitle: z.string().min(2),
  userRole: z.enum(["SOVEREIGN_ADMIN", "PROCUREMENT_OFFICER", "ANALYST", "AUDITOR"]),
  pscLevel: clearanceLevel,
  pscIssuingAuthority: z.string().min(2),
  pscIssueDate: z.string().refine((d) => new Date(d) < new Date(), "PSC issue date must be in the past"),
  pscExpiryDate: z.string().refine((d) => new Date(d) > new Date(), "PSC expiry date must be in the future"),
});

export const governmentPersonnelListSchema = z
  .array(governmentPersonnelSchema)
  .min(2, "At least 2 personnel are required (a Sovereign Administrator plus one other)")
  .refine((list) => list.some((p) => p.userRole === "SOVEREIGN_ADMIN"), {
    message: "At least one listed person must have the Sovereign Administrator role",
  })
  .refine((list) => list.every((p) => p.pscLevel === "SECRET" || p.pscLevel === "NATO_SECRET" || p.pscLevel === "TOP_SECRET"), {
    message: "Every listed person must hold at least SECRET-level clearance",
  });

// All five are mandatory per the Government pathway spec -- the submit
// route rejects anything short of all five rather than accepting a
// partial list.
export const SOVEREIGN_FRAMEWORK_KEYS = [
  "PRIVACY_POLICY",
  "DATA_PROCESSING_AGREEMENT",
  "SOVEREIGN_TRUST_FRAMEWORK",
  "SECURITY_PROTOCOL_COMMITMENT",
  "DATA_ISOLATION_POLICY",
] as const;

export const governmentFrameworkAcceptanceSchema = z
  .array(z.enum(SOVEREIGN_FRAMEWORK_KEYS))
  .refine((keys) => new Set(keys).size === SOVEREIGN_FRAMEWORK_KEYS.length, {
    message: "All five legal frameworks must be individually accepted",
  });

export const kybReviewSchema = z
  .object({
    status: z.enum(["APPROVED", "REJECTED"]),
    reviewNotes: z.string().max(2000).optional(),
    rejectionReason: z.string().max(1000).optional(),
    bankAccountVerified: z.boolean().optional(),
    physicalAddressConfirmed: z.boolean().optional(),
    // Corporate-tier checklist
    financialAuditCompleted: z.boolean().optional(),
    certificationsVerified: z.boolean().optional(),
    pepScreeningStatus: z.enum(["NOT_STARTED", "PENDING", "CLEAR", "FLAGGED"]).optional(),
    pepScreeningNotes: z.string().max(1000).optional(),
    // Sovereign-tier checklist
    diplomaticVerificationCompleted: z.boolean().optional(),
    diplomaticVerificationNotes: z.string().max(1000).optional(),
    fscValidated: z.boolean().optional(),
    pscAllValidated: z.boolean().optional(),
  })
  .refine((data) => data.status !== "REJECTED" || (data.rejectionReason && data.rejectionReason.trim().length > 0), {
    message: "rejectionReason is required when rejecting an application",
    path: ["rejectionReason"],
  });

export const dealRoomCreateSchema = z.object({
  title: z.string().min(2),
  sellerId: z.string().min(1),
  buyerCompanyId: z.string().optional(),
  sellerCompanyId: z.string().optional(),
  valueUsd: z.number().int().nonnegative().optional(),
});

export const messageCreateSchema = z.object({
  body: z.string().min(1).max(5000),
});

export const chatSchema = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().min(1).max(4000),
      })
    )
    .min(1)
    .max(30),
});

export const companyQuerySchema = z.object({
  search: z.string().optional(),
  industry: z.string().optional(),
  countryCodes: z.string().optional(), // comma-separated ISO country codes
  region: z.string().optional(),
  minTrust: z.coerce.number().int().min(0).max(100).optional(),
  verifiedOnly: z.coerce.boolean().optional(),
  page: z.coerce.number().int().min(1).default(1),
  perPage: z.coerce.number().int().min(1).max(50).default(9),
});

export const tradeSignalQuerySchema = z.object({
  category: z.string().optional(),
  countryCode: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  perPage: z.coerce.number().int().min(1).max(50).default(12),
});

export const tradeSignalCreateSchema = z.object({
  title: z.string().min(3).max(200),
  category: z.enum(["demand", "shipping", "pricing", "tariffs"]),
  countryCode: z.string().length(2).optional(),
  value: z.number(),
  unit: z.string().min(1).max(20),
  trend: z.enum(["up", "down", "flat"]).optional(),
  sourceName: z.string().min(1).max(120),
  sourceUrl: z.string().url(),
  asOf: z.coerce.date(),
});

// Was previously unvalidated (`req.body.stage` passed straight to Prisma) —
// tightened while adding the deal-completion fee logic in deals.routes.ts.
export const dealStageUpdateSchema = z.object({
  stage: z.enum(["DISCOVERY", "NEGOTIATION", "CONTRACT", "ESCROW", "COMPLETED", "CANCELLED"]),
});

const slugSchema = z
  .string()
  .min(2)
  .max(60)
  .regex(/^[a-z0-9][a-z0-9-]*[a-z0-9]$/, "Slug must be lowercase letters, numbers, and hyphens only");

export const tenantCreateSchema = z.object({
  name: z.string().min(2).max(120),
  slug: slugSchema,
  logoUrl: z.string().url().optional(),
  primaryColor: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/, "primaryColor must be a hex color like #3B82F6")
    .optional(),
  contactEmail: z.string().email(),
});

export const tenantUpdateSchema = tenantCreateSchema.partial();
