/**
 * The directory's geographic scope: EU27 + EEA/EFTA + UK + recognized
 * European microstates + Balkan states, PLUS Turkey as an explicit,
 * deliberate exception (not because it's geographically in Europe by every
 * definition, but because it's officially allowed for this platform per
 * product policy). ISO 3166-1 alpha-2 codes.
 *
 * This is the single source of truth for "is this company in scope" --
 * used by both the one-off cleanup script (enforceGeographicScope.ts) and
 * anywhere new companies get imported/created, so the rule can't drift
 * between the two.
 */
export const EUROPEAN_COUNTRY_CODES: readonly string[] = [
  // EU27
  "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR",
  "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
  "SI", "ES", "SE",
  // EEA / EFTA (non-EU)
  "IS", "LI", "NO", "CH",
  // UK (post-Brexit, still geographically/economically European)
  "GB",
  // Balkans / other recognized European states
  "AL", "BA", "ME", "MK", "RS", "XK", "MD", "UA", "BY",
  // European microstates
  "AD", "MC", "SM", "VA",
  // Explicit product-policy exception (not auto-derived from geography)
  "TR",
] as const;

export function isInDirectoryScope(countryCode: string): boolean {
  return EUROPEAN_COUNTRY_CODES.includes(countryCode.toUpperCase());
}
