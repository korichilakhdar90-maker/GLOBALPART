import { prisma } from "../lib/prisma.js";

/**
 * Common free/consumer email providers. ENTERPRISE registrations must NOT
 * use one of these -- the whole point of the enterprise tier is that the
 * email domain itself is a weak but free identity signal (you control
 * name@yourcompany.com only if you actually work there).
 *
 * This list is deliberately static/hardcoded rather than admin-editable:
 * unlike the sovereign domain allowlist (which needs to grow per-country),
 * this is a blocklist of well-known public providers that doesn't change
 * often enough to justify an admin UI, and a hardcoded list can't be
 * accidentally emptied by an admin mistake.
 */
const FREE_EMAIL_DOMAINS = new Set([
  "gmail.com", "googlemail.com",
  "yahoo.com", "yahoo.co.uk", "ymail.com",
  "outlook.com", "hotmail.com", "hotmail.co.uk", "live.com", "msn.com",
  "icloud.com", "me.com", "mac.com",
  "aol.com",
  "protonmail.com", "proton.me",
  "mail.com", "gmx.com", "zoho.com",
  "yandex.com", "yandex.ru",
]);

/** Default sovereign TLD/suffix patterns recognized without any admin configuration. */
const DEFAULT_SOVEREIGN_SUFFIXES = [
  ".gov",       // generic / US government
  ".edu",       // accredited educational institutions
  ".mil",       // military
  ".gouv.fr",   // France
  ".gov.uk",    // United Kingdom
  ".europa.eu", // EU institutions themselves
  ".admin.ch",  // Switzerland
  ".bund.de",   // Germany (federal)
];

function domainOf(email: string): string {
  return email.trim().toLowerCase().split("@")[1] ?? "";
}

export function isFreeEmailDomain(email: string): boolean {
  return FREE_EMAIL_DOMAINS.has(domainOf(email));
}

function matchesSovereignSuffix(domain: string): boolean {
  return DEFAULT_SOVEREIGN_SUFFIXES.some((suffix) => domain === suffix.replace(/^\./, "") || domain.endsWith(suffix));
}

/**
 * A GOVERNMENT registration is accepted if the domain matches a default
 * sovereign suffix OR an admin-added row in SovereignDomain. Checked at
 * registration time in auth.routes.ts -- this is a hard rejection, not a
 * soft flag, per the "restrict registration strictly" requirement.
 */
export async function isSovereignDomain(email: string): Promise<boolean> {
  const domain = domainOf(email);
  if (!domain) return false;
  if (matchesSovereignSuffix(domain)) return true;

  const configured = await prisma.sovereignDomain.findFirst({
    where: {
      domain: {
        equals: domain,
        mode: "insensitive",
      },
    },
  });
  if (configured) return true;

  // Also allow a configured *parent* domain (e.g. an admin adds
  // "gouv.example" and a user registers from "trade.gouv.example").
  const parts = domain.split(".");
  for (let i = 1; i < parts.length - 1; i++) {
    const parentDomain = parts.slice(i).join(".");
    const match = await prisma.sovereignDomain.findFirst({ where: { domain: { equals: parentDomain, mode: "insensitive" } } });
    if (match) return true;
  }
  return false;
}
