import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import cookieParser from "cookie-parser";
import { apiRateLimit } from "./middleware/rateLimit.js";
import { env } from "./config/env.js";
import { authRouter } from "./routes/auth.routes.js";
import { companiesRouter } from "./routes/companies.routes.js";
import { favoritesRouter } from "./routes/favorites.routes.js";
import { kybRouter } from "./routes/kyb.routes.js";
import { dealsRouter } from "./routes/deals.routes.js";
import { aiRouter } from "./routes/ai.routes.js";
import { billingRouter, stripeWebhookRouter } from "./routes/billing.routes.js";
import { adminRouter } from "./routes/admin.routes.js";
import { filesRouter } from "./routes/files.routes.js";
import { waitlistRouter } from "./routes/waitlist.routes.js";
import { feedbackRouter } from "./routes/feedback.routes.js";
import { invitationsRouter } from "./routes/invitations.routes.js";
import { tradeSignalsRouter } from "./routes/tradeSignals.routes.js";
import { trustBadgeRouter } from "./routes/trustBadge.routes.js";
import { tenantsRouter } from "./routes/tenants.routes.js";
import { gdprRouter } from "./routes/gdpr.routes.js";
import { notificationsRouter } from "./routes/notifications.routes.js";
import { governmentRouter } from "./routes/government.routes.js";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler.js";

export function createApp() {
  const app = express();

  app.set("trust proxy", 1);

  // Explicit security headers rather than bare helmet() defaults, so each
  // policy is a deliberate, reviewable decision.
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          // 'unsafe-inline' is required for styles because the app uses
          // inline style attributes (CSS custom properties set per-element)
          // and Tailwind's runtime-injected styles. Removing it needs a
          // nonce/hash strategy wired through the Vite build -- worth
          // doing, but it's a build-pipeline change, not a header change.
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'"],
          // Fonts are self-hosted on purpose (see the GDPR note in
          // index.html) -- no Google Fonts origin is allowlisted here,
          // which means a regression that re-adds the CDN <link> will be
          // blocked by CSP rather than silently shipping.
          fontSrc: ["'self'", "data:"],
          imgSrc: ["'self'", "data:", "https:"],
          // API + Stripe only. Anything else the frontend tries to reach
          // is refused by the browser.
          connectSrc: ["'self'", "https://api.stripe.com"],
          frameSrc: ["https://js.stripe.com", "https://hooks.stripe.com"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"], // modern equivalent of X-Frame-Options: DENY
          upgradeInsecureRequests: env.NODE_ENV === "production" ? [] : null,
        },
      },
      // 2 years + preload is the threshold hstspreload.org requires.
      // Only meaningful once served over real HTTPS behind a proper
      // domain -- harmless in development.
      hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
      // helmet sets X-Content-Type-Options: nosniff and
      // X-Frame-Options: DENY by default; both are kept.
      crossOriginEmbedderPolicy: false, // would break Stripe's embedded elements
    })
  );

  // Not covered by helmet: explicitly denies access to device APIs this
  // platform never uses. Without it, any injected third-party script
  // could prompt for camera/mic/geolocation.
  app.use((_req, res, next) => {
    res.setHeader(
      "Permissions-Policy",
      "camera=(), microphone=(), geolocation=(), payment=(self), usb=(), magnetometer=(), gyroscope=()"
    );
    next();
  });

  app.use(compression());
  app.use(cors({ origin: env.CORS_ORIGIN, credentials: true }));

  // Stripe webhook needs the raw body for signature verification, so it
  // must be mounted BEFORE express.json() touches the request stream.
  app.use("/api/billing/webhook", stripeWebhookRouter);

  app.use(express.json({ limit: "2mb" }));
  app.use(cookieParser());

  // Generous global rate limit as a baseline defense; tighten per-route
  // (e.g. /auth/login) if you see abuse in production logs. Backed by
  // Redis when REDIS_URL is set (see rateLimit.ts) so this works correctly
  // across multiple instances, not just one.
  app.use("/api", apiRateLimit);

  app.get("/api/health", (_req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

  app.use("/api/auth", authRouter);
  app.use("/api/companies", companiesRouter);
  app.use("/api/favorites", favoritesRouter);
  app.use("/api/kyb", kybRouter);
  app.use("/api/deals", dealsRouter);
  app.use("/api/ai", aiRouter);
  app.use("/api/billing", billingRouter);
  app.use("/api/admin", adminRouter);
  app.use("/api/files", filesRouter);
  app.use("/api/waitlist", waitlistRouter);
  app.use("/api/feedback", feedbackRouter);
  app.use("/api/invitations", invitationsRouter);
  app.use("/api/trade-signals", tradeSignalsRouter);
  app.use("/api/trust-badge", trustBadgeRouter);
  app.use("/api/tenants", tenantsRouter);
  app.use("/api/gdpr", gdprRouter);
  app.use("/api/notifications", notificationsRouter);
  app.use("/api/government", governmentRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
