import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { getStripe, isBillingConfigured, TRUST_BADGE_PRICE_ID } from "../lib/stripe.js";

// Feature 1 — Verified Trust Badge: registration and search stay free.
// This is the paid product for a supplier who wants GlobalPart to actually
// audit their registration/paperwork and grant the verified badge +
// priority placement in search. See kyb.routes.ts, which requires an
// active subscription from this table before a KYB submission can be
// approved.
export const trustBadgeRouter = Router();

trustBadgeRouter.get(
  "/status",
  requireAuth,
  asyncHandler(async (req, res) => {
    const sub = await prisma.trustBadgeSubscription.findUnique({ where: { userId: req.user!.id } });
    res.json({ active: sub?.status === "active", subscription: sub ?? null });
  })
);

trustBadgeRouter.post(
  "/checkout",
  requireAuth,
  asyncHandler(async (req, res) => {
    if (!isBillingConfigured()) throw new ApiError(503, "Billing is not configured on this server yet");
    if (!TRUST_BADGE_PRICE_ID) throw new ApiError(400, "Trust Badge price is not configured (STRIPE_PRICE_TRUST_BADGE)");

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, "User not found");

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer_email: user.email,
      line_items: [{ price: TRUST_BADGE_PRICE_ID, quantity: 1 }],
      success_url: `${env.APP_URL}/kyb?badge=success`,
      cancel_url: `${env.APP_URL}/kyb?badge=cancelled`,
      metadata: { userId: user.id, product: "TRUST_BADGE" },
    });

    res.json({ url: session.url });
  })
);
