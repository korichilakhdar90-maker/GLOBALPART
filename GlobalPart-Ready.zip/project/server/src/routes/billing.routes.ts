import { Router } from "express";
import express from "express";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { getStripe, isBillingConfigured, PLAN_PRICE_IDS } from "../lib/stripe.js";

export const billingRouter = Router();

billingRouter.get("/status", (_req, res) => {
  res.json({ configured: isBillingConfigured() });
});

billingRouter.post(
  "/checkout",
  requireAuth,
  asyncHandler(async (req, res) => {
    if (!isBillingConfigured()) throw new ApiError(503, "Billing is not configured on this server yet");

    const tier = req.body.tier as "PROFESSIONAL" | "ENTERPRISE";
    const priceId = PLAN_PRICE_IDS[tier];
    if (!priceId) throw new ApiError(400, `No Stripe price configured for tier ${tier}`);

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, "User not found");

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer_email: user.email,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${env.APP_URL}/dashboard?checkout=success`,
      cancel_url: `${env.APP_URL}/pricing?checkout=cancelled`,
      metadata: { userId: user.id, tier },
    });

    res.json({ url: session.url });
  })
);

/**
 * Stripe webhook — MUST be mounted with express.raw() (see server.ts) so the
 * signature can be verified against the exact raw request body.
 */
export const stripeWebhookRouter = Router();
stripeWebhookRouter.post(
  "/",
  express.raw({ type: "application/json" }),
  asyncHandler(async (req, res) => {
    if (!isBillingConfigured() || !env.STRIPE_WEBHOOK_SECRET) {
      throw new ApiError(503, "Stripe webhook is not configured");
    }
    const stripe = getStripe();
    const signature = req.headers["stripe-signature"];
    if (!signature) throw new ApiError(400, "Missing stripe-signature header");

    const event = stripe.webhooks.constructEvent(req.body, signature, env.STRIPE_WEBHOOK_SECRET);

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as {
        metadata?: { userId?: string; tier?: string; product?: string; tenantId?: string; dealFeeId?: string };
        customer?: string;
        subscription?: string;
        payment_intent?: string;
      };
      const product = session.metadata?.product;

      if (!product || product === "PLAN") {
        const userId = session.metadata?.userId;
        const tier = session.metadata?.tier as "PROFESSIONAL" | "ENTERPRISE" | undefined;
        if (userId && tier) {
          await prisma.subscription.upsert({
            where: { userId },
            create: {
              userId,
              tier,
              stripeCustomerId: session.customer as string,
              stripeSubscriptionId: session.subscription as string,
              status: "active",
            },
            update: {
              tier,
              stripeCustomerId: session.customer as string,
              stripeSubscriptionId: session.subscription as string,
              status: "active",
            },
          });
        }
      }

      if (product === "TRUST_BADGE" && session.metadata?.userId) {
        const userId = session.metadata.userId;
        await prisma.trustBadgeSubscription.upsert({
          where: { userId },
          create: {
            userId,
            status: "active",
            stripeCustomerId: session.customer as string,
            stripeSubscriptionId: session.subscription as string,
          },
          update: {
            status: "active",
            stripeCustomerId: session.customer as string,
            stripeSubscriptionId: session.subscription as string,
          },
        });
      }

      if (product === "TENANT_LICENSE" && session.metadata?.tenantId) {
        await prisma.tenant.update({
          where: { id: session.metadata.tenantId },
          data: {
            licenseStatus: "active",
            stripeCustomerId: session.customer as string,
            stripeSubscriptionId: session.subscription as string,
          },
        });
      }

      if (product === "DEAL_FEE" && session.metadata?.dealFeeId) {
        await prisma.dealFee.update({
          where: { id: session.metadata.dealFeeId },
          data: { status: "paid", stripePaymentIntentId: session.payment_intent as string },
        });
      }
    }

    if (event.type === "customer.subscription.deleted") {
      const sub = event.data.object as { id: string };
      await prisma.subscription.updateMany({
        where: { stripeSubscriptionId: sub.id },
        data: { status: "cancelled", tier: "STARTER" },
      });
      await prisma.trustBadgeSubscription.updateMany({
        where: { stripeSubscriptionId: sub.id },
        data: { status: "cancelled" },
      });
      await prisma.tenant.updateMany({
        where: { stripeSubscriptionId: sub.id },
        data: { licenseStatus: "cancelled" },
      });
    }

    res.json({ received: true });
  })
);
