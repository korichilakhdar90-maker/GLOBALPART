import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { readLocalFile } from "../lib/storage.js";
import { prisma } from "../lib/prisma.js";

export const filesRouter = Router();

// Gated behind auth AND ownership: this is a dev convenience, not a public
// CDN. In production with STORAGE_PROVIDER=s3, files are served via signed
// URLs straight from S3/R2 instead of proxying through this server.
//
// SECURITY: requireAuth alone is NOT enough here — it only proves the
// caller is *someone*, not that they're allowed to see *this* file. This
// endpoint fronts KYB documents (business registration, financials) and
// deal-room attachments, so every request must be checked against the
// Document row: the uploader, an admin, or (for deal-room files) a
// participant in that deal room. A random/guessed/leaked storageKey alone
// must never be sufficient to read a file.
filesRouter.get(
  "/local/:key",
  requireAuth,
  asyncHandler(async (req, res) => {
    const document = await prisma.document.findUnique({
      where: { storageKey: req.params.key },
      include: { dealRoom: { select: { buyerId: true, sellerId: true } } },
    });
    if (!document) throw new ApiError(404, "File not found");

    const userId = req.user!.id;
    const isOwner = document.userId === userId;
    const isAdmin = req.user!.role === "ADMIN";
    const isDealParticipant =
      document.dealRoom && (document.dealRoom.buyerId === userId || document.dealRoom.sellerId === userId);

    if (!isOwner && !isAdmin && !isDealParticipant) {
      throw new ApiError(403, "Not authorized to access this file");
    }

    const buffer = await readLocalFile(document.storageKey);
    res.send(buffer);
  })
);
