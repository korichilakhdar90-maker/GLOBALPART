import { Router } from "express";
import multer from "multer";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { blockUnverifiedGovernment } from "../middleware/accountPolicy.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import {
  governmentStep1Schema,
  governmentStep2Schema,
  governmentStep4Schema,
  governmentPersonnelSchema,
  SOVEREIGN_FRAMEWORK_KEYS,
} from "../utils/validation.js";
import { uploadFile } from "../lib/storage.js";
import { notifyAdminsOfNewSubmission, logAdminAction } from "../services/notification.service.js";

export const governmentRouter = Router();
const upload = multer({ limits: { fileSize: 15 * 1024 * 1024 } });

governmentRouter.use(requireAuth);
governmentRouter.use(blockUnverifiedGovernment); // every route here requires email+MFA for Government (this whole router IS the Government pathway)

/** Only the owning applicant (or an admin) may read/modify a draft. */
async function loadOwnedDraft(id: string, userId: string, role: string) {
  const draft = await prisma.kybSubmission.findUnique({
    where: { id },
    include: { personnel: true, frameworkAcceptances: true, documents: true },
  });
  if (!draft) throw new ApiError(404, "Application draft not found");
  if (draft.userId !== userId && role !== "ADMIN") throw new ApiError(403, "Not authorized to modify this application");
  if (draft.status !== "DRAFT") throw new ApiError(409, "This application has already been submitted and can no longer be edited");
  return draft;
}

/**
 * Step 1 — Sovereign Identity Verification. Creates the draft. Reachable
 * only by GOVERNMENT accounts with email verified AND MFA already enabled
 * (see blockUnverifiedGovernment, mounted router-wide above) -- consistent
 * with "MFA is mandatory for all government users", applied from the very
 * first step rather than only at final activation.
 */
governmentRouter.post(
  "/draft",
  upload.fields([
    { name: "sovereignStatusLetter", maxCount: 1 },
    { name: "entityRegistrationDoc", maxCount: 1 },
  ]),
  asyncHandler(async (req, res) => {
    const requester = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { accountCategory: true } });
    if (requester?.accountCategory !== "GOVERNMENT") {
      throw new ApiError(403, "This pathway is only available to Government/Sovereign accounts.");
    }

    const body = governmentStep1Schema.parse(req.body);
    const files = (req.files as Record<string, Express.Multer.File[]> | undefined) ?? {};
    if (!files.sovereignStatusLetter?.[0]) throw new ApiError(400, "Letter of Sovereign Status is required.");
    if (!files.entityRegistrationDoc?.[0]) throw new ApiError(400, "Entity Registration Document is required.");

    const draft = await prisma.$transaction(async (tx) => {
      const created = await tx.kybSubmission.create({
        data: {
          userId: req.user!.id,
          companyName: body.entityName,
          registrationNo: body.registrationNo,
          email: body.officialEmail,
          phone: body.officialPhone,
          countries: body.countryCode,
          // See government submission notes elsewhere: Step 1 doesn't
          // collect a street address, so this reuses the shared column as
          // a descriptor composed from real submitted data.
          address: `${body.entityName}, ${body.countryCode}`,
          status: "DRAFT",
        },
      });
      for (const [field, fileArr] of Object.entries(files)) {
        const file = fileArr[0];
        const stored = await uploadFile(file.buffer, file.originalname, file.mimetype);
        await tx.document.create({
          data: {
            userId: req.user!.id,
            kybSubmissionId: created.id,
            fileName: file.originalname,
            storageKey: stored.storageKey,
            mimeType: file.mimetype,
            sizeBytes: file.size,
            docCategory: field,
          },
        });
      }
      return created;
    });

    await logAdminAction({
      adminId: req.user!.id,
      action: "government.step1_completed",
      entityType: "KybSubmission",
      entityId: draft.id,
      entityName: draft.companyName,
    });

    res.status(201).json({ id: draft.id, status: draft.status });
  })
);

/** Step 2 — Facility Security Clearance. */
governmentRouter.patch(
  "/draft/:id/fsc",
  upload.fields([
    { name: "fscCertificate", maxCount: 1 },
    { name: "fscJustification", maxCount: 1 },
  ]),
  asyncHandler(async (req, res) => {
    await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    const body = governmentStep2Schema.parse(req.body);
    const files = (req.files as Record<string, Express.Multer.File[]> | undefined) ?? {};

    if (!body.fscReferenceNumber && !body.fscJustificationProvided) {
      throw new ApiError(400, "Either an FSC reference number or a justification document is required.");
    }
    if (!files.fscCertificate?.[0] && !files.fscJustification?.[0]) {
      throw new ApiError(400, "Either an FSC Certificate or a justification document must be uploaded.");
    }

    await prisma.$transaction(async (tx) => {
      await tx.kybSubmission.update({
        where: { id: req.params.id },
        data: {
          fscLevel: body.fscLevel,
          fscIssuingAuthority: body.fscIssuingAuthority,
          fscIssueDate: new Date(body.fscIssueDate),
          fscExpiryDate: new Date(body.fscExpiryDate),
          fscReferenceNumber: body.fscReferenceNumber,
          fscJustificationProvided: body.fscJustificationProvided,
        },
      });
      for (const [field, fileArr] of Object.entries(files)) {
        const file = fileArr[0];
        const stored = await uploadFile(file.buffer, file.originalname, file.mimetype);
        await tx.document.create({
          data: {
            userId: req.user!.id,
            kybSubmissionId: req.params.id,
            fileName: file.originalname,
            storageKey: stored.storageKey,
            mimeType: file.mimetype,
            sizeBytes: file.size,
            docCategory: field,
          },
        });
      }
    });

    await logAdminAction({ adminId: req.user!.id, action: "government.step2_completed", entityType: "KybSubmission", entityId: req.params.id });
    res.json({ id: req.params.id, step: 2, saved: true });
  })
);

/**
 * Step 3 — Personnel Security Clearance. Called once per person as the
 * applicant adds them in the dynamic UI, so each entry saves immediately
 * rather than waiting for the whole list to be submitted at once.
 */
governmentRouter.post(
  "/draft/:id/personnel",
  asyncHandler(async (req, res) => {
    await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    const body = governmentPersonnelSchema.parse(req.body);

    const person = await prisma.governmentPersonnel.create({
      data: {
        kybSubmissionId: req.params.id,
        fullName: body.fullName,
        officialTitle: body.officialTitle,
        userRole: body.userRole,
        pscLevel: body.pscLevel,
        pscIssuingAuthority: body.pscIssuingAuthority,
        pscIssueDate: new Date(body.pscIssueDate),
        pscExpiryDate: new Date(body.pscExpiryDate),
      },
    });

    await logAdminAction({
      adminId: req.user!.id,
      action: "government.personnel_added",
      entityType: "KybSubmission",
      entityId: req.params.id,
      notes: `${body.fullName} (${body.userRole})`,
    });

    res.status(201).json(person);
  })
);

governmentRouter.delete(
  "/draft/:id/personnel/:personnelId",
  asyncHandler(async (req, res) => {
    await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    await prisma.governmentPersonnel.delete({ where: { id: req.params.personnelId } }).catch(() => {
      throw new ApiError(404, "Personnel entry not found");
    });
    res.status(204).end();
  })
);

/** Step 4 — Need-to-Know Access Protocols. */
governmentRouter.patch(
  "/draft/:id/access",
  asyncHandler(async (req, res) => {
    await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    const body = governmentStep4Schema.parse(req.body);

    await prisma.kybSubmission.update({
      where: { id: req.params.id },
      data: {
        dataClassificationPolicy: body.dataClassificationPolicy,
        securityOfficerName: body.securityOfficerName,
      },
    });

    await logAdminAction({ adminId: req.user!.id, action: "government.step4_completed", entityType: "KybSubmission", entityId: req.params.id });
    res.json({ id: req.params.id, step: 4, saved: true });
  })
);

/**
 * Step 5 — Legal Framework Subscription. Accepts ONE framework per call
 * (the UI checks a box, this fires immediately) so each acceptance gets
 * its own real timestamp -- see SovereignFrameworkAcceptance's doc comment
 * on why this project never records a single bundled "accepted everything"
 * click.
 */
governmentRouter.post(
  "/draft/:id/frameworks/:key/accept",
  asyncHandler(async (req, res) => {
    await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    const key = req.params.key as (typeof SOVEREIGN_FRAMEWORK_KEYS)[number];
    if (!SOVEREIGN_FRAMEWORK_KEYS.includes(key)) throw new ApiError(400, "Unknown framework key");

    const acceptance = await prisma.sovereignFrameworkAcceptance.upsert({
      where: { kybSubmissionId_frameworkKey: { kybSubmissionId: req.params.id, frameworkKey: key } },
      create: { kybSubmissionId: req.params.id, frameworkKey: key, ipAddress: req.ip },
      update: { acceptedAt: new Date(), ipAddress: req.ip },
    });

    res.status(201).json(acceptance);
  })
);

/** Step 6 — Final Verification & Activation. Read-only summary for the review screen. */
governmentRouter.get(
  "/draft/:id",
  asyncHandler(async (req, res) => {
    const draft = await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);
    res.json(draft);
  })
);

/**
 * Step 6 submit. Validates completeness of everything collected across
 * Steps 1–5, flips DRAFT → PENDING (now visible to admins for the first
 * time), and fires the same notification/audit pipeline as the Standard
 * and Corporate pathways.
 */
governmentRouter.post(
  "/draft/:id/submit",
  asyncHandler(async (req, res) => {
    const draft = await loadOwnedDraft(req.params.id, req.user!.id, req.user!.role);

    if (!draft.fscLevel) throw new ApiError(400, "Step 2 (Facility Security Clearance) is not complete.");
    if (!draft.securityOfficerName) throw new ApiError(400, "Step 4 (Access Control) is not complete.");
    if (draft.personnel.length < 2) throw new ApiError(400, "At least 2 personnel are required (Step 3).");
    if (!draft.personnel.some((p) => p.userRole === "SOVEREIGN_ADMIN")) {
      throw new ApiError(400, "At least one listed person must have the Sovereign Administrator role (Step 3).");
    }
    if (draft.frameworkAcceptances.length < SOVEREIGN_FRAMEWORK_KEYS.length) {
      throw new ApiError(400, "All five legal frameworks must be accepted (Step 5).");
    }

    const submission = await prisma.kybSubmission.update({ where: { id: draft.id }, data: { status: "PENDING" } });

    await logAdminAction({
      adminId: req.user!.id,
      action: "government.submitted_for_review",
      entityType: "KybSubmission",
      entityId: submission.id,
      entityName: submission.companyName,
    });
    await notifyAdminsOfNewSubmission(submission.companyName, submission.id);

    res.json(submission);
  })
);

// ---- Admin: Government-specific queue view ----
governmentRouter.get(
  "/admin/queue",
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const submissions = await prisma.kybSubmission.findMany({
      where: { status: { in: ["PENDING", "IN_REVIEW"] }, user: { accountCategory: "GOVERNMENT" } },
      include: { personnel: true, frameworkAcceptances: true, user: { select: { name: true, email: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json(submissions);
  })
);
