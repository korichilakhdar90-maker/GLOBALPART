import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { companyQuerySchema } from "../utils/validation.js";
import { cached } from "../lib/cache.js";
import { requireAuth } from "../middleware/auth.js";
import type { Prisma } from "@prisma/client";

export const companiesRouter = Router();

companiesRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const q = companyQuerySchema.parse(req.query);
    const countryCodes = q.countryCodes ? q.countryCodes.split(",").filter(Boolean) : [];

    const where: Prisma.CompanyWhereInput = {
      ...(q.industry && q.industry !== "All" ? { industry: q.industry } : {}),
      ...(countryCodes.length ? { countryCode: { in: countryCodes } } : {}),
      ...(q.region && q.region !== "All" ? { region: q.region } : {}),
      ...(q.minTrust ? { trustScore: { gte: q.minTrust } } : {}),
      ...(q.verifiedOnly ? { verified: true } : {}),
      ...(q.search
        ? {
            OR: [
              { name: { contains: q.search, mode: "insensitive" } },
              { description: { contains: q.search, mode: "insensitive" } },
              { industry: { contains: q.search, mode: "insensitive" } },
              { countryName: { contains: q.search, mode: "insensitive" } },
            ],
          }
        : {}),
    };

    // Cache key encodes every filter so different searches never collide;
    // short 30s TTL keeps results fresh while still absorbing bursts of
    // identical requests (e.g. many visitors browsing the default view).
    const cacheKey = `companies:${JSON.stringify(q)}`;
    const result = await cached(cacheKey, 30, async () => {
      const [items, total] = await Promise.all([
        prisma.company.findMany({
          where,
          orderBy: [{ verified: "desc" }, { trustScore: "desc" }],
          skip: (q.page - 1) * q.perPage,
          take: q.perPage,
        }),
        prisma.company.count({ where }),
      ]);
      return { items, total, page: q.page, perPage: q.perPage, totalPages: Math.max(1, Math.ceil(total / q.perPage)) };
    });

    res.json(result);
  })
);

companiesRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const company = await prisma.company.findUnique({ where: { id: req.params.id } });
    if (!company) throw new ApiError(404, "Company not found");
    res.json(company);
  })
);

/**
 * "Claim Profile" -- step one of two. This only marks the profile as
 * claim-in-progress (locks it from being claimed by someone else in
 * parallel); it does NOT grant Verified Partner status. Step two is
 * mandatory: the user must submit a full KYB application referencing this
 * company (POST /api/kyb with claimedCompanyId), which only flips
 * profileStatus to VERIFIED_PARTNER once a reviewer approves it (see the
 * approval transaction in kyb.routes.ts). Directory Listed → claiming does
 * not skip strict KYB, ever.
 */
companiesRouter.post(
  "/:id/claim",
  requireAuth,
  asyncHandler(async (req, res) => {
    const company = await prisma.company.findUnique({ where: { id: req.params.id } });
    if (!company) throw new ApiError(404, "Company not found");
    if (company.profileStatus === "VERIFIED_PARTNER") {
      throw new ApiError(409, "This profile is already a Verified Partner and cannot be claimed again.");
    }
    if (company.claimedByUserId && company.claimedByUserId !== req.user!.id) {
      throw new ApiError(409, "This profile is already being claimed by another user.");
    }

    const updated = await prisma.company.update({
      where: { id: company.id },
      data: { claimedByUserId: req.user!.id, claimedAt: new Date() },
    });
    res.json({
      companyId: updated.id,
      claimed: true,
      nextStep: "Submit KYB verification (POST /api/kyb) with claimedCompanyId set to this company's id to complete the claim.",
    });
  })
);
