import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { tradeSignalQuerySchema, tradeSignalCreateSchema } from "../utils/validation.js";
import { cached, cacheInvalidate } from "../lib/cache.js";

// Trade Signal Exchange (product notes, feature #2): a small, honestly
// sourced dashboard of market indicators (shipping rates, demand shifts,
// tariff changes). Every row requires sourceName + sourceUrl + asOf at the
// database level (see schema.prisma) so nothing here can be a made-up
// number — only an admin (today) or an automated import job (later) can
// publish a signal, and it always carries where it came from and when.
export const tradeSignalsRouter = Router();

tradeSignalsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const q = tradeSignalQuerySchema.parse(req.query);
    const where = {
      ...(q.category ? { category: q.category } : {}),
      ...(q.countryCode ? { countryCode: q.countryCode } : {}),
    };

    const cacheKey = `signals:${JSON.stringify(q)}`;
    const result = await cached(cacheKey, 120, async () => {
      const [items, total] = await Promise.all([
        prisma.tradeSignal.findMany({
          where,
          orderBy: { asOf: "desc" },
          skip: (q.page - 1) * q.perPage,
          take: q.perPage,
        }),
        prisma.tradeSignal.count({ where }),
      ]);
      return { items, total, page: q.page, perPage: q.perPage, totalPages: Math.max(1, Math.ceil(total / q.perPage)) };
    });

    res.json(result);
  })
);

tradeSignalsRouter.post(
  "/",
  requireAuth,
  requireAdmin,
  asyncHandler(async (req, res) => {
    const body = tradeSignalCreateSchema.parse(req.body);
    const signal = await prisma.tradeSignal.create({ data: body });
    cacheInvalidate("signals:");
    res.status(201).json(signal);
  })
);

tradeSignalsRouter.delete(
  "/:id",
  requireAuth,
  requireAdmin,
  asyncHandler(async (req, res) => {
    const existing = await prisma.tradeSignal.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Trade signal not found");
    await prisma.tradeSignal.delete({ where: { id: req.params.id } });
    cacheInvalidate("signals:");
    res.status(204).end();
  })
);
