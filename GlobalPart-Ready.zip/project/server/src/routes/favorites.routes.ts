import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/errorHandler.js";

export const favoritesRouter = Router();
favoritesRouter.use(requireAuth);

favoritesRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const favorites = await prisma.favorite.findMany({
      where: { userId: req.user!.id },
      include: { company: true },
      orderBy: { createdAt: "desc" },
    });
    res.json(favorites.map((f) => f.company));
  })
);

favoritesRouter.post(
  "/:companyId",
  asyncHandler(async (req, res) => {
    await prisma.favorite.upsert({
      where: { userId_companyId: { userId: req.user!.id, companyId: req.params.companyId } },
      create: { userId: req.user!.id, companyId: req.params.companyId },
      update: {},
    });
    res.status(201).json({ favorited: true });
  })
);

favoritesRouter.delete(
  "/:companyId",
  asyncHandler(async (req, res) => {
    await prisma.favorite
      .delete({ where: { userId_companyId: { userId: req.user!.id, companyId: req.params.companyId } } })
      .catch(() => {}); // idempotent — already-removed is not an error
    res.status(204).end();
  })
);
