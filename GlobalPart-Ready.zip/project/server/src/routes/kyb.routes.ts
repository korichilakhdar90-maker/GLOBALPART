import { Router } from "express";
import multer from "multer";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { kybSubmitSchema, kybReviewSchema } from "../utils/validation.js";
import { uploadFile, getFileUrl } from "../lib/storage.js";
import { runProviderVerification } from "../services/kyb.service.js";
import { syncFromKybApprovalInTx } from "../services/trustScore.service.js";
import { notifyUser, notifyAdminsOfNewSubmission, logAdminAction } from "../services/notification.service.js";
import { simulateGovernmentSystemSubmission } from "../services/governmentGateway.service.js";
import { requireVerifiedEmail, blockUnverifiedGovernment } from "../middleware/accountPolicy.js";

export const kybRouter = Router();
const upload = multer({ limits: { fileSize: 15 * 1024 * 1024 } }); // 15MB per file

kybRouter.use(requireAuth);
kybRouter.use(blockUnverifiedGovernment); // no-op for Standard/Enterprise; blocks Government until email+MFA done

kybRouter.post(
  "/",
  requireVerifiedEmail, // Standard/Corporate: "cannot submit a full application without email verification"
  upload.array("documents", 10),
  asyncHandler(async (req, res) => {
    const body = kybSubmitSchema.parse(req.body);
    const files = (req.files as Express.Multer.File[] | undefined) ?? [];

    // If this submission is claiming an existing Directory Listed company,
    // confirm the claim actually belongs to this user (set via POST
    // /api/companies/:id/claim) before linking the submission to it --
    // otherwise anyone could KYB-verify themselves into someone else's
    // unclaimed profile.
    if (body.claimedCompanyId) {
      const claimedCompany = await prisma.company.findUnique({ where: { id: body.claimedCompanyId } });
      if (!claimedCompany) throw new ApiError(404, "Claimed company not found");
      if (claimedCompany.profileStatus === "VERIFIED_PARTNER") {
        throw new ApiError(409, "This profile is already a Verified Partner.");
      }
      if (claimedCompany.claimedByUserId !== req.user!.id) {
        throw new ApiError(403, "Call POST /api/companies/:id/claim for this company before submitting KYB for it.");
      }
    }

    // Try automated provider verification first (no-op if not configured);
    // the submission proceeds to human review regardless of the outcome.
    const providerResult = await runProviderVerification({
      companyName: body.companyName,
      registrationNo: body.registrationNo,
      countries: body.countries,
    }).catch((err) => {
      console.error("KYB provider verification failed, continuing with human review:", err);
      return null;
    });

    const submission = await prisma.kybSubmission.create({
      data: {
        userId: req.user!.id,
        companyId: body.claimedCompanyId,
        companyName: body.companyName,
        registrationNo: body.registrationNo,
        email: body.email,
        phone: body.phone,
        countries: body.countries,
        address: body.address,
        status: "PENDING",
        providerRef: providerResult?.providerRef,
        providerRaw: providerResult?.raw as never,
      },
    });

    for (const file of files) {
      const stored = await uploadFile(file.buffer, file.originalname, file.mimetype);
      await prisma.document.create({
        data: {
          userId: req.user!.id,
          kybSubmissionId: submission.id,
          fileName: file.originalname,
          storageKey: stored.storageKey,
          mimeType: file.mimetype,
          sizeBytes: file.size,
        },
      });
    }

    // Requirement: "when a new application is submitted, send a
    // notification to all admins." In-app only (see notification.service.ts
    // doc comment) -- admins work from the queue, not their inbox, for
    // volume like this.
    await notifyAdminsOfNewSubmission(submission.companyName, submission.id);

    res.status(201).json(submission);
  })
);

kybRouter.get(
  "/mine",
  asyncHandler(async (req, res) => {
    const submissions = await prisma.kybSubmission.findMany({
      where: { userId: req.user!.id },
      include: { documents: true, personnel: true, frameworkAcceptances: true },
      orderBy: { createdAt: "desc" },
    });
    // Resolve a download URL per document so "My Dashboard" (view/download,
    // requirement 7) doesn't need a second round-trip per file.
    const withUrls = await Promise.all(
      submissions.map(async (s) => ({
        ...s,
        documents: await Promise.all(s.documents.map(async (d) => ({ ...d, url: await getFileUrl(d.storageKey) }))),
      }))
    );
    res.json(withUrls);
  })
);

kybRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const submission = await prisma.kybSubmission.findUnique({
      where: { id: req.params.id },
      include: { documents: true },
    });
    if (!submission) throw new ApiError(404, "Submission not found");
    if (submission.userId !== req.user!.id && req.user!.role !== "ADMIN") {
      throw new ApiError(403, "Not authorized to view this submission");
    }
    const documents = await Promise.all(
      submission.documents.map(async (d) => ({ ...d, url: await getFileUrl(d.storageKey) }))
    );
    res.json({ ...submission, documents });
  })
);

// ---- Admin review workflow ----

kybRouter.get(
  "/",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const status = req.query.status as string | undefined;
    const submissions = await prisma.kybSubmission.findMany({
      where: status ? { status: status as never } : undefined,
      include: { user: { select: { name: true, email: true, accountCategory: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json(submissions);
  })
);

// Trust Score formula (Year-1, human-reviewed model — see kyb.methodology.*
// on the frontend for the public-facing explanation). Branches by account
// tier because Standard, Corporate, and Sovereign applicants go through
// genuinely different verification depth, so a single flat formula can't
// honestly represent all three:
//
//   Standard (INDIVIDUAL): base 50, +10 per completed step out of the 5
//     tracked below, +5 per uploaded document up to +20 max.
//   Corporate (ENTERPRISE): base 30, +20 financial audit completed,
//     +15 certifications verified, +25 PEP/Sanctions screening CLEAR.
//   Sovereign (GOVERNMENT): weighted, starts at 0 —
//     Diplomatic Verification 40 + FSC Validation 30 + PSC Validation 20
//     + Legal Frameworks 10 = 100 max. Every component except Legal
//     Frameworks requires an explicit admin sign-off (fscValidated,
//     pscAllValidated, diplomaticVerificationCompleted) — none of it is
//     inferred just because the applicant filled in a form field, per the
//     "no autonomous decisions" principle. Legal Frameworks is the one
//     purely-computed component: it's just "did they accept all 5",
//     which is objectively checkable from SovereignFrameworkAcceptance
//     rows without needing a human judgment call.
type Tier = "INDIVIDUAL" | "ENTERPRISE" | "GOVERNMENT";
const REQUIRED_SOVEREIGN_FRAMEWORKS = 5;

function computeTrustScore(
  tier: Tier,
  input: {
    bankAccountVerified: boolean;
    physicalAddressConfirmed: boolean;
    documentCount: number;
    financialAuditCompleted: boolean;
    certificationsVerified: boolean;
    pepScreeningStatus: "NOT_STARTED" | "PENDING" | "CLEAR" | "FLAGGED";
    diplomaticVerificationCompleted: boolean;
    fscValidated: boolean;
    pscAllValidated: boolean;
    acceptedFrameworksCount: number;
  }
): number {
  if (tier === "GOVERNMENT") {
    let score = 0;
    if (input.diplomaticVerificationCompleted) score += 40;
    if (input.fscValidated) score += 30;
    if (input.pscAllValidated) score += 20;
    if (input.acceptedFrameworksCount >= REQUIRED_SOVEREIGN_FRAMEWORKS) score += 10;
    return score;
  }

  if (tier === "ENTERPRISE") {
    let score = 30;
    if (input.financialAuditCompleted) score += 20;
    if (input.certificationsVerified) score += 15;
    if (input.pepScreeningStatus === "CLEAR") score += 25;
    return Math.min(score, 100);
  }

  // Standard (INDIVIDUAL). The 5 tracked steps are the fields this tier's
  // KYB form actually collects — registration number, official email,
  // phone, address, and independently-verified bank account — rather than
  // an arbitrary count, so "10 points per step" always traces back to a
  // real completed field.
  const stepsCompleted = 1 /* registrationNo */ + 1 /* email */ + 1 /* phone */ + 1 /* address */ + (input.bankAccountVerified ? 1 : 0);
  let score = 50 + stepsCompleted * 10;
  score += Math.min(input.documentCount * 5, 20);
  return Math.min(score, 100);
}

/**
 * "Review" button: claims this submission for the currently logged-in
 * admin and moves status PENDING → IN_REVIEW. Distinct from the final
 * approve/reject decision below -- an application can be assigned and
 * still sit IN_REVIEW for a while before anyone approves or rejects it.
 */
kybRouter.post(
  "/:id/assign",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const existing = await prisma.kybSubmission.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Submission not found");
    if (existing.status !== "PENDING" && existing.status !== "IN_REVIEW") {
      throw new ApiError(409, `Cannot assign a submission that is already ${existing.status}`);
    }

    const updated = await prisma.kybSubmission.update({
      where: { id: existing.id },
      data: { status: "IN_REVIEW", assignedToId: req.user!.id, assignedAt: new Date() },
    });

    await logAdminAction({
      adminId: req.user!.id,
      action: "kyb.assigned",
      entityType: "KybSubmission",
      entityId: updated.id,
      entityName: updated.companyName,
    });

    await notifyUser({
      userId: updated.userId,
      userEmail: updated.email,
      type: "KYB_ASSIGNED",
      title: "Your application is now under review",
      body: `Your KYB application for ${updated.companyName} is being reviewed by our team.`,
      kybSubmissionId: updated.id,
    });

    res.json(updated);
  })
);

kybRouter.patch(
  "/:id/review",
  requireAdmin,
  asyncHandler(async (req, res) => {
    const body = kybReviewSchema.parse(req.body);
    const bankAccountVerified = body.bankAccountVerified ?? false;
    const physicalAddressConfirmed = body.physicalAddressConfirmed ?? false;
    const financialAuditCompleted = body.financialAuditCompleted ?? false;
    const certificationsVerified = body.certificationsVerified ?? false;
    const pepScreeningStatus = body.pepScreeningStatus ?? "NOT_STARTED";
    const diplomaticVerificationCompleted = body.diplomaticVerificationCompleted ?? false;
    const diplomaticVerificationNotes = body.diplomaticVerificationNotes;
    const fscValidated = body.fscValidated ?? false;
    const pscAllValidated = body.pscAllValidated ?? false;

    const existing = await prisma.kybSubmission.findUnique({
      where: { id: req.params.id },
      include: { documents: true, frameworkAcceptances: true, user: { select: { accountCategory: true } } },
    });
    if (!existing) throw new ApiError(404, "Submission not found");

    if (body.status === "APPROVED") {
      // Feature 1: the audit + verified badge is the paid product for
      // Standard/Corporate applicants. Sovereign approval is a government
      // vetting decision, not a paid subscription product -- gating it
      // behind Trust Badge billing would be wrong, so it's excluded here.
      if (existing.user.accountCategory !== "GOVERNMENT") {
        const badge = await prisma.trustBadgeSubscription.findUnique({ where: { userId: existing.userId } });
        if (badge?.status !== "active") {
          throw new ApiError(
            402,
            "This applicant does not have an active Verified Trust Badge subscription. Ask them to subscribe before approving."
          );
        }
      }
    }

    const tier = existing.user.accountCategory as Tier;
    const trustScore =
      body.status === "APPROVED"
        ? computeTrustScore(tier, {
            bankAccountVerified,
            physicalAddressConfirmed,
            documentCount: existing.documents.length,
            financialAuditCompleted,
            certificationsVerified,
            pepScreeningStatus,
            diplomaticVerificationCompleted,
            fscValidated,
            pscAllValidated,
            acceptedFrameworksCount: existing.frameworkAcceptances.length,
          })
        : undefined;

    const submission = await prisma.$transaction(async (tx) => {
      const updated = await tx.kybSubmission.update({
        where: { id: req.params.id },
        data: {
          status: body.status,
          reviewNotes: body.reviewNotes,
          rejectionReason: body.status === "REJECTED" ? body.rejectionReason : undefined,
          bankAccountVerified,
          physicalAddressConfirmed,
          financialAuditCompleted,
          certificationsVerified,
          pepScreeningStatus,
          pepScreeningNotes: body.pepScreeningNotes,
          diplomaticVerificationCompleted,
          diplomaticVerificationNotes,
          fscValidated,
          pscAllValidated,
          trustScore,
          reviewedById: req.user!.id,
          reviewedAt: new Date(),
          // A final decision clears the "in progress" assignment -- the
          // submission is no longer being worked on, it's done.
          assignedToId: null,
          assignedAt: null,
        },
      });


      // Explainable Trust Score sync: same transaction as the submission
      // update above, so an approval can never leave the legacy
      // KybSubmission.trustScore field and the new, versioned
      // TrustAssessment/Company.trustScore out of sync with each other —
      // either both commit or neither does. Only runs once this
      // submission is linked to a Company directory row; see
      // prisma/migrations/20260809140000_kyb_submission_company_link.
      if (body.status === "APPROVED" && updated.companyId) {
        await syncFromKybApprovalInTx(tx, {
          companyId: updated.companyId,
          bankAccountVerified,
          physicalAddressConfirmed,
        });
      }

      // An approved KYB submission is what unblocks an ENTERPRISE account
      // out of PENDING_KYB. Scoped with the accountStatus check so this
      // never touches an account that's already ACTIVE/SUSPENDED or a
      // non-enterprise category for an unrelated reason.
      if (body.status === "APPROVED") {
        await tx.user.updateMany({
          where: { id: updated.userId, accountCategory: "ENTERPRISE", accountStatus: "PENDING_KYB" },
          data: { accountStatus: "ACTIVE" },
        });
      }

      // Claimable Profiles: an approved KYB submission linked to a
      // Directory Listed company (see companies.routes.ts POST /:id/claim)
      // is exactly what upgrades it to Verified Partner. `verified` is
      // updated in the same write so the two never disagree.
      if (updated.companyId) {
        if (body.status === "APPROVED") {
          await tx.company.update({
            where: { id: updated.companyId },
            data: { profileStatus: "VERIFIED_PARTNER", verified: true },
          });
        } else if (body.status === "REJECTED") {
          // Release the claim lock so someone else (or the same user,
          // later, with corrected documents) can claim this profile again.
          await tx.company.update({
            where: { id: updated.companyId },
            data: { claimedByUserId: null, claimedAt: null },
          });
        }
      }

      return updated;
    });

    await logAdminAction({
      adminId: req.user!.id,
      action: body.status === "APPROVED" ? "kyb.approved" : "kyb.rejected",
      entityType: "KybSubmission",
      entityId: submission.id,
      entityName: submission.companyName,
      notes: body.status === "REJECTED" ? body.rejectionReason : body.reviewNotes,
    });

    await notifyUser({
      userId: submission.userId,
      userEmail: submission.email,
      type: body.status === "APPROVED" ? "KYB_APPROVED" : "KYB_REJECTED",
      title: body.status === "APPROVED" ? "Your application has been approved" : "Your application was not approved",
      body:
        body.status === "APPROVED"
          ? `Congratulations — ${submission.companyName} is now a Verified Partner on GlobalPart.`
          : `Your KYB application for ${submission.companyName} was rejected. Reason: ${body.rejectionReason}`,
      kybSubmissionId: submission.id,
      // Selects the fully-branded approval/rejection template (with CTA)
      // rather than the generic status fallback -- see notifyUser.
      companyName: submission.companyName,
      rejectionReason: body.rejectionReason,
    });

    // 🛑 LIVE SYSTEM PLACEHOLDER — see governmentGateway.service.ts. Only
    // generates a simulated, clearly-labeled confirmation; nothing is
    // transmitted to any real government system.
    const gatewaySimulation =
      body.status === "APPROVED" && tier === "GOVERNMENT" ? simulateGovernmentSystemSubmission(submission.id) : undefined;

    res.json({ ...submission, gatewaySimulation });
  })
);
