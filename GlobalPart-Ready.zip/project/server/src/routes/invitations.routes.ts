import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { requireVerifiedEmail, blockUnverifiedGovernment } from "../middleware/accountPolicy.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { invitationCreateSchema } from "../utils/validation.js";
import { sendEmail } from "../lib/email.js";
import { partnerInvitationEmail } from "../lib/email/templates.js";
import { notifyUser, notifyAdminsOfNewSubmission } from "../services/notification.service.js";
import { generateOneTimeToken } from "../lib/jwt.js";

export const invitationsRouter = Router();

const INVITE_TTL_DAYS = 30;
/** Credit granted to the inviter when an invitation is actually accepted (not merely sent). */
const REFERRAL_REWARD_CENTS = 5000; // $50.00
/** Sending more than this many invitations flags the account for admin review. */
const ABUSE_ALERT_THRESHOLD = 25;

invitationsRouter.use(requireAuth);
invitationsRouter.use(blockUnverifiedGovernment);

/** Lazily marks a PENDING invitation EXPIRED once its expiry has passed. */
function withExpiry<T extends { status: string; expiresAt: Date }>(inv: T): T {
  if (inv.status === "PENDING" && inv.expiresAt < new Date()) {
    return { ...inv, status: "EXPIRED" };
  }
  return inv;
}

/**
 * Create an invitation. Requires a verified email: without that gate, an
 * unverified account could mass-send branded GlobalPart emails to
 * arbitrary addresses, which is a spam vector, not a growth loop.
 */
invitationsRouter.post(
  "/",
  requireVerifiedEmail,
  asyncHandler(async (req, res) => {
    const body = invitationCreateSchema.parse(req.body);
    const inviter = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { name: true, company: true, email: true } });
    if (!inviter) throw new ApiError(404, "User not found");

    if (body.inviteeEmail.toLowerCase() === inviter.email.toLowerCase()) {
      throw new ApiError(400, "You can't invite your own account.");
    }

    // An already-registered address can't be "invited" -- otherwise the
    // reward could be farmed by inviting existing users.
    const alreadyRegistered = await prisma.user.findUnique({ where: { email: body.inviteeEmail } });
    if (alreadyRegistered) throw new ApiError(409, "That email already belongs to a GlobalPart account.");

    const existingOpen = await prisma.partnerInvitation.findFirst({
      where: { inviterId: req.user!.id, inviteeEmail: body.inviteeEmail, status: "PENDING", expiresAt: { gt: new Date() } },
    });
    if (existingOpen) throw new ApiError(409, "You already have an open invitation to that address.");

    const token = generateOneTimeToken();
    const invitation = await prisma.partnerInvitation.create({
      data: {
        inviterId: req.user!.id,
        inviteeEmail: body.inviteeEmail,
        inviteeType: body.inviteeType,
        token,
        expiresAt: new Date(Date.now() + INVITE_TTL_DAYS * 24 * 60 * 60 * 1000),
      },
    });

    const link = `${env.APP_URL}/invite/${token}`;
    const rendered = partnerInvitationEmail({
      inviterName: inviter.company || inviter.name,
      invitedCompany: body.inviteeEmail,
      link,
    });
    // Don't fail the request if the email bounces -- the invitation row
    // and its link are already valid, and the inviter can copy the link
    // manually from the UI.
    await sendEmail({ to: body.inviteeEmail, subject: rendered.subject, html: rendered.html }).catch((err) => {
      console.error("Invitation email failed to send (invitation itself was still created):", err);
    });

    const sentCount = await prisma.partnerInvitation.count({ where: { inviterId: req.user!.id } });
    if (sentCount === ABUSE_ALERT_THRESHOLD) {
      // Fires once, exactly at the threshold, rather than on every send
      // past it -- otherwise a heavy inviter would spam the admin queue.
      await notifyAdminsOfNewSubmission(
        `${inviter.company || inviter.name} has sent ${sentCount} partner invitations`,
        invitation.id
      ).catch(() => {});
    }

    res.status(201).json({ ...invitation, link });
  })
);

/** The caller's own sent invitations, plus their current referral credit balance. */
invitationsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const invitations = await prisma.partnerInvitation.findMany({
      where: { inviterId: req.user!.id },
      orderBy: { createdAt: "desc" },
    });

    const credits = await prisma.referralCredit.aggregate({
      where: { userId: req.user!.id },
      _sum: { amountCents: true },
    });

    res.json({
      invitations: invitations.map((inv) => ({ ...withExpiry(inv), link: `${env.APP_URL}/invite/${inv.token}` })),
      creditBalanceCents: credits._sum.amountCents ?? 0,
    });
  })
);

/**
 * Accept an invitation. Called by the *invitee* after they've registered
 * (the token travels with them through signup via /invite/:token on the
 * frontend), which is why this requires auth rather than being public:
 * the reward must attach to a real, registered account, not to whoever
 * happens to open the link.
 */
invitationsRouter.post(
  "/:token/accept",
  asyncHandler(async (req, res) => {
    const invitation = await prisma.partnerInvitation.findUnique({ where: { token: req.params.token } });
    if (!invitation) throw new ApiError(404, "Invitation not found");
    if (invitation.status === "REVOKED") throw new ApiError(409, "This invitation was revoked by the sender.");
    if (invitation.status === "ACCEPTED") throw new ApiError(409, "This invitation has already been accepted.");
    if (invitation.expiresAt < new Date()) {
      await prisma.partnerInvitation.update({ where: { id: invitation.id }, data: { status: "EXPIRED" } });
      throw new ApiError(410, "This invitation has expired.");
    }
    if (invitation.inviterId === req.user!.id) throw new ApiError(400, "You can't accept your own invitation.");

    const accepter = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { email: true, name: true } });
    if (!accepter) throw new ApiError(404, "User not found");
    // Binding the reward to the invited address specifically is what stops
    // a leaked link from being redeemed by an unrelated account.
    if (accepter.email.toLowerCase() !== invitation.inviteeEmail.toLowerCase()) {
      throw new ApiError(403, "This invitation was issued to a different email address.");
    }

    const [updated] = await prisma.$transaction([
      prisma.partnerInvitation.update({
        where: { id: invitation.id },
        data: { status: "ACCEPTED", acceptedAt: new Date(), acceptedById: req.user!.id },
      }),
      prisma.referralCredit.create({
        data: {
          userId: invitation.inviterId,
          amountCents: REFERRAL_REWARD_CENTS,
          reason: "invitation_accepted",
          invitationId: invitation.id,
        },
      }),
    ]);

    const inviter = await prisma.user.findUnique({ where: { id: invitation.inviterId }, select: { email: true } });
    if (inviter) {
      await notifyUser({
        userId: invitation.inviterId,
        userEmail: inviter.email,
        type: "INVITATION_ACCEPTED",
        title: "Your invitation was accepted",
        body: `${accepter.name} accepted your invitation. $${(REFERRAL_REWARD_CENTS / 100).toFixed(2)} in verification credit has been added to your account.`,
      }).catch(() => {});
    }

    res.json(updated);
  })
);

invitationsRouter.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const invitation = await prisma.partnerInvitation.findUnique({ where: { id: req.params.id } });
    if (!invitation) throw new ApiError(404, "Invitation not found");
    if (invitation.inviterId !== req.user!.id) throw new ApiError(403, "Not authorized to revoke this invitation");
    if (invitation.status === "ACCEPTED") throw new ApiError(409, "An accepted invitation can't be revoked.");

    await prisma.partnerInvitation.update({ where: { id: invitation.id }, data: { status: "REVOKED" } });
    res.status(204).end();
  })
);

/** Public: lets the frontend show who invited you before you register. */
invitationsRouter.get(
  "/:token/preview",
  asyncHandler(async (req, res) => {
    const invitation = await prisma.partnerInvitation.findUnique({
      where: { token: req.params.token },
      include: { inviter: { select: { name: true, company: true } } },
    });
    if (!invitation) throw new ApiError(404, "Invitation not found");
    res.json({
      inviterName: invitation.inviter.company || invitation.inviter.name,
      inviteeEmail: invitation.inviteeEmail,
      inviteeType: invitation.inviteeType,
      status: withExpiry(invitation).status,
      expiresAt: invitation.expiresAt,
    });
  })
);
