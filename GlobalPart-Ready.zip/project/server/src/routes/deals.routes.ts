import { Router } from "express";
import multer from "multer";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { requireVerifiedEmail, requireActiveAccount, blockUnverifiedGovernment } from "../middleware/accountPolicy.js";
import { assertVerifiedPartner } from "../services/companyPolicy.service.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { dealRoomCreateSchema, messageCreateSchema, dealStageUpdateSchema } from "../utils/validation.js";
import { uploadFile, getFileUrl } from "../lib/storage.js";
import { getStripe, isBillingConfigured } from "../lib/stripe.js";

export const dealsRouter = Router();
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 } });

dealsRouter.use(requireAuth);
dealsRouter.use(blockUnverifiedGovernment);

dealsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const deals = await prisma.dealRoom.findMany({
      where: { OR: [{ buyerId: req.user!.id }, { sellerId: req.user!.id }] },
      include: { buyerCompany: true, sellerCompany: true, _count: { select: { messages: true, documents: true } } },
      orderBy: { updatedAt: "desc" },
    });
    res.json(deals);
  })
);

dealsRouter.post(
  "/",
  requireVerifiedEmail,
  requireActiveAccount,
  asyncHandler(async (req, res) => {
    const body = dealRoomCreateSchema.parse(req.body);

    // B2G/escrow lock: a Directory Listed (unclaimed) company on either
    // side of the deal cannot have an escrow contract executed against it.
    // Deals without a linked Company on one side (buyerCompanyId/
    // sellerCompanyId are optional -- see dealRoomCreateSchema) skip that
    // side's check, since there's nothing to verify yet.
    if (body.buyerCompanyId) await assertVerifiedPartner(body.buyerCompanyId, "execute an escrow contract");
    if (body.sellerCompanyId) await assertVerifiedPartner(body.sellerCompanyId, "execute an escrow contract");

    const deal = await prisma.dealRoom.create({
      data: {
        title: body.title,
        buyerId: req.user!.id,
        sellerId: body.sellerId,
        buyerCompanyId: body.buyerCompanyId,
        sellerCompanyId: body.sellerCompanyId,
        valueUsd: body.valueUsd,
      },
    });
    res.status(201).json(deal);
  })
);

async function assertParticipant(dealId: string, userId: string) {
  const deal = await prisma.dealRoom.findUnique({ where: { id: dealId } });
  if (!deal) throw new ApiError(404, "Deal room not found");
  if (deal.buyerId !== userId && deal.sellerId !== userId) {
    throw new ApiError(403, "Not a participant in this deal room");
  }
  return deal;
}

dealsRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    await assertParticipant(req.params.id, req.user!.id);
    const deal = await prisma.dealRoom.findUnique({
      where: { id: req.params.id },
      include: {
        buyerCompany: true,
        sellerCompany: true,
        documents: true,
        messages: { include: { sender: { select: { name: true } } }, orderBy: { createdAt: "asc" } },
      },
    });
    if (!deal) throw new ApiError(404, "Deal room not found");
    const documents = await Promise.all(deal.documents.map(async (d) => ({ ...d, url: await getFileUrl(d.storageKey) })));
    res.json({ ...deal, documents });
  })
);

dealsRouter.post(
  "/:id/messages",
  asyncHandler(async (req, res) => {
    await assertParticipant(req.params.id, req.user!.id);
    const body = messageCreateSchema.parse(req.body);
    const message = await prisma.message.create({
      data: { dealRoomId: req.params.id, senderId: req.user!.id, body: body.body },
    });
    res.status(201).json(message);
  })
);

dealsRouter.post(
  "/:id/documents",
  upload.single("file"),
  asyncHandler(async (req, res) => {
    await assertParticipant(req.params.id, req.user!.id);
    const file = req.file;
    if (!file) throw new ApiError(400, "No file uploaded");
    const stored = await uploadFile(file.buffer, file.originalname, file.mimetype);
    const document = await prisma.document.create({
      data: {
        userId: req.user!.id,
        dealRoomId: req.params.id,
        fileName: file.originalname,
        storageKey: stored.storageKey,
        mimeType: file.mimetype,
        sizeBytes: file.size,
      },
    });
    res.status(201).json(document);
  })
);

// Feature 2: platform success fee, in basis points (100 = 1%). See the
// DealFee model comment in schema.prisma for the legal boundary this
// respects — this is a fee for GlobalPart's own service, not a cut of
// escrowed trade funds we don't hold.
const DEAL_FEE_RATE_BPS = 100;

dealsRouter.patch(
  "/:id/stage",
  asyncHandler(async (req, res) => {
    const deal = await assertParticipant(req.params.id, req.user!.id);
    const { stage } = dealStageUpdateSchema.parse(req.body);

    const updated = await prisma.dealRoom.update({ where: { id: req.params.id }, data: { stage } });

    // Moving into COMPLETED for the first time on a priced deal creates the
    // platform fee record (idempotent — skip if one already exists for
    // this deal). The seller is billed by default, matching standard
    // marketplace convention of the fee coming out of proceeds.
    if (stage === "COMPLETED" && deal.stage !== "COMPLETED" && deal.valueUsd) {
      const existingFee = await prisma.dealFee.findFirst({ where: { dealRoomId: deal.id } });
      if (!existingFee) {
        const amountCents = Math.round(deal.valueUsd * 100 * (DEAL_FEE_RATE_BPS / 10_000));
        await prisma.dealFee.create({
          data: {
            dealRoomId: deal.id,
            amountCents,
            feeRateBps: DEAL_FEE_RATE_BPS,
            payerId: deal.sellerId,
            status: "pending",
          },
        });
      }
    }

    res.json(updated);
  })
);

dealsRouter.get(
  "/:id/fees",
  asyncHandler(async (req, res) => {
    await assertParticipant(req.params.id, req.user!.id);
    const fees = await prisma.dealFee.findMany({ where: { dealRoomId: req.params.id }, orderBy: { createdAt: "desc" } });
    res.json(fees);
  })
);

// Creates (or resumes) a Stripe Checkout session to pay a pending platform
// fee. Only the payer named on the fee record can pay it.
dealsRouter.post(
  "/:id/fees/:feeId/checkout",
  requireVerifiedEmail,
  asyncHandler(async (req, res) => {
    const deal = await assertParticipant(req.params.id, req.user!.id);
    const fee = await prisma.dealFee.findUnique({ where: { id: req.params.feeId } });
    if (!fee || fee.dealRoomId !== deal.id) throw new ApiError(404, "Fee not found");
    if (fee.payerId !== req.user!.id) throw new ApiError(403, "Only the payer can pay this fee");
    if (fee.status === "paid") throw new ApiError(409, "This fee has already been paid");
    if (!isBillingConfigured()) throw new ApiError(503, "Billing is not configured on this server yet");

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: fee.currency,
            unit_amount: fee.amountCents,
            product_data: {
              name: `GlobalPart deal fee — ${deal.title}`,
              description: `${(fee.feeRateBps / 100).toFixed(2)}% platform fee on a completed deal`,
            },
          },
          quantity: 1,
        },
      ],
      success_url: `${env.APP_URL}/deals/${deal.id}?fee=success`,
      cancel_url: `${env.APP_URL}/deals/${deal.id}?fee=cancelled`,
      metadata: { dealFeeId: fee.id, product: "DEAL_FEE" },
    });

    res.json({ url: session.url });
  })
);
