import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import {
  signAccessToken,
  generateRefreshTokenValue,
  generateOneTimeToken,
  signTwoFactorPendingToken,
  verifyTwoFactorPendingToken,
} from "../lib/jwt.js";
import { sendEmail, verificationEmailHtml, passwordResetEmailHtml } from "../lib/email.js";
import { issueOtp, verifyOtp } from "../lib/otp.js";
import { generateTwoFactorSecret, buildOtpAuthUrl, generateQrCodeDataUrl, verifyTotpCode } from "../lib/twoFactor.js";
import { isFreeEmailDomain, isSovereignDomain } from "../utils/domainPolicy.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { requireAuth } from "../middleware/auth.js";
import { authRateLimit } from "../middleware/rateLimit.js";
import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  otpRequestSchema,
  otpVerifySchema,
  twoFactorEnableSchema,
  twoFactorVerifyLoginSchema,
} from "../utils/validation.js";

export const authRouter = Router();

const REFRESH_COOKIE = "gp_refresh";

function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: "lax" as const,
    maxAge: env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000,
    path: "/api/auth",
  };
}

async function issueSession(userId: string) {
  const value = generateRefreshTokenValue();
  const expiresAt = new Date(Date.now() + env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000);
  await prisma.refreshToken.create({ data: { token: value, userId, expiresAt } });
  return value;
}

authRouter.post(
  "/register",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = registerSchema.parse(req.body);

    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) throw new ApiError(409, "An account with this email already exists");

    // --- Category-specific registration policy ---
    // 1. INDIVIDUAL: no domain restriction, frictionless.
    // 2. ENTERPRISE: must be a corporate domain, never a free consumer provider.
    // 3. GOVERNMENT: must match a recognized sovereign domain -- rejected
    //    outright otherwise, not just flagged, per the "restrict
    //    registration strictly" requirement.
    if (body.accountCategory === "ENTERPRISE" && isFreeEmailDomain(body.email)) {
      throw new ApiError(
        400,
        "Enterprise accounts require a corporate email address (e.g. name@yourcompany.com). Free consumer email providers (Gmail, Yahoo, Outlook, Hotmail, etc.) aren't accepted for this account type."
      );
    }
    if (body.accountCategory === "GOVERNMENT" && !(await isSovereignDomain(body.email))) {
      throw new ApiError(
        403,
        "Government/sovereign registration is restricted to approved governmental domains (e.g. .gov, .edu, or your country's registered sovereign domain). This email domain isn't on the approved list — contact platform administration if you believe this is an error."
      );
    }

    const accountStatus =
      body.accountCategory === "ENTERPRISE" ? "PENDING_KYB" : body.accountCategory === "GOVERNMENT" ? "PENDING_SOVEREIGN_APPROVAL" : "ACTIVE";

    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email,
        passwordHash,
        company: body.company,
        accountCategory: body.accountCategory,
        accountStatus,
      },
    });

    const token = generateOneTimeToken();
    await prisma.emailVerificationToken.create({
      data: { token, userId: user.id, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) },
    });
    await sendEmail({
      to: user.email,
      subject: "Verify your GlobalPart email",
      html: verificationEmailHtml(`${env.APP_URL}/verify-email?token=${token}`),
    });

    const userPayload = {
      id: user.id,
      name: user.name,
      email: user.email,
      company: user.company,
      role: user.role,
      emailVerified: user.emailVerified,
      accountCategory: user.accountCategory,
      accountStatus: user.accountStatus,
      twoFactorEnabled: user.twoFactorEnabled,
    };

    // GOVERNMENT: "100% block on session creation until verified" -- no
    // access/refresh token is issued at registration at all. Individuals
    // and Enterprises get immediate access (frictionless per requirement
    // 1; Enterprise/Sovereign access is separately capped by requireSovereignOrEnterpriseAccess
    // until email + 2FA are both done, so an immediate session here is
    // safe and matches "immediate email verification link activation"
    // rather than a full login block).
    if (body.accountCategory === "GOVERNMENT") {
      res.status(201).json({
        sessionIssued: false,
        message: "Registration received. Please verify your email to activate your account; it will then await Super Admin sovereign approval.",
        user: userPayload,
      });
      return;
    }

    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
    const refreshToken = await issueSession(user.id);
    res.cookie(REFRESH_COOKIE, refreshToken, refreshCookieOptions());

    res.status(201).json({ sessionIssued: true, accessToken, user: userPayload });
  })
);

authRouter.get(
  "/verify-email",
  asyncHandler(async (req, res) => {
    const token = String(req.query.token ?? "");
    const record = await prisma.emailVerificationToken.findUnique({ where: { token } });
    if (!record || record.expiresAt < new Date()) {
      throw new ApiError(400, "This verification link is invalid or has expired");
    }
    await prisma.user.update({ where: { id: record.userId }, data: { emailVerified: true } });
    await prisma.emailVerificationToken.delete({ where: { token } });
    res.json({ verified: true });
  })
);

authRouter.post(
  "/login",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = loginSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: body.email } });
    if (!user) throw new ApiError(401, "Invalid email or password");

    // Checked BEFORE the password comparison runs, so a locked account
    // can't be used to keep brute-forcing guesses during the lockout
    // window -- the lock itself is the thing that stops the attack, not
    // just a delayed error message after every guess.
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60_000);
      throw new ApiError(423, `Too many failed login attempts. This account is temporarily locked. Try again in ${minutesLeft} minute${minutesLeft === 1 ? "" : "s"}.`);
    }

    const valid = await bcrypt.compare(body.password, user.passwordHash);
    if (!valid) {
      const attempts = user.failedLoginAttempts + 1;
      const lockingNow = attempts >= 3;
      await prisma.user.update({
        where: { id: user.id },
        data: {
          failedLoginAttempts: lockingNow ? 0 : attempts,
          lockedUntil: lockingNow ? new Date(Date.now() + 15 * 60 * 1000) : null,
        },
      });
      if (lockingNow) {
        throw new ApiError(423, "Too many failed login attempts. This account is temporarily locked for 15 minutes.");
      }
      throw new ApiError(401, "Invalid email or password");
    }

    // Correct password -- clear any prior failed-attempt count.
    if (user.failedLoginAttempts > 0 || user.lockedUntil) {
      await prisma.user.update({ where: { id: user.id }, data: { failedLoginAttempts: 0, lockedUntil: null } });
    }

    // GOVERNMENT: instantaneous, mandatory email verification -- no
    // session, not even a 2FA step-up, until verified. This is the first
    // half of "completely blocked from any access until email
    // verification AND MFA are both completed" -- the second half (MFA)
    // is enforced by blockUnverifiedGovernment on every authenticated
    // Government-reachable route once a session does exist, since MFA
    // can only be set up after logging in once.
    if (user.accountCategory === "GOVERNMENT" && !user.emailVerified) {
      throw new ApiError(403, "Please verify your email before signing in. Check your inbox for the verification link sent at registration.");
    }

    // Step-up for any account with 2FA enabled: password is correct, but
    // no real session yet -- only a short-lived pending token that must be
    // exchanged via /2fa/verify-login with a valid TOTP code.
    if (user.twoFactorEnabled) {
      const pendingToken = signTwoFactorPendingToken(user.id);
      res.json({ twoFactorRequired: true, pendingToken });
      return;
    }

    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
    const refreshToken = await issueSession(user.id);
    res.cookie(REFRESH_COOKIE, refreshToken, refreshCookieOptions());

    res.json({
      twoFactorRequired: false,
      accessToken,
      user: {
        id: user.id, name: user.name, email: user.email, company: user.company, role: user.role,
        emailVerified: user.emailVerified, accountCategory: user.accountCategory, accountStatus: user.accountStatus,
        twoFactorEnabled: user.twoFactorEnabled,
      },
    });
  })
);

authRouter.post(
  "/2fa/verify-login",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = twoFactorVerifyLoginSchema.parse(req.body);
    let userId: string;
    try {
      userId = verifyTwoFactorPendingToken(body.pendingToken);
    } catch {
      throw new ApiError(401, "This login attempt has expired. Please sign in again.");
    }

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.twoFactorEnabled || !user.twoFactorSecret) {
      throw new ApiError(401, "This login attempt has expired. Please sign in again.");
    }
    if (!(await verifyTotpCode(user.twoFactorSecret, body.code))) {
      throw new ApiError(401, "Invalid authenticator code");
    }

    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
    const refreshToken = await issueSession(user.id);
    res.cookie(REFRESH_COOKIE, refreshToken, refreshCookieOptions());

    res.json({
      accessToken,
      user: {
        id: user.id, name: user.name, email: user.email, company: user.company, role: user.role,
        emailVerified: user.emailVerified, accountCategory: user.accountCategory, accountStatus: user.accountStatus,
        twoFactorEnabled: user.twoFactorEnabled,
      },
    });
  })
);

authRouter.post(
  "/refresh",
  asyncHandler(async (req, res) => {
    const token = req.cookies?.[REFRESH_COOKIE];
    if (!token) throw new ApiError(401, "No refresh session found");

    const record = await prisma.refreshToken.findUnique({ where: { token }, include: { user: true } });
    if (!record || record.revoked || record.expiresAt < new Date()) {
      throw new ApiError(401, "Refresh session expired — please log in again");
    }

    // Rotate: revoke the used token and issue a new one, so a leaked
    // refresh token can only be replayed once before detection.
    await prisma.refreshToken.update({ where: { id: record.id }, data: { revoked: true } });
    const newRefreshToken = await issueSession(record.userId);
    res.cookie(REFRESH_COOKIE, newRefreshToken, refreshCookieOptions());

    const accessToken = signAccessToken({ sub: record.user.id, role: record.user.role, email: record.user.email });
    res.json({ accessToken });
  })
);

authRouter.post(
  "/logout",
  asyncHandler(async (req, res) => {
    const token = req.cookies?.[REFRESH_COOKIE];
    if (token) {
      await prisma.refreshToken.updateMany({ where: { token }, data: { revoked: true } });
    }
    res.clearCookie(REFRESH_COOKIE, { path: "/api/auth" });
    res.status(204).end();
  })
);

authRouter.post(
  "/forgot-password",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = forgotPasswordSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: body.email } });

    // Always respond the same way whether or not the account exists, so
    // this endpoint can't be used to enumerate registered emails.
    if (user) {
      const token = generateOneTimeToken();
      await prisma.passwordResetToken.create({
        data: { token, userId: user.id, expiresAt: new Date(Date.now() + 60 * 60 * 1000) },
      });
      await sendEmail({
        to: user.email,
        subject: "Reset your GlobalPart password",
        html: passwordResetEmailHtml(`${env.APP_URL}/reset-password?token=${token}`),
      });
    }
    res.json({ message: "If that email is registered, a reset link has been sent." });
  })
);

authRouter.post(
  "/reset-password",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = resetPasswordSchema.parse(req.body);
    const record = await prisma.passwordResetToken.findUnique({ where: { token: body.token } });
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      throw new ApiError(400, "This reset link is invalid or has expired");
    }
    const passwordHash = await bcrypt.hash(body.password, 12);
    await prisma.$transaction([
      prisma.user.update({ where: { id: record.userId }, data: { passwordHash } }),
      prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      // Revoke all existing sessions on password reset for safety.
      prisma.refreshToken.updateMany({ where: { userId: record.userId }, data: { revoked: true } }),
    ]);
    res.json({ message: "Password updated. Please log in again." });
  })
);

authRouter.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, "User not found");
    res.json({
      id: user.id, name: user.name, email: user.email, company: user.company, role: user.role,
      emailVerified: user.emailVerified, accountCategory: user.accountCategory, accountStatus: user.accountStatus,
      twoFactorEnabled: user.twoFactorEnabled,
    });
  })
);

// ---- Sensitive-action OTP gate (Individuals + anyone else mid-checkout) ----

authRouter.post(
  "/otp/request",
  requireAuth,
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = otpRequestSchema.parse(req.body ?? {});
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, "User not found");
    await issueOtp(user.id, user.email, body.purpose);
    res.json({ sent: true });
  })
);

authRouter.post(
  "/otp/verify",
  requireAuth,
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = otpVerifySchema.parse(req.body);
    const ok = await verifyOtp(req.user!.id, body.purpose, body.code);
    if (!ok) throw new ApiError(400, "Invalid or expired code");
    // A correct OTP is proof of mailbox ownership -- same trust level as
    // clicking the registration link, so it satisfies emailVerified too.
    await prisma.user.update({ where: { id: req.user!.id }, data: { emailVerified: true } });
    res.json({ verified: true });
  })
);

// ---- Enterprise mandatory 2FA setup ----

authRouter.post(
  "/2fa/setup",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, "User not found");
    if (user.twoFactorEnabled) throw new ApiError(409, "Two-factor authentication is already enabled");

    // Secret is stored as soon as setup begins but twoFactorEnabled stays
    // false until /2fa/enable confirms possession with a valid code.
    const secret = generateTwoFactorSecret();
    await prisma.user.update({ where: { id: user.id }, data: { twoFactorSecret: secret } });

    const otpAuthUrl = buildOtpAuthUrl(user.email, secret);
    const qrCodeDataUrl = await generateQrCodeDataUrl(otpAuthUrl);
    res.json({ secret, otpAuthUrl, qrCodeDataUrl });
  })
);

authRouter.post(
  "/2fa/enable",
  requireAuth,
  asyncHandler(async (req, res) => {
    const body = twoFactorEnableSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user?.twoFactorSecret) throw new ApiError(400, "Start 2FA setup first with /api/auth/2fa/setup");

    if (!(await verifyTotpCode(user.twoFactorSecret, body.code))) {
      throw new ApiError(400, "Invalid code — check your authenticator app and try again");
    }
    await prisma.user.update({ where: { id: user.id }, data: { twoFactorEnabled: true } });
    res.json({ twoFactorEnabled: true });
  })
);

authRouter.post(
  "/2fa/disable",
  requireAuth,
  asyncHandler(async (req, res) => {
    await prisma.user.update({ where: { id: req.user!.id }, data: { twoFactorEnabled: false, twoFactorSecret: null } });
    res.json({ twoFactorEnabled: false });
  })
);
