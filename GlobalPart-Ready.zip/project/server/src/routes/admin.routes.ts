import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { sovereignDomainSchema } from "../utils/validation.js";

export const adminRouter = Router();
adminRouter.use(requireAuth, requireAdmin);

adminRouter.get(
  "/stats",
  asyncHandler(async (_req, res) => {
    const [userCount, companyCount, pendingKyb, activeDeals, subscriptions] = await Promise.all([
      prisma.user.count(),
      prisma.company.count(),
      prisma.kybSubmission.count({ where: { status: "PENDING" } }),
      prisma.dealRoom.count({ where: { stage: { notIn: ["COMPLETED", "CANCELLED"] } } }),
      prisma.subscription.groupBy({ by: ["tier"], _count: true }),
    ]);
    res.json({ userCount, companyCount, pendingKyb, activeDeals, subscriptions });
  })
);

adminRouter.get(
  "/users",
  asyncHandler(async (_req, res) => {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        emailVerified: true,
        accountCategory: true,
        accountStatus: true,
        twoFactorEnabled: true,
        createdAt: true,
        subscription: { select: { tier: true, status: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 200,
    });
    res.json(users);
  })
);

// ---- Government/sovereign approval queue (Super Admin) ----
// Note: this reuses the existing ADMIN role/requireAdmin gate. If a
// distinct "Super Admin" tier (separate from operational ADMIN staff) is
// needed later, add a dedicated Role.SUPER_ADMIN and swap requireAdmin for
// a requireSuperAdmin check on just this route -- kept as plain ADMIN here
// to avoid introducing a role split the rest of the app isn't ready for.

adminRouter.get(
  "/sovereign-approvals",
  asyncHandler(async (_req, res) => {
    const pending = await prisma.user.findMany({
      where: { accountCategory: "GOVERNMENT", accountStatus: "PENDING_SOVEREIGN_APPROVAL" },
      select: { id: true, name: true, email: true, company: true, emailVerified: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    });
    res.json(pending);
  })
);

adminRouter.post(
  "/sovereign-approvals/:id/approve",
  asyncHandler(async (req, res) => {
    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) throw new ApiError(404, "User not found");
    if (target.accountCategory !== "GOVERNMENT") throw new ApiError(400, "This account is not a government/sovereign account");
    if (!target.emailVerified) throw new ApiError(409, "This account has not verified its email yet");

    const updated = await prisma.user.update({
      where: { id: target.id },
      data: { accountStatus: "ACTIVE", sovereignApprovedAt: new Date(), sovereignApprovedById: req.user!.id },
    });
    res.json({ id: updated.id, accountStatus: updated.accountStatus, sovereignApprovedAt: updated.sovereignApprovedAt });
  })
);

adminRouter.post(
  "/sovereign-approvals/:id/reject",
  asyncHandler(async (req, res) => {
    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) throw new ApiError(404, "User not found");
    const updated = await prisma.user.update({ where: { id: target.id }, data: { accountStatus: "SUSPENDED" } });
    res.json({ id: updated.id, accountStatus: updated.accountStatus });
  })
);

// ---- Sovereign domain allowlist (extends the static defaults in domainPolicy.ts) ----

adminRouter.get(
  "/sovereign-domains",
  asyncHandler(async (_req, res) => {
    const domains = await prisma.sovereignDomain.findMany({ orderBy: { createdAt: "desc" } });
    res.json(domains);
  })
);

adminRouter.post(
  "/sovereign-domains",
  asyncHandler(async (req, res) => {
    const body = sovereignDomainSchema.parse(req.body);
    const domain = body.domain.trim().toLowerCase().replace(/^\.+/, "");
    const existing = await prisma.sovereignDomain.findUnique({ where: { domain } });
    if (existing) throw new ApiError(409, "This domain is already on the sovereign allowlist");

    const created = await prisma.sovereignDomain.create({
      data: { domain, label: body.label, addedById: req.user!.id },
    });
    res.status(201).json(created);
  })
);

adminRouter.delete(
  "/sovereign-domains/:id",
  asyncHandler(async (req, res) => {
    await prisma.sovereignDomain.delete({ where: { id: req.params.id } }).catch(() => {
      throw new ApiError(404, "Domain entry not found");
    });
    res.status(204).end();
  })
);

// ---- Admin audit log (every Approve/Reject/Review action) ----
// Filterable by entityType/action/adminId, sortable by createdAt -- matches
// what the "Audit log" tab in the admin console needs to render a
// sortable, filterable table without pulling the whole table client-side.
adminRouter.get(
  "/audit-log",
  asyncHandler(async (req, res) => {
    const { entityType, action, adminId, sort } = req.query as Record<string, string | undefined>;
    const events = await prisma.adminAuditEvent.findMany({
      where: {
        ...(entityType ? { entityType } : {}),
        ...(action ? { action } : {}),
        ...(adminId ? { adminId } : {}),
      },
      include: { admin: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: sort === "asc" ? "asc" : "desc" },
      take: 500,
    });
    res.json(events);
  })
);
