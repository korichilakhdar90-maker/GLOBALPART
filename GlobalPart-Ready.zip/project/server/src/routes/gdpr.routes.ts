import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { requireAuth, requireAdmin, optionalAuth } from "../middleware/auth.js";
import { consentSchema, erasureRequestSchema, erasureResolveSchema } from "../utils/validation.js";

export const gdprRouter = Router();

/**
 * Log one consent decision for one purpose (GDPR Art. 7 -- consent must be
 * as easy to withdraw as to give, and never bundled). Works for both
 * authenticated users and anonymous flows (e.g. the waitlist form), which
 * is why auth here is optional but an email is required when there's no
 * session -- otherwise a later erasure request has nothing to look up.
 */
gdprRouter.post(
  "/consent",
  optionalAuth,
  asyncHandler(async (req, res) => {
    const body = consentSchema.parse(req.body);
    if (!req.user && !body.email) {
      throw new ApiError(400, "email is required when not authenticated");
    }
    const record = await prisma.consentRecord.create({
      data: {
        userId: req.user?.id,
        email: body.email ?? req.user?.email,
        purpose: body.purpose,
        granted: body.granted,
        version: body.version,
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"]?.toString().slice(0, 300),
      },
    });
    res.status(201).json({ consent: record });
  })
);

/** The caller's own consent history -- what Article 30 calls "records of processing". */
gdprRouter.get(
  "/consent",
  requireAuth,
  asyncHandler(async (req, res) => {
    const records = await prisma.consentRecord.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: "desc" },
    });
    res.json({ consent: records });
  })
);

/**
 * Article 17 "right to erasure" -- opens a request rather than deleting
 * immediately, since a human still has to confirm no legally-required
 * records (tax/AML retention) block it. See ErasureRequest doc comment
 * in schema.prisma for what does and doesn't get purged.
 */
gdprRouter.post(
  "/erasure-request",
  requireAuth,
  asyncHandler(async (req, res) => {
    const body = erasureRequestSchema.parse(req.body);
    const existing = await prisma.erasureRequest.findFirst({
      where: { userId: req.user!.id, status: { in: ["PENDING", "IN_REVIEW"] } },
    });
    if (existing) throw new ApiError(409, "You already have an open erasure request");

    const request = await prisma.erasureRequest.create({
      data: { userId: req.user!.id, reason: body.reason },
    });
    res.status(201).json({ erasureRequest: request });
  })
);

gdprRouter.get(
  "/erasure-requests/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const requests = await prisma.erasureRequest.findMany({
      where: { userId: req.user!.id },
      orderBy: { requestedAt: "desc" },
    });
    res.json({ erasureRequests: requests });
  })
);

// ---- Admin: erasure request queue ----

gdprRouter.get(
  "/admin/erasure-requests",
  requireAuth,
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const requests = await prisma.erasureRequest.findMany({
      where: { status: { in: ["PENDING", "IN_REVIEW"] } },
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { requestedAt: "asc" },
    });
    res.json({ erasureRequests: requests });
  })
);

/**
 * Completing a request anonymizes the user in place rather than deleting
 * the row outright, so that rows with a legally-required retention window
 * (DealFee, TrustAssessment, PerformanceRecord) keep referential integrity
 * without keeping identifiable personal data attached to them.
 */
gdprRouter.post(
  "/admin/erasure-requests/:id/resolve",
  requireAuth,
  requireAdmin,
  asyncHandler(async (req, res) => {
    const body = erasureResolveSchema.parse(req.body);
    const request = await prisma.erasureRequest.findUnique({ where: { id: req.params.id } });
    if (!request) throw new ApiError(404, "Erasure request not found");
    if (request.status === "COMPLETED" || request.status === "REJECTED") {
      throw new ApiError(409, "This request has already been resolved");
    }

    if (body.action === "reject") {
      const updated = await prisma.erasureRequest.update({
        where: { id: request.id },
        data: { status: "REJECTED", resolvedAt: new Date(), resolvedById: req.user!.id, rejectionNote: body.rejectionNote },
      });
      res.json({ erasureRequest: updated });
      return;
    }

    await prisma.$transaction([
      prisma.user.update({
        where: { id: request.userId },
        data: {
          name: "Erased User",
          email: `erased-${request.userId}@erased.globalpart.eu`,
          passwordHash: "erased",
          company: null,
        },
      }),
      prisma.erasureRequest.update({
        where: { id: request.id },
        data: { status: "COMPLETED", resolvedAt: new Date(), resolvedById: req.user!.id },
      }),
    ]);

    const updated = await prisma.erasureRequest.findUnique({ where: { id: request.id } });
    res.json({ erasureRequest: updated });
  })
);
