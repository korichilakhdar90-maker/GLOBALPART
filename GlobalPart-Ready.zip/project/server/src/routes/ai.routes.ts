import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, optionalAuth } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/errorHandler.js";
import { chatSchema } from "../utils/validation.js";
import { chatWithAssistant, explainRecommendations, isAiConfigured } from "../lib/ai.js";
import { scoreCompanies } from "../services/recommendation.service.js";

export const aiRouter = Router();

aiRouter.get("/status", (_req, res) => {
  res.json({ configured: isAiConfigured() });
});

aiRouter.post(
  "/chat",
  optionalAuth,
  asyncHandler(async (req, res) => {
    const body = chatSchema.parse(req.body);
    const reply = await chatWithAssistant(body.messages);
    res.json({ reply });
  })
);

aiRouter.get(
  "/recommendations",
  requireAuth,
  asyncHandler(async (req, res) => {
    const favorites = await prisma.favorite.findMany({
      where: { userId: req.user!.id },
      include: { company: true },
    });

    // Derive the buyer's interests from what they've already favorited,
    // instead of requiring a separate preferences form.
    const preferredIndustries = [...new Set(favorites.map((f) => f.company.industry))];
    const preferredCountryCodes = [...new Set(favorites.map((f) => f.company.countryCode))];

    const candidates = await prisma.company.findMany({ take: 200, orderBy: { trustScore: "desc" } });
    const ranked = scoreCompanies(candidates, {
      preferredIndustries,
      preferredCountryCodes,
      excludeCompanyIds: favorites.map((f) => f.companyId),
    }).slice(0, 6);

    const explanation = await explainRecommendations({
      userIndustryInterests: preferredIndustries,
      userCountryInterests: preferredCountryCodes,
      candidateCompanies: ranked.map((r) => ({
        id: r.company.id,
        name: r.company.name,
        industry: r.company.industry,
        countryName: r.company.countryName,
        trustScore: r.company.trustScore,
        description: r.company.description,
      })),
    });

    res.json({
      explanation,
      recommendations: ranked.map((r) => ({ company: r.company, score: r.score, reasons: r.reasons })),
    });
  })
);
