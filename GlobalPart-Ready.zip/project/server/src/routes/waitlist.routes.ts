import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../middleware/errorHandler.js";
import { authRateLimit } from "../middleware/rateLimit.js";
import { waitlistSchema } from "../utils/validation.js";

// Public early-access capture. This is intentionally simple (no auth) since
// the whole point is to let an anonymous visitor register interest before
// GlobalPart has real onboarded users. Re-uses the auth rate limiter so it
// can't be used to spam the database.
export const waitlistRouter = Router();

waitlistRouter.post(
  "/",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = waitlistSchema.parse(req.body);

    const existing = await prisma.waitlistEntry.findUnique({ where: { email: body.email } });
    if (existing) {
      // Idempotent: re-submitting the same email is a success, not an error.
      res.status(200).json({ waitlisted: true, alreadyRegistered: true });
      return;
    }

    await prisma.waitlistEntry.create({
      data: {
        email: body.email,
        company: body.company,
        country: body.country,
        note: body.note,
      },
    });

    res.status(201).json({ waitlisted: true, alreadyRegistered: false });
  })
);

// Real, honest count — used by the frontend to show actual interest instead
// of a fabricated number. Returns 0 until real sign-ups exist.
waitlistRouter.get(
  "/count",
  asyncHandler(async (_req, res) => {
    const count = await prisma.waitlistEntry.count();
    res.json({ count });
  })
);
