import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";
import { tenantCreateSchema, tenantUpdateSchema } from "../utils/validation.js";
import { getStripe, isBillingConfigured, TENANT_LICENSE_PRICE_ID } from "../lib/stripe.js";
import { cached, cacheInvalidate } from "../lib/cache.js";

// Feature 3 — White-label licensing: chambers of commerce / industry
// associations license GlobalPart's platform under their own branding for
// an annual fee. This router covers three things: (a) a public, cached
// lookup so the frontend can re-skin itself for a given tenant slug
// (?partner=<slug>), (b) admin CRUD to onboard/manage licensees, and
// (c) a Stripe checkout for the annual license fee.
export const tenantsRouter = Router();

// Public — deliberately unauthenticated: this is read by the marketing
// site before any user is logged in, to render the right logo/name/color.
tenantsRouter.get(
  "/by-slug/:slug",
  asyncHandler(async (req, res) => {
    const slug = req.params.slug.toLowerCase();
    const tenant = await cached<{
      name: string;
      slug: string;
      logoUrl: string | null;
      primaryColor: string | null;
      licenseStatus: string;
    } | null>(`tenant:${slug}`, 300, () =>
      prisma.tenant.findUnique({
        where: { slug },
        select: { name: true, slug: true, logoUrl: true, primaryColor: true, licenseStatus: true },
      })
    );
    if (!tenant || tenant.licenseStatus !== "active") {
      throw new ApiError(404, "No active license found for this partner");
    }
    res.json(tenant);
  })
);

tenantsRouter.use(requireAuth, requireAdmin);

tenantsRouter.get(
  "/",
  asyncHandler(async (_req, res) => {
    const tenants = await prisma.tenant.findMany({ orderBy: { createdAt: "desc" } });
    res.json(tenants);
  })
);

tenantsRouter.post(
  "/",
  asyncHandler(async (req, res) => {
    const body = tenantCreateSchema.parse(req.body);
    const existing = await prisma.tenant.findUnique({ where: { slug: body.slug } });
    if (existing) throw new ApiError(409, "That slug is already in use");
    const tenant = await prisma.tenant.create({ data: body });
    cacheInvalidate(`tenant:${body.slug}`);
    res.status(201).json(tenant);
  })
);

tenantsRouter.patch(
  "/:id",
  asyncHandler(async (req, res) => {
    const body = tenantUpdateSchema.parse(req.body);
    const existing = await prisma.tenant.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new ApiError(404, "Tenant not found");
    const tenant = await prisma.tenant.update({ where: { id: req.params.id }, data: body });
    cacheInvalidate(`tenant:${existing.slug}`);
    if (body.slug && body.slug !== existing.slug) cacheInvalidate(`tenant:${body.slug}`);
    res.json(tenant);
  })
);

tenantsRouter.post(
  "/:id/checkout",
  asyncHandler(async (req, res) => {
    if (!isBillingConfigured()) throw new ApiError(503, "Billing is not configured on this server yet");
    if (!TENANT_LICENSE_PRICE_ID) throw new ApiError(400, "Tenant license price is not configured (STRIPE_PRICE_TENANT_LICENSE)");

    const tenant = await prisma.tenant.findUnique({ where: { id: req.params.id } });
    if (!tenant) throw new ApiError(404, "Tenant not found");

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer_email: tenant.contactEmail,
      line_items: [{ price: TENANT_LICENSE_PRICE_ID, quantity: 1 }],
      success_url: `${env.APP_URL}/admin?license=success`,
      cancel_url: `${env.APP_URL}/admin?license=cancelled`,
      metadata: { tenantId: tenant.id, product: "TENANT_LICENSE" },
    });

    res.json({ url: session.url });
  })
);
