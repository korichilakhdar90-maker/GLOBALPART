import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { blockUnverifiedGovernment } from "../middleware/accountPolicy.js";
import { asyncHandler, ApiError } from "../middleware/errorHandler.js";

export const notificationsRouter = Router();
notificationsRouter.use(requireAuth);
notificationsRouter.use(blockUnverifiedGovernment);

notificationsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const notifications = await prisma.notification.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    const unreadCount = await prisma.notification.count({ where: { userId: req.user!.id, read: false } });
    res.json({ notifications, unreadCount });
  })
);

notificationsRouter.post(
  "/:id/read",
  asyncHandler(async (req, res) => {
    const notification = await prisma.notification.findUnique({ where: { id: req.params.id } });
    if (!notification || notification.userId !== req.user!.id) throw new ApiError(404, "Notification not found");
    const updated = await prisma.notification.update({ where: { id: notification.id }, data: { read: true } });
    res.json(updated);
  })
);

notificationsRouter.post(
  "/read-all",
  asyncHandler(async (req, res) => {
    await prisma.notification.updateMany({ where: { userId: req.user!.id, read: false }, data: { read: true } });
    res.json({ ok: true });
  })
);
