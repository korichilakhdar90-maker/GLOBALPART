import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../middleware/errorHandler.js";
import { authRateLimit } from "../middleware/rateLimit.js";
import { feedbackSchema } from "../utils/validation.js";
import { notifyAdminsOfNewSubmission } from "../services/notification.service.js";

/**
 * Public early-tester feedback capture (pre-launch). No auth required --
 * matches waitlist.routes.ts's reasoning: a tester filling this in may not
 * have finished onboarding, or may be reporting a problem that's blocking
 * them from logging in at all.
 */
export const feedbackRouter = Router();

feedbackRouter.post(
  "/",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const body = feedbackSchema.parse(req.body);
    await prisma.feedbackEntry.create({
      data: { email: body.email, liked: body.liked, issues: body.issues, suggestions: body.suggestions },
    });

    // Reuses the same "notify all admins" helper as new KYB submissions --
    // early feedback during a pilot is exactly the kind of thing an admin
    // wants to see immediately, not discover days later.
    await notifyAdminsOfNewSubmission(`Feedback from ${body.email ?? "an anonymous tester"}`, "feedback").catch(() => {});

    res.status(201).json({ received: true });
  })
);
