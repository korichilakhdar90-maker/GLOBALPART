import { env } from "./config/env.js";
import { initMonitoring } from "./lib/monitoring.js";

initMonitoring();

import { createApp } from "./app.js";
import { prisma } from "./lib/prisma.js";

const app = createApp();

const server = app.listen(env.PORT, () => {
  console.log(`🚀 GlobalPart API listening on http://localhost:${env.PORT} (${env.NODE_ENV})`);
});

// Graceful shutdown: stop accepting new connections, let in-flight requests
// finish, then close the DB pool cleanly. Without this, a rolling deploy or
// container restart can cut off requests mid-flight and leak DB
// connections until they eventually time out.
async function shutdown(signal: string) {
  console.log(`\n${signal} received — shutting down gracefully…`);
  server.close(async () => {
    await prisma.$disconnect();
    console.log("✅ Server closed, DB connections released.");
    process.exit(0);
  });
  // Safety net: force-exit if something hangs longer than 10s.
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
