import { prisma } from "../lib/prisma.js";
import { sendEmail } from "../lib/email.js";
import { kybApprovedEmail, kybRejectedEmail, genericStatusEmail } from "../lib/email/templates.js";
import type { NotificationType } from "@prisma/client";

interface NotifyInput {
  userId: string;
  userEmail: string;
  type: NotificationType;
  title: string;
  body: string;
  kybSubmissionId?: string;
  /** Enables the branded approval/rejection templates; without it, falls back to the generic status layout. */
  companyName?: string;
  rejectionReason?: string;
  /** Recipient's preferred language; falls back to English (see emailStrings). */
  lang?: string | null;
}

/**
 * Single entry point for "something happened, tell the user" -- writes the
 * in-app Notification row (visible in their dashboard) AND sends the
 * matching email, together, so the two channels can never drift out of
 * sync (e.g. an email sent with no in-app record, or vice versa).
 */
export async function notifyUser(input: NotifyInput): Promise<void> {
  await prisma.notification.create({
    data: {
      userId: input.userId,
      type: input.type,
      title: input.title,
      body: input.body,
      kybSubmissionId: input.kybSubmissionId,
    },
  });

  // Approval/rejection get their own fully-branded templates (with a CTA
  // back into the app); anything else falls back to the generic branded
  // status layout rather than the bare <p> this used to send.
  let rendered;
  if (input.type === "KYB_APPROVED" && input.companyName) {
    rendered = kybApprovedEmail(input.companyName, input.lang);
  } else if (input.type === "KYB_REJECTED" && input.companyName) {
    rendered = kybRejectedEmail(input.companyName, input.rejectionReason ?? "", input.lang);
  } else {
    rendered = genericStatusEmail(input.title, input.body, input.lang);
  }

  await sendEmail({ to: input.userEmail, subject: rendered.subject, html: rendered.html });
}

/**
 * "New application submitted -- notify all admins" (in-app only; admins
 * don't need an email per submission, they have the queue). Deliberately
 * separate from notifyUser above since this fans out to many recipients
 * and never sends email.
 */
export async function notifyAdminsOfNewSubmission(companyName: string, submissionId: string): Promise<void> {
  const admins = await prisma.user.findMany({ where: { role: "ADMIN" }, select: { id: true } });
  if (admins.length === 0) return;
  await prisma.notification.createMany({
    data: admins.map((a) => ({
      userId: a.id,
      type: "KYB_SUBMITTED" as NotificationType,
      title: "New KYB submission",
      body: `${companyName} submitted a new KYB application awaiting review.`,
      kybSubmissionId: submissionId,
    })),
  });
}

/** Writes one append-only row to the admin audit trail. See AdminAuditEvent's doc comment in schema.prisma. */
export async function logAdminAction(input: {
  adminId: string;
  action: string;
  entityType: string;
  entityId: string;
  entityName?: string;
  notes?: string;
}): Promise<void> {
  await prisma.adminAuditEvent.create({ data: input });
}
