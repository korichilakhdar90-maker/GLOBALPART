import { env } from "../config/env.js";

export interface KybProviderResult {
  providerRef: string;
  raw: unknown;
  /** Provider's own risk/verification signal, if it returns one. */
  suggestedTrustScore?: number;
}

/**
 * Calls a real third-party business-verification provider (Middesk,
 * Trulioo, Dow Jones, etc.) when KYB_PROVIDER is configured. Each provider
 * has its own API shape — this function is the single integration point to
 * implement against your chosen provider's docs once you have an account
 * and API key.
 *
 * When no provider is configured (the default), this returns null and the
 * submission proceeds through human review only, which is a legitimate and
 * common KYB workflow for early-stage platforms — it's slower per-case but
 * requires no external contract to launch with.
 */
export async function runProviderVerification(input: {
  companyName: string;
  registrationNo: string;
  countries: string;
}): Promise<KybProviderResult | null> {
  if (env.KYB_PROVIDER === "none" || !env.KYB_PROVIDER_API_KEY) {
    return null;
  }

  if (env.KYB_PROVIDER === "middesk") {
    // Example shape only — replace with the real Middesk Business Verification
    // API request per https://docs.middesk.com once you have credentials.
    const res = await fetch("https://api.middesk.com/v1/businesses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.KYB_PROVIDER_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: input.companyName,
        tin: input.registrationNo,
      }),
    });
    if (!res.ok) throw new Error(`Middesk verification failed: ${res.status}`);
    const data = (await res.json()) as { id?: string; [key: string]: unknown };
    return { providerRef: data.id ?? "unknown", raw: data };
  }

  if (env.KYB_PROVIDER === "trulioo") {
    // Example shape only — replace with the real Trulioo GlobalGateway
    // request per https://developer.trulioo.com once you have credentials.
    const res = await fetch("https://api.globaldatacompany.com/business/verify", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.KYB_PROVIDER_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(input),
    });
    if (!res.ok) throw new Error(`Trulioo verification failed: ${res.status}`);
    const data = (await res.json()) as { transactionId?: string; [key: string]: unknown };
    return { providerRef: data.transactionId ?? "unknown", raw: data };
  }

  return null;
}
