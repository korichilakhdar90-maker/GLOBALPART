import { prisma } from "../lib/prisma.js";
import { ApiError } from "../middleware/errorHandler.js";

/**
 * The single enforcement point for "Directory Listed companies can appear
 * in search but cannot transact." Call this wherever a company is about to
 * take a transactional action: executing an escrow contract (DealRoom
 * creation, wired in deals.routes.ts), and -- once those endpoints exist --
 * submitting a B2G tender application or a bid. Keeping this in one place
 * means the rule can't drift between call sites the way copy-pasted
 * `if (company.profileStatus !== "VERIFIED_PARTNER")` checks eventually do.
 */
export async function assertVerifiedPartner(companyId: string, action: string): Promise<void> {
  const company = await prisma.company.findUnique({ where: { id: companyId }, select: { profileStatus: true, name: true } });
  if (!company) throw new ApiError(404, "Company not found");
  if (company.profileStatus !== "VERIFIED_PARTNER") {
    throw new ApiError(
      403,
      `${company.name} is a Directory Listed (unclaimed, unverified) profile and cannot ${action}. The profile owner must claim it and complete KYB verification first.`
    );
  }
}
