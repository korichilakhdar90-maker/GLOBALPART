import type { Company } from "@prisma/client";

export interface RecommendationWeights {
  industryMatch: number;
  countryMatch: number;
  regionMatch: number;
  trustScore: number;
}

const DEFAULT_WEIGHTS: RecommendationWeights = {
  industryMatch: 0.4,
  countryMatch: 0.25,
  regionMatch: 0.15,
  trustScore: 0.2,
};

export interface RecommendationInput {
  preferredIndustries: string[];
  preferredCountryCodes: string[];
  preferredRegions?: string[];
  excludeCompanyIds?: string[];
}

export interface ScoredCompany {
  company: Company;
  score: number; // 0-100
  reasons: string[];
}

/**
 * Deterministic, explainable recommendation scoring. Ranks companies by how
 * well they match a buyer's stated interests, weighted and normalized to a
 * 0-100 score — this replaces the old UI mock where "match %" was a random
 * number. AI (see lib/ai.ts explainRecommendations) is layered on top only
 * to phrase *why* the top matches were chosen, in natural language; it does
 * not decide the ranking itself, so results stay stable and auditable even
 * when the AI integration isn't configured.
 */
export function scoreCompanies(
  companies: Company[],
  input: RecommendationInput,
  weights: RecommendationWeights = DEFAULT_WEIGHTS
): ScoredCompany[] {
  const industries = new Set(input.preferredIndustries.map((s) => s.toLowerCase()));
  const countries = new Set(input.preferredCountryCodes.map((s) => s.toUpperCase()));
  const regions = new Set((input.preferredRegions ?? []).map((s) => s.toLowerCase()));
  const excluded = new Set(input.excludeCompanyIds ?? []);

  const results: ScoredCompany[] = [];

  for (const company of companies) {
    if (excluded.has(company.id)) continue;

    const reasons: string[] = [];
    let score = 0;

    if (industries.size === 0 || industries.has(company.industry.toLowerCase())) {
      score += weights.industryMatch * 100;
      if (industries.has(company.industry.toLowerCase())) reasons.push(`matches your ${company.industry} focus`);
    }

    if (countries.size === 0 || countries.has(company.countryCode.toUpperCase())) {
      score += weights.countryMatch * 100;
      if (countries.has(company.countryCode.toUpperCase())) reasons.push(`based in ${company.countryName}`);
    }

    if (regions.size === 0 || regions.has(company.region.toLowerCase())) {
      score += weights.regionMatch * 100;
    }

    // Trust score contributes proportionally (a 90/100 trust score
    // contributes 90% of its weight, not a flat bonus).
    score += weights.trustScore * company.trustScore;
    if (company.trustScore >= 90) reasons.push("exceptionally high Trust Score");
    else if (company.trustScore >= 80) reasons.push("strong Trust Score");

    results.push({ company, score: Math.round(Math.min(100, score)), reasons });
  }

  return results.sort((a, b) => b.score - a.score);
}
