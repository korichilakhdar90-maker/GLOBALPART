/**
 * 🛑 LIVE SYSTEM PLACEHOLDER — Replace with actual government API after
 * contract signing and legal approval.
 *
 * This module does NOT connect to any live government system (customs,
 * tax, health, or otherwise). It exists so the rest of the application has
 * a stable interface to call, and so the "ready for government submission"
 * status shown to applicants is backed by real code rather than a lie --
 * but the code itself only simulates a submission for testing purposes.
 *
 * Per the platform's legal operating principle: GLOBALPART collects,
 * validates, and formats data, and transmits it to a government system
 * ONLY when explicitly approved by that government entity through a real,
 * signed integration agreement. Until that agreement exists for a given
 * country/system, every function here is a no-op that records intent
 * without performing any external call.
 */

export interface SimulatedGatewaySubmission {
  simulated: true;
  submissionId: string;
  status: "READY_FOR_GOVERNMENT_SUBMISSION";
  message: string;
  requiresManualApproval: true;
  submittedAt: string;
}

/**
 * Called once a Government KybSubmission is fully approved. Does not send
 * anything anywhere -- generates a simulated confirmation record so the
 * admin console and applicant dashboard have something concrete to show,
 * exactly as the spec requires ("Generate a simulated submission
 * confirmation (for testing only)").
 */
export function simulateGovernmentSystemSubmission(kybSubmissionId: string): SimulatedGatewaySubmission {
  return {
    simulated: true,
    submissionId: `SIM-${kybSubmissionId}-${Date.now()}`,
    status: "READY_FOR_GOVERNMENT_SUBMISSION",
    message:
      "This is a simulated confirmation for testing only. No data has been transmitted to any government system. " +
      "Live submission requires a signed integration agreement with the relevant government entity and separate legal/security review.",
    requiresManualApproval: true,
    submittedAt: new Date().toISOString(),
  };
}
