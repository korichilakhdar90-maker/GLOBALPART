import { Prisma, type PrismaClient } from "@prisma/client";
import { prisma } from "../lib/prisma.js";
import { TRUST_SCORE_CATEGORIES } from "../lib/trustCategories.js";

/**
 * The Explainable Trust Score sync service.
 *
 * `Company.trustScore` is a denormalized cache — the fast-read column the
 * Companies directory sorts/filters on (search stays cheap: it never has to
 * join TrustAssessment/TrustScoreFactor). TrustAssessment is the durable,
 * versioned history that explains *why* the number is what it is.
 *
 * The rule this service exists to enforce: Company.trustScore is NEVER
 * written directly by anything else. The only way it changes is by first
 * writing a TrustAssessment (with its explaining factors), then copying
 * that assessment's score onto the Company row, in the same transaction.
 * If that rule gets violated somewhere else in the codebase, the "why did
 * our score change" answer stops being trustworthy.
 */

/** Any Prisma client capable of running queries — the top-level client, or an interactive `tx`. */
type Db = PrismaClient | Prisma.TransactionClient;

export interface TrustScoreFactorInput {
  /** Must match a key in TRUST_SCORE_CATEGORIES. */
  category: string;
  pointsAwarded: number;
  pointsPossible: number;
  explanation: string;
  evidenceItemId?: string | null;
}

export interface FinalizeTrustAssessmentInput {
  companyId: string;
  factors: TrustScoreFactorInput[];
  /** e.g. "kyb_approval" | "evidence_update" | "manual_review" | "dispute_resolution" */
  triggeredBy: string;
}

export interface FinalizeTrustAssessmentResult {
  assessmentId: string;
  score: number;
  previousScore: number | null;
}

/**
 * Computes the 0-100 score from category factors, weighted by
 * TRUST_SCORE_CATEGORIES. Each factor contributes
 * (pointsAwarded / pointsPossible) * categoryWeight. Exported so other
 * code (e.g. seed data) can derive a correct score without duplicating
 * this formula by hand.
 */
export function computeWeightedScore(factors: TrustScoreFactorInput[]): number {
  let totalBps = 0;
  for (const factor of factors) {
    const category = TRUST_SCORE_CATEGORIES.find((c) => c.key === factor.category);
    if (!category) {
      throw new Error(`Unknown trust score category "${factor.category}" — check TRUST_SCORE_CATEGORIES.`);
    }
    if (factor.pointsPossible <= 0) {
      throw new Error(`pointsPossible must be > 0 for category "${factor.category}".`);
    }
    if (factor.pointsAwarded < 0 || factor.pointsAwarded > factor.pointsPossible) {
      throw new Error(
        `pointsAwarded (${factor.pointsAwarded}) out of range [0, ${factor.pointsPossible}] for category "${factor.category}".`
      );
    }
    totalBps += (factor.pointsAwarded / factor.pointsPossible) * category.weightBps;
  }
  const score = Math.round(totalBps / 100);
  return Math.max(0, Math.min(100, score));
}

/**
 * Does the actual work of finalizing a Trust Assessment, against whatever
 * `Db` it's given. Not exported directly — callers use either
 * `finalizeTrustAssessment` (opens its own transaction) or
 * `finalizeTrustAssessmentInTx` (runs inside a transaction you already
 * hold), depending on whether this is the only write in the operation or
 * one step of a larger one (e.g. "approve KYB submission" + "sync score"
 * as a single atomic unit — see kyb.routes.ts).
 *
 * Concurrency: takes a Postgres row lock on the Company being scored
 * (`SELECT ... FOR UPDATE`) as its first statement, so two finalizations
 * for the *same* company serialize instead of racing to both mark
 * themselves "current" — while scoring for every other company proceeds
 * untouched. That's what keeps this from becoming a bottleneck as the
 * number of companies grows: it's a per-company lock, not a table- or
 * platform-wide one.
 *
 * (For an even stronger DB-level guarantee that only one TrustAssessment
 * per company can ever be `isCurrent`, add a partial unique index —
 * `CREATE UNIQUE INDEX ... ON "TrustAssessment"(companyId) WHERE
 * "isCurrent" = true` — as a follow-up migration. Prisma's schema language
 * can't express partial indexes directly, so that has to be raw SQL. Not
 * included here; flagging it as a deliberate next step, not adding it
 * silently to a migration you've already reviewed.)
 */
async function finalizeTrustAssessmentWith(
  db: Db,
  input: FinalizeTrustAssessmentInput
): Promise<FinalizeTrustAssessmentResult> {
  const { companyId, factors, triggeredBy } = input;

  if (factors.length === 0) {
    throw new Error("finalizeTrustAssessment requires at least one factor.");
  }

  const score = computeWeightedScore(factors);

  const locked = await db.$queryRaw<{ id: string }[]>(
    Prisma.sql`SELECT "id" FROM "Company" WHERE "id" = ${companyId} FOR UPDATE`
  );
  if (locked.length === 0) {
    throw new Error(`Company "${companyId}" not found.`);
  }

  const previous = await db.trustAssessment.findFirst({
    where: { companyId, isCurrent: true },
    select: { id: true, score: true },
  });

  if (previous) {
    await db.trustAssessment.update({
      where: { id: previous.id },
      data: { isCurrent: false },
    });
  }

  const assessment = await db.trustAssessment.create({
    data: {
      companyId,
      score,
      previousScore: previous?.score ?? null,
      isCurrent: true,
      triggeredBy,
      factors: {
        create: factors.map((f) => ({
          category: f.category,
          weightBps: TRUST_SCORE_CATEGORIES.find((c) => c.key === f.category)!.weightBps,
          pointsAwarded: f.pointsAwarded,
          pointsPossible: f.pointsPossible,
          explanation: f.explanation,
          evidenceItemId: f.evidenceItemId ?? null,
        })),
      },
    },
  });

  // The only write to Company.trustScore in the whole codebase should be
  // this one — always immediately after (never instead of) creating the
  // TrustAssessment that explains it.
  await db.company.update({
    where: { id: companyId },
    data: { trustScore: score },
  });

  return {
    assessmentId: assessment.id,
    score,
    previousScore: previous?.score ?? null,
  };
}

/**
 * Finalizes a new Trust Assessment for a company and syncs the result onto
 * Company.trustScore, atomically, in its own new transaction. Use this
 * when the assessment is the *only* write in the operation (e.g. a
 * standalone "recalculate this company's score" admin action).
 */
export async function finalizeTrustAssessment(
  input: FinalizeTrustAssessmentInput
): Promise<FinalizeTrustAssessmentResult> {
  return prisma.$transaction((tx) => finalizeTrustAssessmentWith(tx, input));
}

/**
 * Same as `finalizeTrustAssessment`, but runs against a transaction you
 * already hold — for operations where the assessment must succeed-or-fail
 * together with another write (e.g. approving a KybSubmission). Prisma
 * doesn't support nested `$transaction` calls, so this is the composable
 * building block: the caller opens the transaction and passes `tx` in.
 */
export async function finalizeTrustAssessmentInTx(
  tx: Prisma.TransactionClient,
  input: FinalizeTrustAssessmentInput
): Promise<FinalizeTrustAssessmentResult> {
  return finalizeTrustAssessmentWith(tx, input);
}

/**
 * KYB-approval trigger, mapped onto the "kyb_verification" category
 * (30% weight — see TRUST_SCORE_CATEGORIES) per the agreed scoring model:
 * KYB approval alone can now reach up to 30 points of the overall 100,
 * with registry/financials/certifications/past-project evidence
 * contributing the rest as it's added. This intentionally changes today's
 * behavior, where KYB approval alone could reach 100 — that's the
 * tradeoff of the new explainable, multi-category model.
 *
 * Composable the same way as the assessment functions above:
 * `syncFromKybApproval` opens its own transaction; `syncFromKybApprovalInTx`
 * runs inside one you already hold (see kyb.routes.ts, which needs the
 * KybSubmission update and this score sync to succeed or fail together).
 */
function kybApprovalFactors(params: {
  bankAccountVerified: boolean;
  physicalAddressConfirmed: boolean;
}): TrustScoreFactorInput[] {
  const bankPoints = params.bankAccountVerified ? 20 : 0;
  const addressPoints = params.physicalAddressConfirmed ? 20 : 0;
  return [
    {
      category: "kyb_verification",
      pointsAwarded: 60 + bankPoints + addressPoints,
      pointsPossible: 100,
      explanation:
        params.bankAccountVerified && params.physicalAddressConfirmed
          ? "KYB approved: registration/email/phone matched official records, bank account ownership verified, and physical address confirmed."
          : "KYB approved on documentation review; bank account and/or physical address not yet independently confirmed.",
    },
  ];
}

export async function syncFromKybApproval(params: {
  companyId: string;
  bankAccountVerified: boolean;
  physicalAddressConfirmed: boolean;
}): Promise<FinalizeTrustAssessmentResult> {
  return finalizeTrustAssessment({
    companyId: params.companyId,
    triggeredBy: "kyb_approval",
    factors: kybApprovalFactors(params),
  });
}

export async function syncFromKybApprovalInTx(
  tx: Prisma.TransactionClient,
  params: {
    companyId: string;
    bankAccountVerified: boolean;
    physicalAddressConfirmed: boolean;
  }
): Promise<FinalizeTrustAssessmentResult> {
  return finalizeTrustAssessmentInTx(tx, {
    companyId: params.companyId,
    triggeredBy: "kyb_approval",
    factors: kybApprovalFactors(params),
  });
}
