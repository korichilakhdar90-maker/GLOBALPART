# GlobalPart API Server

Real production backend for the GlobalPart platform: PostgreSQL (via Prisma), JWT auth with
refresh-token rotation, file storage, KYB workflow, Claude-powered AI, Stripe billing, and an
admin API.

## ⚠️ Before you start: a note on this codebase's origin

This server was written in a sandboxed environment with **no access to `binaries.prisma.sh`**,
so `npx prisma generate` could not be run or verified here. The Prisma schema and every route
were reviewed by hand for correctness, and all logic that doesn't depend on generated Prisma
types has a passing test suite (`npm test`). The moment you run `npm install && npx prisma
generate` on a machine with normal internet access, the remaining type errors (all of them
`unknown`/`any` propagation from the un-generated client) disappear — there is nothing to fix,
just to generate.

## 1. Local setup

```bash
cd server
cp .env.example .env        # then fill in real secrets — see below
npm install

# Start Postgres locally (or point DATABASE_URL at a hosted instance)
docker compose up -d postgres

npx prisma migrate dev --name init   # creates tables AND generates the client
npm run seed                         # loads the 108 demo companies + an admin account
npm run dev                          # http://localhost:4000
```

Generate strong secrets for `.env`:
```bash
openssl rand -hex 32   # run twice: once for JWT_ACCESS_SECRET, once for JWT_REFRESH_SECRET
```

## 2. Connect the frontend

In the frontend project root, create `.env`:
```
VITE_API_URL=http://localhost:4000
```
Restart `npm run dev` on the frontend. That's it — the app automatically switches from local
demo mode (localStorage) to calling this real API. **Leaving `VITE_API_URL` unset keeps the
frontend working exactly as before, with zero backend required** — useful for design previews
or quick demos.

## 3. What's real vs. what needs your own accounts

| Feature | Works out of the box | Needs you to configure |
|---|---|---|
| Auth (register/login/JWT/refresh) | ✅ (frontend fully wired: login, signup, logout) | — |
| Password reset / email verification | ✅ full UI + API (emails logged to console) | Real delivery: set `EMAIL_PROVIDER=resend` + `RESEND_API_KEY` |
| Companies directory (search/filter/paginate) | ✅ frontend fully wired to real API | — |
| Company detail pages | ✅ frontend fully wired | — |
| Favorites | ✅ frontend fully wired | — |
| KYB submission + human review queue | ✅ frontend fully wired, incl. real file upload | Automated verification: set `KYB_PROVIDER` + `KYB_PROVIDER_API_KEY` (see `src/services/kyb.service.ts`) |
| Deal rooms: list, view, documents, e-signature (as a stage update) | ✅ frontend wired | **Creating** a new deal room needs a counterparty-picker UI that doesn't exist yet (the "New" button explains this rather than faking it); **milestones** are still static demo data — there's no `Milestone` model in the schema yet |
| AI assistant chat | Fallback message only | Set `ANTHROPIC_API_KEY` — then real Claude replies power the chat widget, the Dashboard's AI recommendations, and Intelligence page's "Generate insight" button |
| AI partner recommendations (Dashboard) | ✅ frontend wired to real scoring engine | Better replies with `ANTHROPIC_API_KEY` set |
| Admin dashboard UI | ✅ new `/admin` page (stats, KYB review queue, users list) — visible only to `role: ADMIN` accounts | — |
| Subscription billing | Disabled (503) | Set `STRIPE_SECRET_KEY`, create Products/Prices in Stripe Dashboard, set `STRIPE_PRICE_PROFESSIONAL`/`STRIPE_PRICE_ENTERPRISE`, set `STRIPE_WEBHOOK_SECRET` |
| Error monitoring | Console only | Set `SENTRY_DSN` for real alerting |
| Escrow | **Not implemented** | This requires a licensed money-transmitter or a partnership with a licensed escrow provider — a legal/regulatory step, not a coding one. `DealRoom.escrowStatus` is a ledger field only; no money moves through this code. |
| SOC 2 / ISO 27001 | **Not implemented** | External audit process, unrelated to this codebase |
| Market intelligence data (sector trends, opportunity scores) | Demo dataset (no live source) | Real market data requires a paid trade-data/economic-indicator API — the "Generate insight" button on the Intelligence page does call real Claude for the write-up, but the underlying trend numbers are still illustrative until a real data feed is connected |

## 4. Deployment

- **Database**: any managed Postgres (Supabase, Railway, Neon, RDS). Run `npx prisma migrate deploy` against it once.
- **API server**: Railway, Render, Fly.io, or the included `Dockerfile` on any container host.
- **File storage**: switch `STORAGE_PROVIDER=s3` before going live — local disk storage does **not** survive most redeploys.
- Set `CORS_ORIGIN` and `APP_URL` to your real frontend domain.
- Point the frontend's `VITE_API_URL` at your deployed API URL.
- Configure the Stripe webhook endpoint (`/api/billing/webhook`) in the Stripe Dashboard once billing is enabled.

## 5. Admin access

The seed script creates an admin account (`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` in
`.env`, defaults to `admin@globalpart.io` / `ChangeMe123!`). **Change the password immediately**
in any non-local environment. Admin-only endpoints: `GET /api/admin/*`, `GET/PATCH /api/kyb`
(review queue).

## 6. Testing & CI

```bash
npm test          # all tests: recommendation engine (pure logic) + e2e API tests (needs DATABASE_URL)
npx vitest run tests/recommendation.test.ts   # just the pure-logic tests, no DB needed
npx tsc --noEmit  # type-check
```
`.github/workflows/ci.yml` runs both the frontend and this backend (with a real ephemeral
Postgres) on every push/PR, including the e2e API tests in `tests/e2e/`.

**Note on migrations**: this codebase was written in a sandbox without internet access to
Prisma's binary CDN, so no migration files could be generated/committed yet (see the warning
at the top of this file). CI currently uses `npx prisma db push` (syncs the schema directly,
no migration history) to unblock testing. The first time you run `npx prisma migrate dev
--name init` locally with real network access, commit the generated `prisma/migrations/`
folder, then switch the CI step to `npx prisma migrate deploy` for proper, reviewable
migration history in production.

## 7. API overview

All routes are prefixed `/api`. See `src/routes/*.ts` for full request/response shapes.

- `auth`: register, login, refresh, logout, verify-email, forgot/reset-password, me
- `companies`: list (search/filter/paginate/region/minTrust/verifiedOnly), get by id
- `favorites`: list, add, remove
- `kyb`: submit (multipart, with documents), mine, admin list/review
- `deals`: list, create, get, post message, upload document, update stage
- `ai`: chat, recommendations, status
- `billing`: checkout, webhook, status
- `admin`: stats, users

## 8. Frontend pages added in this pass

- `/forgot-password`, `/reset-password`, `/verify-email` — full auth flows, styled identically
  to the existing Dashboard sign-in card, only rendered when navigated to (no visual change to
  any existing page). A "Forgot your password?" link was added to the existing login form to
  reach the first one.
- `/admin` — stats, KYB review queue (approve/reject), users table. Only visible/accessible to
  accounts with `role: ADMIN`; a small "Admin" link appears in the header next to "Dashboard"
  for such accounts only.

## 9. Security hardening added in this pass

- Dedicated strict rate limit (10 requests / 15 min, keyed by IP+email) on `/auth/register`,
  `/auth/login`, `/auth/forgot-password`, `/auth/reset-password` — separate from the general
  300 req/15min API-wide limit in `app.ts`.
- Sentry integration (`src/lib/monitoring.ts`) — set `SENTRY_DSN` to get real alerting on 5xx
  errors instead of console-only logging. No-op (console-only) when unset.

## 10. Testing

```bash
npx vitest run tests/recommendation.test.ts   # pure-logic tests, no DB needed
npm test                                       # everything, including tests/e2e/ (needs DATABASE_URL)
```
`tests/e2e/api.test.ts` uses supertest against the real Express app + a live Postgres
connection: registration, duplicate-email rejection, login (correct/incorrect password),
protected-route auth checks, company search/pagination/404, and admin-role enforcement. These
could not be executed inside the sandbox this was built in (no DB connectivity there — see the
warning at the top of this file), but they run automatically in `.github/workflows/ci.yml`
against a real ephemeral Postgres service, and locally once you have `DATABASE_URL` set.
