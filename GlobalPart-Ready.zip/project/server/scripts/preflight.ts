/**
 * Pre-flight check: run this before starting the server in production
 * (or as a deploy-pipeline gate) to catch the kind of "works on my
 * machine, breaks in prod" issues that are otherwise only discovered when
 * a real user hits them. Exits non-zero if anything critical fails.
 *
 * Usage: npm run preflight
 */
import { execSync } from "child_process";
import { existsSync } from "fs";

interface CheckResult {
  name: string;
  ok: boolean;
  detail: string;
  critical: boolean; // non-critical failures warn but don't fail the whole run
}

const results: CheckResult[] = [];

function record(name: string, ok: boolean, detail: string, critical = true) {
  results.push({ name, ok, detail, critical });
}

async function checkEnvVars() {
  try {
    // env.ts's Zod schema throws on import if a required variable is
    // missing or malformed -- reuse it here instead of re-listing every
    // required var a second time in this script, where the two lists
    // could quietly drift apart.
    const { env } = await import("../src/config/env.js");
    record("Environment variables", true, `Loaded OK (NODE_ENV=${env.NODE_ENV})`);
    return env;
  } catch (err) {
    record("Environment variables", false, err instanceof Error ? err.message : String(err));
    return null;
  }
}

async function checkDatabase() {
  try {
    const { prisma } = await import("../src/lib/prisma.js");
    await prisma.$queryRaw`SELECT 1`;
    await prisma.$disconnect();
    record("Database connectivity", true, "Connected and responded to a test query");
  } catch (err) {
    record("Database connectivity", false, err instanceof Error ? err.message : String(err));
  }
}

function checkMigrationStatus() {
  try {
    const output = execSync("npx prisma migrate status", { encoding: "utf-8", stdio: "pipe" });
    const hasPending = /have not yet been applied|following migration/i.test(output);
    record(
      "Migration status",
      !hasPending,
      hasPending ? "Pending migrations detected -- run `npx prisma migrate deploy` before starting the server." : "Database schema is up to date with prisma/migrations/"
    );
  } catch (err) {
    // prisma migrate status exits non-zero if it can't reach the DB at
    // all (already reported by checkDatabase above) or if the migration
    // history and schema have drifted -- surface the raw message either way.
    record("Migration status", false, err instanceof Error ? err.message.split("\n").slice(0, 5).join(" ") : String(err));
  }
}

function checkEmailProvider(env: { EMAIL_PROVIDER: string; RESEND_API_KEY?: string } | null) {
  if (!env) return;
  if (env.EMAIL_PROVIDER === "console") {
    record(
      "Email delivery",
      true,
      "EMAIL_PROVIDER=console — verification/reset/notification emails are logged, not actually delivered. Fine for local dev, NOT fine for real users.",
      false // warns, doesn't fail preflight -- console mode is a valid (if limited) configuration
    );
  } else if (env.EMAIL_PROVIDER === "resend") {
    record(
      "Email delivery",
      !!env.RESEND_API_KEY,
      env.RESEND_API_KEY
        ? "EMAIL_PROVIDER=resend with a key present (key validity itself is only confirmed by an actual send — this check cannot verify that without sending real email)."
        : "EMAIL_PROVIDER=resend but RESEND_API_KEY is not set — emails will fail to send."
    );
  }
}

function checkBuildArtifacts() {
  const ok = existsSync("dist/index.js");
  record("Build artifacts", ok, ok ? "dist/index.js present" : "dist/index.js not found — run `npm run build` first", false);
}

async function main() {
  console.log("Running GlobalPart API pre-flight checks...\n");

  const env = await checkEnvVars();
  await checkDatabase();
  checkMigrationStatus();
  checkEmailProvider(env);
  checkBuildArtifacts();

  console.log("");
  let hasCriticalFailure = false;
  for (const r of results) {
    const icon = r.ok ? "✅" : r.critical ? "❌" : "⚠️ ";
    console.log(`${icon} ${r.name}: ${r.detail}`);
    if (!r.ok && r.critical) hasCriticalFailure = true;
  }

  console.log("");
  if (hasCriticalFailure) {
    console.error("Pre-flight FAILED — do not start the server in this state.");
    process.exit(1);
  }
  console.log("Pre-flight passed (warnings above, if any, are non-blocking but worth reading).");
}

main().catch((err) => {
  console.error("Pre-flight script crashed unexpectedly:", err);
  process.exit(1);
});
