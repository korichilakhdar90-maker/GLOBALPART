# Records of Processing Activities (ROPA) — Template

**Status: TEMPLATE. Not yet a completed, accurate register.** Article 30 GDPR
requires this register to reflect processing that actually happens. Do not
present this document to a regulator, auditor, or DPO as complete — every
`[TODO]` below needs a real, verified answer first, and rows should only be
marked "Live" once the corresponding processing is actually running in
production.

Controller: GlobalPart, [TODO: legal entity name once incorporated]
Contact: privacy@globalpart.eu (or current founder contact — see `About.tsx`)
DPO: [TODO — not yet designated. See README in this folder.]

## How to use this register

Add one row per distinct processing activity. A processing activity is
"live" only when there's a corresponding data flow actually running in the
app — cross-check against `server/prisma/schema.prisma` and the route that
writes the data, not against the roadmap.

| # | Processing activity | Data categories | Legal basis (Art. 6) | Purpose | Retention | Recipients / sub-processors | Cross-border transfer? | Status |
|---|---|---|---|---|---|---|---|---|
| 1 | Waitlist signup | Email, company name (optional), note (optional) | Consent | Contact about early access | [TODO — set a retention period] | [TODO — current hosting provider] | [TODO] | Live — see `WaitlistEntry` model, `waitlist.routes.ts` |
| 2 | Account registration | Name, email, password hash, company name | Contract (Art. 6(1)(b)) | Provide platform account | [TODO] | [TODO] | [TODO] | Live — see `User` model, `auth.routes.ts` |
| 3 | Consent logging | Purpose, granted/withdrawn, policy version, IP, user agent | Legal obligation (Art. 7(1) proof of consent) | Evidence of consent for audits | [TODO — likely retain for statute-of-limitations period] | [TODO] | [TODO] | Live — see `ConsentRecord` model, `gdpr.routes.ts` |
| 4 | Erasure requests | User ID, request reason, resolution notes | Legal obligation (Art. 17) | Process right-to-erasure requests | [TODO] | [TODO] | [TODO] | Live — see `ErasureRequest` model, `gdpr.routes.ts` |
| 5 | KYB verification | Company registration number, official email/phone, uploaded incorporation documents | Legitimate interest / contract | Verify business identity, compute trust score | [TODO] | [TODO — document storage vendor] | [TODO] | Live — see `KybSubmission`, `Document` models, `kyb.routes.ts` |
| 6 | Deal room documents & messages | Uploaded files, message content between parties | Contract | Enable transaction between two verified companies | [TODO] | [TODO] | [TODO] | Live — see `DealRoom`, `Message`, `Document` models |
| 7 | Escrow / deal fee payments | Payment metadata via Stripe (not raw card data) | Contract | Process platform fees | [TODO — align with Stripe's own retention] | Stripe (payment processor) | Yes — Stripe is a US company; needs an SCC/adequacy check | Live — see `DealFee`, `Subscription` models, `billing.routes.ts` |
| 8 | EUDI Wallet / eIDAS identity verification | Verified attributes via Verifiable Presentation (legal name, EORI, professional identity) | Legal obligation / consent | Strong identity assertion for onboarding | N/A | N/A | N/A | **Not built.** Planned only — see `docs/compliance/README.md`. Do not list as live until an actual OIDC4VP relying-party integration exists. |
| 9 | Infrastructure hosting (compute, database, object storage) | All of the above, at rest | N/A (processor, not a separate purpose) | Hosting | N/A | **[TODO — no vendor selected yet]** | **[TODO]** | **Not built.** No cloud provider is currently configured for this project. |

## Next steps before this register is real

1. Pick and contract with an actual hosting vendor, then fill in row 9 and
   the "Recipients / sub-processors" column everywhere else.
2. Set actual retention periods per row (a lawyer or DPO should sign off —
   this isn't a judgment call for the codebase to make silently).
3. Confirm Stripe's DPA/SCC status is still current before treating row 7 as
   compliant as-is.
4. Only mark row 8 as "Live" once `server/src/routes/` actually contains an
   OIDC4VP verifier — see the eIDAS section of `docs/compliance/README.md`.
