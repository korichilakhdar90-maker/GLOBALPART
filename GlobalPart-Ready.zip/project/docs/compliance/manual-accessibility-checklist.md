# Manual Accessibility Testing Checklist

## Why this document exists

Automated tooling has taken this interface as far as it can. The current
measured state is:

| Tool | Result |
|---|---|
| Lighthouse — Accessibility | 100 / 100 |
| Lighthouse — Best Practices | 100 / 100 |
| Lighthouse — Performance | 89–91 / 100 (see note) |

> **Note on the performance number:** measured repeatedly in a shared CI
> sandbox, the composite score lands at 89–91 with occasional outliers
> into the low 70s caused by CPU contention on the host, not by the
> application. The metrics that actually matter are stable across every
> run: **LCP 2.5–2.6s**, **CLS 0.007**, **TBT 180–260ms**. Re-measure on
> your own hardware before quoting a number publicly.
| axe-core (WCAG 2.1 A + AA) | 0 violations |

**Those numbers do not mean the interface is WCAG 2.1 AA compliant.**
Automated tools detect roughly 30–40% of WCAG success criteria. The
remaining 60–70% — whether a label is *meaningful*, whether focus order
is *logical*, whether an error message actually *tells you how to fix
it* — can only be judged by a person.

This was demonstrated concretely during development: Lighthouse scored
this site **100/100 on accessibility while a genuine colour-contrast
failure was present** (`--text-faint` at 4.07:1 against a 4.5:1
requirement). axe-core caught it; Lighthouse did not. Assume the same
gap exists for the criteria below.

---

## Part 1 — Keyboard-only navigation

Unplug your mouse or put it out of reach. Complete each flow using only
`Tab`, `Shift+Tab`, `Enter`, `Space`, `Esc`, and arrow keys.

- [ ] **Skip link** — Load the homepage, press `Tab` once. A "Skip to main
      content" link should appear at the top-left. Press `Enter`; focus
      should land inside `<main>`, past the navigation.
- [ ] **Focus is always visible** — At every single `Tab` stop, a gold
      outline should be clearly visible. If focus ever "disappears", note
      which element preceded it.
- [ ] **Header** — Reach and activate: language switcher, theme toggle,
      Smart Audit Assistant toggle, notification bell (when signed in),
      mobile menu button (narrow the window below 1024px first).
- [ ] **Dropdowns** — Open the language switcher with `Enter`. Can you
      reach every language? Does `Esc` close it? Does focus return to the
      button that opened it?
- [ ] **Cookie banner** — On first load (clear `localStorage` first), does
      focus move into the banner? Can you reach "Accept all", "Reject
      all", and "Customise" in a sensible order?
- [ ] **Modals** — Trigger the sensitive-action modal (attempt a gated
      action while unverified) and the 2FA setup modal.
      - [ ] Does focus move into the modal when it opens?
      - [ ] ⚠️ **Known gap:** focus is *not* currently trapped inside
            modals — `Tab` will eventually escape to the page behind.
            This is a WCAG 2.1 SC 2.4.3 concern and is listed under
            "Known gaps" below.
      - [ ] Does `Esc` close the modal?
      - [ ] Does focus return to the triggering element on close?
- [ ] **Government wizard** (`/apply/government/wizard`) — Complete all
      six steps by keyboard alone, including file inputs and the dynamic
      "add personnel" section.
- [ ] **Admin console** — Reach and operate the search box, tier filter,
      status filter, and the Approve / Reject / Review buttons.
- [ ] **No keyboard traps** — At no point should you be unable to `Tab`
      away from an element.

---

## Part 2 — Screen reader

Test with at least one of: **NVDA + Firefox** (Windows), **VoiceOver +
Safari** (macOS), or **TalkBack + Chrome** (Android). NVDA + Firefox is
the most common real-world combination for European public-sector users.

### Landmarks and structure
- [ ] Pull up the landmarks list (NVDA: `D` to cycle; VoiceOver:
      `VO+U` → Landmarks). Are `banner`/header, `navigation`, `main`, and
      `contentinfo`/footer all announced?
- [ ] Pull up the headings list (NVDA: `H`; VoiceOver: `VO+U` → Headings).
      - [ ] Is there exactly **one** `<h1>` per page?
      - [ ] Do heading levels descend without skipping (h1 → h2 → h3)?
- [ ] Does the page `<title>` change meaningfully on navigation between
      routes?

### Announcements
- [ ] **Toasts** — Trigger a success toast (save a setting) and an error
      toast (submit an invalid form). Is the message read aloud without
      you having to hunt for it? *(The toast host is marked
      `role="status" aria-live="polite"`.)*
- [ ] **Route changes** — After navigating, is it clear that the page
      changed? ⚠️ **Known gap:** there is currently no route-change
      announcement region — see "Known gaps".
- [ ] **Loading states** — When a list is loading, is that communicated,
      or is there just silence?

### Controls
- [ ] **Icon-only buttons** — Every one should announce a meaningful
      purpose, not "button" or "graphic". Specifically check: notification
      bell, theme toggle, mobile menu, modal close buttons, copy-link and
      revoke buttons on `/invite-partners`.
- [ ] **State-dependent labels** — The menu button should announce
      "Open menu" vs "Close menu" and expose expanded/collapsed state.
      The theme toggle should announce "Switch to light/dark mode".
- [ ] **Form fields** — Every input, select, and textarea should announce
      its label. Check the KYB form, the Government wizard, the invitation
      form, and the admin filters.
- [ ] **Required fields and errors** — When validation fails, is the error
      announced, and is it associated with the right field?
      ⚠️ Likely gap — form errors currently surface as toasts rather than
      being tied to fields with `aria-describedby` / `aria-invalid`.
- [ ] **Consent switches** — On `/consent-settings`, the toggles use
      `role="switch"` with `aria-checked`. Is on/off state announced, and
      does it update when toggled?

### Content
- [ ] **Images** — The logo should announce as "GlobalPart", not a
      filename. The EU flag emoji in the hero and footer badge is marked
      `aria-hidden` (decorative) — confirm it isn't read as "flag of
      European Union" mid-sentence.
- [ ] **Tables** — On `/invite-partners` and the admin audit log, are
      column headers announced when moving between cells?
- [ ] **Links** — Does every link make sense out of context? No bare
      "click here" / "read more" without surrounding context.

---

## Part 3 — Reduced motion

- [ ] Enable the OS setting:
      - **Windows:** Settings → Accessibility → Visual effects → Animation effects **off**
      - **macOS:** System Settings → Accessibility → Display → **Reduce motion**
      - **Chrome DevTools:** Rendering panel → Emulate CSS `prefers-reduced-motion: reduce`
- [ ] Reload. Confirm: no fade/slide-in on scroll, no floating/pulsing
      decorative elements, no hover lift on cards and buttons.
- [ ] Confirm loading spinners **still spin** — these are deliberately
      exempt, because a frozen spinner makes "is this still working?"
      harder to judge, not easier.
- [ ] Confirm content is still fully visible and usable (elements that
      animate *in* must not stay invisible).

---

## Part 4 — Zoom and reflow (WCAG 2.1 SC 1.4.10)

- [ ] Zoom the browser to **200%**. Is all content still readable and
      reachable, with no horizontal scrolling?
- [ ] Zoom to **400%** at 1280px wide (equivalent to a 320px viewport).
      Content must reflow to a single column without loss of function.
- [ ] Increase text size only (Firefox: View → Zoom → Zoom Text Only) to
      200%. Does any text get clipped or overlap?

---

## Previously-identified gaps — now CLOSED

These were listed as open in the earlier revision of this document and
have since been implemented. **They still need human verification** —
that they exist in code is not proof that they behave correctly with real
assistive technology, which is the entire point of this checklist.

1. ✅ **Focus trap in dialogs** — `react-focus-lock` now wraps
   `SensitiveActionGateModal` and `TwoFactorSetupModal`, with
   `returnFocus` restoring focus to the triggering element on close.
   *Verify:* Part 1, "Modals".
2. ✅ **Route-change announcement** — `RouteAnnouncer` renders a
   visually-hidden `aria-live="polite"` region that announces the new
   page title on every navigation. *Verify:* Part 2, "Announcements".
3. ✅ **Form errors tied to fields — now across all four major forms.**
   Each renders a shared `<FormError>` (`role="alert"`) *in addition to*
   the toast, never instead of it:
   - **Sign-in / sign-up** — `aria-invalid` + `aria-describedby` on the
     email and password inputs (field-level).
   - **Invite Partners** — `aria-invalid` + `aria-describedby` on the
     email input (field-level).
   - **KYB** — step-level, linked to the review step's `role="group"`.
   - **Government wizard** — step-level, linked to the current step's
     `role="group"`.

   KYB and the wizard are deliberately step-level rather than field-level:
   their failures are cross-field ("provide an FSC reference **or** a
   justification file") or server-side, so there is no single input that
   is "the" invalid one. Flagging an arbitrary field would be misleading
   to a screen-reader user, not helpful.
   *Verify:* Part 2, "Required fields and errors".
4. ✅ **Esc closes dialogs** — shared `useEscapeKey` hook, registered in
   the capture phase so it fires even when focus is inside a text input.
   *Verify:* Part 1, "Modals".
5. ✅ **Accessibility strings translated** — all 34 `a11y.*`, `cookies.*`,
   and `consentSettings.*` keys are now present in all 9 active languages
   (verified at parity), not just English.

---

## Remaining known gaps

1. **Error messages have not been observed firing with a real screen
   reader.** The code paths exist and are typechecked, but the KYB form,
   the Government wizard, and the invitation form are all backend-gated,
   so their error states could not be triggered in the offline sandbox
   where this was built. **This is the single most important thing to
   verify manually** — see Part 2, "Required fields and errors".
2. **Dropdowns (language switcher, notification bell) are not focus-
   trapped.** They close on outside click and now on Esc, but `Tab` moves
   focus past them rather than cycling within. This is acceptable for
   non-modal popups under WCAG, but should be confirmed against real AT
   behaviour rather than assumed.
3. **No testing against real assistive technology has been performed.**
   This remains the single largest unknown. Everything above is verified
   by automated tooling and code review only.

---

## Reporting

For each failure found, record: the page URL, the exact steps, what the
screen reader announced versus what it should have announced, and the
browser + AT version. That detail is what makes an issue fixable.
