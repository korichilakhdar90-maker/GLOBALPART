# Data Processing Agreement (DPA) Rider — Template

**Status: TEMPLATE / DRAFT. Unsigned, non-binding, and not yet attached to
any actual vendor relationship.** This is a starting point for a real DPA to
be reviewed by a qualified lawyer and countersigned by whichever
infrastructure vendor GlobalPart actually selects. As of this writing,
**no such vendor has been contracted** — see `docs/compliance/README.md`.

---

## Data Processing Agreement

**Between:**
Controller: GlobalPart, [TODO: legal entity name, registered address —
pending incorporation]

**And:**
Processor: [TODO: vendor legal name — e.g. "Scaleway SAS" only once an
actual account and contract exist; do not name a vendor here speculatively]

### 1. Subject matter and duration

The Processor shall process personal data on behalf of the Controller
solely to provide [TODO: describe the actual services contracted — e.g.
"compute hosting, managed PostgreSQL database, and object storage"], for the
duration of the underlying services agreement between the parties.

### 2. Nature and purpose of processing

Processing is limited to what is necessary to operate the GlobalPart
platform as described in the Records of Processing Activities register
(`docs/compliance/ropa-template.md`). The Processor has no independent right
to use, sell, or repurpose the data.

### 3. Categories of data subjects and personal data

As enumerated in the ROPA (see `ropa-template.md` in this folder) — at
minimum: platform users (name, email, company), and where applicable,
company representatives named in KYB submissions.

### 4. Location of processing

All processing and storage shall occur strictly within European Union /
European Economic Area data centers ([TODO: name the specific region(s)
once a vendor and region are actually selected — e.g. "Paris, France" or
"Frankfurt, Germany"]). No transfer outside the EEA is permitted without a
valid transfer mechanism (adequacy decision or Standard Contractual Clauses)
and prior written notice to the Controller.

### 5. Security measures (Art. 32)

The Processor shall implement and maintain technical and organizational
measures appropriate to the risk, including at minimum:
- Encryption at rest (AES-256 or equivalent) and in transit (TLS 1.2+).
- Role-based access control and logging of administrative access.
- Regular vulnerability management and, where applicable, independent
  penetration testing.

[TODO: replace with the Processor's actual published security
documentation once a vendor is selected, rather than assuming these
defaults apply.]

### 6. Sub-processors

The Processor shall not engage a new sub-processor without providing prior
notice to the Controller and maintaining data protection obligations on that
sub-processor equivalent to those in this DPA. [TODO: attach the
Processor's current sub-processor list as an appendix once known.]

### 7. Assistance with data subject rights

The Processor shall assist the Controller, insofar as reasonably possible,
in responding to data subject requests under GDPR Articles 15–22 (access,
rectification, erasure, portability, objection), consistent with the
`ErasureRequest` workflow implemented in `server/src/routes/gdpr.routes.ts`.

### 8. Breach notification

The Processor shall notify the Controller without undue delay, and in any
event within [TODO: agree a number — commonly 24–48 hours] of becoming
aware of a personal data breach affecting Controller data, to allow the
Controller to meet its own 72-hour notification obligation to the competent
supervisory authority.

### 9. Deletion or return of data

Upon termination of the underlying services agreement, the Processor shall,
at the Controller's choice, delete or return all personal data, and delete
existing copies, unless EU or Member State law requires storage.

### 10. Audit rights

The Controller (or an appointed auditor) may audit the Processor's
compliance with this DPA on reasonable notice, [TODO: agree frequency/terms
— commonly annually, or upon reasonable suspicion of non-compliance].

---

**Signature block — do not use until both parties are real and have
actually agreed to these terms.**

Controller: ______________________  Date: __________
Processor: ______________________  Date: __________
