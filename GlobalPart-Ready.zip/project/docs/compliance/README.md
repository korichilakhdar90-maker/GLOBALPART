# Compliance planning documents

**These are internal planning templates, not statements of GlobalPart's current
state.** Nothing in this folder should be published to the public site, sent
to a regulator, or signed as-is.

GlobalPart today is a pre-launch, single-founder, pre-revenue product (see
`src/pages/About.tsx` and `src/pages/Privacy.tsx` for what's actually true
right now, and `src/pages/Roadmap.tsx` for the honest current-vs-planned
split). None of the following exist yet:

- A production EU cloud deployment (Scaleway, T Cloud, or otherwise) — the
  app currently has no hosting provider configured.
- An EUDI Wallet / eIDAS 2.0 integration.
- A signed Data Processing Agreement with any infrastructure vendor.
- A designated Data Protection Officer.

## What's in this folder

| File | Purpose | Fill in before it's real |
|---|---|---|
| `ropa-template.md` | Article 30 Records of Processing Activities — a register of what data is (or will be) collected, why, and for how long. | Actual retention periods, legal basis per processing activity, sub-processor list once one is chosen. |
| `dpa-template.md` | Data Processing Agreement rider template for whichever cloud/infrastructure vendor is ultimately selected. | Vendor legal name, signature block, DPA is only valid once countersigned by that vendor. |

## What ships in the actual application

The application-layer GDPR building blocks these documents describe already
exist in code and are real, working infrastructure — not claims:

- `server/prisma/schema.prisma` — `ConsentRecord` (Art. 7, one row per
  purpose) and `ErasureRequest` (Art. 17 request queue).
- `server/src/routes/gdpr.routes.ts` — `/api/gdpr/consent` and
  `/api/gdpr/erasure-request` endpoints.

Those are genuinely there today. The documents in this folder describe the
policies and vendor relationships that should exist *around* that code
before GlobalPart can accurately claim GDPR compliance to a user or
regulator — which is a business and legal step, not a coding one.
